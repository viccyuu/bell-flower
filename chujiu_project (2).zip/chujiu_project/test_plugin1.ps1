# 插件一完整测试脚本
# 使用方法：.\test_plugin1.ps1

$ErrorActionPreference = "Stop"
$baseUrl = "http://localhost:5000"
$testFile = "C:\Users\yoyo\.openclaw\workspace\chujiu_design\vba2js3 -chujiu .xlsm"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  插件一测试：Excel VBA -> WPS JS" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 检查文件是否存在
if (-not (Test-Path $testFile)) {
    Write-Host "ERROR: 测试文件不存在：$testFile" -ForegroundColor Red
    exit 1
}

Write-Host "[1/5] 上传文件..." -ForegroundColor Yellow
try {
    $upload = Invoke-RestMethod -Uri "$baseUrl/api/uploads" -Method Post `
      -Form @{file=Get-Item $testFile; pluginCode="excel_vba_to_wps_js"}
    $uploadId = $upload.data.uploadId
    Write-Host "      ✓ Upload ID: $uploadId" -ForegroundColor Green
    Write-Host "      ✓ 文件名：$($upload.data.fileName)" -ForegroundColor Green
} catch {
    Write-Host "      ✗ 上传失败：$($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "[2/5] 创建 TaskRun..." -ForegroundColor Yellow
try {
    $task = Invoke-RestMethod -Uri "$baseUrl/api/task-runs" -Method Post `
      -ContentType "application/json" `
      -Body (@{taskTemplateCode="excel_vba_to_wps_js"; uploadId=$uploadId} | ConvertTo-Json)
    $taskRunId = $task.data.taskRunId
    Write-Host "      ✓ TaskRun ID: $taskRunId" -ForegroundColor Green
    Write-Host "      ✓ 状态：$($task.data.status)" -ForegroundColor Green
} catch {
    Write-Host "      ✗ 创建失败：$($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "[3/5] 启动 TaskRun..." -ForegroundColor Yellow
try {
    $start = Invoke-RestMethod -Uri "$baseUrl/api/task-runs/$taskRunId/start" -Method Post
    Write-Host "      ✓ 状态：$($start.data.status)" -ForegroundColor Green
} catch {
    Write-Host "      ✗ 启动失败：$($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "[4/5] 查询进度..." -ForegroundColor Yellow
$maxWait = 300  # 最多等待 5 分钟
$elapsed = 0
do {
    Start-Sleep -Seconds 2
    $elapsed += 2
    $status = Invoke-RestMethod -Uri "$baseUrl/api/task-runs/$taskRunId"
    $progress = $status.data.progress
    $currentStatus = $status.data.status
    Write-Host "      进度：$progress%, 状态：$currentStatus, 耗时：${elapsed}s" -ForegroundColor Cyan
    
    if ($elapsed -gt $maxWait) {
        Write-Host "      ✗ 超时 (${maxWait}s)" -ForegroundColor Red
        exit 1
    }
} while ($currentStatus -eq "RUNNING")

Write-Host ""
Write-Host "[5/5] 完成!" -ForegroundColor Yellow
Write-Host "      ✓ 最终状态：$($status.data.status)" -ForegroundColor Green
if ($status.data.finishedAt) {
    Write-Host "      ✓ 完成时间：$($status.data.finishedAt)" -ForegroundColor Green
}

# 检查是否成功
if ($status.data.status -eq "SUCCESS") {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "  测试通过！✓" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
} else {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Red
    Write-Host "  测试失败：$($status.data.status)" -ForegroundColor Red
    Write-Host "========================================" -ForegroundColor Red
    exit 1
}
