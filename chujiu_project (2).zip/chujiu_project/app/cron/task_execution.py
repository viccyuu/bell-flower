# -*- coding: utf-8 -*-
"""
任务执行能力

从 celery_tasks.py 迁移过来
"""
import logging
from typing import Dict, Any
from app.extensions import db
from app.models import TaskRun, JobRun, NodeRun
from app.todolist.node_status_updater import update_node_status
from app.todolist.node_executors import get_executor
from app.todolist.task_context import TaskExecutionContext

logger = logging.getLogger(__name__)


class TaskExecutionService:
    """任务执行服务"""
    
    def execute_task_run(self, task_run_id: int) -> Dict[str, Any]:
        """
        执行 TaskRun
        
        Args:
            task_run_id: TaskRun ID
        
        Returns:
            执行结果
        """
        logger.info(f"Executing TaskRun {task_run_id}")
        
        # 获取任务
        task_run = TaskRun.query.get(task_run_id)
        if not task_run:
            return {'success': False, 'error': f'TaskRun not found: {task_run_id}'}
        
        # 执行关联的 Job
        job_results = []
        for job_run in task_run.job_runs:
            result = self.execute_job_run(job_run.id)
            job_results.append(result)
        
        return {
            'success': all(r['success'] for r in job_results),
            'task_run_id': task_run_id,
            'job_results': job_results
        }
    
    def execute_job_run(self, job_run_id: int) -> Dict[str, Any]:
        """
        执行 JobRun
        
        Args:
            job_run_id: JobRun ID
        
        Returns:
            执行结果
        """
        logger.info(f"Executing JobRun {job_run_id}")
        
        # 获取 Job
        job_run = JobRun.query.get(job_run_id)
        if not job_run:
            return {'success': False, 'error': f'JobRun not found: {job_run_id}'}
        
        # 执行关联的 Node
        node_results = []
        for node_run in job_run.node_runs:
            result = self.execute_node_run(node_run.id)
            node_results.append(result)
        
        return {
            'success': all(r['success'] for r in node_results),
            'job_run_id': job_run_id,
            'node_results': node_results
        }
    
    def execute_node_run(self, node_run_id: int) -> Dict[str, Any]:
        """
        执行 NodeRun
        
        Args:
            node_run_id: NodeRun ID
        
        Returns:
            执行结果
        """
        logger.info(f"Executing NodeRun {node_run_id}")
        
        # 获取节点
        node_run = NodeRun.query.get(node_run_id)
        if not node_run:
            return {'success': False, 'error': f'NodeRun not found: {node_run_id}'}
        
        # 更新节点状态为 RUNNING
        update_node_status(
            node_code=node_run.code,
            job_run_id=node_run.job_run_id,
            status='RUNNING'
        )
        
        # 创建执行上下文
        context = TaskExecutionContext(
            file_id=node_run.job_run.task_run.upload_file_id if node_run.job_run.task_run.upload_file_id else 1,
            macro_id=1
        )
        context.task_run_id = node_run.job_run.task_run_id
        context.job_run_id = node_run.job_run_id
        context.node_run_id = node_run_id
        
        # 获取执行器
        executor = get_executor(node_run.node_type)
        if not executor:
            error_msg = f"Unknown node type: {node_run.node_type}"
            logger.error(error_msg)
            update_node_status(
                node_code=node_run.code,
                job_run_id=node_run.job_run_id,
                status='FAILED',
                error_json=error_msg
            )
            return {'success': False, 'error': error_msg}
        
        # 执行节点
        result = executor.execute(context, node_run)
        
        if result.get('success'):
            update_node_status(
                node_code=node_run.code,
                job_run_id=node_run.job_run_id,
                status='SUCCESS',
                output_json=str(result.get('output', {}))
            )
        else:
            update_node_status(
                node_code=node_run.code,
                job_run_id=node_run.job_run_id,
                status='FAILED',
                error_json=result.get('error', 'Unknown error')
            )
        
        return result


# 全局执行服务实例
task_execution = TaskExecutionService()
