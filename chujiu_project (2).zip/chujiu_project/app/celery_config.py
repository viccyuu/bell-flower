# -*- coding: utf-8 -*-
"""
Celery 配置

异步任务执行配置
"""
from celery import Celery
from kombu import Exchange, Queue

# Celery 配置
celery_app = Celery(
    'chujiu',
    broker='redis://localhost:6379/0',
    backend='redis://localhost:6379/0',
    include=[
        'app.todolist.celery_tasks',
    ]
)

# 任务配置
celery_app.conf.update(
    # 任务序列化
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    
    # 时区
    timezone='Asia/Shanghai',
    enable_utc=True,
    
    # 任务路由
    task_routes={
        'app.todolist.celery_tasks.execute_task': {'queue': 'tasks'},
        'app.todolist.celery_tasks.execute_node': {'queue': 'nodes'},
    },
    
    # 任务队列
    task_queues=[
        Queue('tasks', Exchange('tasks'), routing_key='tasks'),
        Queue('nodes', Exchange('nodes'), routing_key='nodes'),
    ],
    
    # 任务限制
    worker_prefetch_multiplier=1,
    worker_max_tasks_per_child=100,
    
    # 任务超时
    task_time_limit=3600,  # 1 小时
    task_soft_time_limit=3000,  # 50 分钟
    
    # 重试配置
    task_default_retry_delay=60,
    task_max_retries=3,
)

# 自动发现任务
celery_app.autodiscover_tasks()


def get_celery_app():
    """获取 Celery 应用实例"""
    return celery_app


if __name__ == '__main__':
    # 开发模式运行
    celery_app.start()
