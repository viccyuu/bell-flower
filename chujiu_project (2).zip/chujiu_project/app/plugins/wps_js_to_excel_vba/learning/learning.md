# Learning Rules - WPS JS to Excel VBA

## Rule 1

- 【错误 ID】ERR-20260312-006
- 【场景】JS Promise 异步处理
- 【错因】WPS JS 中的 Promise 异步模式在 VBA 中未正确处理
- 【禁用语/禁行为】
  1. 不可直接将 Promise 链转换为 VBA 代码
  2. 不可忽略 VBA 的同步执行特性
- 【正确范式】
  1. 使用 VBA 的同步调用模式
  2. 必要时使用回调函数模拟异步行为
