﻿# -*- coding: utf-8 -*-

"""
鎻掍欢浜岋細WPS JS -> VBA

涓撳睘宸ュ叿鍑芥暟
"""


def validate_file_type(file_path: str) -> bool:
    """楠岃瘉鏂囦欢绫诲瀷"""
    allowed = ['.xlsm', '.et', '.wps']
    return any(file_path.lower().endswith(ext) for ext in allowed)
