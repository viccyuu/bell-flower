﻿# -*- coding: utf-8 -*-

"""Plugin 2: WPS JS to Excel VBA - DAG Configuration"""

# Plugin Metadata
PLUGIN_META = {
    "code": "wps_js_to_excel_vba",
    "name": "WPS JS to Excel VBA",
    "version": "1.0.0",
    "description": "Convert WPS Excel JavaScript macros to MS Excel VBA macros",
    "author": "Chujiu Design",
    "allowed_extensions": [".et", ".wps", ".xlsx", ".xlsm"],
    "output_extension": ".xlsm"
}

# Plugin DAG Definition (Reverse of Plugin 1)
PLUGIN_DAG = {
    "job": {
        "code": "wps_js_to_excel_vba_main",
        "name": "WPS Excel JavaScript to MS Excel VBA Macro Conversion",
        "version": 1,
        "is_sub_job": False,
        "description": "Upload WPS Excel file, extract JavaScript macros, convert to VBA"
    },
    "defaults": {
        "continue_on_error": False,
        "timeout_seconds": 180,
        "retry_policy": {
            "max_retries": 1,
            "backoff_seconds": 5,
            "retry_on": ["TIMEOUT", "TEMPORARY_ERROR", "LLM_TRANSIENT_ERROR"]
        }
    },
    "nodes": [
        {
            "code": "upload_validate",
            "name": "Validate Upload",
            "action_type": "PYTHON",
            "executor": "python_executor",
            "timeout_seconds": 30,
            "config": {
                "callable": "plugins.wps_js_to_excel_vba.handlers.validate_upload"
            }
        },
        {
            "code": "extract_js_macros",
            "name": "Extract JavaScript Macros",
            "action_type": "PYTHON",
            "executor": "python_executor",
            "timeout_seconds": 120,
            "config": {
                "callable": "plugins.wps_js_to_excel_vba.handlers.extract_js_macros"
            }
        },
        {
            "code": "analyze_macro_dependencies",
            "name": "Analyze Macro Dependencies",
            "action_type": "PYTHON",
            "executor": "python_executor",
            "timeout_seconds": 60,
            "config": {
                "callable": "plugins.wps_js_to_excel_vba.handlers.analyze_macro_dependencies"
            }
        }
    ],
    "edges": [
        {"from": "upload_validate", "to": "extract_js_macros"},
        {"from": "extract_js_macros", "to": "analyze_macro_dependencies"}
    ]
}
