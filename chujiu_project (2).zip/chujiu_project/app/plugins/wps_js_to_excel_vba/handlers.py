﻿# -*- coding: utf-8 -*-

"""
插件二：WPS JS -> VBA

Node 处理器实现（骨架）
"""
from app.todolist.task_context import TaskContext, TaskResult


def validate_upload(context: TaskContext) -> TaskResult:
    """校验上传文件"""
    return TaskResult(success=True, message="Upload validated")


def extract_js_macros(context: TaskContext) -> TaskResult:
    """提取 JS 宏"""
    context.extra['macros'] = []
    return TaskResult(success=True, message="JS macros extracted")


def write_vba_to_excel_file(context: TaskContext) -> TaskResult:
    """将 VBA 写入 Excel 文件"""
    context.output_file_path = "/path/to/output.xlsm"
    return TaskResult(success=True, message="VBA written")


HANDLERS = {
    'validate_upload': validate_upload,
    'extract_js_macros': extract_js_macros,
    'write_vba_to_excel_file': write_vba_to_excel_file,
}
