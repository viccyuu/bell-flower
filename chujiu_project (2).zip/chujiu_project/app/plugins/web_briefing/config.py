﻿# -*- coding: utf-8 -*-

"""Plugin 3: Web Briefing - DAG Configuration"""

# Plugin Metadata
PLUGIN_META = {
    "code": "web_briefing",
    "name": "Web Briefing",
    "version": "1.0.0",
    "description": "Read web pages, extract content, summarize with LLM",
    "author": "Chujiu Design"
}

# Plugin DAG Definition
PLUGIN_DAG = {
    "job": {
        "code": "web_briefing_main",
        "name": "Web Content Integration and Briefing",
        "version": 1,
        "is_sub_job": False,
        "description": "Read specified web pages, extract content, summarize with LLM, output briefing"
    },
    "defaults": {
        "continue_on_error": False,
        "timeout_seconds": 120,
        "retry_policy": {
            "max_retries": 1,
            "backoff_seconds": 3,
            "retry_on": ["TIMEOUT", "TEMPORARY_ERROR", "HTTP_5XX"]
        }
    },
    "nodes": [
        {
            "code": "validate_input",
            "name": "Validate Input",
            "action_type": "PYTHON",
            "executor": "python_executor",
            "timeout_seconds": 20,
            "config": {
                "callable": "plugins.web_briefing.handlers.validate_input"
            }
        },
        {
            "code": "fetch_web_pages",
            "name": "Fetch Web Pages",
            "action_type": "PYTHON",
            "executor": "python_executor",
            "timeout_seconds": 180,
            "config": {
                "callable": "plugins.web_briefing.handlers.fetch_web_pages"
            }
        },
        {
            "code": "extract_clean_content",
            "name": "Extract Clean Content",
            "action_type": "PYTHON",
            "executor": "python_executor",
            "timeout_seconds": 120,
            "config": {
                "callable": "plugins.web_briefing.handlers.extract_clean_content"
            }
        },
        {
            "code": "summarize_with_llm",
            "name": "Summarize with LLM",
            "action_type": "LLM",
            "executor": "llm_executor",
            "timeout_seconds": 180,
            "config": {
                "model": "default-llm",
                "planning_enabled": False
            }
        },
        {
            "code": "save_report_file",
            "name": "Save Report File",
            "action_type": "FILE",
            "executor": "file_executor",
            "timeout_seconds": 30,
            "config": {
                "operation": "write_text_artifact",
                "artifact_type": "REPORT"
            }
        }
    ],
    "edges": [
        {"from": "validate_input", "to": "fetch_web_pages"},
        {"from": "fetch_web_pages", "to": "extract_clean_content"},
        {"from": "extract_clean_content", "to": "summarize_with_llm"},
        {"from": "summarize_with_llm", "to": "save_report_file"}
    ]
}
