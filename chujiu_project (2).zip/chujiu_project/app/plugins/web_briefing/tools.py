﻿# -*- coding: utf-8 -*-

"""
鎻掍欢涓夛細缃戦〉绠€鎶?
涓撳睘宸ュ叿鍑芥暟
"""


def validate_url(url: str) -> bool:
    """楠岃瘉 URL 鏍煎紡"""
    import re
    pattern = r'^https?://[^\s]+$'
    return bool(re.match(pattern, url))
