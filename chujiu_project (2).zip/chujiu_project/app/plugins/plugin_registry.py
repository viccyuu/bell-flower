﻿# -*- coding: utf-8 -*-

"""
插件注册中心

功能：
1. 自动发现并注册所有插件
2. 提供插件查询接口
3. 管理插件启用/禁用状态
4. 加载插件 DAG 配置
"""
import os
import importlib
from pathlib import Path


class PluginRegistry:
    """插件注册表"""
    
    _instance = None
    
    def __new__(cls):
        """单例模式"""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.plugins = {}
            cls._instance.initialized = False
        return cls._instance
    
    def initialize(self, plugins_dir=None):
        """
        初始化插件注册表
        
        Args:
            plugins_dir: 插件目录路径，默认为项目根目录/plugins
        """
        if self.initialized:
            return
        
        if plugins_dir is None:
            # 使用绝对路径，避免与 config 模块冲突
            import sys
            project_root = Path(__file__).parent.parent
            plugins_dir = project_root / 'plugins'
        
        self.plugins_dir = Path(plugins_dir)
        self._scan_and_register_plugins()
        self.initialized = True
    
    def _scan_and_register_plugins(self):
        """扫描插件目录并注册所有插件"""
        if not self.plugins_dir.exists():
            return
        
        for item in self.plugins_dir.iterdir():
            if item.is_dir() and not item.name.startswith('_'):
                self._register_plugin_directory(item)
    
    def _register_plugin_directory(self, plugin_dir):
        """注册单个插件目录"""
        config_path = plugin_dir / 'config.py'
        if not config_path.exists():
            return
        
        try:
            # 动态导入插件配置
            module_name = f'app.plugins.{plugin_dir.name}.config'
            config_module = importlib.import_module(module_name)
            
            # 获取插件元数据
            if hasattr(config_module, 'PLUGIN_META'):
                plugin_meta = config_module.PLUGIN_META
                plugin_code = plugin_meta.get('code', plugin_dir.name)
                
                # 获取 DAG 配置
                dag_config = {}
                if hasattr(config_module, 'PLUGIN_DAG'):
                    dag_config = config_module.PLUGIN_DAG
                
                # 注册插件
                self.plugins[plugin_code] = {
                    'code': plugin_code,
                    'name': plugin_meta.get('name', plugin_dir.name),
                    'version': plugin_meta.get('version', '1.0.0'),
                    'description': plugin_meta.get('description', ''),
                    'author': plugin_meta.get('author', ''),
                    'dag': dag_config,
                    'enabled': True,
                    'module': config_module,
                    'path': str(plugin_dir),
                    'learning_path': str(plugin_dir / 'learning')
                }
                
                # 同步注册到 todolist/plugin_registry.py（P1-01 修复）
                if dag_config:
                    try:
                        from app.todolist.plugin_registry import plugin_dag_registry
                        plugin_dag_registry.register_plugin_dag(plugin_code, dag_config)
                        print(f"Registered DAG for plugin {plugin_code}")
                    except Exception as e:
                        print(f"Failed to register DAG for {plugin_code}: {e}")
                
        except Exception as e:
            print(f"Failed to register plugin {plugin_dir.name}: {e}")
    
    def get_plugin(self, plugin_code):
        """
        获取插件信息
        
        Args:
            plugin_code: 插件代码
            
        Returns:
            dict: 插件信息，不存在返回 None
        """
        return self.plugins.get(plugin_code)
    
    def list_plugins(self, enabled_only=False):
        """
        列出所有插件
        
        Args:
            enabled_only: 是否只返回启用的插件
            
        Returns:
            list: 插件信息列表
        """
        if enabled_only:
            return [
                {k: v for k, v in p.items() if k != 'module'} 
                for p in self.plugins.values() if p['enabled']
            ]
        return [
            {k: v for k, v in p.items() if k != 'module'} 
            for p in self.plugins.values()
        ]
    
    def toggle_plugin(self, plugin_code, enabled):
        """
        启用/禁用插件
        
        Args:
            plugin_code: 插件代码
            enabled: True=启用，False=禁用
            
        Returns:
            bool: 是否成功
        """
        if plugin_code in self.plugins:
            self.plugins[plugin_code]['enabled'] = enabled
            return True
        return False
    
    def reload_plugin(self, plugin_code):
        """
        重新加载插件
        
        Args:
            plugin_code: 插件代码
            
        Returns:
            bool: 是否成功
        """
        if plugin_code not in self.plugins:
            return False
        
        plugin = self.plugins[plugin_code]
        plugin_dir = Path(plugin['path'])
        
        try:
            # 重新导入模块
            module_name = f'app.plugins.{plugin_dir.name}.config'
            importlib.reload(plugin['module'])
            
            # 更新配置
            config_module = plugin['module']
            if hasattr(config_module, 'PLUGIN_DAG'):
                plugin['dag'] = config_module.PLUGIN_DAG
            
            return True
        except Exception as e:
            print(f"Failed to reload plugin {plugin_code}: {e}")
            return False
    
    def get_plugin_dag(self, plugin_code):
        """
        获取插件 DAG 配置
        
        Args:
            plugin_code: 插件代码
            
        Returns:
            dict: DAG 配置
        """
        plugin = self.get_plugin(plugin_code)
        if plugin:
            return plugin.get('dag', {})
        return {}
    
    def get_learning_path(self, plugin_code):
        """
        获取插件 learning 目录路径
        
        Args:
            plugin_code: 插件代码
            
        Returns:
            str: learning 目录路径
        """
        plugin = self.get_plugin(plugin_code)
        if plugin:
            return plugin.get('learning_path')
        return None


# 全局单例
plugin_registry = PluginRegistry()


def init_plugins(plugins_dir=None):
    """
    初始化插件系统
    
    Args:
        plugins_dir: 插件目录路径
    """
    plugin_registry.initialize(plugins_dir)
