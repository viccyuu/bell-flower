# Learning Rules - Excel VBA to WPS JS

## Rule 1

- 【错误 ID】ERR-20260312-001
- 【场景】VBA Range 对象映射
- 【错因】WPS JS 中将 Excel Range 对象错误映射为普通数组，导致单元格赋值语义失真
- 【禁用语/禁行为】
  1. 不可将 Range.Value 直接映射为 JS 普通数组变量后再写回
  2. 不可忽略单元格区域对象的读写副作用
- 【正确范式】
  1. 优先保持 Range 对象语义，使用 `sheet.getRange(...).Value`
  2. 若需转换中间结构，必须在写回前恢复为 WPS API 支持的数据结构

## Rule 2

- 【错误 ID】ERR-20260312-002
- 【场景】VBA 全局对象映射
- 【错因】VBA 中的 Application、Workbook 等全局对象在 JS 中未正确映射
- 【禁用语/禁行为】
  1. 不可直接使用 VBA 全局对象
  2. 不可忽略对象作用域差异
- 【正确范式】
  1. 使用 WPS JS 对应的全局对象（如 Application → wps.Application）
  2. 明确对象作用域（ThisWorkbook → wps.ThisWorkbook）

## Rule 3

- 【错误 ID】ERR-20260312-003
- 【场景】VBA 事件处理映射
- 【错因】VBA 事件驱动模式在 JS 中未正确转换
- 【禁用语/禁行为】
  1. 不可直接复制 VBA 事件处理函数
  2. 不可忽略事件触发时机差异
- 【正确范式】
  1. 使用 WPS JS 的事件监听模式
  2. 确保事件处理函数签名正确


## Rule 1

- 【错误 ID】ERR-20260314-001
- 【场景】Test scenario
- 【错因】Test error for learning generation
- 【禁止行为】
  （待补充）
- 【正确范式】
  （待补充）


## Rule 1

- 【错误 ID】ERR-20260314-001
- 【场景】Test scenario
- 【错因】Test error for learning generation
- 【禁止行为】
  （待补充）
- 【正确范式】
  （待补充）


## Rule 1

- 【错误 ID】ERR-20260314-001
- 【场景】Test scenario
- 【错因】Test error for learning generation
- 【禁止行为】
  （待补充）
- 【正确范式】
  （待补充）
