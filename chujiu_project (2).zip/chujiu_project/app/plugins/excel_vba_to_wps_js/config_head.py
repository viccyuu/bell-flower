﻿# -*- coding: utf-8 -*-

"""Plugin 1: Excel VBA to WPS JS - DAG Configuration"""

# Plugin Metadata
PLUGIN_META = {
    "code": "excel_vba_to_wps_js",
    "name": "MS Excel VBA to WPS JS",
    "version": "1.0.0",
    "description": "Convert MS Excel VBA macros to WPS Excel JavaScript macros",
    "author": "Chujiu Design",
    "allowed_extensions": [".xlsm", ".xls", ".xlsx"],
    "output_extension": ".xlsm"
}
