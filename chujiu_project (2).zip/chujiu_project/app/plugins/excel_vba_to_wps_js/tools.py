﻿# -*- coding: utf-8 -*-

"""
鎻掍欢涓€锛歁S Excel VBA -> WPS JS

涓撳睘宸ュ叿鍑芥暟
"""


def validate_file_type(file_path: str) -> bool:
    """楠岃瘉鏂囦欢绫诲瀷"""
    allowed = ['.xlsm', '.xls', '.xlsx']
    return any(file_path.lower().endswith(ext) for ext in allowed)


def get_file_size(file_path: str) -> int:
    """鑾峰彇鏂囦欢澶у皬"""
    import os
    return os.path.getsize(file_path)


# TODO: 娣诲姞鏇村宸ュ叿鍑芥暟
