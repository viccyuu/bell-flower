# -*- coding: utf-8 -*-
"""
Excel VBA 宏转 WPS JS 宏插件配置
"""

PLUGIN_META = {
    'code': 'excel_vba_to_wps_js',
    'name': 'MS Excel VBA 宏转换为 WPS Excel Javascript 宏',
    'version': '1.0.0',
    'description': '上传 MS Excel 文件，提取 VBA 宏，转换为 Canonical AST 与 WPS JS AST，生成源码并测试，失败后总结 learning rule 并重试。',
    'author': 'Chujiu Team',
}

# DAG 配置
PLUGIN_DAG = {
    "job": {
        "code": "excel_vba_to_wps_js_main",
        "name": "MS Excel VBA 宏转换为 WPS Excel Javascript 宏",
        "version": 1,
        "is_sub_job": False,
        "description": "上传 MS Excel 文件，提取 VBA 宏，转换为 Canonical AST 与 WPS JS AST，生成源码并测试。"
    },
    "defaults": {
        "continue_on_error": False,
        "timeout_seconds": 180,
        "retry_policy": {
            "max_retries": 1,
            "backoff_seconds": 5,
            "retry_on": ["TIMEOUT", "TEMPORARY_ERROR", "LLM_TRANSIENT_ERROR"]
        }
    },
    "nodes": [
        {
            "code": "upload_validate",
            "name": "校验上传文件",
            "action_type": "PYTHON",
            "executor": "python_executor",
            "timeout_seconds": 30,
            "config": {
                "callable": "app.plugins.excel_vba_to_wps_js.handler.validate_upload"
            },
            "input_mapping": {
                "file_path": "{{ task.vars.file_path }}",
                "allowed_extensions": [".xlsm", ".xls", ".xlsx"]
            }
        },
        {
            "code": "extract_vba_macros",
            "name": "提取 VBA 宏",
            "action_type": "PYTHON",
            "executor": "python_executor",
            "timeout_seconds": 120,
            "config": {
                "callable": "app.plugins.excel_vba_to_wps_js.handler.extract_vba_macros"
            },
            "input_mapping": {
                "file_path": "{{ node.upload_validate.output.file_path }}"
            }
        },
        {
            "code": "analyze_macro_dependencies",
            "name": "分析宏依赖关系",
            "action_type": "PYTHON",
            "executor": "python_executor",
            "timeout_seconds": 60,
            "config": {
                "callable": "app.plugins.excel_vba_to_wps_js.handler.analyze_macro_dependencies"
            },
            "input_mapping": {
                "macros": "{{ node.extract_vba_macros.output.macros }}"
            }
        },
        {
            "code": "load_learning_rules",
            "name": "加载历史学习规则",
            "action_type": "FILE",
            "executor": "file_executor",
            "timeout_seconds": 15,
            "config": {
                "operation": "read_learning_rules",
                "plugin_code": "excel_vba_to_wps_js"
            },
            "input_mapping": {
                "task_run_id": "{{ task.id }}"
            }
        },
        {
            "code": "vba_to_vba_ast",
            "name": "VBA 源码转换为 VBA AST",
            "action_type": "LLM",
            "executor": "llm_executor",
            "timeout_seconds": 180,
            "retry_policy": {
                "max_retries": 2,
                "backoff_seconds": 8,
                "retry_on": ["TIMEOUT", "LLM_TRANSIENT_ERROR", "LLM_RESPONSE_INVALID"]
            },
            "config": {
                "model": "dashscope/glm-5",
                "planning_enabled": True,
                "response_mode": "json_schema",
                "system_prompt_template": "你是 VBA 语法分析专家。请将输入 VBA 源码转换为结构化 AST。必须严格输出 JSON，保持调用关系、模块、过程、函数、变量、引用、控制流。"
            },
            "input_mapping": {
                "macros": "{{ node.extract_vba_macros.output.macros }}",
                "topo_order": "{{ node.analyze_macro_dependencies.output.topo_order }}",
                "learning_rules": "{{ node.load_learning_rules.output.rules_text }}"
            }
        },
        {
            "code": "review_vba_ast",
            "name": "审查 VBA AST",
            "action_type": "LLM",
            "executor": "llm_executor",
            "timeout_seconds": 120,
            "config": {
                "model": "dashscope/glm-5",
                "planning_enabled": False,
                "response_mode": "json_schema",
                "system_prompt_template": "你是 AST 审查器。请检查 VBA AST 是否完整、结构合法、依赖关系正确、语义无缺失。"
            },
            "input_mapping": {
                "ast": "{{ node.vba_to_vba_ast.output.vba_ast }}"
            }
        },
        {
            "code": "vba_ast_to_canonical_ast",
            "name": "VBA AST 转 Canonical AST",
            "action_type": "LLM",
            "executor": "llm_executor",
            "timeout_seconds": 180,
            "config": {
                "model": "dashscope/glm-5",
                "planning_enabled": True,
                "response_mode": "json_schema",
                "system_prompt_template": "你是跨语言宏语义归一化专家。请将 VBA AST 转换为语言无关 Canonical AST。"
            },
            "input_mapping": {
                "vba_ast": "{{ node.vba_to_vba_ast.output.vba_ast }}",
                "review": "{{ node.review_vba_ast.output }}",
                "learning_rules": "{{ node.load_learning_rules.output.rules_text }}"
            }
        },
        {
            "code": "review_canonical_ast",
            "name": "审查 Canonical AST",
            "action_type": "LLM",
            "executor": "llm_executor",
            "timeout_seconds": 120,
            "config": {
                "model": "dashscope/glm-5",
                "planning_enabled": False,
                "response_mode": "json_schema",
                "system_prompt_template": "检查 Canonical AST 是否具备完整的业务语义、控制流、对象模型、依赖引用与跨语言可映射性。"
            },
            "input_mapping": {
                "ast": "{{ node.vba_ast_to_canonical_ast.output.canonical_ast }}"
            }
        },
        {
            "code": "canonical_ast_to_wps_js_ast",
            "name": "Canonical AST 转 WPS JS AST",
            "action_type": "LLM",
            "executor": "llm_executor",
            "timeout_seconds": 180,
            "config": {
                "model": "dashscope/glm-5",
                "planning_enabled": True,
                "response_mode": "json_schema",
                "system_prompt_template": "你是 WPS Excel Javascript 宏专家。请把 Canonical AST 转换为 WPS JS AST，保留 Excel 对象模型与 API 语义。"
            },
            "input_mapping": {
                "canonical_ast": "{{ node.vba_ast_to_canonical_ast.output.canonical_ast }}",
                "review": "{{ node.review_canonical_ast.output }}",
                "learning_rules": "{{ node.load_learning_rules.output.rules_text }}"
            }
        },
        {
            "code": "review_wps_js_ast",
            "name": "审查 WPS JS AST",
            "action_type": "LLM",
            "executor": "llm_executor",
            "timeout_seconds": 120,
            "config": {
                "model": "dashscope/glm-5",
                "planning_enabled": False,
                "response_mode": "json_schema",
                "system_prompt_template": "检查 WPS JS AST 的语法结构、API 使用、对象模型、依赖关系、控制流与可生成性。"
            },
            "input_mapping": {
                "ast": "{{ node.canonical_ast_to_wps_js_ast.output.wps_js_ast }}"
            }
        },
        {
            "code": "wps_js_ast_to_source",
            "name": "WPS JS AST 转 WPS JS 源码",
            "action_type": "LLM",
            "executor": "llm_executor",
            "timeout_seconds": 180,
            "config": {
                "model": "dashscope/glm-5",
                "planning_enabled": True,
                "response_mode": "json_schema",
                "system_prompt_template": "请将 WPS JS AST 转换为可执行的 WPS Excel Javascript 宏源码。"
            },
            "input_mapping": {
                "wps_js_ast": "{{ node.canonical_ast_to_wps_js_ast.output.wps_js_ast }}",
                "review": "{{ node.review_wps_js_ast.output }}",
                "learning_rules": "{{ node.load_learning_rules.output.rules_text }}"
            }
        },
        {
            "code": "review_wps_js_source",
            "name": "审查 WPS JS 源码",
            "action_type": "LLM",
            "executor": "llm_executor",
            "timeout_seconds": 90,
            "config": {
                "model": "dashscope/glm-5",
                "planning_enabled": False,
                "response_mode": "json_schema",
                "system_prompt_template": "检查 WPS JS 源码是否符合 WPS API、语法正确、结构清晰、避免高风险错误。"
            },
            "input_mapping": {
                "source_code": "{{ node.wps_js_ast_to_source.output.wps_js_source }}"
            }
        },
        {
            "code": "generate_vba_testcases",
            "name": "生成 VBA 宏测试用例",
            "action_type": "LLM",
            "executor": "llm_executor",
            "timeout_seconds": 120,
            "config": {
                "model": "dashscope/glm-5",
                "planning_enabled": False,
                "response_mode": "json_schema",
                "system_prompt_template": "根据 VBA 源宏语义生成测试用例，覆盖正常、边界、异常场景。"
            },
            "input_mapping": {
                "macros": "{{ node.extract_vba_macros.output.macros }}",
                "dependency_graph": "{{ node.analyze_macro_dependencies.output.dependency_graph }}"
            }
        },
        {
            "code": "generate_wps_js_testcases",
            "name": "生成 WPS JS 宏测试用例",
            "action_type": "LLM",
            "executor": "llm_executor",
            "timeout_seconds": 120,
            "config": {
                "model": "dashscope/glm-5",
                "planning_enabled": False,
                "response_mode": "json_schema",
                "system_prompt_template": "根据目标 WPS JS 宏语义生成测试用例，要求与源宏场景等价。"
            },
            "input_mapping": {
                "wps_js_source": "{{ node.wps_js_ast_to_source.output.wps_js_source }}",
                "vba_testcases": "{{ node.generate_vba_testcases.output.testcases }}"
            }
        },
        {
            "code": "write_js_to_wps_file",
            "name": "将 JS 宏写入目标 WPS 文件",
            "action_type": "PYTHON",
            "executor": "python_executor",
            "timeout_seconds": 120,
            "config": {
                "callable": "app.plugins.excel_vba_to_wps_js.handler.write_js_to_wps_file"
            },
            "input_mapping": {
                "source_file": "{{ node.upload_validate.output.file_path }}",
                "wps_js_source": "{{ node.wps_js_ast_to_source.output.wps_js_source }}"
            }
        },
        {
            "code": "run_vba_tests",
            "name": "执行 VBA 测试",
            "action_type": "PYTHON",
            "executor": "python_executor",
            "timeout_seconds": 180,
            "config": {
                "callable": "app.plugins.excel_vba_to_wps_js.handler.run_vba_tests"
            },
            "input_mapping": {
                "source_file": "{{ node.upload_validate.output.file_path }}",
                "testcases": "{{ node.generate_vba_testcases.output.testcases }}"
            }
        },
        {
            "code": "run_js_tests",
            "name": "执行 WPS JS 测试",
            "action_type": "PYTHON",
            "executor": "python_executor",
            "timeout_seconds": 180,
            "config": {
                "callable": "app.plugins.excel_vba_to_wps_js.handler.run_js_tests"
            },
            "input_mapping": {
                "target_file": "{{ node.write_js_to_wps_file.output.target_file_path }}",
                "testcases": "{{ node.generate_wps_js_testcases.output.testcases }}"
            }
        },
        {
            "code": "compare_results",
            "name": "比对 VBA 与 WPS JS 测试结果",
            "action_type": "PYTHON",
            "executor": "python_executor",
            "timeout_seconds": 60,
            "config": {
                "callable": "app.plugins.excel_vba_to_wps_js.handler.compare_results"
            },
            "input_mapping": {
                "vba_report": "{{ node.run_vba_tests.output.report }}",
                "js_report": "{{ node.run_js_tests.output.report }}"
            }
        },
        {
            "code": "generate_learning_rule_if_needed",
            "name": "生成学习规则",
            "action_type": "LLM",
            "executor": "llm_executor",
            "timeout_seconds": 120,
            "config": {
                "model": "dashscope/glm-5",
                "planning_enabled": True,
                "response_mode": "json_schema",
                "system_prompt_template": "根据测试失败信息总结转换规则，输出 learning.md 所需结构，包括错误 ID、场景、错因、禁用语/禁行为、正确范式。"
            },
            "input_mapping": {
                "compare_result": "{{ node.compare_results.output }}",
                "source_macros": "{{ node.extract_vba_macros.output.macros }}",
                "target_source": "{{ node.wps_js_ast_to_source.output.wps_js_source }}"
            }
        },
        {
            "code": "persist_learning_rule",
            "name": "保存学习规则",
            "action_type": "FILE",
            "executor": "file_executor",
            "timeout_seconds": 30,
            "config": {
                "operation": "write_learning_rule",
                "plugin_code": "excel_vba_to_wps_js"
            },
            "input_mapping": {
                "task_run_id": "{{ task.id }}",
                "learning_markdown": "{{ node.generate_learning_rule_if_needed.output.learning_markdown }}",
                "error_id": "{{ node.generate_learning_rule_if_needed.output.error_id }}"
            }
        },
        {
            "code": "retry_with_learning_rule",
            "name": "基于新规则重新转换",
            "action_type": "PYTHON",
            "executor": "python_executor",
            "timeout_seconds": 60,
            "config": {
                "callable": "app.plugins.excel_vba_to_wps_js.handler.request_retry_from_node"
            },
            "input_mapping": {
                "task_run_id": "{{ task.id }}",
                "recovery_node_code": "vba_to_vba_ast",
                "need_retry": "{{ node.generate_learning_rule_if_needed.output.need_retry }}"
            }
        },
        {
            "code": "publish_download_artifact",
            "name": "发布下载产物",
            "action_type": "FILE",
            "executor": "file_executor",
            "timeout_seconds": 30,
            "config": {
                "operation": "publish_artifact",
                "artifact_type": "OUTPUT_FILE"
            },
            "input_mapping": {
                "task_run_id": "{{ task.id }}",
                "file_path": "{{ node.write_js_to_wps_file.output.target_file_path }}",
                "publish_enabled": "{{ node.compare_results.output.passed }}"
            }
        }
    ],
    "edges": [
        {"from": "upload_validate", "to": "extract_vba_macros"},
        {"from": "extract_vba_macros", "to": "analyze_macro_dependencies"},
        {"from": "analyze_macro_dependencies", "to": "load_learning_rules"},
        {"from": "load_learning_rules", "to": "vba_to_vba_ast"},
        {"from": "vba_to_vba_ast", "to": "review_vba_ast"},
        {
            "from": "review_vba_ast",
            "to": "vba_ast_to_canonical_ast",
            "condition_expr": "{{ node.review_vba_ast.output.passed == true }}"
        },
        {"from": "vba_ast_to_canonical_ast", "to": "review_canonical_ast"},
        {
            "from": "review_canonical_ast",
            "to": "canonical_ast_to_wps_js_ast",
            "condition_expr": "{{ node.review_canonical_ast.output.passed == true }}"
        },
        {"from": "canonical_ast_to_wps_js_ast", "to": "review_wps_js_ast"},
        {
            "from": "review_wps_js_ast",
            "to": "wps_js_ast_to_source",
            "condition_expr": "{{ node.review_wps_js_ast.output.passed == true }}"
        },
        {"from": "wps_js_ast_to_source", "to": "review_wps_js_source"},
        {
            "from": "review_wps_js_source",
            "to": "generate_vba_testcases",
            "condition_expr": "{{ node.review_wps_js_source.output.passed == true }}"
        },
        {"from": "generate_vba_testcases", "to": "generate_wps_js_testcases"},
        {"from": "generate_wps_js_testcases", "to": "write_js_to_wps_file"},
        {"from": "write_js_to_wps_file", "to": "run_vba_tests"},
        {"from": "write_js_to_wps_file", "to": "run_js_tests"},
        {"from": "run_vba_tests", "to": "compare_results"},
        {"from": "run_js_tests", "to": "compare_results"},
        {
            "from": "compare_results",
            "to": "publish_download_artifact",
            "condition_expr": "{{ node.compare_results.output.passed == true }}"
        },
        {
            "from": "compare_results",
            "to": "generate_learning_rule_if_needed",
            "condition_expr": "{{ node.compare_results.output.passed == false }}"
        },
        {
            "from": "generate_learning_rule_if_needed",
            "to": "persist_learning_rule",
            "condition_expr": "{{ node.generate_learning_rule_if_needed.output.need_retry == true }}"
        },
        {
            "from": "persist_learning_rule",
            "to": "retry_with_learning_rule",
            "condition_expr": "{{ node.generate_learning_rule_if_needed.output.need_retry == true }}"
        }
    ]
}
