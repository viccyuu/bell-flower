# -*- coding: utf-8 -*-
"""
VBA AST 转换和代码生成

实现 VBA 到 WPS JS 的 AST 转换和代码生成逻辑
"""
import re
import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


def vba_to_ast(vba_code: str) -> Dict[str, Any]:
    """
    将 VBA 代码转换为 AST
    
    Args:
        vba_code: VBA 源代码
    
    Returns:
        AST 字典结构
    """
    ast = {
        'type': 'Module',
        'name': 'Module1',
        'body': [],
        'declarations': [],
        'procedures': []
    }
    
    # 简单解析 VBA 代码
    lines = vba_code.split('\n')
    current_procedure = None
    current_body = []
    
    for line in lines:
        line = line.strip()
        
        # 跳过空行和注释
        if not line or line.startswith("'") or line.startswith('Rem '):
            continue
        
        # 检测 Sub 过程
        sub_match = re.match(r'^Sub\s+(\w+)\s*\((.*?)\)', line, re.IGNORECASE)
        if sub_match:
            if current_procedure:
                # 保存前一个过程
                ast['procedures'].append({
                    'type': 'Sub',
                    'name': current_procedure['name'],
                    'params': current_procedure['params'],
                    'body': current_body
                })
            
            # 开始新过程
            current_procedure = {
                'name': sub_match.group(1),
                'params': sub_match.group(2).split(',') if sub_match.group(2) else []
            }
            current_body = []
            continue
        
        # 检测 Function 函数
        func_match = re.match(r'^Function\s+(\w+)\s*\((.*?)\)', line, re.IGNORECASE)
        if func_match:
            if current_procedure:
                ast['procedures'].append({
                    'type': 'Function',
                    'name': current_procedure['name'],
                    'params': current_procedure['params'],
                    'body': current_body
                })
            
            current_procedure = {
                'name': func_match.group(1),
                'params': func_match.group(2).split(',') if func_match.group(2) else []
            }
            current_body = []
            continue
        
        # 检测 End Sub/Function
        if re.match(r'^End\s+(Sub|Function)', line, re.IGNORECASE):
            if current_procedure:
                ast['procedures'].append({
                    'type': current_procedure.get('type', 'Sub'),
                    'name': current_procedure['name'],
                    'params': current_procedure['params'],
                    'body': current_body
                })
                current_procedure = None
                current_body = []
            continue
        
        # 收集过程体
        if current_procedure:
            current_body.append(line)
        
        # 检测变量声明
        dim_match = re.match(r'^Dim\s+(\w+)\s+As\s+(\w+)', line, re.IGNORECASE)
        if dim_match:
            ast['declarations'].append({
                'type': 'Variable',
                'name': dim_match.group(1),
                'dataType': dim_match.group(2)
            })
    
    # 保存最后一个过程
    if current_procedure:
        ast['procedures'].append({
            'type': 'Sub',
            'name': current_procedure['name'],
            'params': current_procedure['params'],
            'body': current_body
        })
    
    return ast


def ast_to_wps_js(ast: Dict[str, Any]) -> str:
    """
    将 AST 转换为 WPS JS 代码
    
    Args:
        ast: AST 字典结构
    
    Returns:
        WPS JS 源代码
    """
    js_code = []
    
    # 生成模块注释
    js_code.append(f"// Module: {ast.get('name', 'Module1')}")
    js_code.append(f"// Converted from VBA")
    js_code.append("")
    
    # 生成变量声明
    for decl in ast.get('declarations', []):
        var_name = decl.get('name', 'unknown')
        var_type = decl.get('dataType', 'Variant')
        js_code.append(f"let {var_name}; // {var_type}")
    
    if ast.get('declarations'):
        js_code.append("")
    
    # 生成过程
    for proc in ast.get('procedures', []):
        proc_type = proc.get('type', 'Sub')
        proc_name = proc.get('name', 'Unknown')
        params = proc.get('params', [])
        body = proc.get('body', [])
        
        # 转换参数
        js_params = []
        for param in params:
            param = param.strip()
            if param:
                # 简化处理，移除 ByRef/ByVal 等修饰符
                param_name = re.sub(r'(ByRef|ByVal)\s+', '', param).strip()
                js_params.append(param_name)
        
        # 生成函数签名
        if proc_type == 'Function':
            js_code.append(f"function {proc_name}({', '.join(js_params)}) {{")
        else:
            js_code.append(f"function {proc_name}({', '.join(js_params)}) {{")
        
        # 转换过程体
        for line in body:
            js_line = convert_vba_line_to_js(line)
            if js_line:
                js_code.append(f"    {js_line}")
        
        js_code.append("}")
        js_code.append("")
    
    return '\n'.join(js_code)


def convert_vba_line_to_js(vba_line: str) -> str:
    """
    转换单行 VBA 代码为 JS
    
    Args:
        vba_line: VBA 代码行
    
    Returns:
        JS 代码行
    """
    line = vba_line.strip()
    
    # 跳过空行和注释
    if not line or line.startswith("'") or line.startswith('Rem '):
        return f"// {line}"
    
    # 转换 MsgBox
    msgbox_match = re.match(r'MsgBox\s+(.+)', line, re.IGNORECASE)
    if msgbox_match:
        msg = msgbox_match.group(1)
        # 移除 VBA 特定的参数
        msg = re.sub(r',\s*vb[A-Z_]+', '', msg)
        msg = msg.strip('"\'')
        return f"alert('{msg}');"
    
    # 转换变量赋值
    assign_match = re.match(r'(\w+)\s*=\s*(.+)', line)
    if assign_match:
        var_name = assign_match.group(1)
        value = assign_match.group(2)
        
        # 转换常见的 VBA 函数
        value = re.sub(r'CStr\(([^)]+)\)', r'String(\1)', value)
        value = re.sub(r'CInt\(([^)]+)\)', r'parseInt(\1)', value)
        value = re.sub(r'CDbl\(([^)]+)\)', r'parseFloat(\1)', value)
        
        return f"let {var_name} = {value};"
    
    # 转换 Call 语句
    call_match = re.match(r'Call\s+(\w+)(?:\((.*)\))?', line, re.IGNORECASE)
    if call_match:
        func_name = call_match.group(1)
        args = call_match.group(2) or ''
        return f"{func_name}({args});"
    
    # 转换 If 语句
    if_match = re.match(r'If\s+(.+)\s+Then', line, re.IGNORECASE)
    if if_match:
        condition = if_match.group(1)
        # 转换 VBA 条件为 JS 条件
        condition = re.sub(r'=(?!=)', '===', condition)
        condition = re.sub(r'<>', '!==', condition)
        condition = re.sub(r'\bAnd\b', '&&', condition)
        condition = re.sub(r'\bOr\b', '||', condition)
        condition = re.sub(r'\bNot\b', '!', condition)
        return f"if ({condition}) {{"
    
    # 转换 End If
    if re.match(r'End\s+If', line, re.IGNORECASE):
        return "}"
    
    # 转换 For 循环
    for_match = re.match(r'For\s+(\w+)\s*=\s*(\d+)\s+To\s+(\d+)', line, re.IGNORECASE)
    if for_match:
        var = for_match.group(1)
        start = for_match.group(2)
        end = for_match.group(3)
        return f"for (let {var} = {start}; {var} <= {end}; {var}++) {{"
    
    # 转换 Next
    if re.match(r'Next\b', line, re.IGNORECASE):
        return "}"
    
    # 转换 Do While 循环
    do_while_match = re.match(r'Do\s+While\s+(.+)', line, re.IGNORECASE)
    if do_while_match:
        condition = do_while_match.group(1)
        return f"while ({condition}) {{"
    
    # 转换 Loop
    if re.match(r'Loop\b', line, re.IGNORECASE):
        return "}"
    
    # 默认：返回原行（添加分号）
    if not line.endswith(';') and not line.endswith('{') and not line.endswith('}'):
        return line + ";"
    
    return line


def convert_macros(macros: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    批量转换宏
    
    Args:
        macros: VBA 宏列表
    
    Returns:
        WPS JS 宏列表
    """
    js_macros = []
    
    for macro in macros:
        vba_code = macro.get('code', '')
        macro_name = macro.get('name', 'Unknown')
        
        # VBA -> AST
        ast = vba_to_ast(vba_code)
        
        # AST -> WPS JS
        js_code = ast_to_wps_js(ast)
        
        js_macros.append({
            'name': macro_name,
            'vba_code': vba_code,
            'js_code': js_code,
            'ast': ast
        })
        
        logger.info(f"Converted macro: {macro_name}")
    
    return js_macros
