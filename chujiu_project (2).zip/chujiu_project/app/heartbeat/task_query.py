# -*- coding: utf-8 -*-
"""
TaskRun 查询能力

从 sqlite_task_queue.py 迁移过来
"""
from app.models import TaskRun
from datetime import datetime, timedelta
from typing import List, Dict, Any


class TaskRunQuery:
    """TaskRun 查询器"""
    
    @staticmethod
    def get_pending_tasks(cutoff_minutes: int = 5) -> List[TaskRun]:
        """
        获取待执行的任务
        
        Args:
            cutoff_minutes: 时间窗口（分钟）
        
        Returns:
            TaskRun 列表
        """
        cutoff_time = datetime.utcnow() - timedelta(minutes=cutoff_minutes)
        
        tasks = TaskRun.query.filter(
            TaskRun.status == 'RUNNING',
            TaskRun.started_at >= cutoff_time
        ).limit(10).all()
        
        return tasks
    
    @staticmethod
    def get_task_with_jobs(task_run_id: int) -> Dict[str, Any]:
        """
        获取任务及其关联的 Jobs
        
        Args:
            task_run_id: TaskRun ID
        
        Returns:
            任务字典
        """
        task_run = TaskRun.query.get(task_run_id)
        if not task_run:
            return {}
        
        return {
            'task_run': task_run,
            'job_runs': task_run.job_runs,
            'node_runs': [node for job in task_run.job_runs for node in job.node_runs]
        }


# 全局查询器实例
task_query = TaskRunQuery()
