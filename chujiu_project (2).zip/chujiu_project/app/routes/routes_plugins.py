# -*- coding: utf-8 -*-
"""
Plugins API Routes - FastAPI ⭐
"""
from fastapi import APIRouter, HTTPException
from typing import List, Dict, Any

router = APIRouter()


# 插件注册表（内存存储，实际应该从数据库或配置加载）
_plugins_registry: Dict[str, Any] = {
    'excel_vba_to_wps_js': {
        'code': 'excel_vba_to_wps_js',
        'name': 'MS Excel VBA 宏转换为 WPS Excel Javascript 宏',
        'version': '1.0.0',
        'description': '上传 MS Excel 文件，提取 VBA 宏，转换为 Canonical AST 与 WPS JS AST，生成源码并测试',
        'author': 'Chujiu Team',
        'enabled': True,
        'dag': {
            'nodes': [],
            'edges': []
        }
    },
    'wps_js_to_excel_vba': {
        'code': 'wps_js_to_excel_vba',
        'name': 'WPS Excel Javascript 宏转换为 MS Excel VBA 宏',
        'version': '1.0.0',
        'description': '上传 WPS Excel 文件，提取 JS 宏，转换为 VBA 宏',
        'author': 'Chujiu Team',
        'enabled': True
    },
    'web_briefing': {
        'code': 'web_briefing',
        'name': '网页业务整合并形成简报',
        'version': '1.0.0',
        'description': '读取指定网页内容，抽取正文，归纳总结，输出简报',
        'author': 'Chujiu Team',
        'enabled': True
    }
}


@router.get("/plugins")
async def list_plugins():
    """
    查询插件列表 ⭐
    
    Returns:
        插件列表
    """
    plugins = list(_plugins_registry.values())
    return {'code': 'OK', 'data': plugins}


@router.get("/plugins/{plugin_code}")
async def get_plugin(plugin_code: str):
    """
    获取插件详情 ⭐
    
    Args:
        plugin_code: 插件代码
    
    Returns:
        插件详情
    """
    plugin = _plugins_registry.get(plugin_code)
    if not plugin:
        raise HTTPException(
            status_code=404,
            detail=f'Plugin {plugin_code} not found'
        )
    
    return {'code': 'OK', 'data': plugin}


@router.post("/plugins/{plugin_code}/enable")
async def enable_plugin(plugin_code: str):
    """
    启用插件 ⭐
    
    Args:
        plugin_code: 插件代码
    
    Returns:
        操作结果
    """
    plugin = _plugins_registry.get(plugin_code)
    if not plugin:
        raise HTTPException(
            status_code=404,
            detail=f'Plugin {plugin_code} not found'
        )
    
    plugin['enabled'] = True
    return {'code': 'OK', 'message': f'Plugin {plugin_code} enabled'}


@router.post("/plugins/{plugin_code}/disable")
async def disable_plugin(plugin_code: str):
    """
    禁用插件 ⭐
    
    Args:
        plugin_code: 插件代码
    
    Returns:
        操作结果
    """
    plugin = _plugins_registry.get(plugin_code)
    if not plugin:
        raise HTTPException(
            status_code=404,
            detail=f'Plugin {plugin_code} not found'
        )
    
    plugin['enabled'] = False
    return {'code': 'OK', 'message': f'Plugin {plugin_code} disabled'}


@router.get("/plugins/{plugin_code}/dag")
async def get_plugin_dag(plugin_code: str):
    """
    获取插件 DAG 配置 ⭐
    
    Args:
        plugin_code: 插件代码
    
    Returns:
        DAG 配置
    """
    plugin = _plugins_registry.get(plugin_code)
    if not plugin:
        raise HTTPException(
            status_code=404,
            detail=f'Plugin {plugin_code} not found'
        )
    
    dag = plugin.get('dag', {'nodes': [], 'edges': []})
    return {'code': 'OK', 'data': dag}
