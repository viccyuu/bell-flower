# -*- coding: utf-8 -*-
"""
SubJob API Routes - FastAPI ⭐
"""
from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List, Optional
from datetime import datetime, timezone

from app.database import get_db
from app.models import JobRun

router = APIRouter()


@router.get("/subjobs")
async def list_subjobs(
    task_run_id: Optional[int] = None,
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    查询 SubJob 列表 ⭐
    
    Args:
        task_run_id: 任务 ID 筛选
        status: 状态筛选
        db: 数据库会话
    
    Returns:
        SubJob 列表
    """
    query = select(JobRun).filter(JobRun.is_sub_job == True)
    
    if task_run_id:
        query = query.filter(JobRun.task_run_id == task_run_id)
    
    if status:
        query = query.filter(JobRun.status == status)
    
    result = await db.execute(query.order_by(JobRun.created_at.desc()))
    subjobs = result.scalars().all()
    
    data = [{
        'id': sj.id,
        'task_run_id': sj.task_run_id,
        'code': sj.code,
        'name': sj.name,
        'status': sj.status,
        'job_source': sj.source,
        'parent_job_id': sj.parent_job_run_id,
        'failed_node_code': sj.recovery_node_code,
        'created_at': sj.created_at.isoformat() if sj.created_at else None
    } for sj in subjobs]
    
    return {'code': 'OK', 'data': data}


@router.get("/subjobs/{subjob_id}")
async def get_subjob(
    subjob_id: int,
    db: AsyncSession = Depends(get_db)
):
    """
    获取 SubJob 详情 ⭐
    
    Args:
        subjob_id: SubJob ID
        db: 数据库会话
    
    Returns:
        SubJob 详情
    """
    subjob = await db.get(JobRun, subjob_id)
    if not subjob or not subjob.is_sub_job:
        raise HTTPException(
            status_code=404,
            detail=f'SubJob {subjob_id} not found'
        )
    
    return {
        'code': 'OK',
        'data': {
            'id': subjob.id,
            'task_run_id': subjob.task_run_id,
            'code': subjob.code,
            'name': subjob.name,
            'status': subjob.status,
            'job_source': subjob.source,
            'parent_job_id': subjob.parent_job_run_id,
            'failed_node_code': subjob.recovery_node_code,
            'context_json': subjob.context_json,
            'created_at': subjob.created_at.isoformat() if subjob.created_at else None,
            'started_at': subjob.started_at.isoformat() if subjob.started_at else None,
            'finished_at': subjob.finished_at.isoformat() if subjob.finished_at else None
        }
    }


@router.post("/subjobs/{subjob_id}/start")
async def start_subjob(
    subjob_id: int,
    db: AsyncSession = Depends(get_db)
):
    """
    启动 SubJob ⭐
    
    Args:
        subjob_id: SubJob ID
        db: 数据库会话
    
    Returns:
        启动结果
    """
    subjob = await db.get(JobRun, subjob_id)
    if not subjob or not subjob.is_sub_job:
        raise HTTPException(
            status_code=404,
            detail=f'SubJob {subjob_id} not found'
        )
    
    if subjob.status not in ['CREATED', 'READY']:
        raise HTTPException(
            status_code=400,
            detail=f'Cannot start subjob in status {subjob.status}'
        )
    
    subjob.status = 'RUNNING'
    subjob.started_at = datetime.now(timezone.utc)
    await db.commit()
    
    # TODO: 触发后台任务执行
    # from app.scheduler.task_scheduler import scheduler
    # asyncio.create_task(scheduler.execute_job(subjob))
    
    return {
        'code': 'OK',
        'data': {
            'subjob_id': subjob.id,
            'status': subjob.status
        }
    }


@router.post("/subjobs/{subjob_id}/cancel")
async def cancel_subjob(
    subjob_id: int,
    db: AsyncSession = Depends(get_db)
):
    """
    取消 SubJob ⭐
    
    Args:
        subjob_id: SubJob ID
        db: 数据库会话
    
    Returns:
        取消结果
    """
    subjob = await db.get(JobRun, subjob_id)
    if not subjob or not subjob.is_sub_job:
        raise HTTPException(
            status_code=404,
            detail=f'SubJob {subjob_id} not found'
        )
    
    if subjob.status != 'RUNNING':
        raise HTTPException(
            status_code=400,
            detail=f'Cannot cancel subjob in status {subjob.status}'
        )
    
    subjob.status = 'CANCELED'
    subjob.finished_at = datetime.now(timezone.utc)
    await db.commit()
    
    return {
        'code': 'OK',
        'data': {
            'subjob_id': subjob.id,
            'status': subjob.status
        }
    }
