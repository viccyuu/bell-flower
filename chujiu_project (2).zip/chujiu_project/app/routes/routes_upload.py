# -*- coding: utf-8 -*-
"""
Upload API Routes - FastAPI ⭐
"""
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional
import logging
from pathlib import Path
import hashlib

from app.database import get_db
from app.models import UploadFile as UploadFileModel
from app.schemas.upload import UploadCreate, UploadResponse
from app.utils.response import success_response, error_response, created_response

logger = logging.getLogger(__name__)

router = APIRouter()


def calculate_checksum(file_path: str) -> str:
    """Calculate SHA256 checksum"""
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()


@router.post("", status_code=status.HTTP_201_CREATED)
async def upload_file(
    file: UploadFile = File(...),
    plugin_code: str = Form(...),
    db: AsyncSession = Depends(get_db)
):
    """
    Upload file ⭐
    
    Args:
        file: Uploaded file
        plugin_code: Plugin code
        db: Database session
    
    Returns:
        {code, data, message}
    """
    try:
        # Save file
        from app.app_config import Settings
        config = Settings()
        
        upload_folder = Path(config.UPLOAD_FOLDER)
        upload_folder.mkdir(parents=True, exist_ok=True)
        
        # Generate unique filename
        import uuid
        stored_name = f"{uuid.uuid4().hex}_{file.filename}"
        file_path = upload_folder / stored_name
        
        # Write file
        with open(file_path, "wb") as buffer:
            content = await file.read()
            buffer.write(content)
        
        # Calculate checksum
        checksum = calculate_checksum(str(file_path))
        
        # Create UploadFile record
        upload_file = UploadFileModel(
            user_id=1,  # TODO: Get from auth
            original_name=file.filename,
            stored_name=stored_name,
            file_path=str(file_path),
            mime_type=file.content_type,
            size_bytes=len(content),
            checksum_sha256=checksum,
            plugin_code=plugin_code,
            status='VALIDATED'
        )
        
        db.add(upload_file)
        await db.commit()
        await db.refresh(upload_file)
        
        return created_response(upload_file, 'File uploaded successfully')
    
    except Exception as e:
        logger.error(f"Upload failed: {str(e)}")
        return error_response(f'Upload failed: {str(e)}', status_code=500)


@router.get("/{upload_id}", response_model=UploadResponse)
async def get_upload(
    upload_id: int,
    db: AsyncSession = Depends(get_db)
):
    """
    Get upload detail ⭐
    
    Args:
        upload_id: Upload ID
        db: Database session
    
    Returns:
        UploadResponse
    """
    upload_file = await db.get(UploadFileModel, upload_id)
    if not upload_file:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f'Upload {upload_id} not found'
        )
    
    return UploadResponse(
        upload_id=upload_file.id,
        original_name=upload_file.original_name,
        stored_name=upload_file.stored_name,
        file_path=upload_file.file_path,
        mime_type=upload_file.mime_type,
        size_bytes=upload_file.size_bytes,
        checksum_sha256=upload_file.checksum_sha256,
        plugin_code=upload_file.plugin_code,
        status=upload_file.status,
        created_at=upload_file.created_at
    )
