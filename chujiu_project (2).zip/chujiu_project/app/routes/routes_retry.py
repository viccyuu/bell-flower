# -*- coding: utf-8 -*-
"""
Retry API Routes - 重试管理 API ⭐

提供：
- 单个节点重试
- 批量重试
- 重试历史查询
- 重试策略更新
"""
from fastapi import APIRouter, HTTPException, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List, Optional
import logging

from app.database import get_db
from app.models import TaskRun, JobRun, NodeRun
from app.schemas.retry import (
    RetryRequest,
    BatchRetryRequest,
    RetryPolicyUpdateRequest,
    RetryHistoryResponse,
    RetryStatusResponse,
    RetryResponse
)
from app.repository.retry_repository import get_retry_repository, RetryRepository
from app.utils.response import success_response, error_response, not_found_response

logger = logging.getLogger(__name__)

router = APIRouter()


@router.post("/nodes", response_model=RetryResponse)
async def retry_node(
    request: RetryRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    重试单个失败节点 ⭐
    
    Args:
        request: RetryRequest
        db: Database session
    
    Returns:
        RetryResponse
    """
    try:
        # 验证任务存在
        task_run = await db.get(TaskRun, request.task_run_id)
        if not task_run:
            return not_found_response(f'TaskRun {request.task_run_id} not found')
        
        # 查找节点
        from sqlalchemy import select
        result = await db.execute(
            select(NodeRun)
            .join(JobRun, NodeRun.job_run_id == JobRun.id)
            .where(
                JobRun.task_run_id == request.task_run_id,
                NodeRun.code == request.node_code
            )
        )
        node_run = result.scalar_one_or_none()
        
        if not node_run:
            return not_found_response(f'Node {request.node_code} not found')
        
        # 验证节点状态
        if node_run.status != 'FAILED':
            return error_response(
                f'Node {request.node_code} status is {node_run.status}, only FAILED nodes can be retried',
                code='INVALID_STATUS'
            )
        
        # 检查重试策略
        import json
        retry_policy = json.loads(node_run.retry_policy_json or '{}')
        max_retries = retry_policy.get('max_retries', 0)
        
        if max_retries > 0 and node_run.attempt_count >= max_retries:
            return error_response(
                f'Node {request.node_code} has reached maximum retry attempts ({max_retries})',
                code='MAX_RETRIES_REACHED'
            )
        
        # 创建重试记录
        retry_repo = get_retry_repository(db)
        await retry_repo.create_retry_record(
            task_run_id=request.task_run_id,
            node_code=request.node_code,
            node_name=node_run.node_name or node_run.code,
            attempt_number=node_run.attempt_count + 1,
            previous_status=node_run.status,
            new_status='RETRYING',
            error_message=json.loads(node_run.error_json or '{}').get('error'),
            retry_reason=request.retry_reason
        )
        
        # 更新节点状态
        from datetime import datetime, timezone
        node_run.status = 'RETRYING'
        node_run.error_json = None
        node_run.attempt_count = (node_run.attempt_count or 0) + 1
        
        await db.commit()
        
        logger.info(f"Node {request.node_code} queued for retry (attempt {node_run.attempt_count})")
        
        return success_response({
            'success': True,
            'message': f'Node {request.node_code} has been queued for retry',
            'node_code': request.node_code,
            'new_status': 'RETRYING',
            'attempt_count': node_run.attempt_count
        })
    
    except Exception as e:
        logger.error(f"Failed to retry node: {str(e)}")
        return error_response(f'Retry failed: {str(e)}', status_code=500)


@router.post("/nodes/batch")
async def batch_retry_nodes(
    request: BatchRetryRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    批量重试失败节点 ⭐
    
    Args:
        request: BatchRetryRequest
        db: Database session
    
    Returns:
        {success_count, failed_count, results}
    """
    try:
        from sqlalchemy import select
        results = []
        success_count = 0
        failed_count = 0
        
        for node_code in request.node_codes:
            # 查找节点
            result = await db.execute(
                select(NodeRun)
                .join(JobRun, NodeRun.job_run_id == JobRun.id)
                .where(
                    JobRun.task_run_id == request.task_run_id,
                    NodeRun.code == node_code
                )
            )
            node_run = result.scalar_one_or_none()
            
            if not node_run:
                results.append({
                    'node_code': node_code,
                    'success': False,
                    'error': 'Node not found'
                })
                failed_count += 1
                continue
            
            if node_run.status != 'FAILED':
                results.append({
                    'node_code': node_code,
                    'success': False,
                    'error': f'Invalid status: {node_run.status}'
                })
                failed_count += 1
                continue
            
            # 更新状态
            node_run.status = 'RETRYING'
            node_run.error_json = None
            node_run.attempt_count = (node_run.attempt_count or 0) + 1
            
            success_count += 1
            results.append({
                'node_code': node_code,
                'success': True,
                'attempt_count': node_run.attempt_count
            })
        
        await db.commit()
        
        return success_response({
            'success_count': success_count,
            'failed_count': failed_count,
            'results': results
        })
    
    except Exception as e:
        logger.error(f"Failed to batch retry nodes: {str(e)}")
        return error_response(f'Batch retry failed: {str(e)}', status_code=500)


@router.get("/history")
async def get_retry_history(
    task_run_id: Optional[int] = None,
    node_code: Optional[str] = None,
    limit: int = 50,
    db: AsyncSession = Depends(get_db)
):
    """
    获取重试历史记录 ⭐
    
    Args:
        task_run_id: 任务运行 ID（可选）
        node_code: 节点代码（可选）
        limit: 返回数量限制
        db: Database session
    
    Returns:
        {history, statistics}
    """
    try:
        retry_repo = get_retry_repository(db)
        records = await retry_repo.get_retry_history(
            task_run_id=task_run_id,
            node_code=node_code,
            limit=limit
        )
        
        history = [
            {
                'id': idx,
                'task_run_id': r.task_run_id,
                'node_code': r.node_code,
                'node_name': r.node_name,
                'attempt_number': r.attempt_number,
                'previous_status': r.previous_status,
                'new_status': r.new_status,
                'error_message': r.error_message,
                'retry_reason': r.retry_reason,
                'retried_by': r.retried_by,
                'retried_at': r.retried_at.isoformat(),
                'result_status': r.result_status,
                'result_message': r.result_message
            }
            for idx, r in enumerate(records)
        ]
        
        # 统计数据
        statistics = {}
        if task_run_id:
            statistics = await retry_repo.get_retry_statistics(task_run_id)
        
        return success_response({
            'history': history,
            'statistics': statistics
        })
    
    except Exception as e:
        logger.error(f"Failed to get retry history: {str(e)}")
        return error_response(f'Get history failed: {str(e)}', status_code=500)


@router.get("/status/{task_run_id}/{node_code}")
async def get_retry_status(
    task_run_id: int,
    node_code: str,
    db: AsyncSession = Depends(get_db)
):
    """
    获取节点重试状态 ⭐
    
    Args:
        task_run_id: 任务运行 ID
        node_code: 节点代码
        db: Database session
    
    Returns:
        RetryStatusResponse
    """
    try:
        from sqlalchemy import select
        
        # 查找节点
        result = await db.execute(
            select(NodeRun)
            .join(JobRun, NodeRun.job_run_id == JobRun.id)
            .where(
                JobRun.task_run_id == task_run_id,
                NodeRun.code == node_code
            )
        )
        node_run = result.scalar_one_or_none()
        
        if not node_run:
            return not_found_response(f'Node {node_code} not found')
        
        # 解析重试策略
        import json
        retry_policy = json.loads(node_run.retry_policy_json or '{}')
        max_retries = retry_policy.get('max_retries', 0)
        
        can_retry = (
            node_run.status == 'FAILED' and
            (max_retries == 0 or node_run.attempt_count < max_retries)
        )
        
        return success_response({
            'node_code': node_code,
            'node_name': node_run.node_name or node_run.code,
            'current_status': node_run.status,
            'attempt_count': node_run.attempt_count or 0,
            'max_retries': max_retries,
            'can_retry': can_retry,
            'last_error': json.loads(node_run.error_json or '{}').get('error'),
            'retry_policy': retry_policy
        })
    
    except Exception as e:
        logger.error(f"Failed to get retry status: {str(e)}")
        return error_response(f'Get status failed: {str(e)}', status_code=500)


@router.put("/policy")
async def update_retry_policy(
    request: RetryPolicyUpdateRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    更新节点重试策略 ⭐
    
    Args:
        request: RetryPolicyUpdateRequest
        db: Database session
    
    Returns:
        {success, message}
    """
    try:
        from sqlalchemy import select
        
        # 查找节点
        result = await db.execute(
            select(NodeRun)
            .join(JobRun, NodeRun.job_run_id == JobRun.id)
            .where(NodeRun.code == request.node_code)
        )
        node_run = result.scalar_one_or_none()
        
        if not node_run:
            return not_found_response(f'Node {request.node_code} not found')
        
        # 更新重试策略
        import json
        retry_policy = {
            'max_retries': request.max_retries,
            'backoff_seconds': request.backoff_seconds,
            'retry_on': request.retry_on
        }
        
        node_run.retry_policy_json = json.dumps(retry_policy)
        await db.commit()
        
        logger.info(f"Retry policy updated for node {request.node_code}: {retry_policy}")
        
        return success_response({
            'success': True,
            'message': f'Retry policy updated for node {request.node_code}'
        })
    
    except Exception as e:
        logger.error(f"Failed to update retry policy: {str(e)}")
        return error_response(f'Update policy failed: {str(e)}', status_code=500)
