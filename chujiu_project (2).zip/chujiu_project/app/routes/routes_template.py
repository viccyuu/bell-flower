# -*- coding: utf-8 -*-
"""
TaskTemplate API Routes - FastAPI ⭐
"""
from fastapi import APIRouter, HTTPException, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List, Optional

from app.database import get_db
from app.models import TaskTemplate

router = APIRouter()


@router.get("/task-templates")
async def list_task_templates(
    category: str = Query(default='all', description="类别：builtin | custom | all"),
    db: AsyncSession = Depends(get_db)
):
    """
    查询 TaskTemplate 列表 ⭐
    
    Args:
        category: 类别筛选
        db: 数据库会话
    
    Returns:
        模板列表
    """
    query = select(TaskTemplate)
    
    if category == 'builtin':
        query = query.filter(TaskTemplate.is_builtin == 1)
    elif category == 'custom':
        query = query.filter(TaskTemplate.is_builtin == 0)
    
    result = await db.execute(query)
    templates = result.scalars().all()
    
    result_list = []
    for template in templates:
        result_list.append({
            'code': template.code,
            'name': template.name,
            'description': template.description,
            'pluginCode': template.plugin_code,
            'isBuiltin': bool(template.is_builtin),
            'version': template.version,
            'category': 'builtin' if template.is_builtin else 'custom',
            'promptTemplates': []  # TODO: 从配置加载
        })
    
    return {'code': 'OK', 'data': result_list}


@router.get("/task-templates/{template_id}")
async def get_task_template(
    template_id: int,
    db: AsyncSession = Depends(get_db)
):
    """
    获取 TaskTemplate 详情 ⭐
    
    Args:
        template_id: 模板 ID
        db: 数据库会话
    
    Returns:
        模板详情
    """
    template = await db.get(TaskTemplate, template_id)
    if not template:
        raise HTTPException(
            status_code=404,
            detail=f'Template {template_id} not found'
        )
    
    return {
        'code': 'OK',
        'data': {
            'id': template.id,
            'code': template.code,
            'name': template.name,
            'description': template.description,
            'plugin_code': template.plugin_code,
            'params_schema_json': template.params_schema_json,
            'is_builtin': bool(template.is_builtin),
            'version': template.version
        }
    }
