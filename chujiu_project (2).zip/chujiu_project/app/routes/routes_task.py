# -*- coding: utf-8 -*-
"""
Task API Routes - FastAPI ⭐

统一响应格式 + 异步执行
"""
from fastapi import APIRouter, HTTPException, Depends, status, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List, Optional
import logging

from app.database import get_db
from app.models import TaskRun, TaskTemplate
from app.schemas.task import TaskCreate, TaskUpdate, TaskResponse, TaskListResponse, TaskStatus
from app.repository.task_repository import task_run_repository
from app.repository.upload_repository import upload_file_repository
from app.utils.response import success_response, error_response, created_response, not_found_response

logger = logging.getLogger(__name__)

router = APIRouter()


def _execute_task_background(task_run_id: int):
    """
    后台执行任务（不阻塞 API 响应）
    
    Args:
        task_run_id: TaskRun ID
    """
    try:
        from app.scheduler.task_scheduler import scheduler
        logger.info(f"Starting background execution for task {task_run_id}")
        scheduler.execute_task(task_run_id)
        logger.info(f"Background execution completed for task {task_run_id}")
    except Exception as e:
        logger.error(f"Background execution failed for task {task_run_id}: {str(e)}")


@router.post("/task-runs", status_code=status.HTTP_201_CREATED)
async def create_task_run(
    task: TaskCreate,
    db: AsyncSession = Depends(get_db)
):
    """
    Create TaskRun ⭐
    
    Args:
        task: TaskCreate request body
        db: Database session
    
    Returns:
        {code, data, message}
    """
    try:
        # Check template exists
        template = await db.get(TaskTemplate, task.template_id)
        if not template:
            return not_found_response(f'Template {task.template_id} not found')
        
        # Check uploadId (if provided)
        if task.upload_file_id:
            upload_file = await upload_file_repository.get(task.upload_file_id)
            if not upload_file:
                return not_found_response(f'Upload {task.upload_file_id} not found')
        
        # Create TaskRun
        task_run = TaskRun(
            task_template_id=task.template_id,
            upload_file_id=task.upload_file_id,
            runtime_params_json=task.runtime_params,
            status='CREATED'
        )
        
        db.add(task_run)
        await db.commit()
        await db.refresh(task_run)
        
        return created_response(task_run, 'Task created successfully')
    
    except Exception as e:
        logger.error(f"Failed to create task: {str(e)}")
        return error_response(f'Task creation failed: {str(e)}', status_code=500)


@router.post("/task-runs/{task_run_id}/start")
async def start_task_run(
    task_run_id: int,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db)
):
    """
    Start TaskRun ⭐
    
    Args:
        task_run_id: TaskRun ID
        background_tasks: FastAPI BackgroundTasks
        db: Database session
    
    Returns:
        {code, data, message}
    """
    task_run = await db.get(TaskRun, task_run_id)
    if not task_run:
        return not_found_response(f'TaskRun {task_run_id} not found')
    
    # Idempotency handling
    if task_run.status == 'RUNNING':
        return success_response(task_run, 'Task is already running')
    
    if task_run.status == 'SUCCESS':
        return success_response(task_run, 'Task has already completed successfully')
    
    if task_run.status not in ['CREATED', 'READY', 'RETRYING']:
        return error_response(
            f'Cannot start task in status {task_run.status}',
            code='INVALID_STATUS'
        )
    
    # Update status to RUNNING
    task_run.status = 'RUNNING'
    from datetime import datetime, timezone
    task_run.started_at = datetime.now(timezone.utc)
    
    await db.commit()
    await db.refresh(task_run)
    
    # Trigger async execution in background (不阻塞)
    background_tasks.add_task(_execute_task_background, task_run.id)
    
    return success_response(task_run, 'Task started successfully')


@router.get("/task-runs/{task_run_id}")
async def get_task_run(
    task_run_id: int,
    db: AsyncSession = Depends(get_db)
):
    """
    Get TaskRun detail ⭐
    
    Args:
        task_run_id: TaskRun ID
        db: Database session
    
    Returns:
        {code, data, message}
    """
    task_run = await db.get(TaskRun, task_run_id)
    if not task_run:
        return not_found_response(f'TaskRun {task_run_id} not found')
    
    # Get associated JobRuns
    from app.models import JobRun, NodeRun
    from sqlalchemy import select
    
    job_runs = await db.execute(
        select(JobRun).where(JobRun.task_run_id == task_run_id)
    )
    job_runs = job_runs.scalars().all()
    
    # Get NodeRuns for each job
    task_data = {
        'id': task_run.id,
        'task_template_id': task_run.task_template_id,
        'status': task_run.status,
        'started_at': task_run.started_at,
        'finished_at': task_run.finished_at,
        'created_at': task_run.created_at,
        'jobs': []
    }
    
    for job in job_runs:
        node_runs = await db.execute(
            select(NodeRun).where(NodeRun.job_run_id == job.id)
        )
        node_runs = node_runs.scalars().all()
        
        task_data['jobs'].append({
            'id': job.id,
            'code': job.code,
            'name': job.name,
            'status': job.status,
            'node_runs': [
                {
                    'id': node.id,
                    'code': node.code,
                    'name': node.code,
                    'action_type': node.action_type,
                    'status': node.status,
                    'input_json': node.input_json,
                    'output_json': node.output_json,
                    'error_json': node.error_json,
                    'attempt_count': node.attempt_count,
                    'started_at': node.started_at,
                    'finished_at': node.finished_at
                }
                for node in node_runs
            ]
        })
    
    return success_response(task_data)


@router.post("/task-runs/{task_run_id}/nodes/{node_code}/retry")
async def retry_node(
    task_run_id: int,
    node_code: str,
    db: AsyncSession = Depends(get_db)
):
    """
    Retry a failed node ⭐
    
    Args:
        task_run_id: TaskRun ID
        node_code: Node code
        db: Database session
    
    Returns:
        {code, data, message}
    """
    try:
        # Get task
        task_run = await db.get(TaskRun, task_run_id)
        if not task_run:
            return not_found_response(f'TaskRun {task_run_id} not found')
        
        # Get node
        from app.models import NodeRun
        from sqlalchemy import select
        
        result = await db.execute(
            select(NodeRun).where(
                NodeRun.job_run_id == JobRun.id,
                NodeRun.code == node_code
            )
        )
        node_run = result.scalar_one_or_none()
        
        if not node_run:
            return not_found_response(f'Node {node_code} not found')
        
        if node_run.status != 'FAILED':
            return error_response(
                f'Node {node_code} status is {node_run.status}, only FAILED nodes can be retried',
                code='INVALID_STATUS'
            )
        
        # Reset node status to PENDING
        node_run.status = 'PENDING'
        node_run.error_json = None
        node_run.attempt_count = (node_run.attempt_count or 0) + 1
        
        await db.commit()
        
        return success_response(
            {'node_code': node_code, 'status': 'PENDING'},
            f'Node {node_code} has been queued for retry'
        )
    
    except Exception as e:
        logger.error(f"Failed to retry node: {str(e)}")
        return error_response(f'Retry failed: {str(e)}', status_code=500)


@router.get("/task-runs")
async def list_task_runs(
    page: int = 1,
    page_size: int = 20,
    status: Optional[TaskStatus] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    List TaskRuns ⭐
    
    Args:
        page: Page number
        page_size: Page size
        status: Filter by status
        db: Database session
    
    Returns:
        {code, data: {tasks, total, page, page_size}, message}
    """
    from app.models import TaskRun
    from sqlalchemy import select, func
    
    # Build query
    query = select(TaskRun)
    if status:
        query = query.where(TaskRun.status == status)
    
    # Get total count
    total_query = select(func.count(TaskRun.id))
    if status:
        total_query = total_query.where(TaskRun.status == status)
    
    total = await db.execute(total_query)
    total = total.scalar()
    
    # Apply pagination
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    # Execute query
    result = await db.execute(query)
    tasks = result.scalars().all()
    
    return success_response({
        'tasks': [
            {
                'id': task.id,
                'task_template_id': task.task_template_id,
                'status': task.status,
                'started_at': task.started_at,
                'finished_at': task.finished_at,
                'created_at': task.created_at
            }
            for task in tasks
        ],
        'total': total,
        'page': page,
        'page_size': page_size
    })
