# -*- coding: utf-8 -*-
"""
Artifact API Routes - FastAPI ⭐
"""
from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List, Optional
import os

from app.database import get_db
from app.models import Artifact

router = APIRouter()


@router.get("/artifacts")
async def list_artifacts(
    limit: int = 50,
    db: AsyncSession = Depends(get_db)
):
    """
    查询产物列表 ⭐
    
    Args:
        limit: 限制结果数量
        db: 数据库会话
    
    Returns:
        产物列表
    """
    result = await db.execute(
        select(Artifact)
        .order_by(Artifact.created_at.desc())
        .limit(limit)
    )
    artifacts = result.scalars().all()
    
    data = [{
        'id': a.id,
        'fileName': a.name,
        'fileType': a.artifact_type,
        'fileSize': len(a.content_text) if a.content_text else 0,
        'createdAt': a.created_at.isoformat() if a.created_at else None
    } for a in artifacts]
    
    return {'code': 'OK', 'data': data}


@router.get("/artifacts/{artifact_id}/download")
async def download_artifact(
    artifact_id: int,
    db: AsyncSession = Depends(get_db)
):
    """
    下载产物 ⭐
    
    Args:
        artifact_id: 产物 ID
        db: 数据库会话
    
    Returns:
        文件流
    """
    artifact = await db.get(Artifact, artifact_id)
    if not artifact:
        raise HTTPException(
            status_code=404,
            detail=f'Artifact {artifact_id} not found'
        )
    
    if not artifact.file_path:
        raise HTTPException(
            status_code=400,
            detail='Artifact has no file path'
        )
    
    if not os.path.exists(artifact.file_path):
        raise HTTPException(
            status_code=404,
            detail=f'File not found: {artifact.file_path}'
        )
    
    from fastapi.responses import FileResponse
    return FileResponse(
        path=artifact.file_path,
        filename=artifact.name,
        media_type='application/octet-stream'
    )


@router.get("/artifacts/{artifact_id}")
async def get_artifact(
    artifact_id: int,
    db: AsyncSession = Depends(get_db)
):
    """
    获取产物详情 ⭐
    
    Args:
        artifact_id: 产物 ID
        db: 数据库会话
    
    Returns:
        产物详情
    """
    artifact = await db.get(Artifact, artifact_id)
    if not artifact:
        raise HTTPException(
            status_code=404,
            detail=f'Artifact {artifact_id} not found'
        )
    
    return {
        'code': 'OK',
        'data': {
            'id': artifact.id,
            'name': artifact.name,
            'artifact_type': artifact.artifact_type,
            'file_path': artifact.file_path,
            'content_text': artifact.content_text,
            'content_json': artifact.content_json,
            'created_at': artifact.created_at.isoformat() if artifact.created_at else None
        }
    }
