# -*- coding: utf-8 -*-
"""
Prompts API Routes - FastAPI ⭐
"""
from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List, Optional

from app.database import get_db

# 临时使用内存存储（实际应该从数据库加载）
_prompts = [
    {
        'id': 1,
        'name': 'vba_to_ast',
        'description': 'VBA 代码转 AST',
        'system_prompt': '你是 VBA 语法分析专家。请将输入 VBA 源码转换为结构化 AST。',
        'user_prompt_template': '请将以下 VBA 代码转换为结构化 AST：\n\n```vba\n{code}\n```',
        'category': 'conversion'
    },
    {
        'id': 2,
        'name': 'review_ast',
        'description': 'AST 审查',
        'system_prompt': '你是 AST 审查器。请检查 AST 是否完整、结构合法。',
        'user_prompt_template': '请审查以下 AST：\n\n```json\n{ast}\n```',
        'category': 'review'
    },
    {
        'id': 3,
        'name': 'ast_to_source',
        'description': 'AST 转源码',
        'system_prompt': '请将 AST 转换为可执行的源码。',
        'user_prompt_template': '请将以下 AST 转换为源码：\n\n```json\n{ast}\n```',
        'category': 'conversion'
    }
]


router = APIRouter()


@router.get("/prompts")
async def list_prompts(
    category: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    查询 Prompt 列表 ⭐
    
    Args:
        category: 类别筛选
        db: 数据库会话
    
    Returns:
        Prompt 列表
    """
    prompts = _prompts
    
    if category:
        prompts = [p for p in prompts if p.get('category') == category]
    
    return {'code': 'OK', 'data': prompts}


@router.get("/prompts/{prompt_id}")
async def get_prompt(
    prompt_id: int,
    db: AsyncSession = Depends(get_db)
):
    """
    获取 Prompt 详情 ⭐
    
    Args:
        prompt_id: Prompt ID
        db: 数据库会话
    
    Returns:
        Prompt 详情
    """
    prompt = next((p for p in _prompts if p['id'] == prompt_id), None)
    if not prompt:
        raise HTTPException(
            status_code=404,
            detail=f'Prompt {prompt_id} not found'
        )
    
    return {'code': 'OK', 'data': prompt}


@router.post("/prompts")
async def create_prompt(
    prompt_data: dict,
    db: AsyncSession = Depends(get_db)
):
    """
    创建 Prompt ⭐
    
    Args:
        prompt_data: Prompt 数据
        db: 数据库会话
    
    Returns:
        创建结果
    """
    new_id = max(p['id'] for p in _prompts) + 1 if _prompts else 1
    new_prompt = {
        'id': new_id,
        **prompt_data
    }
    _prompts.append(new_prompt)
    
    return {
        'code': 'OK',
        'data': {'id': new_id, 'message': 'Prompt created'}
    }


@router.put("/prompts/{prompt_id}")
async def update_prompt(
    prompt_id: int,
    prompt_data: dict,
    db: AsyncSession = Depends(get_db)
):
    """
    更新 Prompt ⭐
    
    Args:
        prompt_id: Prompt ID
        prompt_data: Prompt 数据
        db: 数据库会话
    
    Returns:
        更新结果
    """
    prompt = next((p for p in _prompts if p['id'] == prompt_id), None)
    if not prompt:
        raise HTTPException(
            status_code=404,
            detail=f'Prompt {prompt_id} not found'
        )
    
    prompt.update(prompt_data)
    
    return {'code': 'OK', 'message': 'Prompt updated'}


@router.delete("/prompts/{prompt_id}")
async def delete_prompt(
    prompt_id: int,
    db: AsyncSession = Depends(get_db)
):
    """
    删除 Prompt ⭐
    
    Args:
        prompt_id: Prompt ID
        db: 数据库会话
    
    Returns:
        删除结果
    """
    global _prompts
    prompt = next((p for p in _prompts if p['id'] == prompt_id), None)
    if not prompt:
        raise HTTPException(
            status_code=404,
            detail=f'Prompt {prompt_id} not found'
        )
    
    _prompts = [p for p in _prompts if p['id'] != prompt_id]
    
    return {'code': 'OK', 'message': 'Prompt deleted'}
