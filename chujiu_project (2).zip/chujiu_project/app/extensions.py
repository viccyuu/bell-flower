# -*- coding: utf-8 -*-
"""
Database Configuration - SQLAlchemy Async ⭐

FastAPI 异步数据库配置
"""
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import declarative_base
from typing import AsyncGenerator
import logging

logger = logging.getLogger(__name__)

# 数据库 URL（从配置读取）
DATABASE_URL = "sqlite+aiosqlite:///./chujiu.db"


# ========== 异步 Base ==========
Base = declarative_base()


# ========== 异步引擎 ==========
# SQLite 不支持连接池，使用 NullPool
engine = create_async_engine(
    DATABASE_URL,
    echo=False,  # 生产环境关闭 SQL 日志
    future=True,
    connect_args={'check_same_thread': False}
)


# ========== 异步 Session ==========
async_session = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False,
)


# ========== 依赖注入：获取数据库会话 ==========
async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    获取数据库会话（FastAPI 依赖注入）⭐
    
    Yields:
        AsyncSession: 数据库会话
    """
    async with async_session() as session:
        try:
            yield session
            await session.commit()
        except Exception as e:
            await session.rollback()
            logger.error(f"Database session error: {str(e)}")
            raise
        finally:
            await session.close()


# ========== 数据库初始化 ==========
async def init_db():
    """创建所有表"""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Database tables created")


async def close_db():
    """关闭引擎"""
    await engine.dispose()
    logger.info("Database connection closed")


# ========== 兼容层：同步 Session（过渡期使用） ==========
def get_sync_db():
    """
    获取同步数据库会话（Flask 兼容）
    
    过渡期使用，迁移完成后删除
    
    Yields:
        Session: 同步数据库会话
    """
    from sqlalchemy.orm import Session
    
    sync_engine = engine.sync_engine
    session = Session(sync_engine)
    
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
