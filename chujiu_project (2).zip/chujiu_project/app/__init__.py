# -*- coding: utf-8 -*-
"""
Chujiu TodoList Application Factory
FastAPI Application Factory Pattern
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import logging

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    logger.info("Starting Chujiu Design API...")
    
    # 初始化数据库
    from app.database import init_db
    await init_db()
    logger.info("Database initialized")
    
    # 初始化插件系统
    from app.plugins.plugin_registry import init_plugins
    init_plugins()
    logger.info("Plugins initialized")
    
    yield
    
    # 关闭时清理
    logger.info("Shutting down Chujiu Design API...")
    
    from app.database import close_db
    await close_db()
    logger.info("Database connection closed")


def create_app() -> FastAPI:
    """Application Factory Function - FastAPI"""
    
    app = FastAPI(
        title="Chujiu Design API",
        description="VBA to WPS JS Converter - Task Management System",
        version="2.0.0",
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
        lifespan=lifespan,
    )
    
    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # 注册所有 FastAPI 路由
    from app.routes.routes_upload import router as upload_router
    from app.routes.routes_task import router as task_router
    from app.routes.routes_artifact import router as artifact_router
    from app.routes.routes_template import router as template_router
    from app.routes.routes_plugins import router as plugins_router
    from app.routes.routes_prompts import router as prompts_router
    from app.routes.routes_subjob import router as subjob_router
    from app.routes.routes_retry import router as retry_router
    
    api_prefix = '/api'
    app.include_router(upload_router, prefix=f"{api_prefix}/uploads", tags=["uploads"])
    app.include_router(task_router, prefix=f"{api_prefix}/tasks", tags=["tasks"])
    app.include_router(artifact_router, prefix=f"{api_prefix}/artifacts", tags=["artifacts"])
    app.include_router(template_router, prefix=f"{api_prefix}/templates", tags=["templates"])
    app.include_router(plugins_router, prefix=f"{api_prefix}/plugins", tags=["plugins"])
    app.include_router(prompts_router, prefix=f"{api_prefix}/prompts", tags=["prompts"])
    app.include_router(subjob_router, prefix=f"{api_prefix}/subjobs", tags=["subjobs"])
    app.include_router(retry_router, prefix=f"{api_prefix}/retry", tags=["retry"])
    
    # Root path
    @app.get("/")
    async def root():
        return {
            "message": "Welcome to Chujiu Design API",
            "version": "3.0.0",
            "docs": "/docs",
            "health": "/health"
        }
    
    # Health check
    @app.get("/health")
    async def health_check():
        return {"status": "healthy", "version": "3.0.0"}
    
    return app


# 不自动创建 app，只在需要时创建
# app = create_app()
