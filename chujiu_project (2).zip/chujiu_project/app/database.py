# -*- coding: utf-8 -*-
"""
数据库配置 - SQLAlchemy 异步 ORM

为 FastAPI 迁移准备的异步数据库配置
"""
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import declarative_base
from typing import AsyncGenerator
import logging

logger = logging.getLogger(__name__)

# 数据库 URL（从配置读取）
# 测试环境使用：sqlite+aiosqlite:///:memory:
# 生产环境使用：sqlite+aiosqlite:///./chujiu.db
DATABASE_URL = "sqlite+aiosqlite:///./chujiu.db"


# 创建异步引擎
engine = create_async_engine(
    DATABASE_URL,
    echo=False,  # 生产环境关闭 SQL 日志
    future=True,
    pool_pre_ping=True,  # 连接前检查
)

# Session 工厂
async_session = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False,
)

# 基类
Base = declarative_base()


# ============================================================================
# 依赖注入：获取数据库会话（FastAPI 使用）
# ============================================================================

async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    获取数据库会话（FastAPI 依赖注入）⭐
    
    Yields:
        AsyncSession: 数据库会话
    """
    async with async_session() as session:
        try:
            yield session
            await session.commit()
        except Exception as e:
            await session.rollback()
            logger.error(f"Database session error: {str(e)}")
            raise
        finally:
            await session.close()


# ============================================================================
# 数据库初始化
# ============================================================================

async def init_db():
    """创建所有表"""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Database tables created")


async def close_db():
    """关闭引擎"""
    await engine.dispose()
    logger.info("Database connection closed")


# ============================================================================
# 兼容层：Flask 同步 Session（过渡期使用）
# ============================================================================

def get_sync_db():
    """
    获取同步数据库会话（Flask 兼容）
    
    过渡期使用，迁移到 FastAPI 后删除
    
    Yields:
        Session: 同步数据库会话
    """
    from sqlalchemy.orm import Session
    
    sync_engine = create_async_engine(DATABASE_URL).sync_engine
    session = Session(sync_engine)
    
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
