﻿# -*- coding: utf-8 -*-

"""Simple in-memory session storage."""

from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any
import json


@dataclass
class Session:
    """Represents a conversation session."""
    key: str
    messages: list[dict[str, Any]] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    
    def get_history(self, max_messages: int = 100) -> list[dict[str, Any]]:
        """Get session history, limited to max_messages."""
        return self.messages[-max_messages:]
    
    def clear(self) -> None:
        """Clear all messages."""
        self.messages = []
        self.updated_at = datetime.now()


class SessionManager:
    """Manages session storage."""
    
    def __init__(self, workspace: Path):
        self.workspace = workspace
        self.sessions_dir = workspace / "sessions"
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self._cache: dict[str, Session] = {}
    
    def get_or_create(self, key: str) -> Session:
        """Get or create a session by key."""
        if key in self._cache:
            return self._cache[key]
        
        session_file = self.sessions_dir / f"{key.replace(':', '_')}.json"
        if session_file.exists():
            try:
                data = json.loads(session_file.read_text(encoding="utf-8"))
                session = Session(
                    key=key,
                    messages=data.get("messages", []),
                    created_at=datetime.fromisoformat(data["created_at"]),
                    updated_at=datetime.fromisoformat(data["updated_at"]),
                )
                self._cache[key] = session
                return session
            except Exception:
                pass
        
        session = Session(key=key)
        self._cache[key] = session
        return session
    
    def save(self, session: Session) -> None:
        """Save session to disk."""
        session_file = self.sessions_dir / f"{session.key.replace(':', '_')}.json"
        data = {
            "key": session.key,
            "messages": session.messages,
            "created_at": session.created_at.isoformat(),
            "updated_at": session.updated_at.isoformat(),
        }
        session_file.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    
    def invalidate(self, key: str) -> None:
        """Remove session from cache."""
        self._cache.pop(key, None)
