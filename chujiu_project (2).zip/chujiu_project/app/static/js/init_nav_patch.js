// 鍒濆鍖栧鑸?function initNav() {
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const page = item.dataset.page;
            
            // 鏇存柊 URL 鍝堝笇
            window.location.hash = page;
            
            // 鍔犺浇瀵瑰簲椤甸潰
            loadPage(page);
        });
    });
    
    // 鐩戝惉鍝堝笇鍙樺寲锛屾敮鎸佹祻瑙堝櫒鍓嶈繘/鍚庨€€
    window.addEventListener('hashchange', () => {
        const hash = window.location.hash.slice(1);
        if (hash) {
            loadPage(hash);
        }
    });
    
    // 椤甸潰鍔犺浇鏃舵鏌ュ搱甯?    const initialHash = window.location.hash.slice(1);
    if (initialHash) {
        loadPage(initialHash);
    }
}