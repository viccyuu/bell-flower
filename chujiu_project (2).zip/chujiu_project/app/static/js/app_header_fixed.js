// Chujiu TodoList Frontend Application - OpenClaw Style

const API_BASE = '/api';

// Page state
let currentPage = 'dashboard';
let healthStatus = 'disconnected';

// DOM elements
const contentArea = document.getElementById('content-area');
const pageTitle = document.getElementById('page-title');
const statusDot = document.getElementById('status-dot');
const statusText = document.getElementById('status-text');
const healthDot = document.getElementById('health-dot');
const healthText = document.getElementById('health-text');
const refreshBtn = document.getElementById('refresh-btn');
const navItems = document.querySelectorAll('.nav-item');
const versionBadge = document.getElementById('version-badge');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initNav();
    initRefresh();
    checkHealth();
    loadPage('dashboard');
    setInterval(checkHealth, 30000);
});

// Initialize navigation
function initNav() {
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const page = item.dataset.page;
            
            // Update URL hash
            window.location.hash = page;
            
            // Load corresponding page
            loadPage(page);
        });
    });
    
    // Listen for hash changes (browser back/forward)
    window.addEventListener('hashchange', () => {
        const hash = window.location.hash.slice(1);
        if (hash) {
            loadPage(hash);
        }
    });
    
    // Check hash on page load
    const initialHash = window.location.hash.slice(1);
    if (initialHash) {
        loadPage(initialHash);
    }
}

// Initialize refresh button
function initRefresh() {
    refreshBtn.addEventListener('click', () => {
        loadPage(currentPage);
        showToast('宸插埛鏂?, 'info');
    });
}
