/**
 * DAG Viewer - FastAPI Version
 * 可视化展示任务 DAG 流程图
 */

// 节点类型图标映射 (避免重复声明)
if (typeof NODE_ICONS === 'undefined') {
    var NODE_ICONS = {
        PYTHON: '🐍',
        LLM: '🤖',
        FILE: '📁',
        API: '🌐',
        SQL: '📊',
        BASH: '💻',
        DEFAULT: '📦'
    };
}

// DAG 颜色配置 (避免重复声明)
if (typeof DAG_COLORS === 'undefined') {
    var DAG_COLORS = {
        cardBg: '#ffffff',
        textPrimary: '#1f2937',
        textSecondary: '#6b7280',
        statusSuccess: '#10b981',
        statusFailed: '#ef4444',
        statusRunning: '#3b82f6',
        statusPending: '#9ca3af'
    };
}

/**
 * 渲染 DAG 流程图
 */
function renderDagViewer(containerId, dagData) {
    const container = document.getElementById(containerId);
    if (!container || !dagData) return;
    
    const nodes = dagData.nodes || [];
    const edges = dagData.edges || [];
    
    if (nodes.length === 0) {
        container.innerHTML = '<p class="text-gray-500">暂无节点数据</p>';
        return;
    }
    
    // 计算布局
    const layout = calculateDagLayout(nodes);
    
    // 创建 SVG
    const svg = createDagSvg(layout, nodes, edges);
    
    // 清空容器并添加 SVG
    container.innerHTML = '';
    container.appendChild(svg);
}

/**
 * 计算 DAG 布局
 */
function calculateDagLayout(nodes) {
    const nodesPerRow = 4;
    const nodeWidth = 280;
    const nodeHeight = 80;
    const paddingX = 40;
    const paddingY = 40;
    
    const rows = Math.ceil(nodes.length / nodesPerRow);
    const width = nodesPerRow * (nodeWidth + paddingX) + paddingX;
    const height = rows * (nodeHeight + paddingY) + paddingY;
    
    return {
        width,
        height,
        nodesPerRow,
        nodeWidth,
        nodeHeight,
        paddingX,
        paddingY
    };
}

/**
 * 创建 SVG 元素
 */
function createDagSvg(layout, nodes, edges) {
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    
    svg.setAttribute('width', '100%');
    svg.setAttribute('height', layout.height);
    svg.setAttribute('viewBox', `0 0 ${layout.width} ${layout.height}`);
    svg.style.background = DAG_COLORS.cardBg;
    svg.style.borderRadius = '12px';
    
    // Create defs (arrows)
    const defs = createDagDefs(ns);
    svg.appendChild(defs);
    
    // Draw edges
    edges.forEach(edge => {
        const fromIndex = nodes.findIndex(n => n.code === edge.from);
        const toIndex = nodes.findIndex(n => n.code === edge.to);
        
        if (fromIndex === -1 || toIndex === -1) return;
        
        const fromPos = getNodePosition(fromIndex, layout);
        const toPos = getNodePosition(toIndex, layout);
        
        const path = createDagEdge(ns, fromPos, toPos, layout);
        svg.appendChild(path);
    });
    
    // Draw nodes
    nodes.forEach((node, index) => {
        const pos = getNodePosition(index, layout);
        const nodeGroup = createDagNode(ns, node, pos, layout);
        svg.appendChild(nodeGroup);
    });
    
    return svg;
}

/**
 * 创建 SVG 定义（箭头等）
 */
function createDagDefs(ns) {
    const defs = document.createElementNS(ns, 'defs');
    
    // Arrow marker
    const marker = document.createElementNS(ns, 'marker');
    marker.setAttribute('id', 'dag-arrowhead');
    marker.setAttribute('markerWidth', '10');
    marker.setAttribute('markerHeight', '7');
    marker.setAttribute('refX', '9');
    marker.setAttribute('refY', '3.5');
    marker.setAttribute('orient', 'auto');
    
    const markerPath = document.createElementNS(ns, 'polygon');
    markerPath.setAttribute('points', '0 0, 10 3.5, 0 7');
    markerPath.setAttribute('fill', DAG_COLORS.textSecondary);
    markerPath.setAttribute('opacity', '0.5');
    
    marker.appendChild(markerPath);
    defs.appendChild(marker);
    
    return defs;
}

/**
 * 获取节点位置
 */
function getNodePosition(index, layout) {
    const row = Math.floor(index / layout.nodesPerRow);
    const col = index % layout.nodesPerRow;
    
    return {
        x: layout.paddingX + col * (layout.nodeWidth + layout.paddingX),
        y: layout.paddingY + row * (layout.nodeHeight + layout.paddingY),
        width: layout.nodeWidth,
        height: layout.nodeHeight
    };
}

/**
 * 创建边（连线）
 */
function createDagEdge(ns, from, to, layout) {
    const startX = from.x + from.width / 2;
    const startY = from.y + from.height;
    const endX = to.x + to.width / 2;
    const endY = to.y;
    
    // Bezier curve
    const controlY1 = startY + 30;
    const controlY2 = endY - 30;
    
    const path = document.createElementNS(ns, 'path');
    path.setAttribute('d', `M ${startX} ${startY} C ${startX} ${controlY1}, ${endX} ${controlY2}, ${endX} ${endY}`);
    path.setAttribute('stroke', DAG_COLORS.textSecondary);
    path.setAttribute('stroke-width', '2');
    path.setAttribute('fill', 'none');
    path.setAttribute('marker-end', 'url(#dag-arrowhead)');
    path.setAttribute('opacity', '0.4');
    
    return path;
}

/**
 * 创建节点
 */
function createDagNode(ns, node, pos, layout) {
    const group = document.createElementNS(ns, 'g');
    
    // Get status colors
    const statusColors = getDagStatusColors(node.status);
    
    // Node background (rounded rectangle)
    const rect = document.createElementNS(ns, 'rect');
    rect.setAttribute('x', pos.x);
    rect.setAttribute('y', pos.y);
    rect.setAttribute('width', pos.width);
    rect.setAttribute('height', pos.height);
    rect.setAttribute('rx', '10');
    rect.setAttribute('ry', '10');
    rect.setAttribute('fill', statusColors.bg);
    rect.setAttribute('stroke', statusColors.border);
    rect.setAttribute('stroke-width', '2.5');
    group.appendChild(rect);
    
    // Node type icon
    const icon = NODE_ICONS[node.action_type] || NODE_ICONS.DEFAULT;
    const iconText = document.createElementNS(ns, 'text');
    iconText.setAttribute('x', pos.x + 16);
    iconText.setAttribute('y', pos.y + pos.height / 2 + 6);
    iconText.setAttribute('font-size', '20');
    iconText.textContent = icon;
    group.appendChild(iconText);
    
    // Node name
    const nameText = document.createElementNS(ns, 'text');
    nameText.setAttribute('x', pos.x + 44);
    nameText.setAttribute('y', pos.y + pos.height / 2 - 6);
    nameText.setAttribute('fill', DAG_COLORS.textPrimary);
    nameText.setAttribute('font-size', '13');
    nameText.setAttribute('font-weight', '600');
    nameText.textContent = truncateText(node.name || node.code, 15);
    group.appendChild(nameText);
    
    // Node code
    const codeText = document.createElementNS(ns, 'text');
    codeText.setAttribute('x', pos.x + 44);
    codeText.setAttribute('y', pos.y + pos.height / 2 + 12);
    codeText.setAttribute('fill', DAG_COLORS.textSecondary);
    codeText.setAttribute('font-size', '11');
    codeText.textContent = node.code;
    group.appendChild(codeText);
    
    // Status indicator (small circle in top-right)
    const indicator = document.createElementNS(ns, 'circle');
    indicator.setAttribute('cx', pos.x + pos.width - 12);
    indicator.setAttribute('cy', pos.y + 12);
    indicator.setAttribute('r', '6');
    indicator.setAttribute('fill', statusColors.border);
    group.appendChild(indicator);
    
    // Hover effect
    group.style.cursor = 'pointer';
    group.addEventListener('mouseenter', () => {
        rect.setAttribute('stroke-width', '3.5');
    });
    group.addEventListener('mouseleave', () => {
        rect.setAttribute('stroke-width', '2.5');
    });
    
    // Click event
    group.addEventListener('click', () => {
        showNodeDetail(node);
    });
    
    return group;
}

/**
 * 获取状态颜色
 */
function getDagStatusColors(status) {
    const colors = {
        'PENDING': { bg: '#f9fafb', border: '#9ca3af' },
        'READY': { bg: '#eff6ff', border: '#3b82f6' },
        'RUNNING': { bg: '#eff6ff', border: '#3b82f6' },
        'SUCCESS': { bg: '#ecfdf5', border: '#10b981' },
        'FAILED': { bg: '#fef2f2', border: '#ef4444' },
        'SKIPPED': { bg: '#f3f4f6', border: '#9ca3af' },
        'RETRYING': { bg: '#fffbeb', border: '#f59e0b' }
    };
    
    return colors[status] || colors.PENDING;
}

/**
 * 截断文本
 */
function truncateText(text, maxLength) {
    if (!text) return '';
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength - 2) + '...';
}

/**
 * 显示节点详情（集成重试功能）⭐
 */
function showNodeDetail(node) {
    // 如果是 FAILED 状态，显示重试对话框
    if (node.status === 'FAILED' && typeof window.retryManager !== 'undefined') {
        // 获取 task_run_id（从全局上下文或节点数据）
        const taskRunId = window.currentTaskRunId || node.task_run_id;
        
        if (taskRunId) {
            window.retryManager.openRetryModal(taskRunId, node.code);
            return;
        }
    }
    
    // 默认显示详情（原有逻辑）
    const detailHtml = `
        <div class="p-4">
            <h3 class="text-lg font-bold mb-2">${node.name || node.code}</h3>
            <div class="space-y-2 text-sm">
                <p><strong>Code:</strong> ${node.code}</p>
                <p><strong>Type:</strong> ${node.action_type}</p>
                <p><strong>Status:</strong> ${node.status}</p>
                ${node.timeout_seconds ? `<p><strong>Timeout:</strong> ${node.timeout_seconds}s</p>` : ''}
            </div>
        </div>
    `;
    
    // 简单实现：使用 alert
    alert(`Node: ${node.name || node.code}\nType: ${node.action_type}\nStatus: ${node.status}`);
}

/**
 * 设置当前任务 ID（用于重试功能）⭐
 */
function setCurrentTaskRunId(taskRunId) {
    window.currentTaskRunId = taskRunId;
}

/**
 * 节点重试回调（由 retry-manager 调用）⭐
 */
function onNodeRetry(taskRunId) {
    console.log(`Node retry initiated for task ${taskRunId}`);
    
    // 自动刷新 DAG 视图
    setTimeout(() => {
        if (typeof window.refreshDagView === 'function') {
            window.refreshDagView(taskRunId);
        }
    }, 2000);
}

// 导出全局回调
window.onNodeRetry = onNodeRetry;
window.setCurrentTaskRunId = setCurrentTaskRunId;

// 导出函数
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        renderDagViewer,
        calculateDagLayout,
        createDagSvg,
        getDagStatusColors
    };
}
