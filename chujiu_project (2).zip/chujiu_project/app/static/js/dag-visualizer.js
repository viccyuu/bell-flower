/**
 * DAG Visualization Component
 * 
 * Renders interactive DAG graph using SVG
 */

class DagVisualizer {
    /**
     * Initialize DAG visualizer
     * @param {string} containerId - Container element ID
     * @param {object} dagData - DAG data with nodes and edges
     */
    constructor(containerId, dagData) {
        this.containerId = containerId;
        this.dagData = dagData;
        this.zoom = 1;
        this.panX = 0;
        this.panY = 0;
        this.nodeWidth = 200;
        this.nodeHeight = 80;
        this.layerSpacing = 250;
        this.nodeSpacing = 100;
        
        this.init();
    }
    
    /**
     * Initialize the visualization
     */
    init() {
        const container = document.getElementById(this.containerId);
        if (!container) {
            console.error(`Container ${this.containerId} not found`);
            return;
        }
        
        // Calculate layout
        const layers = this.calculateLayers();
        const svgSize = this.calculateSvgSize(layers);
        
        // Create SVG
        const svg = this.createSVG(svgSize);
        container.innerHTML = '';
        container.appendChild(svg);
        
        // Draw elements
        this.drawEdges(svg, layers);
        this.drawNodes(svg, layers);
        
        // Add controls
        this.addControls(container);
    }
    
    /**
     * Calculate node layers using topological sort
     */
    calculateLayers() {
        const nodes = this.dagData.nodes || [];
        const edges = this.dagData.edges || [];
        
        // Build adjacency list
        const adj = {};
        const inDegree = {};
        
        nodes.forEach(node => {
            adj[node.code] = [];
            inDegree[node.code] = 0;
        });
        
        edges.forEach(edge => {
            if (adj[edge.from]) {
                adj[edge.from].push(edge.to);
                inDegree[edge.to] = (inDegree[edge.to] || 0) + 1;
            }
        });
        
        // Kahn's algorithm for topological sort with layers
        const layers = [];
        const queue = nodes.filter(n => inDegree[n.code] === 0).map(n => n.code);
        
        while (queue.length > 0) {
            const layer = [];
            const nextQueue = [];
            
            queue.forEach(nodeCode => {
                const node = nodes.find(n => n.code === nodeCode);
                if (node) {
                    layer.push(node);
                }
                
                adj[nodeCode].forEach(neighbor => {
                    inDegree[neighbor]--;
                    if (inDegree[neighbor] === 0) {
                        nextQueue.push(neighbor);
                    }
                });
            });
            
            if (layer.length > 0) {
                layers.push(layer);
            }
            
            queue.length = 0;
            queue.push(...nextQueue);
        }
        
        return layers;
    }
    
    /**
     * Calculate SVG size based on layers
     */
    calculateSvgSize(layers) {
        const maxNodesInLayer = Math.max(...layers.map(l => l.length));
        const width = Math.max(800, maxNodesInLayer * (this.nodeWidth + this.nodeSpacing) + this.nodeSpacing);
        const height = Math.max(600, layers.length * (this.nodeHeight + this.layerSpacing) + this.layerSpacing);
        
        return { width, height };
    }
    
    /**
     * Create SVG element
     */
    createSVG(size) {
        const ns = 'http://www.w3.org/2000/svg';
        const svg = document.createElementNS(ns, 'svg');
        
        svg.setAttribute('width', '100%');
        svg.setAttribute('height', '100%');
        svg.setAttribute('viewBox', `0 0 ${size.width} ${size.height}`);
        svg.style.background = 'var(--bg-color)';
        svg.style.borderRadius = '8px';
        svg.style.cursor = 'grab';
        
        // Create groups for pan/zoom
        const g = document.createElementNS(ns, 'g');
        g.setAttribute('transform', 'translate(0,0) scale(1)');
        g.setAttribute('id', 'dag-content');
        
        svg.appendChild(g);
        
        return svg;
    }
    
    /**
     * Draw edges between nodes
     */
    drawEdges(svg, layers) {
        const ns = 'http://www.w3.org/2000/svg';
        const g = svg.querySelector('#dag-content');
        const edges = this.dagData.edges || [];
        
        edges.forEach(edge => {
            const fromPos = this.getNodePosition(edge.from, layers);
            const toPos = this.getNodePosition(edge.to, layers);
            
            if (!fromPos || !toPos) return;
            
            const path = document.createElementNS(ns, 'path');
            
            // Calculate control points for bezier curve
            const startX = fromPos.x + this.nodeWidth / 2;
            const startY = fromPos.y + this.nodeHeight;
            const endX = toPos.x + this.nodeWidth / 2;
            const endY = toPos.y;
            
            const controlY1 = startY + 50;
            const controlY2 = endY - 50;
            
            const d = `M ${startX} ${startY} C ${startX} ${controlY1}, ${endX} ${controlY2}, ${endX} ${endY}`;
            
            path.setAttribute('d', d);
            path.setAttribute('stroke', 'var(--text-secondary)');
            path.setAttribute('stroke-width', '2');
            path.setAttribute('fill', 'none');
            path.setAttribute('marker-end', 'url(#arrowhead)');
            path.setAttribute('opacity', '0.6');
            
            g.appendChild(path);
        });
    }
    
    /**
     * Draw nodes
     */
    drawNodes(svg, layers) {
        const ns = 'http://www.w3.org/2000/svg';
        const g = svg.querySelector('#dag-content');
        
        // Add arrowhead marker
        const defs = document.createElementNS(ns, 'defs');
        const marker = document.createElementNS(ns, 'marker');
        marker.setAttribute('id', 'arrowhead');
        marker.setAttribute('markerWidth', '10');
        marker.setAttribute('markerHeight', '7');
        marker.setAttribute('refX', '9');
        marker.setAttribute('refY', '3.5');
        marker.setAttribute('orient', 'auto');
        
        const markerPath = document.createElementNS(ns, 'polygon');
        markerPath.setAttribute('points', '0 0, 10 3.5, 0 7');
        markerPath.setAttribute('fill', 'var(--text-secondary)');
        markerPath.setAttribute('opacity', '0.6');
        
        marker.appendChild(markerPath);
        defs.appendChild(marker);
        g.appendChild(defs);
        
        // Draw nodes
        layers.forEach((layer, layerIndex) => {
            layer.forEach((node, nodeIndex) => {
                const pos = this.getNodePosition(node.code, layers);
                if (!pos) return;
                
                const nodeGroup = this.createNodeElement(ns, node, pos);
                g.appendChild(nodeGroup);
            });
        });
    }
    
    /**
     * Create node SVG element
     */
    createNodeElement(ns, node, pos) {
        const g = document.createElementNS(ns, 'g');
        g.setAttribute('transform', `translate(${pos.x}, ${pos.y})`);
        g.style.cursor = 'pointer';
        
        // Determine status color
        const statusColors = this.getStatusColors(node.status);
        
        // Background rectangle with rounded corners
        const rect = document.createElementNS(ns, 'rect');
        rect.setAttribute('width', this.nodeWidth);
        rect.setAttribute('height', this.nodeHeight);
        rect.setAttribute('rx', '8');
        rect.setAttribute('ry', '8');
        rect.setAttribute('fill', statusColors.bg);
        rect.setAttribute('stroke', statusColors.border);
        rect.setAttribute('stroke-width', '2');
        
        g.appendChild(rect);
        
        // Node type icon
        const icon = this.getNodeIcon(node.action_type);
        const iconText = document.createElementNS(ns, 'text');
        iconText.setAttribute('x', '12');
        iconText.setAttribute('y', '36');
        iconText.setAttribute('font-size', '20');
        iconText.textContent = icon;
        
        g.appendChild(iconText);
        
        // Node name
        const nameText = document.createElementNS(ns, 'text');
        nameText.setAttribute('x', '40');
        nameText.setAttribute('y', '28');
        nameText.setAttribute('fill', 'var(--text-primary)');
        nameText.setAttribute('font-size', '13');
        nameText.setAttribute('font-weight', '600');
        nameText.textContent = this.truncateText(node.name, 20);
        
        g.appendChild(nameText);
        
        // Node code
        const codeText = document.createElementNS(ns, 'text');
        codeText.setAttribute('x', '40');
        codeText.setAttribute('y', '50');
        codeText.setAttribute('fill', 'var(--text-secondary)');
        codeText.setAttribute('font-size', '11');
        codeText.textContent = node.code;
        
        g.appendChild(codeText);
        
        // Status indicator
        const statusCircle = document.createElementNS(ns, 'circle');
        statusCircle.setAttribute('cx', this.nodeWidth - 12);
        statusCircle.setAttribute('cy', '12');
        statusCircle.setAttribute('r', '6');
        statusCircle.setAttribute('fill', statusColors.border);
        
        g.appendChild(statusCircle);
        
        // Click handler
        g.addEventListener('click', () => {
            this.showNodeDetail(node);
        });
        
        // Hover effects
        g.addEventListener('mouseenter', () => {
            rect.setAttribute('stroke', 'var(--primary-color)');
            rect.setAttribute('stroke-width', '3');
        });
        
        g.addEventListener('mouseleave', () => {
            rect.setAttribute('stroke', statusColors.border);
            rect.setAttribute('stroke-width', '2');
        });
        
        return g;
    }
    
    /**
     * Get node position based on layer
     */
    getNodePosition(nodeCode, layers) {
        for (let layerIndex = 0; layerIndex < layers.length; layerIndex++) {
            const layer = layers[layerIndex];
            const nodeIndex = layer.findIndex(n => n.code === nodeCode);
            
            if (nodeIndex !== -1) {
                const x = this.nodeSpacing + nodeIndex * (this.nodeWidth + this.nodeSpacing);
                const y = this.layerSpacing + layerIndex * (this.nodeHeight + this.layerSpacing);
                return { x, y };
            }
        }
        return null;
    }
    
    /**
     * Get status colors
     */
    getStatusColors(status) {
        const colors = {
            'PENDING': { bg: 'var(--pending-bg)', border: 'var(--pending)' },
            'READY': { bg: 'var(--pending-bg)', border: 'var(--pending)' },
            'RUNNING': { bg: 'var(--running-bg)', border: 'var(--running)' },
            'SUCCESS': { bg: 'var(--success-bg)', border: 'var(--success)' },
            'COMPLETED': { bg: 'var(--success-bg)', border: 'var(--success)' },
            'FAILED': { bg: 'var(--failed-bg)', border: 'var(--failed)' },
            'ERROR': { bg: 'var(--failed-bg)', border: 'var(--failed)' },
            'SKIPPED': { bg: 'var(--skipped-bg)', border: 'var(--skipped)' }
        };
        
        return colors[status] || colors['PENDING'];
    }
    
    /**
     * Get node type icon
     */
    getNodeIcon(actionType) {
        const icons = {
            'API': '🌐',
            'SQL': '📊',
            'BASH': '💻',
            'LLM': '🤖',
            'PYTHON': '🐍',
            'FILE': '📁'
        };
        return icons[actionType] || '📦';
    }
    
    /**
     * Truncate text
     */
    truncateText(text, maxLength) {
        if (!text) return '';
        if (text.length <= maxLength) return text;
        return text.substring(0, maxLength - 2) + '...';
    }
    
    /**
     * Show node detail modal
     */
    showNodeDetail(node) {
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
        `;
        
        modal.innerHTML = `
            <div style="
                background: var(--card-bg);
                border-radius: 12px;
                padding: 24px;
                max-width: 600px;
                width: 90%;
                max-height: 80vh;
                overflow: auto;
            ">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
                    <h3 style="margin: 0;">${node.name}</h3>
                    <button class="btn-icon" onclick="this.closest('.modal-overlay').remove()" style="width: 32px; height: 32px; border: 1px solid var(--border-color); background: var(--card-bg); border-radius: 8px; cursor: pointer;">✕</button>
                </div>
                
                <div style="margin-bottom: 16px;">
                    <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 4px;">代码</div>
                    <code style="background: var(--primary-light); color: var(--primary-color); padding: 4px 8px; border-radius: 4px;">${node.code}</code>
                </div>
                
                <div style="margin-bottom: 16px;">
                    <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 4px;">类型</div>
                    <div>${this.getNodeIcon(node.action_type)} ${node.action_type}</div>
                </div>
                
                ${node.status ? `
                <div style="margin-bottom: 16px;">
                    <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 4px;">状态</div>
                    <span class="status-badge ${node.status.toLowerCase()}">${node.status}</span>
                </div>
                ` : ''}
                
                ${node.description ? `
                <div style="margin-bottom: 16px;">
                    <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 4px;">描述</div>
                    <div style="color: var(--text-primary);">${node.description}</div>
                </div>
                ` : ''}
            </div>
        `;
        
        document.body.appendChild(modal);
    }
    
    /**
     * Add zoom/pan controls
     */
    addControls(container) {
        const controls = document.createElement('div');
        controls.style.cssText = `
            position: absolute;
            bottom: 16px;
            right: 16px;
            display: flex;
            gap: 8px;
            background: var(--card-bg);
            padding: 8px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        `;
        
        controls.innerHTML = `
            <button class="btn-icon" onclick="dagVisualizer.zoomIn()" style="width: 32px; height: 32px; border: 1px solid var(--border-color); background: var(--card-bg); border-radius: 6px; cursor: pointer;">🔍</button>
            <button class="btn-icon" onclick="dagVisualizer.zoomOut()" style="width: 32px; height: 32px; border: 1px solid var(--border-color); background: var(--card-bg); border-radius: 6px; cursor: pointer;">🔎</button>
            <button class="btn-icon" onclick="dagVisualizer.reset()" style="width: 32px; height: 32px; border: 1px solid var(--border-color); background: var(--card-bg); border-radius: 6px; cursor: pointer;">⟲</button>
        `;
        
        container.style.position = 'relative';
        container.appendChild(controls);
    }
    
    /**
     * Zoom in
     */
    zoomIn() {
        this.zoom *= 1.2;
        this.applyTransform();
    }
    
    /**
     * Zoom out
     */
    zoomOut() {
        this.zoom /= 1.2;
        this.applyTransform();
    }
    
    /**
     * Reset zoom and pan
     */
    reset() {
        this.zoom = 1;
        this.panX = 0;
        this.panY = 0;
        this.applyTransform();
    }
    
    /**
     * Apply transform to SVG content
     */
    applyTransform() {
        const svg = document.getElementById(this.containerId);
        if (!svg) return;
        
        const g = svg.querySelector('#dag-content');
        if (!g) return;
        
        g.setAttribute('transform', `translate(${this.panX},${this.panY}) scale(${this.zoom})`);
    }
}

// Make globally accessible
window.DagVisualizer = DagVisualizer;
let dagVisualizer = null;
