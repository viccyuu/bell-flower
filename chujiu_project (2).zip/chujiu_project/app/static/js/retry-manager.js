/**
 * Retry Manager - 重试管理模块 ⭐
 * 
 * 提供：
 * - 单个节点重试
 * - 批量重试
 * - 重试历史查看
 * - 重试策略配置
 */

// 防止重复声明
if (typeof RetryManager === 'undefined') {

class RetryManager {
    constructor() {
        this.apiBase = '/api/retry';
        this.currentTaskId = null;
        this.currentNodeCode = null;
        this.pollingInterval = null;
        this.modalElement = null;
    }

    /**
     * 初始化重试管理器
     */
    init() {
        this.createModal();
        this.bindEvents();
        console.log('✅ RetryManager initialized');
    }

    /**
     * 创建重试对话框
     */
    createModal() {
        const modalHtml = `
            <div id="retry-modal" class="retry-modal-overlay" style="display: none;">
                <div class="retry-modal">
                    <div class="retry-modal-header">
                        <h3 class="retry-modal-title">
                            <span class="icon">🔄</span>
                            <span class="title-text">节点重试</span>
                        </h3>
                        <button class="retry-modal-close" onclick="retryManager.closeModal()">&times;</button>
                    </div>
                    <div class="retry-modal-body">
                        <!-- 动态内容 -->
                    </div>
                    <div class="retry-modal-footer">
                        <button class="btn-retry-secondary" onclick="retryManager.closeModal()">取消</button>
                        <button class="btn-retry-primary" onclick="retryManager.confirmRetry()">
                            <span>🔄</span> 确认重试
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        this.modalElement = document.getElementById('retry-modal');
    }

    /**
     * 绑定事件
     */
    bindEvents() {
        // 键盘事件
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.modalElement && this.modalElement.style.display !== 'none') {
                this.closeModal();
            }
        });
    }

    /**
     * 打开重试对话框
     * @param {number} taskRunId - 任务运行 ID
     * @param {string} nodeCode - 节点代码
     */
    async openRetryModal(taskRunId, nodeCode) {
        this.currentTaskId = taskRunId;
        this.currentNodeCode = nodeCode;
        
        const modalBody = this.modalElement.querySelector('.retry-modal-body');
        modalBody.innerHTML = '<div class="retry-loading"><div class="retry-loading-spinner"></div> 加载中...</div>';
        
        this.modalElement.style.display = 'flex';
        
        try {
            // 获取节点状态
            const statusData = await this.getRetryStatus(taskRunId, nodeCode);
            
            if (statusData.code !== 200) {
                throw new Error(statusData.message || '获取节点状态失败');
            }
            
            const status = statusData.data;
            
            // 渲染对话框内容
            this.renderModalContent(status);
            
        } catch (error) {
            console.error('Failed to open retry modal:', error);
            modalBody.innerHTML = `
                <div class="retry-error-box">
                    <div class="retry-error-title">⚠️ 错误</div>
                    <div class="retry-error-message">${error.message}</div>
                </div>
            `;
        }
    }

    /**
     * 渲染对话框内容
     * @param {Object} status - 节点状态数据
     */
    renderModalContent(status) {
        const modalBody = this.modalElement.querySelector('.retry-modal-body');
        
        const canRetry = status.can_retry;
        const attemptCount = status.attempt_count;
        const maxRetries = status.max_retries || '无限';
        
        modalBody.innerHTML = `
            <div class="retry-info-card">
                <h4>📊 节点信息</h4>
                <div class="retry-info-grid">
                    <div class="retry-info-item">
                        <span class="retry-info-label">节点代码</span>
                        <span class="retry-info-value">${status.node_code}</span>
                    </div>
                    <div class="retry-info-item">
                        <span class="retry-info-label">节点名称</span>
                        <span class="retry-info-value">${status.node_name}</span>
                    </div>
                    <div class="retry-info-item">
                        <span class="retry-info-label">当前状态</span>
                        <span class="retry-info-value ${status.current_status === 'FAILED' ? 'error' : ''}">
                            ${this.getStatusBadge(status.current_status)}
                        </span>
                    </div>
                    <div class="retry-info-item">
                        <span class="retry-info-label">尝试次数</span>
                        <span class="retry-info-value">${attemptCount} / ${maxRetries}</span>
                    </div>
                </div>
            </div>
            
            ${status.last_error ? `
                <div class="retry-error-box">
                    <div class="retry-error-title">⚠️ 错误信息</div>
                    <div class="retry-error-message">${this.escapeHtml(status.last_error)}</div>
                </div>
            ` : ''}
            
            <div class="retry-policy-section">
                <h4>⚙️ 重试策略</h4>
                <div class="retry-info-grid">
                    <div class="retry-info-item">
                        <span class="retry-info-label">最大重试次数</span>
                        <span class="retry-info-value">${status.retry_policy?.max_retries || '无限'}</span>
                    </div>
                    <div class="retry-info-item">
                        <span class="retry-info-label">重试间隔</span>
                        <span class="retry-info-value">${status.retry_policy?.backoff_seconds || 0} 秒</span>
                    </div>
                </div>
            </div>
            
            ${!canRetry ? `
                <div class="retry-error-box" style="margin-top: 16px;">
                    <div class="retry-error-title">⚠️ 无法重试</div>
                    <div class="retry-error-message">
                        ${status.current_status !== 'FAILED' 
                            ? `节点当前状态为 ${status.current_status}，只有 FAILED 状态的节点可以重试`
                            : `已达到最大重试次数限制 (${maxRetries})`
                        }
                    </div>
                </div>
            ` : ''}
            
            <!-- 重试历史记录 -->
            <div class="retry-history-section" style="margin-top: 20px;">
                <h4 style="font-size: 14px; font-weight: 600; margin-bottom: 12px;">📜 重试历史</h4>
                <div id="retry-history-list" class="retry-history-list">
                    <div class="retry-loading" style="padding: 20px;">加载中...</div>
                </div>
            </div>
        `;
        
        // 加载重试历史
        this.loadRetryHistory();
        
        // 更新按钮状态
        const confirmBtn = this.modalElement.querySelector('.btn-retry-primary');
        confirmBtn.disabled = !canRetry;
        confirmBtn.style.opacity = canRetry ? '1' : '0.5';
        confirmBtn.style.cursor = canRetry ? 'pointer' : 'not-allowed';
    }

    /**
     * 获取状态徽章
     * @param {string} status - 状态
     */
    getStatusBadge(status) {
        const badges = {
            'PENDING': '<span class="retry-status-badge">⏳ 等待中</span>',
            'READY': '<span class="retry-status-badge">✅ 就绪</span>',
            'RUNNING': '<span class="retry-status-badge">🔄 执行中</span>',
            'SUCCESS': '<span class="retry-status-badge" style="background: #ecfdf5; border-color: #10b981; color: #065f46;">✓ 成功</span>',
            'FAILED': '<span class="retry-status-badge" style="background: #fef2f2; border-color: #ef4444; color: #991b1b;">✗ 失败</span>',
            'RETRYING': '<span class="retry-status-badge retrying">🔄 重试中</span>',
            'SKIPPED': '<span class="retry-status-badge" style="background: #f3f4f6; border-color: #9ca3af; color: #374151;">⊘ 跳过</span>'
        };
        return badges[status] || status;
    }

    /**
     * 加载重试历史
     */
    async loadRetryHistory() {
        try {
            const historyData = await this.getRetryHistory(this.currentTaskId, this.currentNodeCode);
            
            if (historyData.code !== 200) {
                throw new Error('加载重试历史失败');
            }
            
            const history = historyData.data.history || [];
            const historyList = document.getElementById('retry-history-list');
            
            if (history.length === 0) {
                historyList.innerHTML = '<div style="padding: 20px; text-align: center; color: #6b7280; font-size: 13px;">暂无重试记录</div>';
                return;
            }
            
            historyList.innerHTML = `
                <div class="retry-history-header">
                    <div class="retry-history-grid" style="display: grid; grid-template-columns: 60px 1fr 100px 120px; gap: 12px;">
                        <span>尝试</span>
                        <span>状态变更</span>
                        <span>时间</span>
                        <span style="text-align: right;">结果</span>
                    </div>
                </div>
                ${history.map(record => `
                    <div class="retry-history-item">
                        <div class="retry-history-attempt">#${record.attempt_number}</div>
                        <div class="retry-history-status">
                            <span class="status-dot ${record.previous_status === 'FAILED' ? 'failed' : 'success'}"></span>
                            <span>${record.previous_status}</span>
                            <span style="color: #9ca3af;">→</span>
                            <span>${record.new_status}</span>
                        </div>
                        <div class="retry-history-time">${this.formatTime(record.retried_at)}</div>
                        <div class="retry-history-result ${record.result_status === 'SUCCESS' ? 'success' : 'failed'}">
                            ${record.result_status || '-'}
                        </div>
                    </div>
                `).join('')}
            `;
            
        } catch (error) {
            console.error('Failed to load retry history:', error);
            document.getElementById('retry-history-list').innerHTML = `
                <div class="retry-error-box" style="margin: 0; border: none; background: #fef2f2;">
                    <div class="retry-error-message">加载失败：${error.message}</div>
                </div>
            `;
        }
    }

    /**
     * 确认重试
     */
    async confirmRetry() {
        if (!this.currentTaskId || !this.currentNodeCode) {
            this.showToast('错误：缺少必要参数', 'error');
            return;
        }
        
        const confirmBtn = this.modalElement.querySelector('.btn-retry-primary');
        confirmBtn.disabled = true;
        confirmBtn.innerHTML = '<div class="retry-loading-spinner"></div> 重试中...';
        
        try {
            const result = await this.retryNode(this.currentTaskId, this.currentNodeCode);
            
            if (result.code !== 200) {
                throw new Error(result.message || '重试失败');
            }
            
            this.showToast(`✅ 节点 ${this.currentNodeCode} 已进入重试队列`, 'success');
            
            // 关闭对话框
            this.closeModal();
            
            // 通知外部刷新 DAG 视图
            if (typeof window.onNodeRetry === 'function') {
                window.onNodeRetry(this.currentTaskId);
            }
            
        } catch (error) {
            console.error('Retry failed:', error);
            this.showToast(`❌ 重试失败：${error.message}`, 'error');
            confirmBtn.disabled = false;
            confirmBtn.innerHTML = '<span>🔄</span> 确认重试';
        }
    }

    /**
     * 关闭对话框
     */
    closeModal() {
        if (this.modalElement) {
            this.modalElement.style.display = 'none';
        }
        this.currentTaskId = null;
        this.currentNodeCode = null;
        
        if (this.pollingInterval) {
            clearInterval(this.pollingInterval);
            this.pollingInterval = null;
        }
    }

    /**
     * 显示提示消息
     * @param {string} message - 消息内容
     * @param {string} type - 类型 (success|error|warning)
     */
    showToast(message, type = 'info') {
        const toastContainer = document.getElementById('toast-container');
        if (!toastContainer) {
            console.log('Toast:', message);
            return;
        }
        
        const colors = {
            success: 'background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%); border-color: #6ee7b7; color: #065f46;',
            error: 'background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%); border-color: #fca5a5; color: #991b1b;',
            warning: 'background: linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%); border-color: #fcd34d; color: #92400e;',
            info: 'background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%); border-color: #93c5fd; color: #1e40af;'
        };
        
        const icons = {
            success: '✅',
            error: '❌',
            warning: '⚠️',
            info: 'ℹ️'
        };
        
        const toast = document.createElement('div');
        toast.className = 'toast';
        toast.style.cssText = `${colors[type]} padding: 12px 16px; border-radius: 8px; margin-bottom: 8px; display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 500; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); border: 1px solid;`;
        toast.innerHTML = `<span>${icons[type]}</span><span>${message}</span>`;
        
        toastContainer.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transition = 'opacity 0.3s';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    /**
     * 转义 HTML
     * @param {string} text - 文本
     */
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * 格式化时间
     * @param {string} isoString - ISO 时间字符串
     */
    formatTime(isoString) {
        if (!isoString) return '-';
        const date = new Date(isoString);
        return date.toLocaleString('zh-CN', {
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    // ========== API 调用 ==========

    /**
     * 获取重试状态
     */
    async getRetryStatus(taskRunId, nodeCode) {
        const response = await fetch(`${this.apiBase}/status/${taskRunId}/${nodeCode}`);
        return await response.json();
    }

    /**
     * 重试节点
     */
    async retryNode(taskRunId, nodeCode) {
        const response = await fetch(`${this.apiBase}/nodes`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                task_run_id: taskRunId,
                node_code: nodeCode
            })
        });
        return await response.json();
    }

    /**
     * 批量重试
     */
    async batchRetry(taskRunId, nodeCodes) {
        const response = await fetch(`${this.apiBase}/nodes/batch`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                task_run_id: taskRunId,
                node_codes: nodeCodes
            })
        });
        return await response.json();
    }

    /**
     * 获取重试历史
     */
    async getRetryHistory(taskRunId, nodeCode) {
        const params = new URLSearchParams({
            task_run_id: taskRunId,
            node_code: nodeCode,
            limit: '20'
        });
        const response = await fetch(`${this.apiBase}/history?${params}`);
        return await response.json();
    }
}

// 创建全局实例
window.retryManager = new RetryManager();

} // end of RetryManager class definition

// 自动初始化
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.retryManager.init();
    });
} else {
    window.retryManager.init();
}
