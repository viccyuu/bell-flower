// -*- coding: utf-8 -*-
/**
 * 统一 API 客户端 ⭐
 * 
 * 统一处理 API 响应格式：
 * - 成功：{code: "OK", data: {...}, message: "..."}
 * - 失败：{code: "ERROR", data: null, message: "..."}
 */

const API_BASE = '/api';

/**
 * 统一 API 调用封装
 * @param {string} url - API 路径
 * @param {Object} options - fetch 选项
 * @returns {Promise<any>} 返回 data 部分
 */
async function apiCall(url, options = {}) {
    try {
        const response = await fetch(`${API_BASE}${url}`, options);
        const result = await response.json();
        
        if (result.code === 'OK') {
            return result.data;
        } else {
            // 错误处理
            const errorMessage = result.message || '请求失败';
            showToast(errorMessage, 'error');
            throw new Error(errorMessage);
        }
    } catch (error) {
        if (error.message !== 'Failed to fetch') {
            // 非网络错误，已在上层处理
            throw error;
        } else {
            // 网络错误
            showToast('网络连接失败，请检查服务器', 'error');
            throw error;
        }
    }
}

/**
 * GET 请求
 * @param {string} url - API 路径
 * @param {Object} params - 查询参数
 * @returns {Promise<any>}
 */
async function apiGet(url, params = {}) {
    const queryString = new URLSearchParams(params).toString();
    const fullUrl = queryString ? `${url}?${queryString}` : url;
    return await apiCall(fullUrl, {
        method: 'GET'
    });
}

/**
 * POST 请求
 * @param {string} url - API 路径
 * @param {Object} data - 请求数据
 * @returns {Promise<any>}
 */
async function apiPost(url, data = {}) {
    return await apiCall(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });
}

/**
 * 上传文件
 * @param {string} url - API 路径
 * @param {FormData} formData - FormData 对象
 * @returns {Promise<any>}
 */
async function apiUpload(url, formData) {
    return await apiCall(url, {
        method: 'POST',
        body: formData
        // Content-Type 由浏览器自动设置
    });
}

/**
 * 显示提示消息
 * @param {string} message - 消息内容
 * @param {string} type - 类型：success, error, info, warning
 */
function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) {
        console.log(`[${type.toUpperCase()}] ${message}`);
        return;
    }
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    
    // 样式
    toast.style.cssText = `
        padding: 12px 24px;
        margin-bottom: 10px;
        border-radius: 4px;
        background: ${type === 'success' ? '#52c41a' : type === 'error' ? '#ff4d4f' : '#1890ff'};
        color: white;
        box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        animation: slideIn 0.3s ease;
    `;
    
    container.appendChild(toast);
    
    // 3 秒后自动消失
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// 导出供其他模块使用
window.apiClient = {
    call: apiCall,
    get: apiGet,
    post: apiPost,
    upload: apiUpload,
    showToast: showToast
};

// 添加 CSS 动画
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    #toast-container {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
    }
`;
document.head.appendChild(style);

// 确保 toast 容器存在
if (!document.getElementById('toast-container')) {
    const container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
}
