// -*- coding: utf-8 -*-
/**
 * 测试报告弹窗 ⭐
 * 
 * 显示 VBA 和 JS 测试结果对比报告
 */

/**
 * 显示测试报告弹窗
 * @param {Object} testData - 测试数据
 */
function showTestReport(testData) {
    const modal = document.createElement('div');
    modal.className = 'test-report-modal';
    modal.innerHTML = `
        <div class="test-report-modal-content">
            <div class="test-report-modal-header">
                <h3>测试报告</h3>
                <button class="test-report-modal-close" onclick="closeTestReport()">&times;</button>
            </div>
            <div class="test-report-modal-body">
                <div class="test-report-summary">
                    <div class="test-report-summary-item">
                        <div class="test-report-summary-label">VBA 测试</div>
                        <div class="test-report-summary-value ${testData.vba_passed ? 'success' : 'error'}">
                            ${testData.vba_passed ? '通过' : '失败'}
                        </div>
                    </div>
                    <div class="test-report-summary-item">
                        <div class="test-report-summary-label">JS 测试</div>
                        <div class="test-report-summary-value ${testData.js_passed ? 'success' : 'error'}">
                            ${testData.js_passed ? '通过' : '失败'}
                        </div>
                    </div>
                    <div class="test-report-summary-item">
                        <div class="test-report-summary-label">一致性</div>
                        <div class="test-report-summary-value ${testData.consistent ? 'success' : 'warning'}">
                            ${testData.consistent ? '一致' : '不一致'}
                        </div>
                    </div>
                </div>
                
                <div class="test-report-section">
                    <h4>VBA 测试详情</h4>
                    <div class="test-report-details">
                        ${renderTestDetails(testData.vba_report)}
                    </div>
                </div>
                
                <div class="test-report-section">
                    <h4>JS 测试详情</h4>
                    <div class="test-report-details">
                        ${renderTestDetails(testData.js_report)}
                    </div>
                </div>
                
                ${testData.diffs && testData.diffs.length > 0 ? `
                <div class="test-report-section">
                    <h4>差异对比</h4>
                    <div class="test-report-diffs">
                        ${testData.diffs.map(diff => `
                            <div class="test-report-diff-item">
                                <div class="test-report-diff-label">${diff.test_name}</div>
                                <div class="test-report-diff-content">
                                    <div class="test-report-diff-side">
                                        <div class="test-report-diff-side-title">VBA</div>
                                        <pre>${JSON.stringify(diff.vba_result, null, 2)}</pre>
                                    </div>
                                    <div class="test-report-diff-side">
                                        <div class="test-report-diff-side-title">JS</div>
                                        <pre>${JSON.stringify(diff.js_result, null, 2)}</pre>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
                ` : ''}
            </div>
            <div class="test-report-modal-footer">
                <button class="btn btn-primary" onclick="downloadTestReport()">下载报告</button>
                <button class="btn" onclick="closeTestReport()">关闭</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'flex';
    
    // 添加样式
    addTestReportStyles();
}

/**
 * 渲染测试详情
 * @param {Object} report - 测试报告
 * @returns {string} HTML
 */
function renderTestDetails(report) {
    if (!report) return '<div class="test-report-no-data">无数据</div>';
    
    const total = report.total || 0;
    const passed = report.passed || 0;
    const failed = total - passed;
    
    return `
        <div class="test-report-stats">
            <div class="test-report-stat-item">
                <div class="test-report-stat-value">${total}</div>
                <div class="test-report-stat-label">总计</div>
            </div>
            <div class="test-report-stat-item success">
                <div class="test-report-stat-value">${passed}</div>
                <div class="test-report-stat-label">通过</div>
            </div>
            <div class="test-report-stat-item error">
                <div class="test-report-stat-value">${failed}</div>
                <div class="test-report-stat-label">失败</div>
            </div>
            <div class="test-report-stat-item">
                <div class="test-report-stat-value">${total > 0 ? ((passed / total) * 100).toFixed(1) : 0}%</div>
                <div class="test-report-stat-label">通过率</div>
            </div>
        </div>
        
        ${report.details ? `
        <div class="test-report-details-list">
            ${report.details.map((detail, index) => `
                <div class="test-report-detail-item ${detail.status === 'PASSED' ? 'success' : 'error'}">
                    <div class="test-report-detail-index">${index + 1}</div>
                    <div class="test-report-detail-content">
                        <div class="test-report-detail-name">${detail.name || `测试 ${index + 1}`}</div>
                        <div class="test-report-detail-status">${detail.status}</div>
                        ${detail.message ? `<div class="test-report-detail-message">${detail.message}</div>` : ''}
                    </div>
                </div>
            `).join('')}
        </div>
        ` : ''}
    `;
}

/**
 * 关闭测试报告弹窗
 */
function closeTestReport() {
    const modal = document.querySelector('.test-report-modal');
    if (modal) {
        modal.remove();
    }
}

/**
 * 下载测试报告
 */
function downloadTestReport() {
    // TODO: 实现下载报告功能
    showToast('报告下载功能开发中', 'info');
}

/**
 * 添加测试报告样式
 */
function addTestReportStyles() {
    if (document.getElementById('test-report-styles')) return;
    
    const style = document.createElement('style');
    style.id = 'test-report-styles';
    style.textContent = `
        .test-report-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 10000;
            justify-content: center;
            align-items: center;
        }
        
        .test-report-modal-content {
            background: white;
            border-radius: 8px;
            width: 90%;
            max-width: 1000px;
            max-height: 90vh;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }
        
        .test-report-modal-header {
            padding: 20px;
            border-bottom: 1px solid #e8e8e8;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .test-report-modal-header h3 {
            margin: 0;
            font-size: 18px;
        }
        
        .test-report-modal-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }
        
        .test-report-modal-close:hover {
            color: #333;
        }
        
        .test-report-modal-body {
            padding: 20px;
            overflow-y: auto;
            flex: 1;
        }
        
        .test-report-summary {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .test-report-summary-item {
            text-align: center;
            padding: 20px;
            background: #f5f5f5;
            border-radius: 8px;
        }
        
        .test-report-summary-label {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
        }
        
        .test-report-summary-value {
            font-size: 24px;
            font-weight: bold;
        }
        
        .test-report-summary-value.success {
            color: #52c41a;
        }
        
        .test-report-summary-value.error {
            color: #ff4d4f;
        }
        
        .test-report-summary-value.warning {
            color: #faad14;
        }
        
        .test-report-section {
            margin-bottom: 30px;
        }
        
        .test-report-section h4 {
            margin: 0 0 15px 0;
            font-size: 16px;
            color: #333;
            border-left: 4px solid #1890ff;
            padding-left: 10px;
        }
        
        .test-report-stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .test-report-stat-item {
            text-align: center;
            padding: 15px;
            background: #f5f5f5;
            border-radius: 4px;
        }
        
        .test-report-stat-item.success {
            background: #f6ffed;
        }
        
        .test-report-stat-item.error {
            background: #fff1f0;
        }
        
        .test-report-stat-value {
            font-size: 28px;
            font-weight: bold;
            color: #1890ff;
        }
        
        .test-report-stat-item.success .test-report-stat-value {
            color: #52c41a;
        }
        
        .test-report-stat-item.error .test-report-stat-value {
            color: #ff4d4f;
        }
        
        .test-report-stat-label {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        
        .test-report-details-list {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .test-report-detail-item {
            display: flex;
            align-items: center;
            padding: 15px;
            background: #f5f5f5;
            border-radius: 4px;
            border-left: 4px solid #ddd;
        }
        
        .test-report-detail-item.success {
            border-left-color: #52c41a;
            background: #f6ffed;
        }
        
        .test-report-detail-item.error {
            border-left-color: #ff4d4f;
            background: #fff1f0;
        }
        
        .test-report-detail-index {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: #ddd;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-right: 15px;
        }
        
        .test-report-detail-item.success .test-report-detail-index {
            background: #52c41a;
        }
        
        .test-report-detail-item.error .test-report-detail-index {
            background: #ff4d4f;
        }
        
        .test-report-detail-content {
            flex: 1;
        }
        
        .test-report-detail-name {
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .test-report-detail-status {
            font-size: 12px;
            color: #666;
        }
        
        .test-report-detail-message {
            font-size: 12px;
            color: #999;
            margin-top: 5px;
        }
        
        .test-report-diffs {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .test-report-diff-item {
            border: 1px solid #e8e8e8;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .test-report-diff-label {
            padding: 10px 15px;
            background: #fafafa;
            border-bottom: 1px solid #e8e8e8;
            font-weight: bold;
        }
        
        .test-report-diff-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
        }
        
        .test-report-diff-side {
            padding: 15px;
        }
        
        .test-report-diff-side:first-child {
            border-right: 1px solid #e8e8e8;
            background: #f6ffed;
        }
        
        .test-report-diff-side:last-child {
            background: #fff1f0;
        }
        
        .test-report-diff-side-title {
            font-weight: bold;
            margin-bottom: 10px;
            text-align: center;
        }
        
        .test-report-diff-side pre {
            background: white;
            padding: 10px;
            border-radius: 4px;
            font-size: 12px;
            overflow: auto;
            max-height: 200px;
        }
        
        .test-report-modal-footer {
            padding: 20px;
            border-top: 1px solid #e8e8e8;
            text-align: right;
        }
        
        .test-report-no-data {
            text-align: center;
            color: #999;
            padding: 40px;
        }
        
        @media (max-width: 768px) {
            .test-report-summary {
                grid-template-columns: 1fr;
            }
            
            .test-report-stats {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .test-report-diff-content {
                grid-template-columns: 1fr;
            }
        }
    `;
    document.head.appendChild(style);
}

// 导出供全局使用
window.showTestReport = showTestReport;
window.closeTestReport = closeTestReport;
window.downloadTestReport = downloadTestReport;
