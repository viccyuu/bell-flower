// -*- coding: utf-8 -*-
/**
 * LLM 节点详情展示 ⭐
 * 
 * 显示 LLM 节点详细信息：
 * - 模型名称
 * - 调用耗时
 * - Token 使用
 * - 输入输出预览
 */

/**
 * 显示 LLM 节点详情弹窗
 * @param {Object} node - 节点数据
 */
function showLLMNodeDetail(node) {
    const modal = document.createElement('div');
    modal.className = 'llm-node-modal';
    modal.innerHTML = `
        <div class="llm-node-modal-content">
            <div class="llm-node-modal-header">
                <h3>LLM 节点详情 - ${node.name}</h3>
                <button class="llm-node-modal-close" onclick="closeLLMNodeDetail()">&times;</button>
            </div>
            <div class="llm-node-modal-body">
                <div class="llm-node-info-section">
                    <h4>基本信息</h4>
                    <div class="llm-node-info-grid">
                        <div class="llm-node-info-item">
                            <label>节点类型:</label>
                            <span>${node.action_type}</span>
                        </div>
                        <div class="llm-node-info-item">
                            <label>状态:</label>
                            <span class="status-badge ${node.status.toLowerCase()}">${node.status}</span>
                        </div>
                        <div class="llm-node-info-item">
                            <label>尝试次数:</label>
                            <span>${node.attempt_count || 1}</span>
                        </div>
                        ${node.started_at && node.finished_at ? `
                        <div class="llm-node-info-item">
                            <label>耗时:</label>
                            <span>${calculateDuration(node.started_at, node.finished_at)}</span>
                        </div>
                        ` : ''}
                    </div>
                </div>
                
                <div class="llm-node-io-section">
                    <div class="llm-node-io-column">
                        <h4>输入</h4>
                        <div class="llm-node-io-content">
                            <pre>${formatJSON(node.input_json)}</pre>
                        </div>
                    </div>
                    <div class="llm-node-io-column">
                        <h4>输出</h4>
                        <div class="llm-node-io-content">
                            <pre>${formatJSON(node.output_json || node.error_json)}</pre>
                        </div>
                    </div>
                </div>
                
                ${node.action_type === 'LLM' ? `
                <div class="llm-node-llm-section">
                    <h4>LLM 调用详情</h4>
                    <div class="llm-metrics">
                        <div class="llm-metric-item">
                            <div class="llm-metric-label">模型</div>
                            <div class="llm-metric-value">dashscope/glm-5</div>
                        </div>
                        ${node.output_json ? `
                        <div class="llm-metric-item">
                            <div class="llm-metric-label">Token 数</div>
                            <div class="llm-metric-value">${estimateTokens(node.output_json)}</div>
                        </div>
                        ` : ''}
                    </div>
                </div>
                ` : ''}
            </div>
            <div class="llm-node-modal-footer">
                <button class="btn btn-primary" onclick="closeLLMNodeDetail()">关闭</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'flex';
    
    // 添加样式
    addLLMNodeDetailStyles();
}

/**
 * 关闭 LLM 节点详情弹窗
 */
function closeLLMNodeDetail() {
    const modal = document.querySelector('.llm-node-modal');
    if (modal) {
        modal.remove();
    }
}

/**
 * 计算时间差
 * @param {string} start - 开始时间
 * @param {string} end - 结束时间
 * @returns {string} 格式化后的时间差
 */
function calculateDuration(start, end) {
    const startDate = new Date(start);
    const endDate = new Date(end);
    const diff = endDate - startDate;
    
    if (diff < 1000) {
        return `${diff}ms`;
    } else if (diff < 60000) {
        return `${(diff / 1000).toFixed(1)}s`;
    } else {
        return `${(diff / 60000).toFixed(1)}m`;
    }
}

/**
 * 估算 Token 数
 * @param {string} text - 文本内容
 * @returns {number} 估算的 Token 数
 */
function estimateTokens(text) {
    if (!text) return 0;
    // 简单估算：中文字符约 1.5 token 一个，英文约 0.75 token 一个
    const chineseChars = (text.match(/[\u4e00-\u9fa5]/g) || []).length;
    const englishChars = text.length - chineseChars;
    return Math.round(chineseChars * 1.5 + englishChars * 0.75);
}

/**
 * 格式化 JSON
 * @param {string|Object} json - JSON 字符串或对象
 * @returns {string} 格式化后的 JSON 字符串
 */
function formatJSON(json) {
    if (!json) return '{}';
    
    try {
        const obj = typeof json === 'string' ? JSON.parse(json) : json;
        return JSON.stringify(obj, null, 2);
    } catch (e) {
        return typeof json === 'string' ? json : JSON.stringify(json);
    }
}

/**
 * 添加 LLM 节点详情样式
 */
function addLLMNodeDetailStyles() {
    if (document.getElementById('llm-node-detail-styles')) return;
    
    const style = document.createElement('style');
    style.id = 'llm-node-detail-styles';
    style.textContent = `
        .llm-node-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 10000;
            justify-content: center;
            align-items: center;
        }
        
        .llm-node-modal-content {
            background: white;
            border-radius: 8px;
            width: 90%;
            max-width: 1200px;
            max-height: 90vh;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }
        
        .llm-node-modal-header {
            padding: 20px;
            border-bottom: 1px solid #e8e8e8;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .llm-node-modal-header h3 {
            margin: 0;
            font-size: 18px;
        }
        
        .llm-node-modal-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }
        
        .llm-node-modal-close:hover {
            color: #333;
        }
        
        .llm-node-modal-body {
            padding: 20px;
            overflow-y: auto;
            flex: 1;
        }
        
        .llm-node-info-section,
        .llm-node-io-section,
        .llm-node-llm-section {
            margin-bottom: 20px;
        }
        
        .llm-node-info-section h4,
        .llm-node-io-section h4,
        .llm-node-llm-section h4 {
            margin: 0 0 10px 0;
            font-size: 16px;
            color: #333;
        }
        
        .llm-node-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 10px;
        }
        
        .llm-node-info-item {
            display: flex;
            justify-content: space-between;
            padding: 10px;
            background: #f5f5f5;
            border-radius: 4px;
        }
        
        .llm-node-info-item label {
            font-weight: bold;
            color: #666;
        }
        
        .llm-node-io-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .llm-node-io-column {
            display: flex;
            flex-direction: column;
        }
        
        .llm-node-io-content {
            flex: 1;
            background: #f5f5f5;
            padding: 10px;
            border-radius: 4px;
            overflow: auto;
            max-height: 400px;
        }
        
        .llm-node-io-content pre {
            margin: 0;
            white-space: pre-wrap;
            word-wrap: break-word;
            font-size: 12px;
            font-family: 'Courier New', monospace;
        }
        
        .llm-metrics {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 10px;
        }
        
        .llm-metric-item {
            background: #e6f7ff;
            padding: 15px;
            border-radius: 4px;
            text-align: center;
        }
        
        .llm-metric-label {
            font-size: 12px;
            color: #666;
            margin-bottom: 5px;
        }
        
        .llm-metric-value {
            font-size: 24px;
            font-weight: bold;
            color: #1890ff;
        }
        
        .llm-node-modal-footer {
            padding: 20px;
            border-top: 1px solid #e8e8e8;
            text-align: right;
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
        }
        
        .status-badge.success {
            background: #f6ffed;
            color: #52c41a;
        }
        
        .status-badge.running {
            background: #e6f7ff;
            color: #1890ff;
        }
        
        .status-badge.error {
            background: #fff1f0;
            color: #ff4d4f;
        }
        
        .status-badge.pending {
            background: #f5f5f5;
            color: #999;
        }
        
        @media (max-width: 768px) {
            .llm-node-io-section {
                grid-template-columns: 1fr;
            }
        }
    `;
    document.head.appendChild(style);
}

// 导出供全局使用
window.showLLMNodeDetail = showLLMNodeDetail;
window.closeLLMNodeDetail = closeLLMNodeDetail;
