﻿// Chujiu TodoList Frontend Application - Full Version

const API_BASE = '/api';

// Page state
let currentPage = 'dashboard';
let healthStatus = 'disconnected';

// DOM elements
const contentArea = document.getElementById('content-area');
const pageTitle = document.getElementById('page-title');
const statusDot = document.getElementById('status-dot');
const statusText = document.getElementById('status-text');
const healthDot = document.getElementById('health-dot');
const healthText = document.getElementById('health-text');
const refreshBtn = document.getElementById('refresh-btn');
const navItems = document.querySelectorAll('.nav-item');
const versionBadge = document.getElementById('version-badge');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initNav();
    initRefresh();
    checkHealth();
    loadPage('dashboard');
    setInterval(checkHealth, 30000);
});

// Initialize navigation
function initNav() {
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const page = item.dataset.page;
            window.location.hash = page;
            loadPage(page);
        });
    });
    
    window.addEventListener('hashchange', () => {
        const hash = window.location.hash.slice(1);
        if (hash) {
            // 解析路由，支持 tasks/:taskId 格式
            const parts = hash.split('/');
            const page = parts[0];
            const taskId = parts[1] || null;
            loadPage(page, taskId);
        }
    });
    
    const initialHash = window.location.hash.slice(1);
    if (initialHash) {
        // 解析路由，支持 tasks/:taskId 格式
        const parts = initialHash.split('/');
        const page = parts[0];
        const taskId = parts[1] || null;
        loadPage(page, taskId);
    }
}

// Initialize refresh button
function initRefresh() {
    refreshBtn.addEventListener('click', () => {
        loadPage(currentPage);
        showToast('已刷新', 'info');
    });
}

// Load page
function loadPage(page, taskId = null) {
    currentPage = page;
    
    navItems.forEach(item => {
        item.classList.toggle('active', item.dataset.page === page);
    });
    
    switch(page) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'upload':
            loadUpload();
            break;
        case 'tasks':
            if (taskId) {
                // 加载任务详情 - 获取任务数据后显示
                fetch(`${API_BASE}/task-runs/${taskId}`)
                    .then(response => response.json())
                    .then(result => {
                        if (result.code === 'OK') {
                            showTaskDetail(taskId, result.data);
                        } else {
                            showToast('获取任务详情失败：' + result.message, 'error');
                        }
                    })
                    .catch(error => {
                        showToast('获取任务详情失败：' + error.message, 'error');
                    });
            } else {
                loadTasks();
            }
            break;
        case 'templates':
            loadTemplates();
            break;
        case 'plugins':
            loadPlugins();
            break;
        case 'artifacts':
            loadArtifacts();
            break;
        case 'health':
            loadHealth();
            break;
        case 'dag-detail':
            break;
    }
}

// Check health
async function checkHealth() {
    try {
        const response = await fetch(`${API_BASE}/../health`);
        const data = await response.json();
        
        healthStatus = 'connected';
        statusDot.className = 'status-dot connected';
        statusText.textContent = '服务正常';
        healthDot.className = 'health-dot';
        healthText.textContent = '正常';
        versionBadge.textContent = `v${data.version}`;
    } catch (error) {
        healthStatus = 'error';
        statusDot.className = 'status-dot error';
        statusText.textContent = '连接失败';
        healthDot.className = 'health-dot error';
        healthText.textContent = '离线';
    }
}

// Show toast
function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// Render status badge
function renderStatusBadge(status) {
    const statusMap = {
        'READY': 'pending',
        'RUNNING': 'running',
        'SUCCESS': 'success',
        'COMPLETED': 'success',
        'FAILED': 'error',
        'ERROR': 'error',
        'UPLOADED': 'pending'
    };
    
    const badgeClass = statusMap[status] || 'pending';
    return `<span class="status-badge ${badgeClass}">${status}</span>`;
}

// Format date
function formatDate(dateStr) {
    if (!dateStr) return '-';
    const date = new Date(dateStr);
    return date.toLocaleString('zh-CN');
}

// Format file size
function formatFileSize(bytes) {
    if (!bytes) return '-';
    const kb = bytes / 1024;
    if (kb < 1024) return `${kb.toFixed(1)} KB`;
    const mb = kb / 1024;
    return `${mb.toFixed(2)} MB`;
}

// Load Dashboard
async function loadDashboard() {
    pageTitle.textContent = '概览';
    
    try {
        const [templatesRes, tasksRes] = await Promise.all([
            fetch(`${API_BASE}/task-templates`),
            fetch(`${API_BASE}/task-runs?limit=10`)
        ]);
        
        const templates = await templatesRes.json();
        const tasks = await tasksRes.json();
        
        const templateCount = templates.data?.length || 0;
        const taskCount = tasks.data?.length || 0;
        
        contentArea.innerHTML = `
            <div class="card">
                <div class="card-header">
                    <div class="card-title">欢迎</div>
                </div>
                <div class="card-body">
                    <p>欢迎使用 Chujiu TodoList 系统</p>
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin-top: 20px;">
                        <div style="padding: 16px; background: var(--bg-color); border-radius: 8px;">
                            <div style="font-size: 24px; font-weight: bold; color: var(--primary-color)">${templateCount}</div>
                            <div style="color: var(--text-secondary)">可用模板</div>
                        </div>
                        <div style="padding: 16px; background: var(--bg-color); border-radius: 8px;">
                            <div style="font-size: 24px; font-weight: bold; color: var(--primary-color)">${taskCount}</div>
                            <div style="color: var(--text-secondary)">任务总数</div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    } catch (error) {
        contentArea.innerHTML = `<div class="card"><div class="card-body">加载失败：${error.message}</div></div>`;
    }
}

// Load Upload
function loadUpload() {
    pageTitle.textContent = '文件上传';
    contentArea.innerHTML = `
        <div class="card" data-testid="upload-card">
            <div class="card-header">
                <div class="card-title" data-testid="upload-title">上传文件</div>
            </div>
            <div class="card-body">
                <div class="upload-area" id="upload-area" data-testid="upload-area" style="border: 2px dashed var(--border-color); border-radius: 12px; padding: 48px; text-align: center; cursor: pointer;">
                    <div style="font-size: 48px; margin-bottom: 16px;">📤</div>
                    <div style="font-size: 16px; font-weight: 500;">点击或拖拽文件到此处上传</div>
                    <div style="color: var(--text-secondary); margin-top: 8px;">支持 .xlsm, .xls, .xlsx, .et, .wps 格式，最大 50MB</div>
                    <input type="file" id="file-input" data-testid="file-input" accept=".xlsm,.xls,.xlsx,.et,.wps" style="display:none">
                </div>
                
                <div class="form-group" style="margin-top: 24px;">
                    <label class="form-label" style="display: block; margin-bottom: 8px; font-weight: 500;">选择插件</label>
                    <select class="form-select" id="plugin-select" data-testid="plugin-select" style="width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 8px;">
                        <option value="excel_vba_to_wps_js">Excel VBA 转 WPS JS</option>
                        <option value="wps_js_to_excel_vba">WPS JS 转 Excel VBA</option>
                        <option value="web_briefing">网页简报</option>
                    </select>
                </div>
                
                <div id="upload-result" data-testid="upload-result" style="margin-top: 24px;"></div>
            </div>
        </div>
    `;
    
    // Initialize upload handlers
    initUploadHandlers();
}

// Initialize upload handlers
function initUploadHandlers() {
    const uploadArea = document.getElementById('upload-area');
    const fileInput = document.getElementById('file-input');
    
    if (!uploadArea || !fileInput) return;
    
    uploadArea.addEventListener('click', () => fileInput.click());
    
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.style.borderColor = 'var(--primary-color)';
        uploadArea.style.background = 'var(--primary-light)';
    });
    
    uploadArea.addEventListener('dragleave', () => {
        uploadArea.style.borderColor = 'var(--border-color)';
        uploadArea.style.background = 'transparent';
    });
    
    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.style.borderColor = 'var(--border-color)';
        uploadArea.style.background = 'transparent';
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleFileUpload(files[0]);
        }
    });
    
    fileInput.addEventListener('change', () => {
        if (fileInput.files.length > 0) {
            handleFileUpload(fileInput.files[0]);
        }
    });
}

// Handle file upload
async function handleFileUpload(file) {
    const pluginCode = document.getElementById('plugin-select').value;
    const formData = new FormData();
    formData.append('file', file);
    formData.append('pluginCode', pluginCode);
    
    const resultDiv = document.getElementById('upload-result');
    if (resultDiv) {
        resultDiv.innerHTML = '<div style="color: var(--text-secondary);">正在上传...</div>';
    }
    
    try {
        const response = await fetch(`${API_BASE}/uploads`, {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.code === 'OK') {
            // Store upload info for task creation
            window.lastUploadInfo = {
                uploadId: result.data.uploadId,
                pluginCode: pluginCode
            };
            
            if (resultDiv) {
                resultDiv.innerHTML = `
                    <div class="card" style="background: var(--primary-light); border: 1px solid var(--primary-color);">
                        <div class="card-header">
                            <div class="card-title" style="color: var(--primary-color)">✅ 上传成功</div>
                        </div>
                        <div class="card-body">
                            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px;">
                                <div>
                                    <div style="font-size: 12px; color: var(--text-secondary)">文件名</div>
                                    <div style="font-weight: 500">${result.data.fileName}</div>
                                </div>
                                <div>
                                    <div style="font-size: 12px; color: var(--text-secondary)">Upload ID</div>
                                    <div style="font-family: monospace; color: var(--primary-color)">${result.data.uploadId}</div>
                                </div>
                                <div>
                                    <div style="font-size: 12px; color: var(--text-secondary)">插件</div>
                                    <div>${result.data.pluginCode}</div>
                                </div>
                                <div>
                                    <div style="font-size: 12px; color: var(--text-secondary)">状态</div>
                                    <div>${renderStatusBadge(result.data.status)}</div>
                                </div>
                            </div>
                            <button class="btn btn-primary" style="margin-top: 16px;" onclick="createTaskRunFromUpload()">
                                创建并启动任务
                            </button>
                        </div>
                    </div>
                `;
            }
            showToast('上传成功!', 'success');
        } else {
            if (resultDiv) {
                resultDiv.innerHTML = `<div style="color: var(--error-color);">上传失败：${result.message}</div>`;
            }
            showToast('上传失败：' + result.message, 'error');
        }
    } catch (error) {
        if (resultDiv) {
            resultDiv.innerHTML = `<div style="color: var(--error-color);">上传失败：${error.message}</div>`;
        }
        showToast('上传失败：' + error.message, 'error');
    }
}

// Create task run from upload (global function for button click)
window.createTaskRunFromUpload = function() {
    const uploadInfo = window.lastUploadInfo;
    if (!uploadInfo) {
        showToast('请先上传文件', 'error');
        return;
    }
    
    const payload = {
        taskTemplateCode: uploadInfo.pluginCode,
        uploadId: uploadInfo.uploadId,
        runtimeParams: {}
    };
    
    const resultDiv = document.getElementById('upload-result');
    if (resultDiv) {
        resultDiv.innerHTML = '<div style="color: var(--text-secondary);">正在创建任务...</div>';
    }
    
    fetch(`${API_BASE}/task-runs`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(response => response.json())
    .then(result => {
        if (result.code === 'OK') {
            if (resultDiv) {
                resultDiv.innerHTML = `
                    <div class="card" style="background: var(--success-bg); border: 1px solid var(--success-color);">
                        <div class="card-header">
                            <div class="card-title" style="color: var(--success-color)">✅ 任务创建成功</div>
                        </div>
                        <div class="card-body">
                            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px;">
                                <div>
                                    <div style="font-size: 12px; color: var(--text-secondary)">任务 ID</div>
                                    <div style="font-family: monospace; color: var(--success-color)">${result.data.taskRunId}</div>
                                </div>
                                <div>
                                    <div style="font-size: 12px; color: var(--text-secondary)">状态</div>
                                    <div>${renderStatusBadge(result.data.status)}</div>
                                </div>
                            </div>
                            <div style="margin-top: 16px; display: flex; gap: 12px;">
                                <button class="btn btn-primary" onclick="loadPage('tasks')">查看任务列表</button>
                                <button class="btn btn-secondary" onclick="loadPage('upload')">继续上传</button>
                            </div>
                        </div>
                    </div>
                `;
            }
            showToast('任务创建成功!', 'success');
            // Clear upload info
            window.lastUploadInfo = null;
        } else {
            if (resultDiv) {
                resultDiv.innerHTML = `<div style="color: var(--error-color);">创建失败：${result.message}</div>`;
            }
            showToast('创建失败：' + result.message, 'error');
        }
    })
    .catch(error => {
        if (resultDiv) {
            resultDiv.innerHTML = `<div style="color: var(--error-color);">创建失败：${error.message}</div>`;
        }
        showToast('创建失败：' + error.message, 'error');
    });
};

// Load Tasks
async function loadTasks() {
    pageTitle.textContent = '任务列表';
    
    try {
        const response = await fetch(`${API_BASE}/task-runs`);
        const result = await response.json();
        
        if (result.data && result.data.length > 0) {
            contentArea.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">任务列表</div>
                    </div>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>任务 ID</th>
                                    <th>模板</th>
                                    <th>状态</th>
                                    <th>进度</th>
                                    <th>创建时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${result.data.map(task => `
                                    <tr>
                                        <td><span style="font-family: monospace; color: var(--primary-color)">#${task.id}</span></td>
                                        <td>${task.taskTemplateCode || '-'}</td>
                                        <td>${renderStatusBadge(task.status)}</td>
                                        <td>
                                            <div style="display: flex; align-items: center; gap: 8px;">
                                                <div class="progress-bar" style="width: 80px; height: 6px; background: var(--bg-color); border-radius: 3px; overflow: hidden;">
                                                    <div class="progress-fill" style="width: ${task.progress || 0}%; height: 100%; background: var(--primary-color);"></div>
                                                </div>
                                                <span style="font-size: 12px; color: var(--text-secondary)">${task.progress || 0}%</span>
                                            </div>
                                        </td>
                                        <td>${formatDate(task.createdAt)}</td>
                                        <td>
                                            <div style="display: flex; gap: 8px;">
                                                ${task.status === 'READY' ? `<button class="btn btn-primary btn-sm" onclick="startTask(${task.id})">启动</button>` : ''}
                                                <button class="btn btn-secondary btn-sm" onclick="viewTask(${task.id})">详情</button>
                                            </div>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
        } else {
            contentArea.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">任务列表</div>
                    </div>
                    <div class="card-body" style="text-align: center; padding: 48px;">
                        <div style="font-size: 48px; margin-bottom: 16px;">📋</div>
                        <div style="color: var(--text-secondary);">暂无任务</div>
                        <div style="margin-top: 16px;">
                            <button class="btn btn-primary" onclick="loadPage('upload')">上传文件创建任务</button>
                        </div>
                    </div>
                </div>
            `;
        }
    } catch (error) {
        contentArea.innerHTML = `<div class="card"><div class="card-body">加载失败：${error.message}</div></div>`;
    }
}

// Start task
window.startTask = function(taskId) {
    fetch(`${API_BASE}/task-runs/${taskId}/start`, {
        method: 'POST'
    })
    .then(response => response.json())
    .then(result => {
        if (result.code === 'OK') {
            showToast('任务已启动!', 'success');
            loadTasks();
        } else {
            showToast('启动失败：' + result.message, 'error');
        }
    })
    .catch(error => {
        showToast('启动失败：' + error.message, 'error');
    });
};

// View task - 跳转到任务详情页
window.viewTask = function(taskId) {
    window.location.hash = `tasks/${taskId}`;
};

// Show task detail with DAG visualization
function showTaskDetail(taskId, taskData) {
    // 先关闭已存在的弹窗（如果有）
    const existingModal = document.querySelector('.modal-overlay');
    if (existingModal) {
        existingModal.remove();
    }
    
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
    `;
    
    // 计算总步骤数和完成数
    const totalSteps = (taskData.dagNodes || taskData.jobs || []).length;
    const completedSteps = (taskData.dagNodes || taskData.jobs || []).filter(n => n.status === 'SUCCESS').length;
    
    modal.innerHTML = `
        <div style="
            background: var(--card-bg);
            border-radius: 12px;
            padding: 24px;
            max-width: 1200px;
            width: 95%;
            max-height: 90vh;
            overflow: auto;
        ">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
                <h3 style="margin: 0;">任务详情 #${taskId}</h3>
                <button onclick="closeTaskDetailModal(this)" style="width: 32px; height: 32px; border: 1px solid var(--border-color); background: var(--card-bg); border-radius: 8px; cursor: pointer; font-size: 16px;">✕</button>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px;">
                <div style="padding: 16px; background: var(--bg-color); border-radius: 8px;">
                    <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 4px;">任务 ID</div>
                    <div style="font-family: monospace; color: var(--primary-color)">#${taskData.id}</div>
                </div>
                <div style="padding: 16px; background: var(--bg-color); border-radius: 8px;">
                    <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 4px;">状态</div>
                    <div>${renderStatusBadge(taskData.status)}</div>
                </div>
                <div style="padding: 16px; background: var(--bg-color); border-radius: 8px;">
                    <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 4px;">总步骤</div>
                    <div style="font-size: 20px; font-weight: 600; color: var(--primary-color)">${totalSteps}</div>
                </div>
                <div style="padding: 16px; background: var(--bg-color); border-radius: 8px;">
                    <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 4px;">完成数</div>
                    <div style="font-size: 20px; font-weight: 600; color: var(--success-color)">${completedSteps}</div>
                </div>
            </div>
            
            <div style="margin-bottom: 24px;">
                <h4 style="margin-bottom: 12px;">DAG 执行流程</h4>
                <div id="dag-visualization" style="height: 500px; border: 1px solid var(--border-color); border-radius: 8px; overflow: hidden;"></div>
            </div>
            
            ${taskData.jobs && taskData.jobs.length > 0 ? `
            <div>
                <h4 style="margin-bottom: 12px;">Job 列表</h4>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Job ID</th>
                                <th>代码</th>
                                <th>名称</th>
                                <th>状态</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${taskData.jobs.map(job => `
                                <tr>
                                    <td><span style="font-family: monospace; color: var(--primary-color)">#${job.id}</span></td>
                                    <td><code>${job.code}</code></td>
                                    <td>${job.name}</td>
                                    <td>${renderStatusBadge(job.status)}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
            ` : ''}
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // 初始化 DAG 可视化
    initDagVisualization(taskId, taskData);
}

// Close task detail modal
window.closeTaskDetailModal = function(btn) {
    const modal = btn.closest('.modal-overlay');
    if (modal) {
        modal.remove();
    }
};

// Initialize DAG visualization helper
function initDagVisualization(taskId, taskData) {
    setTimeout(() => {
        const dagData = {
            nodes: taskData.dagNodes || [],
            edges: taskData.dagEdges || []
        };
        
        // Add status to nodes from job runs if available
        if (taskData.jobs) {
            dagData.nodes = dagData.nodes.map(node => {
                const job = taskData.jobs.find(j => j.code === node.code);
                return {
                    ...node,
                    status: job ? job.status : node.status || 'PENDING'
                };
            });
        }
        
        if (dagData.nodes.length > 0) {
            dagVisualizer = new DagVisualizer('dag-visualization', dagData);
        } else {
            document.getElementById('dag-visualization').innerHTML = `
                <div style="display: flex; align-items: center; justify-content: center; height: 100%; color: var(--text-secondary);">
                    <div style="text-align: center;">
                        <div style="font-size: 48px; margin-bottom: 16px;">📊</div>
                        <div>暂无 DAG 节点数据</div>
                    </div>
                </div>
            `;
        }
    }, 100);
}

// Load Templates (Prompts)
async function loadTemplates() {
    pageTitle.textContent = '提示词库';
    
    try {
        // Fetch categories and prompts
        const [categoriesRes, promptsRes] = await Promise.all([
            fetch(`${API_BASE}/prompt-categories`),
            fetch(`${API_BASE}/prompts`)
        ]);
        
        const categoriesResult = await categoriesRes.json();
        const promptsResult = await promptsRes.json();
        
        const categories = categoriesResult.data || [];
        const prompts = promptsResult.data || [];
        
        if (prompts.length > 0) {
            // 创建分类 ID 到名称的映射
            const categoryMap = {};
            categories.forEach(cat => {
                categoryMap[cat.id] = cat.name;
            });
            
            // Group prompts by category
            const byCategory = {};
            
            // Add prompts to categories
            prompts.forEach(prompt => {
                // 使用 category_id 查找分类名称
                const catName = categoryMap[prompt.category_id] || '其他';
                if (!byCategory[catName]) {
                    byCategory[catName] = {
                        category: { name: catName },
                        prompts: []
                    };
                }
                byCategory[catName].prompts.push(prompt);
            });
            
            contentArea.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">提示词库</div>
                        <div class="card-actions">
                            <button class="btn btn-primary btn-sm" onclick="createNewPrompt()">➕ 新增提示词</button>
                        </div>
                    </div>
                    ${Object.entries(byCategory).map(([categoryName, data]) => `
                        <div style="margin-bottom: 24px;">
                            <h3 style="font-size: 16px; font-weight: 600; margin-bottom: 12px; color: var(--primary-color); display: flex; align-items: center; gap: 8px;">
                                ${getCategoryIcon(categoryName)} ${categoryName}
                                <span class="badge" style="font-size: 11px; padding: 2px 8px; background: var(--primary-light); color: var(--primary-color); border-radius: 6px;">${data.prompts.length}</span>
                            </h3>
                            <div class="table-container">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>代码</th>
                                            <th>名称</th>
                                            <th>描述</th>
                                            <th>变量</th>
                                            <th>操作</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${data.prompts.map(prompt => `
                                            <tr>
                                                <td><code style="background: var(--bg-color); padding: 2px 6px; border-radius: 4px; font-size: 12px;">${prompt.code}</code></td>
                                                <td>${prompt.name}</td>
                                                <td style="color: var(--text-secondary); max-width: 300px;">${prompt.description || '-'}</td>
                                                <td>
                                                    ${prompt.variables ? Object.keys(prompt.variables).map(v => 
                                                        `<span class="badge badge-primary" style="font-size: 11px; padding: 2px 8px; background: var(--primary-light); color: var(--primary-color); border-radius: 6px;">${v}</span>`
                                                    ).join(' ') : '-'}
                                                </td>
                                                <td>
                                                    <div style="display: flex; gap: 8px;">
                                                        <button class="btn btn-secondary btn-sm" onclick="viewPromptDetail('${prompt.code}')">查看</button>
                                                        ${!prompt.is_system ? `<button class="btn btn-secondary btn-sm" onclick="editPrompt('${prompt.code}')">编辑</button>` : ''}
                                                    </div>
                                                </td>
                                            </tr>
                                        `).join('')}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        } else {
            contentArea.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">提示词库</div>
                        <div class="card-actions">
                            <button class="btn btn-primary btn-sm" onclick="createNewPrompt()">➕ 新增提示词</button>
                        </div>
                    </div>
                    <div class="card-body" style="text-align: center; padding: 48px;">
                        <div style="font-size: 48px; margin-bottom: 16px;">📝</div>
                        <div style="color: var(--text-secondary);">暂无提示词</div>
                        <div style="margin-top: 16px;">
                            <button class="btn btn-primary" onclick="createNewPrompt()">新增第一个提示词</button>
                        </div>
                    </div>
                </div>
            `;
        }
    } catch (error) {
        contentArea.innerHTML = `<div class="card"><div class="card-body">加载失败：${error.message}</div></div>`;
    }
}

// Get category icon
function getCategoryIcon(category) {
    const icons = {
        'Excel 转换': '📊',
        '代码审视': '🔍',
        '网页浏览': '🌐',
        '通用': '📝'
    };
    return icons[category] || '📄';
}

// Create new prompt
window.createNewPrompt = function() {
    // Fetch categories first
    fetch(`${API_BASE}/prompt-categories`)
    .then(response => response.json())
    .then(result => {
        if (result.code !== 'OK') {
            showToast('获取分类失败', 'error');
            return;
        }
        
        const categories = result.data;
        showPromptModal(null, categories);
    })
    .catch(error => {
        showToast('获取分类失败：' + error.message, 'error');
    });
};

// Edit prompt
window.editPrompt = function(promptCode) {
    // Fetch prompt details
    fetch(`${API_BASE}/prompts/code/${promptCode}`)
    .then(response => response.json())
    .then(result => {
        if (result.code !== 'OK') {
            showToast('获取提示词失败', 'error');
            return;
        }
        
        // Fetch categories
        return fetch(`${API_BASE}/prompt-categories`)
        .then(response => response.json())
        .then(catResult => {
            if (catResult.code !== 'OK') {
                showToast('获取分类失败', 'error');
                return;
            }
            
            showPromptModal(result.data, catResult.data, true);
        });
    })
    .catch(error => {
        showToast('获取提示词失败：' + error.message, 'error');
    });
};

// Show prompt modal (create or edit)
function showPromptModal(promptData, categories, isEdit = false) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
    `;
    
    modal.innerHTML = `
        <div style="
            background: var(--card-bg);
            border-radius: 12px;
            padding: 24px;
            max-width: 800px;
            width: 90%;
            max-height: 80vh;
            overflow: auto;
        ">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
                <h3 style="margin: 0;">${isEdit ? '✏️ 编辑提示词' : '➕ 新增提示词'}</h3>
                <button class="btn-icon" onclick="this.closest('.modal-overlay').remove()" style="width: 32px; height: 32px; border: 1px solid var(--border-color); background: var(--card-bg); border-radius: 8px; cursor: pointer;">✕</button>
            </div>
            
            <form id="prompt-form">
                <input type="hidden" id="prompt-code-original" value="${promptData?.code || ''}">
                
                <div class="form-group" style="margin-bottom: 16px;">
                    <label class="form-label" style="display: block; margin-bottom: 8px; font-weight: 500;">所属分类 *</label>
                    <select class="form-select" id="prompt-category" required style="width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 8px;">
                        ${categories.map(cat => `
                            <option value="${cat.id}" ${promptData && promptData.category_id === cat.id ? 'selected' : ''}>${cat.name}</option>
                        `).join('')}
                    </select>
                </div>
                
                <div class="form-group" style="margin-bottom: 16px;">
                    <label class="form-label" style="display: block; margin-bottom: 8px; font-weight: 500;">提示词代码 *</label>
                    <input type="text" class="form-input" id="prompt-code" value="${promptData?.code || ''}" placeholder="如：vba_to_ast" required ${isEdit ? 'disabled' : ''} style="width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 8px;">
                    <div class="form-hint" style="font-size: 12px; color: var(--text-secondary); margin-top: 4px;">唯一标识符，只能包含字母、数字和下划线${isEdit ? '（不可修改）' : ''}</div>
                </div>
                
                <div class="form-group" style="margin-bottom: 16px;">
                    <label class="form-label" style="display: block; margin-bottom: 8px; font-weight: 500;">提示词名称 *</label>
                    <input type="text" class="form-input" id="prompt-name" value="${promptData?.name || ''}" placeholder="如：VBA 转 AST" required style="width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 8px;">
                </div>
                
                <div class="form-group" style="margin-bottom: 16px;">
                    <label class="form-label" style="display: block; margin-bottom: 8px; font-weight: 500;">描述</label>
                    <textarea class="form-textarea" id="prompt-description" rows="2" placeholder="简要描述提示词的用途" style="width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 8px; resize: vertical; min-height: 60px;">${promptData?.description || ''}</textarea>
                </div>
                
                <div class="form-group" style="margin-bottom: 16px;">
                    <label class="form-label" style="display: block; margin-bottom: 8px; font-weight: 500;">System Prompt</label>
                    <textarea class="form-textarea" id="prompt-system" rows="4" placeholder="系统级提示词，定义 AI 的角色和行为准则" style="width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 8px; resize: vertical; min-height: 100px;">${promptData?.system_prompt || ''}</textarea>
                </div>
                
                <div class="form-group" style="margin-bottom: 16px;">
                    <label class="form-label" style="display: block; margin-bottom: 8px; font-weight: 500;">User Prompt *</label>
                    <textarea class="form-textarea" id="prompt-user" rows="6" placeholder="用户提示词模板，支持 Jinja2 变量（如：{{code}}）" required style="width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 8px; resize: vertical; min-height: 150px;">${promptData?.user_prompt || ''}</textarea>
                    <div class="form-hint" style="font-size: 12px; color: var(--text-secondary); margin-top: 4px;">支持 Jinja2 模板语法，变量使用 {{变量名}} 格式</div>
                </div>
                
                <div class="form-group" style="margin-bottom: 16px;">
                    <label class="form-label" style="display: block; margin-bottom: 8px; font-weight: 500;">变量定义</label>
                    <textarea class="form-textarea" id="prompt-variables" rows="3" placeholder='{"code": "VBA 源代码", "schema": "AST 结构定义"}' style="width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 8px; resize: vertical; min-height: 80px; font-family: monospace;">${promptData?.variables ? JSON.stringify(promptData.variables, null, 2) : ''}</textarea>
                    <div class="form-hint" style="font-size: 12px; color: var(--text-secondary); margin-top: 4px;">JSON 格式，定义变量名和说明</div>
                </div>
                
                <div style="margin-top: 24px; display: flex; gap: 12px; justify-content: flex-end;">
                    <button type="button" class="btn btn-secondary" onclick="this.closest('.modal-overlay').remove()">取消</button>
                    <button type="submit" class="btn btn-primary">${isEdit ? '💾 保存' : '✅ 创建'}</button>
                </div>
            </form>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Handle form submission
    const form = document.getElementById('prompt-form');
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const category_id = parseInt(document.getElementById('prompt-category').value);
        const code = document.getElementById('prompt-code').value.trim();
        const name = document.getElementById('prompt-name').value.trim();
        const description = document.getElementById('prompt-description').value.trim();
        const system_prompt = document.getElementById('prompt-system').value.trim();
        const user_prompt = document.getElementById('prompt-user').value.trim();
        const variablesText = document.getElementById('prompt-variables').value.trim();
        
        // Parse variables
        let variables = {};
        if (variablesText) {
            try {
                variables = JSON.parse(variablesText);
            } catch (e) {
                showToast('变量定义必须是有效的 JSON 格式', 'error');
                return;
            }
        }
        
        const payload = {
            category_id,
            code,
            name,
            description,
            system_prompt,
            user_prompt,
            variables,
            is_system: false
        };
        
        const url = isEdit 
            ? `${API_BASE}/prompts/code/${promptData.code}`
            : `${API_BASE}/prompts`;
        
        const method = isEdit ? 'PUT' : 'POST';
        
        fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
        .then(response => response.json())
        .then(result => {
            if (result.code === 'OK') {
                showToast(isEdit ? '提示词已更新' : '提示词创建成功', 'success');
                modal.remove();
                loadTemplates(); // Refresh list
            } else {
                showToast((isEdit ? '更新' : '创建') + '失败：' + result.message, 'error');
            }
        })
        .catch(error => {
            showToast((isEdit ? '更新' : '创建') + '失败：' + error.message, 'error');
        });
    });
}

// View prompt detail
window.viewPromptDetail = function(promptCode) {
    fetch(`${API_BASE}/prompts/code/${promptCode}`)
    .then(response => response.json())
    .then(result => {
        if (result.code === 'OK') {
            const prompt = result.data;
            const modal = document.createElement('div');
            modal.className = 'modal-overlay';
            modal.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0,0,0,0.5);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 1000;
            `;
            modal.innerHTML = `
                <div style="
                    background: var(--card-bg);
                    border-radius: 12px;
                    padding: 24px;
                    max-width: 900px;
                    width: 90%;
                    max-height: 80vh;
                    overflow: auto;
                ">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
                        <h3 style="margin: 0;">${prompt.name}</h3>
                        <button class="btn-icon" onclick="this.closest('.modal-overlay').remove()" style="width: 32px; height: 32px; border: 1px solid var(--border-color); background: var(--card-bg); border-radius: 8px; cursor: pointer;">✕</button>
                    </div>
                    
                    <div style="margin-bottom: 16px;">
                        <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 4px;">代码</div>
                        <code style="background: var(--primary-light); color: var(--primary-color); padding: 4px 8px; border-radius: 4px;">${prompt.code}</code>
                    </div>
                    
                    <div style="margin-bottom: 16px;">
                        <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 4px;">System Prompt</div>
                        <div style="
                            background: var(--primary-light);
                            border-left: 3px solid var(--primary-color);
                            padding: 12px;
                            border-radius: 6px;
                            font-size: 13px;
                            color: var(--text-primary);
                            margin-bottom: 12px;
                            white-space: pre-wrap;
                        ">${prompt.system_prompt || '无'}</div>
                    </div>
                    
                    <div style="margin-bottom: 16px;">
                        <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 4px;">User Prompt（预览）</div>
                        <div class="code-block" style="max-height: 200px; overflow: auto; white-space: pre-wrap; margin-bottom: 12px; background: var(--bg-color); padding: 16px; border-radius: 8px; font-family: monospace; font-size: 13px;">${prompt.user_prompt}</div>
                        <div style="font-size: 12px; color: var(--text-secondary);">变量定义：</div>
                        <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-top: 8px;">
                            ${Object.entries(prompt.variables || {}).map(([key, value]) => `
                                <div style="
                                    background: var(--bg-color);
                                    padding: 8px 12px;
                                    border-radius: 6px;
                                    font-size: 12px;
                                ">
                                    <strong style="color: var(--primary-color);">${key}</strong>: ${value}
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    
                    <div style="margin-top: 24px; display: flex; gap: 12px; justify-content: flex-end; flex-wrap: wrap;">
                        <button class="btn btn-secondary" onclick="copyPromptContent('${prompt.code}', 'system')">📋 复制 System Prompt</button>
                        <button class="btn btn-secondary" onclick="copyPromptContent('${prompt.code}', 'user')">📋 复制 User Prompt</button>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
        }
    })
    .catch(error => {
        showToast('获取详情失败：' + error.message, 'error');
    });
};

// Copy prompt content
window.copyPromptContent = function(promptCode, type) {
    fetch(`${API_BASE}/prompts/code/${promptCode}`)
    .then(response => response.json())
    .then(result => {
        if (result.code === 'OK') {
            const prompt = result.data;
            const content = type === 'system' ? prompt.system_prompt : prompt.user_prompt;
            navigator.clipboard.writeText(content || '').then(() => {
                showToast(`${type === 'system' ? 'System Prompt' : 'User Prompt'} 已复制到剪贴板`, 'success');
            });
        }
    })
    .catch(error => {
        showToast('复制失败：' + error.message, 'error');
    });
};

// Load Plugins
async function loadPlugins() {
    pageTitle.textContent = '插件管理';
    
    try {
        const response = await fetch(`${API_BASE}/plugins`);
        const result = await response.json();
        
        if (result.data && result.data.length > 0) {
            contentArea.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">插件列表</div>
                        <div class="card-actions">
                            <label style="display: flex; align-items: center; gap: 8px; font-size: 13px;">
                                <input type="checkbox" id="show-enabled-only" onchange="loadPlugins()">
                                仅显示启用的
                            </label>
                        </div>
                    </div>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>状态</th>
                                    <th>插件代码</th>
                                    <th>名称</th>
                                    <th>版本</th>
                                    <th>描述</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${result.data.map(plugin => `
                                    <tr>
                                        <td>
                                            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                                                <input type="checkbox" 
                                                    ${plugin.enabled ? 'checked' : ''} 
                                                    onchange="togglePlugin('${plugin.code}', this.checked)">
                                                <span class="status-badge ${plugin.enabled ? 'success' : 'pending'}" style="font-size: 11px; padding: 2px 8px;">
                                                    ${plugin.enabled ? '✓ 启用' : '○ 禁用'}
                                                </span>
                                            </label>
                                        </td>
                                        <td><code style="background: var(--bg-color); padding: 2px 6px; border-radius: 4px; font-size: 12px;">${plugin.code}</code></td>
                                        <td>${plugin.name}</td>
                                        <td><span class="badge badge-primary" style="font-size: 11px; padding: 2px 8px; background: var(--primary-light); color: var(--primary-color); border-radius: 6px;">v${plugin.version}</span></td>
                                        <td style="color: var(--text-secondary); max-width: 300px;">${plugin.description || '-'}</td>
                                        <td>
                                            <div style="display: flex; gap: 8px;">
                                                <button class="btn btn-secondary btn-sm" onclick="viewPluginDag('${plugin.code}')">查看 DAG</button>
                                                <button class="btn btn-secondary btn-sm" onclick="viewPluginLearning('${plugin.code}')">Learning</button>
                                                <button class="btn btn-secondary btn-sm" onclick="reloadPlugin('${plugin.code}')">⟳ 重载</button>
                                            </div>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
        } else {
            contentArea.innerHTML = `<div class="card"><div class="card-body">暂无插件</div></div>`;
        }
    } catch (error) {
        contentArea.innerHTML = `<div class="card"><div class="card-body">加载失败：${error.message}</div></div>`;
    }
}

// Toggle plugin enabled/disabled
window.togglePlugin = function(pluginCode, enabled) {
    fetch(`${API_BASE}/plugins/${pluginCode}/toggle`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled })
    })
    .then(response => response.json())
    .then(result => {
        if (result.code === 'OK') {
            showToast(`插件已${enabled ? '启用' : '禁用'}`, 'success');
            loadPlugins();
        } else {
            showToast('操作失败：' + result.message, 'error');
        }
    })
    .catch(error => {
        showToast('操作失败：' + error.message, 'error');
    });
};

// View plugin DAG
window.viewPluginDag = function(pluginCode) {
    fetch(`${API_BASE}/plugins/${pluginCode}/dag`)
    .then(response => response.json())
    .then(result => {
        if (result.code === 'OK') {
            const dag = result.data;
            const dagJson = JSON.stringify(dag, null, 2);
            
            const modal = document.createElement('div');
            modal.className = 'modal-overlay';
            modal.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0,0,0,0.5);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 1000;
            `;
            modal.innerHTML = `
                <div style="
                    background: var(--card-bg);
                    border-radius: 12px;
                    padding: 24px;
                    max-width: 900px;
                    width: 90%;
                    max-height: 80vh;
                    overflow: auto;
                ">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
                        <h3 style="margin: 0;">DAG 配置 - ${pluginCode}</h3>
                        <button class="btn-icon" onclick="this.closest('.modal-overlay').remove()" style="width: 32px; height: 32px; border: 1px solid var(--border-color); background: var(--card-bg); border-radius: 8px; cursor: pointer;">✕</button>
                    </div>
                    <div class="code-block" style="max-height: 60vh; overflow: auto; background: var(--bg-color); padding: 16px; border-radius: 8px; font-family: monospace; font-size: 13px;">
                        <pre>${dagJson}</pre>
                    </div>
                    <div style="margin-top: 16px; padding: 16px; background: var(--bg-color); border-radius: 8px;">
                        <div style="font-weight: 600; margin-bottom: 8px;">📊 DAG 统计</div>
                        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px;">
                            <div>
                                <div style="font-size: 12px; color: var(--text-secondary)">节点数</div>
                                <div style="font-size: 20px; font-weight: 700; color: var(--primary-color)">${dag.nodes?.length || 0}</div>
                            </div>
                            <div>
                                <div style="font-size: 12px; color: var(--text-secondary)">边数</div>
                                <div style="font-size: 20px; font-weight: 700; color: var(--primary-color)">${dag.edges?.length || 0}</div>
                            </div>
                            <div>
                                <div style="font-size: 12px; color: var(--text-secondary)">条件边</div>
                                <div style="font-size: 20px; font-weight: 700; color: var(--primary-color)">${dag.edges?.filter(e => e.condition_expr)?.length || 0}</div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
        }
    })
    .catch(error => {
        showToast('获取 DAG 失败：' + error.message, 'error');
    });
};

// View plugin Learning rules
window.viewPluginLearning = function(pluginCode) {
    fetch(`${API_BASE}/plugins/${pluginCode}/learning`)
    .then(response => response.json())
    .then(result => {
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
        `;
        
        const content = result.data?.content || '';
        const exists = result.data?.exists || false;
        
        modal.innerHTML = `
            <div style="
                background: var(--card-bg);
                border-radius: 12px;
                padding: 24px;
                max-width: 900px;
                width: 90%;
                max-height: 80vh;
                overflow: auto;
            ">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
                    <h3 style="margin: 0;">Learning Rules - ${pluginCode}</h3>
                    <button class="btn-icon" onclick="this.closest('.modal-overlay').remove()" style="width: 32px; height: 32px; border: 1px solid var(--border-color); background: var(--card-bg); border-radius: 8px; cursor: pointer;">✕</button>
                </div>
                ${exists ? `
                    <textarea id="learning-editor" style="
                        width: 100%;
                        min-height: 400px;
                        padding: 16px;
                        border: 1px solid var(--border-color);
                        border-radius: 8px;
                        font-family: monospace;
                        font-size: 13px;
                        resize: vertical;
                        white-space: pre-wrap;
                    ">${content}</textarea>
                    <div style="margin-top: 16px; display: flex; gap: 12px; justify-content: flex-end;">
                        <button class="btn btn-secondary" onclick="this.closest('.modal-overlay').remove()">取消</button>
                        <button class="btn btn-primary" onclick="saveLearning('${pluginCode}')">💾 保存</button>
                    </div>
                ` : `
                    <div class="empty-state" style="text-align: center; padding: 48px;">
                        <div style="font-size: 48px; margin-bottom: 16px;">📝</div>
                        <div style="font-size: 16px; font-weight: 600; margin-bottom: 8px;">暂无 Learning 规则</div>
                        <div style="color: var(--text-secondary);">任务执行失败后会自动生成 Learning 规则</div>
                    </div>
                `}
            </div>
        `;
        document.body.appendChild(modal);
    })
    .catch(error => {
        showToast('获取 Learning 规则失败：' + error.message, 'error');
    });
};

// Save Learning rules
window.saveLearning = function(pluginCode) {
    const editor = document.getElementById('learning-editor');
    if (!editor) return;
    
    const content = editor.value;
    
    fetch(`${API_BASE}/plugins/${pluginCode}/learning`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content })
    })
    .then(response => response.json())
    .then(result => {
        if (result.code === 'OK') {
            showToast('Learning 规则已保存', 'success');
            editor.closest('.modal-overlay').remove();
        } else {
            showToast('保存失败：' + result.message, 'error');
        }
    })
    .catch(error => {
        showToast('保存失败：' + error.message, 'error');
    });
};

// Reload plugin
window.reloadPlugin = function(pluginCode) {
    fetch(`${API_BASE}/plugins/${pluginCode}/reload`, {
        method: 'POST'
    })
    .then(response => response.json())
    .then(result => {
        if (result.code === 'OK') {
            showToast('插件已重新加载', 'success');
        } else {
            showToast('重载失败：' + result.message, 'error');
        }
    })
    .catch(error => {
        showToast('重载失败：' + error.message, 'error');
    });
};

// Load Artifacts
async function loadArtifacts() {
    pageTitle.textContent = '产物下载';
    
    try {
        const response = await fetch(`${API_BASE}/artifacts`);
        const result = await response.json();
        
        if (result.data && result.data.length > 0) {
            contentArea.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">产物列表</div>
                    </div>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>文件名</th>
                                    <th>类型</th>
                                    <th>大小</th>
                                    <th>创建时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${result.data.map(a => `
                                    <tr>
                                        <td><span style="font-family: monospace; color: var(--primary-color)">#${a.id}</span></td>
                                        <td>${a.fileName}</td>
                                        <td>${a.fileType || '-'}</td>
                                        <td>${formatFileSize(a.fileSize)}</td>
                                        <td style="color: var(--text-secondary)">${formatDate(a.createdAt)}</td>
                                        <td>
                                            <a href="${API_BASE}/artifacts/${a.id}/download" class="btn btn-secondary btn-sm">
                                                下载
                                            </a>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
        } else {
            contentArea.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">产物列表</div>
                    </div>
                    <div class="card-body" style="text-align: center; padding: 48px;">
                        <div style="font-size: 48px; margin-bottom: 16px;">📦</div>
                        <div style="color: var(--text-secondary);">暂无产物</div>
                        <div style="margin-top: 16px; color: var(--text-secondary); font-size: 14px;">完成任务后，产物将显示在这里</div>
                    </div>
                </div>
            `;
        }
    } catch (error) {
        contentArea.innerHTML = `<div class="card"><div class="card-body">加载失败：${error.message}</div></div>`;
    }
}

// Load Health
async function loadHealth() {
    pageTitle.textContent = '健康检查';
    
    try {
        const response = await fetch(`${API_BASE}/../health`);
        const data = await response.json();
        
        contentArea.innerHTML = `
            <div class="card">
                <div class="card-header">
                    <div class="card-title">服务状态</div>
                </div>
                <div class="card-body">
                    <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 16px;">
                        <span class="status-dot connected"></span>
                        <span style="font-weight: bold; color: var(--success-color)">服务正常运行</span>
                    </div>
                    <pre style="background: var(--bg-color); padding: 16px; border-radius: 8px; overflow: auto;">${JSON.stringify(data, null, 2)}</pre>
                </div>
            </div>
        `;
    } catch (error) {
        contentArea.innerHTML = `<div class="card"><div class="card-body">检查失败：${error.message}</div></div>`;
    }
}

// Expose functions globally
window.startTask = function(taskId) {
    // 启动任务 API: POST /api/task-runs/<id>/start
    fetch(`${API_BASE}/task-runs/${taskId}/start`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(result => {
        if (result.code === 'OK') {
            showToast('任务已启动！', 'success');
            loadTasks(); // 刷新任务列表
        } else {
            showToast('启动失败：' + (result.message || '未知错误'), 'error');
        }
    })
    .catch(error => {
        showToast('启动失败：' + error.message, 'error');
    });
};

// viewTask 已在上面定义
