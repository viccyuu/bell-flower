// -*- coding: utf-8 -*-
/**
 * 节点操作功能 ⭐
 * 
 * 提供节点级别的操作：
 * - 查看节点详情
 * - 失败节点重试
 * - 查看节点日志
 */

/**
 * 重试失败节点
 * @param {number} taskId - 任务 ID
 * @param {string} nodeCode - 节点代码
 */
async function retryNode(taskId, nodeCode) {
    try {
        const confirmMsg = `确定要重试节点 "${nodeCode}" 吗？`;
        if (!confirm(confirmMsg)) return;
        
        showToast(`正在重试节点 ${nodeCode}...`, 'info');
        
        const result = await apiClient.post(`/task-runs/${taskId}/nodes/${nodeCode}/retry`);
        
        showToast(`节点 ${nodeCode} 重试成功`, 'success');
        
        // 刷新任务状态
        setTimeout(() => {
            loadTaskDetail(taskId);
        }, 1000);
        
    } catch (error) {
        showToast(`重试失败：${error.message}`, 'error');
    }
}

/**
 * 查看节点日志
 * @param {Object} node - 节点数据
 */
function viewNodeLog(node) {
    const modal = document.createElement('div');
    modal.className = 'node-log-modal';
    modal.innerHTML = `
        <div class="node-log-modal-content">
            <div class="node-log-modal-header">
                <h3>节点日志 - ${node.name}</h3>
                <button class="node-log-modal-close" onclick="closeNodeLog()">&times;</button>
            </div>
            <div class="node-log-modal-body">
                <div class="node-log-info">
                    <div class="node-log-info-item">
                        <label>节点代码:</label>
                        <span>${node.code}</span>
                    </div>
                    <div class="node-log-info-item">
                        <label>节点类型:</label>
                        <span>${node.action_type}</span>
                    </div>
                    <div class="node-log-info-item">
                        <label>状态:</label>
                        <span class="status-badge ${node.status.toLowerCase()}">${node.status}</span>
                    </div>
                    <div class="node-log-info-item">
                        <label>尝试次数:</label>
                        <span>${node.attempt_count || 1}</span>
                    </div>
                    ${node.started_at ? `
                    <div class="node-log-info-item">
                        <label>开始时间:</label>
                        <span>${new Date(node.started_at).toLocaleString('zh-CN')}</span>
                    </div>
                    ` : ''}
                    ${node.finished_at ? `
                    <div class="node-log-info-item">
                        <label>结束时间:</label>
                        <span>${new Date(node.finished_at).toLocaleString('zh-CN')}</span>
                    </div>
                    ` : ''}
                </div>
                
                ${node.input_json ? `
                <div class="node-log-section">
                    <h4>输入数据</h4>
                    <pre class="node-log-json">${formatJSON(node.input_json)}</pre>
                </div>
                ` : ''}
                
                ${node.output_json ? `
                <div class="node-log-section">
                    <h4>输出数据</h4>
                    <pre class="node-log-json">${formatJSON(node.output_json)}</pre>
                </div>
                ` : ''}
                
                ${node.error_json ? `
                <div class="node-log-section">
                    <h4>错误信息</h4>
                    <pre class="node-log-error">${formatJSON(node.error_json)}</pre>
                </div>
                ` : ''}
            </div>
            <div class="node-log-modal-footer">
                ${node.status === 'FAILED' ? `
                <button class="btn btn-warning" onclick="retryNodeFromLog(${task_id}, '${node.code}')">重试节点</button>
                ` : ''}
                <button class="btn" onclick="closeNodeLog()">关闭</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'flex';
    
    // 保存当前 task_id 供重试使用
    window.currentTaskId = taskId;
    
    addNodeLogStyles();
}

/**
 * 从日志弹窗重试节点
 */
function retryNodeFromLog(taskId, nodeCode) {
    closeNodeLog();
    retryNode(taskId, nodeCode);
}

/**
 * 关闭节点日志弹窗
 */
function closeNodeLog() {
    const modal = document.querySelector('.node-log-modal');
    if (modal) {
        modal.remove();
    }
}

/**
 * 格式化 JSON
 */
function formatJSON(json) {
    if (!json) return '{}';
    try {
        const obj = typeof json === 'string' ? JSON.parse(json) : json;
        return JSON.stringify(obj, null, 2);
    } catch (e) {
        return typeof json === 'string' ? json : JSON.stringify(json);
    }
}

/**
 * 添加节点日志样式
 */
function addNodeLogStyles() {
    if (document.getElementById('node-log-styles')) return;
    
    const style = document.createElement('style');
    style.id = 'node-log-styles';
    style.textContent = `
        .node-log-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 10000;
            justify-content: center;
            align-items: center;
        }
        
        .node-log-modal-content {
            background: white;
            border-radius: 8px;
            width: 90%;
            max-width: 900px;
            max-height: 90vh;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }
        
        .node-log-modal-header {
            padding: 20px;
            border-bottom: 1px solid #e8e8e8;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .node-log-modal-header h3 {
            margin: 0;
            font-size: 18px;
        }
        
        .node-log-modal-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }
        
        .node-log-modal-body {
            padding: 20px;
            overflow-y: auto;
            flex: 1;
        }
        
        .node-log-info {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .node-log-info-item {
            display: flex;
            justify-content: space-between;
            padding: 10px;
            background: #f5f5f5;
            border-radius: 4px;
        }
        
        .node-log-info-item label {
            font-weight: bold;
            color: #666;
        }
        
        .node-log-section {
            margin-bottom: 20px;
        }
        
        .node-log-section h4 {
            margin: 0 0 10px 0;
            font-size: 16px;
            color: #333;
        }
        
        .node-log-json,
        .node-log-error {
            background: #f5f5f5;
            padding: 15px;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            overflow: auto;
            max-height: 300px;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        
        .node-log-error {
            background: #fff1f0;
            color: #ff4d4f;
        }
        
        .node-log-modal-footer {
            padding: 20px;
            border-top: 1px solid #e8e8e8;
            text-align: right;
        }
        
        .btn-warning {
            background: #faad14;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 10px;
        }
        
        .btn-warning:hover {
            background: #ffc53d;
        }
        
        @media (max-width: 768px) {
            .node-log-info {
                grid-template-columns: 1fr;
            }
        }
    `;
    document.head.appendChild(style);
}

// 导出供全局使用
window.retryNode = retryNode;
window.viewNodeLog = viewNodeLog;
window.closeNodeLog = closeNodeLog;
window.retryNodeFromLog = retryNodeFromLog;
