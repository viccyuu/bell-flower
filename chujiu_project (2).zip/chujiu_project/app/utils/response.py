# -*- coding: utf-8 -*-
"""
统一响应格式工具 ⭐

提供统一的 API 响应格式：
- 成功：{code: "OK", data: {...}, message: "..."}
- 失败：{code: "ERROR", data: null, message: "..."}
"""
from typing import Any, Optional
from fastapi.responses import JSONResponse
from fastapi.encoders import jsonable_encoder


def success_response(data: Any = None, message: str = "Success", status_code: int = 200):
    """
    成功响应
    
    Args:
        data: 响应数据
        message: 成功消息
        status_code: HTTP 状态码
    
    Returns:
        JSONResponse
    """
    return JSONResponse(
        status_code=status_code,
        content={
            "code": "OK",
            "data": jsonable_encoder(data),
            "message": message
        }
    )


def error_response(message: str, code: str = "ERROR", status_code: int = 400, data: Any = None):
    """
    失败响应
    
    Args:
        message: 错误消息
        code: 错误代码
        status_code: HTTP 状态码
        data: 附加数据
    
    Returns:
        JSONResponse
    """
    return JSONResponse(
        status_code=status_code,
        content={
            "code": code,
            "data": jsonable_encoder(data),
            "message": message
        }
    )


def created_response(data: Any, message: str = "Created"):
    """
    创建成功响应 (201)
    
    Args:
        data: 响应数据
        message: 成功消息
    
    Returns:
        JSONResponse
    """
    return success_response(data, message, status_code=201)


def not_found_response(message: str = "Not Found"):
    """
    未找到响应 (404)
    
    Args:
        message: 错误消息
    
    Returns:
        JSONResponse
    """
    return error_response(message, code="NOT_FOUND", status_code=404)


def bad_request_response(message: str):
    """
    错误请求响应 (400)
    
    Args:
        message: 错误消息
    
    Returns:
        JSONResponse
    """
    return error_response(message, code="BAD_REQUEST", status_code=400)


def internal_error_response(message: str = "Internal Server Error"):
    """
    服务器内部错误响应 (500)
    
    Args:
        message: 错误消息
    
    Returns:
        JSONResponse
    """
    return error_response(message, code="INTERNAL_ERROR", status_code=500)
