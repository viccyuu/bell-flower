﻿# -*- coding: utf-8 -*-

"""
Models Package - Export all models
"""
from app.models.models import (
    User,
    UploadFile,
    TaskTemplate,
    TaskRun,
    JobTemplate,
    JobRun,
    NodeTemplate,
    EdgeTemplate,
    NodeRun,
    Artifact,
    ExecutionLog,
    LearningRule,
    PluginDagRegistry,
    db
)

from app.models.prompts import (
    PromptCategory,
    PromptTemplate
)

__all__ = [
    # Core models
    'User',
    'UploadFile',
    'TaskTemplate',
    'TaskRun',
    'JobTemplate',
    'JobRun',
    'NodeTemplate',
    'EdgeTemplate',
    'NodeRun',
    'Artifact',
    'ExecutionLog',
    'LearningRule',
    'PluginDagRegistry',
    'db',
    # Prompt models
    'PromptCategory',
    'PromptTemplate'
]
