﻿# -*- coding: utf-8 -*-

"""
Prompt Management Module - Data Models
"""
from datetime import datetime
from app.extensions import db
import json


class PromptCategory(db.Model):
    """Prompt Category Table"""
    __tablename__ = 'prompt_category'
    
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(50), unique=True, nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    parent_id = db.Column(db.Integer, db.ForeignKey('prompt_category.id'), nullable=True)
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    parent = db.relationship('PromptCategory', remote_side=[id], backref='children')
    prompts = db.relationship('PromptTemplate', backref='category', lazy='dynamic')
    
    def to_dict(self):
        """Convert to dictionary"""
        return {
            'id': self.id,
            'code': self.code,
            'name': self.name,
            'description': self.description,
            'parent_id': self.parent_id,
            'sort_order': self.sort_order,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'prompt_count': self.prompts.count()
        }


class PromptTemplate(db.Model):
    """Prompt Template Table"""
    __tablename__ = 'prompt_template'
    
    id = db.Column(db.Integer, primary_key=True)
    category_id = db.Column(db.Integer, db.ForeignKey('prompt_category.id'), nullable=False, index=True)
    code = db.Column(db.String(100), unique=True, nullable=False, index=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    system_prompt = db.Column(db.Text)
    user_prompt = db.Column(db.Text, nullable=False)
    variables = db.Column(db.Text)
    version = db.Column(db.Integer, default=1)
    enabled = db.Column(db.Boolean, default=True, index=True)
    is_system = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def get_variables(self):
        """Get variables definition"""
        if self.variables:
            try:
                return json.loads(self.variables)
            except:
                return {}
        return {}
    
    def set_variables(self, variables_dict):
        """Set variables definition"""
        self.variables = json.dumps(variables_dict, ensure_ascii=False)
    
    def to_dict(self):
        """Convert to dictionary"""
        return {
            'id': self.id,
            'category_id': self.category_id,
            'category_name': self.category.name if self.category else None,
            'code': self.code,
            'name': self.name,
            'description': self.description,
            'system_prompt': self.system_prompt,
            'user_prompt': self.user_prompt,
            'variables': self.get_variables(),
            'version': self.version,
            'enabled': self.enabled,
            'is_system': self.is_system,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
