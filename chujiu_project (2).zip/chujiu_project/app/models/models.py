﻿# -*- coding: utf-8 -*-

"""
数据模型定义
"""
from datetime import datetime
from app.extensions import db


class User(db.Model):
    """用户表"""
    __tablename__ = 'user'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='user')
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)


class UploadFile(db.Model):
    """上传文件表"""
    __tablename__ = 'upload_file'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    original_name = db.Column(db.String(255), nullable=False)
    stored_name = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(500), nullable=False)
    mime_type = db.Column(db.String(100), nullable=True)
    size_bytes = db.Column(db.Integer, nullable=False)
    checksum_sha256 = db.Column(db.String(64), nullable=False, index=True)
    plugin_code = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(20), nullable=False, default='UPLOADED')  # UPLOADED, VALIDATED, FAILED
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 状态机定义（SDD 4.2.2）
    STATUS_TRANSITIONS = {
        'UPLOADED': ['VALIDATED', 'FAILED'],
        'VALIDATED': [],  # 终止状态
        'FAILED': ['UPLOADED']  # 允许重新上传
    }
    
    @classmethod
    def is_valid_transition(cls, from_status: str, to_status: str) -> bool:
        """校验状态转换是否合法"""
        return to_status in cls.STATUS_TRANSITIONS.get(from_status, [])


class TaskTemplate(db.Model):
    """任务模板表"""
    __tablename__ = 'task_template'
    
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(100), unique=True, nullable=False, index=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    plugin_code = db.Column(db.String(100), nullable=True)  # 关联插件 DAG
    params_schema_json = db.Column(db.Text, nullable=True)
    is_builtin = db.Column(db.Integer, nullable=False, default=0)
    version = db.Column(db.Integer, nullable=False, default=1)
    category = db.Column(db.String(20), nullable=True)  # builtin | custom
    prompt_templates = db.Column(db.Text, nullable=True)  # JSON: 关联的提示词模板代码列表
    runtime_params_schema = db.Column(db.Text, nullable=True)  # JSON: 运行时参数 Schema
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def get_prompt_templates(self):
        """获取关联的提示词模板代码列表"""
        if self.prompt_templates:
            try:
                import json
                return json.loads(self.prompt_templates)
            except:
                return []
        return []
    
    def set_prompt_templates(self, codes):
        """设置关联的提示词模板代码列表"""
        import json
        self.prompt_templates = json.dumps(codes, ensure_ascii=False)


class TaskRun(db.Model):
    """任务运行实例表"""
    __tablename__ = 'task_run'
    
    id = db.Column(db.Integer, primary_key=True)
    task_template_id = db.Column(db.Integer, db.ForeignKey('task_template.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    upload_file_id = db.Column(db.Integer, db.ForeignKey('upload_file.id'), nullable=True)
    status = db.Column(db.String(20), nullable=False, default='CREATED')  # CREATED, READY, RUNNING, SUCCESS, FAILED, PARTIAL_SUCCESS, CANCELED, RETRYING
    runtime_params_json = db.Column(db.Text, nullable=True)
    context_json = db.Column(db.Text, nullable=True)
    started_at = db.Column(db.DateTime, nullable=True)
    finished_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关联关系
    task_template = db.relationship('TaskTemplate', backref='task_runs')
    upload_file = db.relationship('UploadFile', backref='task_runs')


class JobTemplate(db.Model):
    """Job 模板表"""
    __tablename__ = 'job_template'
    
    id = db.Column(db.Integer, primary_key=True)
    task_template_id = db.Column(db.Integer, db.ForeignKey('task_template.id'), nullable=False)
    parent_job_template_id = db.Column(db.Integer, db.ForeignKey('job_template.id'), nullable=True)
    code = db.Column(db.String(100), nullable=False)
    name = db.Column(db.String(255), nullable=False)
    is_sub_job = db.Column(db.Integer, nullable=False, default=0)
    dag_json = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    
    __table_args__ = (
        db.UniqueConstraint('task_template_id', 'code', name='uq_job_template_code'),
    )


class JobRun(db.Model):
    """Job 运行实例表"""
    __tablename__ = 'job_run'
    
    id = db.Column(db.Integer, primary_key=True)
    task_run_id = db.Column(db.Integer, db.ForeignKey('task_run.id'), nullable=False)
    job_template_id = db.Column(db.Integer, db.ForeignKey('job_template.id'), nullable=True)
    parent_job_run_id = db.Column(db.Integer, db.ForeignKey('job_run.id'), nullable=True)
    code = db.Column(db.String(100), nullable=False)
    name = db.Column(db.String(255), nullable=False)
    source = db.Column(db.String(20), nullable=False, default='TEMPLATE')  # TEMPLATE, LLM_PLANNED
    job_source = db.Column(db.String(20), nullable=False, default='PLUGIN')  # PLUGIN, LLM
    is_sub_job = db.Column(db.Boolean, nullable=False, default=False)
    failed_node_code = db.Column(db.String(100), nullable=True)
    error_context_json = db.Column(db.Text, nullable=True)
    dag_json = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(20), nullable=False, default='PENDING')  # PENDING, RUNNING, WAITING_SUBJOB, SUCCESS, FAILED, RETRYING, SKIPPED
    context_json = db.Column(db.Text, nullable=True)
    recovery_node_code = db.Column(db.String(100), nullable=True)
    started_at = db.Column(db.DateTime, nullable=True)
    finished_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    
    # 关联关系
    task_run = db.relationship('TaskRun', backref='job_runs')


class NodeTemplate(db.Model):
    """Node 模板表"""
    __tablename__ = 'node_template'
    
    id = db.Column(db.Integer, primary_key=True)
    job_template_id = db.Column(db.Integer, db.ForeignKey('job_template.id'), nullable=False)
    code = db.Column(db.String(100), nullable=False)
    name = db.Column(db.String(255), nullable=False)
    action_type = db.Column(db.String(20), nullable=False)  # API, SQL, BASH, LLM, PYTHON, FILE
    config_json = db.Column(db.Text, nullable=False)
    input_mapping_json = db.Column(db.Text, nullable=True)
    output_schema_json = db.Column(db.Text, nullable=True)
    retry_policy_json = db.Column(db.Text, nullable=True)
    continue_on_error = db.Column(db.Integer, nullable=False, default=0)
    timeout_seconds = db.Column(db.Integer, nullable=True)
    order_hint = db.Column(db.Integer, nullable=True)
    
    __table_args__ = (
        db.UniqueConstraint('job_template_id', 'code', name='uq_node_template_code'),
    )


class EdgeTemplate(db.Model):
    """Edge 模板表（DAG 边）"""
    __tablename__ = 'edge_template'
    
    id = db.Column(db.Integer, primary_key=True)
    job_template_id = db.Column(db.Integer, db.ForeignKey('job_template.id'), nullable=False)
    from_node_code = db.Column(db.String(100), nullable=False)
    to_node_code = db.Column(db.String(100), nullable=False)
    condition_expr = db.Column(db.Text, nullable=True)


class NodeRun(db.Model):
    """Node 运行实例表"""
    __tablename__ = 'node_run'
    
    id = db.Column(db.Integer, primary_key=True)
    job_run_id = db.Column(db.Integer, db.ForeignKey('job_run.id'), nullable=False)
    node_template_id = db.Column(db.Integer, db.ForeignKey('node_template.id'), nullable=True)
    code = db.Column(db.String(100), nullable=False)
    action_type = db.Column(db.String(20), nullable=False)
    status = db.Column(db.String(20), nullable=False, default='PENDING')  # PENDING, READY, RUNNING, SUCCESS, FAILED, RETRYING, SKIPPED
    input_json = db.Column(db.Text, nullable=True)
    output_json = db.Column(db.Text, nullable=True)
    error_json = db.Column(db.Text, nullable=True)
    attempt_count = db.Column(db.Integer, nullable=False, default=0)
    version = db.Column(db.Integer, nullable=False, default=0)  # 乐观锁版本号
    started_at = db.Column(db.DateTime, nullable=True)
    finished_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    
    # 关联关系
    job_run = db.relationship('JobRun', backref='node_runs')
    
    # 状态机定义（SDD 2.4.3）
    STATUS_TRANSITIONS = {
        'PENDING': ['READY', 'RUNNING', 'SKIPPED'],
        'READY': ['RUNNING', 'SKIPPED'],
        'RUNNING': ['SUCCESS', 'FAILED', 'RETRYING', 'WAITING_SUBJOB', 'SKIPPED'],
        'FAILED': ['RETRYING'],
        'RETRYING': ['RUNNING'],
        'WAITING_SUBJOB': ['RUNNING', 'FAILED'],
        'SUCCESS': [],  # 终止状态
        'SKIPPED': []   # 终止状态
    }
    
    TERMINAL_STATUSES = ['SUCCESS', 'SKIPPED']
    
    @classmethod
    def is_valid_transition(cls, from_status: str, to_status: str) -> bool:
        """校验状态转换是否合法"""
        return to_status in cls.STATUS_TRANSITIONS.get(from_status, [])
    
    @classmethod
    def is_terminal_status(cls, status: str) -> bool:
        """判断是否为终止状态"""
        return status in cls.TERMINAL_STATUSES


class Artifact(db.Model):
    """产物表"""
    __tablename__ = 'artifact'
    
    id = db.Column(db.Integer, primary_key=True)
    task_run_id = db.Column(db.Integer, db.ForeignKey('task_run.id'), nullable=False)
    job_run_id = db.Column(db.Integer, db.ForeignKey('job_run.id'), nullable=True)
    node_run_id = db.Column(db.Integer, db.ForeignKey('node_run.id'), nullable=True)
    artifact_type = db.Column(db.String(20), nullable=False)  # SOURCE, AST, REPORT, TESTCASE, OUTPUT_FILE, LOG, RULE
    name = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(500), nullable=True)
    content_text = db.Column(db.Text, nullable=True)
    content_json = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)


class ExecutionLog(db.Model):
    """执行日志表"""
    __tablename__ = 'execution_log'
    
    id = db.Column(db.Integer, primary_key=True)
    task_run_id = db.Column(db.Integer, db.ForeignKey('task_run.id'), nullable=False)
    job_run_id = db.Column(db.Integer, db.ForeignKey('job_run.id'), nullable=True)
    node_run_id = db.Column(db.Integer, db.ForeignKey('node_run.id'), nullable=True)
    level = db.Column(db.String(10), nullable=False)  # DEBUG, INFO, WARN, ERROR
    event_type = db.Column(db.String(50), nullable=False)
    message = db.Column(db.Text, nullable=False)
    detail_json = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)


class LearningRule(db.Model):
    """学习规则表"""
    __tablename__ = 'learning_rule'
    
    id = db.Column(db.Integer, primary_key=True)
    task_run_id = db.Column(db.Integer, db.ForeignKey('task_run.id'), nullable=False)
    plugin_code = db.Column(db.String(100), nullable=False)
    error_id = db.Column(db.String(50), nullable=False)
    scenario = db.Column(db.Text, nullable=False)
    root_cause = db.Column(db.Text, nullable=False)
    forbidden_patterns = db.Column(db.Text, nullable=False)
    correct_patterns = db.Column(db.Text, nullable=False)
    markdown_content = db.Column(db.Text, nullable=False)
    file_path = db.Column(db.String(500), nullable=True)  # learning.md 文件路径
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)


class PluginDagRegistry(db.Model):
    """插件 DAG 注册表"""
    __tablename__ = 'plugin_dag_registry'
    
    id = db.Column(db.Integer, primary_key=True)
    plugin_code = db.Column(db.String(100), unique=True, nullable=False)
    dag_json = db.Column(db.Text, nullable=False)
    version = db.Column(db.Integer, nullable=False, default=1)
    status = db.Column(db.String(20), nullable=False, default='ACTIVE')  # ACTIVE, INACTIVE
    registered_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
