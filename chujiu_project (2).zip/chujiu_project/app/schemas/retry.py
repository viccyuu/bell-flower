# -*- coding: utf-8 -*-
"""
Retry Schema - 重试管理请求/响应模型 ⭐
"""
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime


class RetryRequest(BaseModel):
    """
    单个节点重试请求
    """
    task_run_id: int = Field(..., description="任务运行 ID")
    node_code: str = Field(..., description="节点代码")
    retry_reason: Optional[str] = Field(None, description="重试原因（可选）")


class BatchRetryRequest(BaseModel):
    """
    批量重试请求
    """
    task_run_id: int = Field(..., description="任务运行 ID")
    node_codes: List[str] = Field(..., description="节点代码列表")
    retry_reason: Optional[str] = Field(None, description="重试原因（可选）")


class RetryPolicyUpdateRequest(BaseModel):
    """
    重试策略更新请求
    """
    node_code: str = Field(..., description="节点代码")
    max_retries: int = Field(..., ge=0, le=10, description="最大重试次数")
    backoff_seconds: int = Field(..., ge=0, le=300, description="重试间隔（秒）")
    retry_on: List[str] = Field(..., description="触发重试的错误类型")


class RetryHistoryResponse(BaseModel):
    """
    重试历史记录响应
    """
    id: int
    task_run_id: int
    node_code: str
    node_name: str
    attempt_number: int
    previous_status: str
    new_status: str
    error_message: Optional[str]
    retry_reason: Optional[str]
    retried_by: Optional[str]
    retried_at: datetime
    result_status: Optional[str]
    result_message: Optional[str]


class RetryStatusResponse(BaseModel):
    """
    重试状态响应
    """
    node_code: str
    node_name: str
    current_status: str
    attempt_count: int
    max_retries: int
    can_retry: bool
    last_error: Optional[str]
    retry_policy: Dict[str, Any]


class RetryResponse(BaseModel):
    """
    重试操作响应
    """
    success: bool
    message: str
    node_code: str
    new_status: str
    attempt_count: int
