# -*- coding: utf-8 -*-
"""
Task Schemas - Pydantic Models ⭐
"""
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List
from datetime import datetime
from enum import Enum


class TaskStatus(str, Enum):
    """任务状态枚举"""
    CREATED = "CREATED"
    READY = "READY"
    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    PARTIAL_SUCCESS = "PARTIAL_SUCCESS"
    CANCELED = "CANCELED"
    RETRYING = "RETRYING"


class TaskCreate(BaseModel):
    """创建任务请求"""
    template_id: int = Field(..., description="任务模板 ID")
    upload_file_id: Optional[int] = Field(None, description="上传文件 ID")
    runtime_params: Optional[Dict[str, Any]] = Field(default_factory=dict, description="运行时参数")


class TaskUpdate(BaseModel):
    """更新任务请求"""
    status: Optional[TaskStatus] = None
    runtime_params: Optional[Dict[str, Any]] = None


class TaskResponse(BaseModel):
    """任务响应"""
    id: int
    task_template_id: int
    user_id: Optional[int] = None
    upload_file_id: Optional[int] = None
    status: TaskStatus
    runtime_params: Optional[Dict[str, Any]] = None
    context_json: Optional[Dict[str, Any]] = None
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class TaskListResponse(BaseModel):
    """任务列表响应"""
    tasks: List[TaskResponse]
    total: int
    page: int = 1
    page_size: int = 20
