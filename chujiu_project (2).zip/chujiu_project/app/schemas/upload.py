# -*- coding: utf-8 -*-
"""
Upload Schemas - Pydantic Models ⭐
"""
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List
from datetime import datetime


class UploadCreate(BaseModel):
    """创建上传请求"""
    plugin_code: str = Field(..., description="插件代码")


class UploadResponse(BaseModel):
    """上传响应"""
    upload_id: int
    original_name: str
    stored_name: str
    file_path: str
    mime_type: Optional[str] = None
    size_bytes: int
    checksum_sha256: str
    plugin_code: str
    status: str
    created_at: datetime
    
    class Config:
        from_attributes = True
