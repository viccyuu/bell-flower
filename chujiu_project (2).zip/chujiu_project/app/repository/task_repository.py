# -*- coding: utf-8 -*-
"""
TaskRun Repository - 精简版 ⭐

职责：纯 CRUD 操作
- create()
- get_by_id()
- update()
- delete()

注意：不包含业务逻辑（如创建 JobRun/NodeRun）
"""
from typing import Optional, Dict, Any
import json

from app.models import TaskRun, TaskTemplate
from app.repository.base import BaseRepository


class TaskRunRepository(BaseRepository[TaskRun]):
    """TaskRun Repository - 纯 CRUD"""
    
    def __init__(self):
        super().__init__(TaskRun)
    
    def create(
        self,
        task_template_id: int,
        upload_file_id: Optional[int] = None,
        runtime_params: Optional[Dict[str, Any]] = None,
        status: str = 'READY'
    ) -> TaskRun:
        """
        创建 TaskRun（纯 CRUD）
        
        Args:
            task_template_id: 模板 ID
            upload_file_id: 上传文件 ID
            runtime_params: 运行时参数
            status: 初始状态
        
        Returns:
            TaskRun 实例
        """
        from app.extensions import db
        
        task_run = TaskRun(
            task_template_id=task_template_id,
            upload_file_id=upload_file_id,
            runtime_params_json=json.dumps(runtime_params) if runtime_params else None,
            status=status
        )
        
        db.session.add(task_run)
        db.session.commit()
        
        return task_run
    
    def get_by_template_code(self, template_code: str):
        """
        根据模板代码获取 TaskRuns
        
        Args:
            template_code: 模板代码
        
        Returns:
            TaskRun 列表
        """
        from app.extensions import db
        
        template = TaskTemplate.query.filter_by(code=template_code).first()
        if not template:
            return []
        
        return self.query.filter_by(task_template_id=template.id).all()
    
    def update_status(self, task_run_id: int, status: str, runtime_params: Optional[Dict] = None):
        """
        更新 TaskRun 状态
        
        Args:
            task_run_id: TaskRun ID
            status: 新状态
            runtime_params: 运行时参数（可选）
        """
        from app.extensions import db
        
        task_run = self.get_by_id(task_run_id)
        if task_run:
            task_run.status = status
            if runtime_params:
                task_run.runtime_params_json = json.dumps(runtime_params)
            db.session.commit()


# 全局 Repository 实例
task_run_repository = TaskRunRepository()
