﻿# -*- coding: utf-8 -*-

"""
NodeRun Repository - 支持乐观锁更新

功能：
1. NodeRun 的 CRUD 操作
2. 基于 version 字段的乐观锁更新
3. 状态变更时自动递增 version
"""
from typing import Optional, Dict, Any
from app.models import NodeRun, db
from sqlalchemy.orm.exc import StaleDataError


class NodeRunRepository:
    """NodeRun 仓储类（支持乐观锁）"""
    
    @staticmethod
    def get(node_run_id: int) -> Optional[NodeRun]:
        """获取 NodeRun"""
        return NodeRun.query.get(node_run_id)
    
    @staticmethod
    def get_by_job_run(job_run_id: int, node_code: str) -> Optional[NodeRun]:
        """根据 JobRun 和 Node 代码获取 NodeRun"""
        return NodeRun.query.filter_by(
            job_run_id=job_run_id,
            code=node_code
        ).first()
    
    @staticmethod
    def create(job_run_id: int, node_template_id: Optional[int], 
               node_code: str, action_type: str) -> NodeRun:
        """创建 NodeRun"""
        node_run = NodeRun(
            job_run_id=job_run_id,
            node_template_id=node_template_id,
            code=node_code,
            action_type=action_type,
            status='PENDING',
            version=1  # 初始版本号为 1
        )
        db.session.add(node_run)
        db.session.commit()
        return node_run
    
    @staticmethod
    def update_status_with_optimistic_lock(
        node_run_id: int, 
        new_status: str,
        expected_version: Optional[int] = None,
        output_json: Optional[Dict[str, Any]] = None,
        error_json: Optional[Dict[str, Any]] = None
    ) -> Optional[NodeRun]:
        """
        使用乐观锁更新 NodeRun 状态
        
        Args:
            node_run_id: NodeRun ID
            new_status: 新状态
            expected_version: 期望的版本号（如果提供则进行校验）
            output_json: 输出数据
            error_json: 错误数据
            
        Returns:
            更新后的 NodeRun，如果版本号冲突返回 None
            
        Raises:
            StaleDataError: 乐观锁冲突
        """
        node_run = NodeRun.query.get(node_run_id)
        if not node_run:
            return None
        
        # 版本号校验（如果提供了 expected_version）
        if expected_version is not None and node_run.version != expected_version:
            raise StaleDataError(
                f"Optimistic lock conflict: expected version {expected_version}, "
                f"but current version is {node_run.version}"
            )
        
        # 状态机校验（防止非法状态转换）
        if not NodeRunRepository._is_valid_transition(node_run.status, new_status):
            raise ValueError(
                f"Invalid status transition: {node_run.status} -> {new_status}"
            )
        
        # 更新状态
        node_run.status = new_status
        
        # 版本号自增（乐观锁核心）
        node_run.version += 1
        
        # 更新输出/错误数据
        if output_json is not None:
            node_run.output_json = str(output_json) if not isinstance(output_json, str) else output_json
        
        if error_json is not None:
            node_run.error_json = str(error_json) if not isinstance(error_json, str) else error_json
        
        db.session.commit()
        return node_run
    
    @staticmethod
    def _is_valid_transition(from_status: str, to_status: str) -> bool:
        """
        校验状态转换是否合法
        
        合法的状态转换：
        - PENDING -> READY, RUNNING, SKIPPED
        - READY -> RUNNING, SKIPPED
        - RUNNING -> SUCCESS, FAILED, RETRYING, WAITING_SUBJOB, SKIPPED
        - FAILED -> RETRYING
        - RETRYING -> RUNNING
        - WAITING_SUBJOB -> RUNNING, FAILED
        """
        valid_transitions = {
            'PENDING': ['READY', 'RUNNING', 'SKIPPED'],
            'READY': ['RUNNING', 'SKIPPED'],
            'RUNNING': ['SUCCESS', 'FAILED', 'RETRYING', 'WAITING_SUBJOB', 'SKIPPED'],
            'FAILED': ['RETRYING'],
            'RETRYING': ['RUNNING'],
            'WAITING_SUBJOB': ['RUNNING', 'FAILED'],
            'SUCCESS': [],  # 终止状态
            'SKIPPED': []   # 终止状态
        }
        
        return to_status in valid_transitions.get(from_status, [])
    
    @staticmethod
    def update_with_retry(
        node_run_id: int,
        new_status: str,
        output_json: Optional[Dict[str, Any]] = None,
        error_json: Optional[Dict[str, Any]] = None,
        max_retries: int = 3
    ) -> Optional[NodeRun]:
        """
        带重试的更新（自动处理乐观锁冲突）
        
        Args:
            node_run_id: NodeRun ID
            new_status: 新状态
            output_json: 输出数据
            error_json: 错误数据
            max_retries: 最大重试次数
            
        Returns:
            更新后的 NodeRun，如果超过重试次数返回 None
        """
        import time
        import random
        
        for attempt in range(max_retries):
            try:
                node_run = NodeRun.query.get(node_run_id)
                if not node_run:
                    return None
                
                # 使用当前版本号进行更新
                result = NodeRunRepository.update_status_with_optimistic_lock(
                    node_run_id=node_run_id,
                    new_status=new_status,
                    expected_version=node_run.version,
                    output_json=output_json,
                    error_json=error_json
                )
                
                return result
                
            except StaleDataError:
                if attempt < max_retries - 1:
                    # 指数退避 + 随机抖动
                    backoff = (2 ** attempt) + random.uniform(0, 0.1)
                    time.sleep(backoff)
                else:
                    # 超过最大重试次数
                    return None
        
        return None
    
    @staticmethod
    def list_by_job_run(job_run_id: int) -> list:
        """获取 JobRun 下的所有 NodeRun"""
        return NodeRun.query.filter_by(job_run_id=job_run_id).order_by(NodeRun.id).all()
    
    @staticmethod
    def get_ready_nodes(job_run_id: int) -> list:
        """获取 JobRun 下所有 READY 状态的 NodeRun"""
        return NodeRun.query.filter_by(
            job_run_id=job_run_id,
            status='READY'
        ).all()
    
    @staticmethod
    def get_pending_nodes(job_run_id: int) -> list:
        """获取 JobRun 下所有 PENDING 状态的 NodeRun"""
        return NodeRun.query.filter_by(
            job_run_id=job_run_id,
            status='PENDING'
        ).all()


# 全局单例
node_run_repository = NodeRunRepository()
