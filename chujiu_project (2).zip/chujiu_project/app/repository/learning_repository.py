﻿# -*- coding: utf-8 -*-

"""
LearningRule Repository - learning.md Bi-directional Sync

Functions:
1. LearningRule CRUD operations
2. Bi-directional sync with plugin learning/learning.md files
3. Auto-load learning rules from all plugins on startup
"""
import os
from typing import Optional, List, Dict, Any
from pathlib import Path
from app.models import LearningRule, db


class LearningRepository:
    """LearningRule Repository (with file sync support)"""
    
    def __init__(self, plugins_dir=None):
        """
        Initialize
        
        Args:
            plugins_dir: Plugin directory path
        """
        if plugins_dir is None:
            self.plugins_dir = Path(__file__).parent.parent.parent / 'plugins'
        else:
            self.plugins_dir = Path(plugins_dir)
    
    def load_all_from_files(self) -> int:
        """
        Load learning rules from all plugin learning.md files to database
        
        Returns:
            Number of successfully loaded rules
        """
        loaded_count = 0
        
        if not self.plugins_dir.exists():
            return 0
        
        # Iterate through all plugin directories
        for plugin_dir in self.plugins_dir.iterdir():
            if not plugin_dir.is_dir() or plugin_dir.name.startswith('_'):
                continue
            
            plugin_code = plugin_dir.name
            learning_file = plugin_dir / 'learning' / 'learning.md'
            
            if not learning_file.exists():
                continue
            
            try:
                with open(learning_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Simple parse: check if file is non-empty
                if content.strip():
                    loaded_count += 1
                    print(f"  Loaded learning rules from {plugin_code}")
                
            except Exception as e:
                print(f"Failed to load learning rules from {learning_file}: {e}")
        
        return loaded_count
    
    def get_file_content(self, plugin_code: str) -> Optional[str]:
        """
        Get plugin learning.md file content
        
        Args:
            plugin_code: Plugin code
            
        Returns:
            File content, None if not exists
        """
        learning_file = self.plugins_dir / plugin_code / 'learning' / 'learning.md'
        
        if not learning_file.exists():
            return None
        
        try:
            with open(learning_file, 'r', encoding='utf-8') as f:
                return f.read()
        except:
            return None


# Global singleton
learning_repository = LearningRepository()
