# -*- coding: utf-8 -*-
"""
Retry Repository - 重试管理数据访问层 ⭐

提供重试历史记录、重试策略管理等数据操作
"""
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone
import logging

logger = logging.getLogger(__name__)


class RetryRecord:
    """
    重试记录模型（临时，后续可迁移到数据库）
    
    用于记录每次重试的详细信息
    """
    def __init__(
        self,
        task_run_id: int,
        node_code: str,
        node_name: str,
        attempt_number: int,
        previous_status: str,
        new_status: str,
        error_message: Optional[str] = None,
        retry_reason: Optional[str] = None,
        retried_by: Optional[str] = None
    ):
        self.task_run_id = task_run_id
        self.node_code = node_code
        self.node_name = node_name
        self.attempt_number = attempt_number
        self.previous_status = previous_status
        self.new_status = new_status
        self.error_message = error_message
        self.retry_reason = retry_reason
        self.retried_by = retried_by
        self.retried_at = datetime.now(timezone.utc)
        self.result_status: Optional[str] = None
        self.result_message: Optional[str] = None


class RetryRepository:
    """
    重试数据访问仓库
    
    提供：
    - 重试记录创建
    - 重试历史查询
    - 重试策略管理
    """
    
    # 内存存储重试历史（生产环境应使用数据库）
    _retry_history: List[RetryRecord] = []
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def create_retry_record(
        self,
        task_run_id: int,
        node_code: str,
        node_name: str,
        attempt_number: int,
        previous_status: str,
        new_status: str,
        error_message: Optional[str] = None,
        retry_reason: Optional[str] = None,
        retried_by: Optional[str] = None
    ) -> RetryRecord:
        """
        创建重试记录
        
        Args:
            task_run_id: 任务运行 ID
            node_code: 节点代码
            node_name: 节点名称
            attempt_number: 尝试次数
            previous_status: 重试前状态
            new_status: 重试后状态
            error_message: 错误信息
            retry_reason: 重试原因
            retried_by: 重试操作人
        
        Returns:
            RetryRecord: 重试记录
        """
        record = RetryRecord(
            task_run_id=task_run_id,
            node_code=node_code,
            node_name=node_name,
            attempt_number=attempt_number,
            previous_status=previous_status,
            new_status=new_status,
            error_message=error_message,
            retry_reason=retry_reason,
            retried_by=retried_by
        )
        
        self._retry_history.append(record)
        logger.info(f"Retry record created: {node_code} (attempt {attempt_number})")
        
        return record
    
    async def get_retry_history(
        self,
        task_run_id: Optional[int] = None,
        node_code: Optional[str] = None,
        limit: int = 50
    ) -> List[RetryRecord]:
        """
        获取重试历史记录
        
        Args:
            task_run_id: 任务运行 ID（可选过滤）
            node_code: 节点代码（可选过滤）
            limit: 返回数量限制
        
        Returns:
            List[RetryRecord]: 重试历史记录
        """
        records = self._retry_history
        
        # 过滤
        if task_run_id:
            records = [r for r in records if r.task_run_id == task_run_id]
        
        if node_code:
            records = [r for r in records if r.node_code == node_code]
        
        # 按时间倒序排序
        records = sorted(records, key=lambda r: r.retried_at, reverse=True)
        
        # 限制数量
        return records[:limit]
    
    async def update_retry_result(
        self,
        record: RetryRecord,
        result_status: str,
        result_message: Optional[str] = None
    ):
        """
        更新重试结果
        
        Args:
            record: 重试记录
            result_status: 结果状态
            result_message: 结果信息
        """
        record.result_status = result_status
        record.result_message = result_message
        logger.info(f"Retry result updated: {record.node_code} -> {result_status}")
    
    async def get_retry_statistics(
        self,
        task_run_id: int
    ) -> Dict[str, Any]:
        """
        获取重试统计数据
        
        Args:
            task_run_id: 任务运行 ID
        
        Returns:
            dict: 统计数据
        """
        records = [r for r in self._retry_history if r.task_run_id == task_run_id]
        
        total_retries = len(records)
        successful_retries = len([r for r in records if r.result_status == 'SUCCESS'])
        failed_retries = len([r for r in records if r.result_status == 'FAILED'])
        
        return {
            'total_retries': total_retries,
            'successful_retries': successful_retries,
            'failed_retries': failed_retries,
            'success_rate': successful_retries / total_retries if total_retries > 0 else 0
        }


# 全局仓库实例（需要在具体上下文中初始化）
retry_repository: Optional[RetryRepository] = None


def get_retry_repository(db: AsyncSession) -> RetryRepository:
    """
    获取重试仓库实例
    
    Args:
        db: 数据库会话
    
    Returns:
        RetryRepository: 重试仓库实例
    """
    global retry_repository
    if retry_repository is None:
        retry_repository = RetryRepository(db)
    return retry_repository
