﻿# -*- coding: utf-8 -*-

"""
Repository 工具类
"""
import time
import random
from typing import Type, Callable, Any
from sqlalchemy.exc import IntegrityError
from app.extensions import db


class NotFoundError(Exception):
    """记录不存在异常"""
    pass


class MaxRetriesExceededError(Exception):
    """超过最大重试次数异常"""
    pass


def optimistic_update(model: Type, id: int, update_func: Callable[[Any], None], max_retries: int = 3, base_delay: float = 0.1) -> Any:
    """
    通用乐观锁更新工具类（带指数退避）
    
    Args:
        model: SQLAlchemy 模型类
        id: 记录 ID
        update_func: 更新函数，接收实例作为参数
        max_retries: 最大重试次数，默认 3 次
        base_delay: 基础延迟秒数，默认 0.1 秒
    
    Returns:
        更新后的实例
    
    Raises:
        NotFoundError: 记录不存在
        MaxRetriesExceededError: 超过最大重试次数
    """
    for attempt in range(max_retries):
        instance = model.query.get(id)
        if not instance:
            raise NotFoundError(f"Record {id} not found")
        
        # 保存旧版本号用于日志
        old_version = instance.version
        
        # 执行更新函数
        update_func(instance)
        
        # 版本号自增
        instance.version += 1
        
        try:
            db.session.commit()
            return instance
        except IntegrityError:
            db.session.rollback()
            # 版本冲突，重试
            if attempt == max_retries - 1:
                raise MaxRetriesExceededError(
                    f"Failed to update {model.__tablename__}.{id} after {max_retries} attempts"
                )
            
            # 指数退避 + 随机抖动（P2-02 修复）
            delay = base_delay * (2 ** attempt) + random.uniform(0, base_delay * 0.1)
            time.sleep(delay)
            continue
    
    # 不应该到达这里
    raise MaxRetriesExceededError(f"Failed to update {model.__tablename__}.{id}")
