﻿# -*- coding: utf-8 -*-

"""
Repository 基类
"""
from typing import TypeVar, Generic, List, Optional
from app.extensions import db

T = TypeVar('T')


class BaseRepository(Generic[T]):
    """Repository 基类"""
    
    def __init__(self, model_class: T):
        self.model_class = model_class
    
    def get(self, id: int) -> Optional[T]:
        """根据 ID 获取记录"""
        return self.model_class.query.get(id)
    
    def get_all(self) -> List[T]:
        """获取所有记录"""
        return self.model_class.query.all()
    
    def create(self, **kwargs) -> T:
        """创建记录"""
        instance = self.model_class(**kwargs)
        db.session.add(instance)
        db.session.commit()
        return instance
    
    def update(self, id: int, **kwargs) -> Optional[T]:
        """更新记录"""
        instance = self.get(id)
        if not instance:
            return None
        for key, value in kwargs.items():
            setattr(instance, key, value)
        db.session.commit()
        return instance
    
    def delete(self, id: int) -> bool:
        """删除记录"""
        instance = self.get(id)
        if not instance:
            return False
        db.session.delete(instance)
        db.session.commit()
        return True
    
    def filter_by(self, **kwargs) -> List[T]:
        """根据条件过滤"""
        return self.model_class.query.filter_by(**kwargs).all()
    
    def first(self, **kwargs) -> Optional[T]:
        """获取第一条匹配记录"""
        return self.model_class.query.filter_by(**kwargs).first()
