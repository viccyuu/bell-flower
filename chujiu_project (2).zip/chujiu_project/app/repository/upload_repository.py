﻿# -*- coding: utf-8 -*-

"""
UploadFile Repository
"""
from app.models import UploadFile
from app.repository.base import BaseRepository


class UploadFileRepository(BaseRepository[UploadFile]):
    """UploadFile Repository"""
    
    def __init__(self):
        super().__init__(UploadFile)
    
    def get_by_checksum(self, checksum: str) -> UploadFile:
        """根据 checksum 获取文件记录（用于幂等性）"""
        return self.first(checksum_sha256=checksum)
    
    def update_status(self, id: int, status: str) -> UploadFile:
        """更新文件状态"""
        return self.update(id, status=status)


# 全局实例
upload_file_repository = UploadFileRepository()
