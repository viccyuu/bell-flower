﻿# -*- coding: utf-8 -*-

"""
鏋氫妇瀹氫箟

鍔熻兘锛?1. 鐘舵€佹灇涓?2. 鍔ㄤ綔绫诲瀷鏋氫妇
3. 鍏朵粬甯搁噺瀹氫箟
"""
from enum import Enum


class TaskRunStatus(str, Enum):
    """TaskRun 鐘舵€佹灇涓撅紙SDD 2.4.1锛?""
    CREATED = 'CREATED'
    READY = 'READY'
    RUNNING = 'RUNNING'
    SUCCESS = 'SUCCESS'
    FAILED = 'FAILED'
    PARTIAL_SUCCESS = 'PARTIAL_SUCCESS'
    CANCELED = 'CANCELED'
    RETRYING = 'RETRYING'


class JobRunStatus(str, Enum):
    """JobRun 鐘舵€佹灇涓撅紙SDD 2.4.2锛?""
    PENDING = 'PENDING'
    RUNNING = 'RUNNING'
    WAITING_SUBJOB = 'WAITING_SUBJOB'
    SUCCESS = 'SUCCESS'
    FAILED = 'FAILED'
    RETRYING = 'RETRYING'
    SKIPPED = 'SKIPPED'


class NodeRunStatus(str, Enum):
    """NodeRun 鐘舵€佹灇涓撅紙SDD 2.4.3锛?""
    PENDING = 'PENDING'
    READY = 'READY'
    RUNNING = 'RUNNING'
    SUCCESS = 'SUCCESS'
    FAILED = 'FAILED'
    RETRYING = 'RETRYING'
    SKIPPED = 'SKIPPED'


class ActionType(str, Enum):
    """鍔ㄤ綔绫诲瀷鏋氫妇锛圫DD 2.2锛?""
    API = 'API'
    SQL = 'SQL'
    BASH = 'BASH'
    LLM = 'LLM'
    PYTHON = 'PYTHON'
    FILE = 'FILE'


class UploadFileStatus(str, Enum):
    """UploadFile 鐘舵€佹灇涓撅紙SDD 4.2.2锛?""
    UPLOADED = 'UPLOADED'
    VALIDATED = 'VALIDATED'
    FAILED = 'FAILED'


class ArtifactType(str, Enum):
    """浜х墿绫诲瀷鏋氫妇锛圫DD 4.2.7锛?""
    SOURCE = 'SOURCE'
    AST = 'AST'
    REPORT = 'REPORT'
    TESTCASE = 'TESTCASE'
    OUTPUT_FILE = 'OUTPUT_FILE'
    LOG = 'LOG'
    RULE = 'RULE'


# 鐘舵€佽浆鎹㈣鍒欙紙SDD 2.4锛?TASK_RUN_TRANSITIONS = {
    TaskRunStatus.CREATED: [TaskRunStatus.READY],
    TaskRunStatus.READY: [TaskRunStatus.RUNNING],
    TaskRunStatus.RUNNING: [TaskRunStatus.SUCCESS, TaskRunStatus.FAILED, TaskRunStatus.PARTIAL_SUCCESS, TaskRunStatus.CANCELED],
    TaskRunStatus.FAILED: [TaskRunStatus.RETRYING],
    TaskRunStatus.RETRYING: [TaskRunStatus.RUNNING],
    TaskRunStatus.SUCCESS: [],  # 缁堟鐘舵€?    TaskRunStatus.PARTIAL_SUCCESS: [],  # 缁堟鐘舵€?    TaskRunStatus.CANCELED: []  # 缁堟鐘舵€?}

JOB_RUN_TRANSITIONS = {
    JobRunStatus.PENDING: [JobRunStatus.RUNNING],
    JobRunStatus.RUNNING: [JobRunStatus.WAITING_SUBJOB, JobRunStatus.SUCCESS, JobRunStatus.FAILED, JobRunStatus.SKIPPED],
    JobRunStatus.WAITING_SUBJOB: [JobRunStatus.RUNNING, JobRunStatus.FAILED],
    JobRunStatus.FAILED: [JobRunStatus.RETRYING],
    JobRunStatus.RETRYING: [JobRunStatus.RUNNING],
    JobRunStatus.SUCCESS: [],  # 缁堟鐘舵€?    JobRunStatus.SKIPPED: []  # 缁堟鐘舵€?}

NODE_RUN_TRANSITIONS = {
    NodeRunStatus.PENDING: [NodeRunStatus.READY, NodeRunStatus.RUNNING, NodeRunStatus.SKIPPED],
    NodeRunStatus.READY: [NodeRunStatus.RUNNING, NodeRunStatus.SKIPPED],
    NodeRunStatus.RUNNING: [NodeRunStatus.SUCCESS, NodeRunStatus.FAILED, NodeRunStatus.RETRYING, NodeRunStatus.WAITING_SUBJOB, NodeRunStatus.SKIPPED],
    NodeRunStatus.FAILED: [NodeRunStatus.RETRYING],
    NodeRunStatus.RETRYING: [NodeRunStatus.RUNNING],
    NodeRunStatus.WAITING_SUBJOB: [NodeRunStatus.RUNNING, NodeRunStatus.FAILED],
    NodeRunStatus.SUCCESS: [],  # 缁堟鐘舵€?    NodeRunStatus.SKIPPED: []  # 缁堟鐘舵€?}

UPLOAD_FILE_TRANSITIONS = {
    UploadFileStatus.UPLOADED: [UploadFileStatus.VALIDATED, UploadFileStatus.FAILED],
    UploadFileStatus.VALIDATED: [],  # 缁堟鐘舵€?    UploadFileStatus.FAILED: [UploadFileStatus.UPLOADED]  # 鍏佽閲嶆柊涓婁紶
}
