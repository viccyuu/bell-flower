﻿# -*- coding: utf-8 -*-

"""
涓婁笅鏂囪В鏋愬櫒

鍔熻兘锛?1. 瑙ｆ瀽妯℃澘鍙橀噺锛堝 {{ node.upload_validate.output.file_path }}锛?2. 娓叉煋杈撳叆鏄犲皠
3. 涓婁笅鏂囧彉閲忕鐞?"""
import re
from typing import Dict, Any, Optional


class ContextResolver:
    """涓婁笅鏂囧彉閲忚В鏋愬櫒"""
    
    def __init__(self, context: Dict[str, Any]):
        """
        鍒濆鍖?        
        Args:
            context: 涓婁笅鏂囨暟鎹?        """
        self.context = context
    
    def resolve(self, template: str) -> str:
        """
        瑙ｆ瀽妯℃澘瀛楃涓?        
        Args:
            template: 妯℃澘瀛楃涓诧紙濡?"{{ node.upload_validate.output.file_path }}"锛?            
        Returns:
            瑙ｆ瀽鍚庣殑鍊?        """
        # 鍖归厤 {{ ... }} 妯″紡
        pattern = r'\{\{\s*(.*?)\s*\}\}'
        
        def replace(match):
            expr = match.group(1).strip()
            value = self._evaluate(expr)
            return str(value) if value is not None else ''
        
        return re.sub(pattern, replace, template)
    
    def resolve_dict(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        瑙ｆ瀽瀛楀吀涓殑鎵€鏈夋ā鏉垮彉閲?        
        Args:
            data: 鍖呭惈妯℃澘鍙橀噺鐨勫瓧鍏?            
        Returns:
            瑙ｆ瀽鍚庣殑瀛楀吀
        """
        result = {}
        
        for key, value in data.items():
            if isinstance(value, str):
                result[key] = self.resolve(value)
            elif isinstance(value, dict):
                result[key] = self.resolve_dict(value)
            elif isinstance(value, list):
                result[key] = self.resolve_list(value)
            else:
                result[key] = value
        
        return result
    
    def resolve_list(self, items: list) -> list:
        """
        瑙ｆ瀽鍒楄〃涓殑鎵€鏈夋ā鏉垮彉閲?        
        Args:
            items: 鍖呭惈妯℃澘鍙橀噺鐨勫垪琛?            
        Returns:
            瑙ｆ瀽鍚庣殑鍒楄〃
        """
        result = []
        
        for item in items:
            if isinstance(item, str):
                result.append(self.resolve(item))
            elif isinstance(item, dict):
                result.append(self.resolve_dict(item))
            elif isinstance(item, list):
                result.append(self.resolve_list(item))
            else:
                result.append(item)
        
        return result
    
    def _evaluate(self, expr: str) -> Any:
        """
        璁＄畻琛ㄨ揪寮?        
        鏀寔鐨勮〃杈惧紡鏍煎紡锛?        - task.vars.upload_id
        - task.id
        - node.upload_validate.output.file_path
        
        Args:
            expr: 琛ㄨ揪寮?            
        Returns:
            璁＄畻缁撴灉
        """
        parts = expr.split('.')
        
        try:
            value = self.context
            
            for part in parts:
                if isinstance(value, dict):
                    value = value.get(part)
                elif hasattr(value, part):
                    value = getattr(value, part)
                else:
                    return None
                
                if value is None:
                    return None
            
            return value
            
        except (KeyError, AttributeError, TypeError):
            return None
    
    @staticmethod
    def build_context(
        task_run: Any = None,
        job_run: Any = None,
        node_outputs: Dict[str, Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        鏋勫缓涓婁笅鏂?        
        Args:
            task_run: TaskRun 瀵硅薄
            job_run: JobRun 瀵硅薄
            node_outputs: 鑺傜偣杈撳嚭瀛楀吀 {node_code: output_data}
            
        Returns:
            涓婁笅鏂囧瓧鍏?        """
        context = {
            'task': {},
            'job': {},
            'node': {}
        }
        
        # Task 涓婁笅鏂?        if task_run:
            context['task'] = {
                'id': task_run.id,
                'vars': task_run.runtime_params_json or {} if hasattr(task_run, 'runtime_params_json') else {}
            }
        
        # Job 涓婁笅鏂?        if job_run:
            context['job'] = {
                'id': job_run.id,
                'code': job_run.code if hasattr(job_run, 'code') else ''
            }
        
        # Node 涓婁笅鏂?        if node_outputs:
            for node_code, output in node_outputs.items():
                context['node'][node_code] = {
                    'output': output
                }
        
        return context
