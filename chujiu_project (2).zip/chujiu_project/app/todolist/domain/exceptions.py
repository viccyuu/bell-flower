# -*- coding: utf-8 -*-

"""Domain Exceptions."""


class AppException(Exception):
    """应用基础异常"""
    def __init__(self, message: str, code: str = None):
        super().__init__(message)
        self.message = message
        self.code = code or 'APP_ERROR'


class BusinessException(AppException):
    """业务异常"""
    pass


class DAGInvalidError(BusinessException):
    """DAG 非法异常"""
    def __init__(self, message: str = "DAG is invalid"):
        super().__init__(message, code='DAG_INVALID')


class ContextVarMissingError(BusinessException):
    """上下文变量缺失异常"""
    def __init__(self, var_name: str):
        super().__init__(f"Context variable '{var_name}' is missing", code='CONTEXT_VAR_MISSING')


class APITimeoutError(BusinessException):
    """API 超时异常"""
    def __init__(self, url: str):
        super().__init__(f"API timeout: {url}", code='API_TIMEOUT')


class LLMResponseInvalidError(BusinessException):
    """LLM 响应非法异常"""
    def __init__(self, message: str = "LLM response is invalid"):
        super().__init__(message, code='LLM_RESPONSE_INVALID')


class BashForbiddenError(BusinessException):
    """Bash 命令禁止异常"""
    def __init__(self, command: str):
        super().__init__(f"Bash command forbidden: {command}", code='BASH_FORBIDDEN')


class SQLForbiddenError(BusinessException):
    """SQL 禁止异常"""
    def __init__(self, sql: str):
        super().__init__(f"SQL forbidden: {sql}", code='SQL_FORBIDDEN')


class SubJobInvalidError(BusinessException):
    """SubJob 非法异常"""
    def __init__(self, message: str = "SubJob definition is invalid"):
        super().__init__(message, code='SUBJOB_INVALID')


class RecoveryNodeInvalidError(BusinessException):
    """恢复点非法异常"""
    def __init__(self, node_code: str):
        super().__init__(f"Recovery node invalid: {node_code}", code='RECOVERY_NODE_INVALID')


class FileCorruptedError(BusinessException):
    """文件损坏异常"""
    def __init__(self, file_path: str):
        super().__init__(f"File corrupted: {file_path}", code='FILE_CORRUPTED')


class TestCompareFailedError(BusinessException):
    """测试比对失败异常"""
    def __init__(self, message: str = "Test comparison failed"):
        super().__init__(message, code='TEST_COMPARE_FAILED')


class ArtifactFileMissingError(BusinessException):
    """产物文件丢失异常"""
    def __init__(self, artifact_id: int):
        super().__init__(f"Artifact file missing: {artifact_id}", code='ARTIFACT_MISSING')


class DBLockedError(BusinessException):
    """数据库锁冲突异常"""
    def __init__(self):
        super().__init__("Database locked", code='DB_LOCKED')


class VersionConflictError(BusinessException):
    """乐观锁版本冲突异常"""
    def __init__(self, record_id: int):
        super().__init__(f"Version conflict: {record_id}", code='VERSION_CONFLICT')


class TaskRecoveryRequiredError(BusinessException):
    """任务恢复要求异常"""
    def __init__(self, task_run_id: int):
        super().__init__(f"Task recovery required: {task_run_id}", code='TASK_RECOVERY_REQUIRED')
