﻿# -*- coding: utf-8 -*-

"""
DAG 鏍￠獙涓庢搷浣?
鍔熻兘锛?1. DAG 鍚堟硶鎬ф牎楠?2. 鎷撴墤鎺掑簭
3. 鐜娴?4. 渚濊禆鍥炬瀯寤?"""
from typing import Dict, List, Set, Any, Optional, Tuple


class DagValidator:
    """DAG 鏍￠獙鍣?""
    
    @staticmethod
    def validate_dag(dag_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        楠岃瘉 DAG 鐨勫悎娉曟€?        
        Args:
            dag_config: DAG 閰嶇疆
            
        Returns:
            楠岃瘉缁撴灉锛歿'valid': bool, 'errors': list, 'warnings': list}
        """
        errors = []
        warnings = []
        
        # 妫€鏌ュ繀闇€瀛楁
        if 'job' not in dag_config:
            errors.append('Missing "job" field')
        
        if 'nodes' not in dag_config:
            errors.append('Missing "nodes" field')
            return {'valid': False, 'errors': errors, 'warnings': warnings}
        
        if 'edges' not in dag_config:
            errors.append('Missing "edges" field')
            return {'valid': False, 'errors': errors, 'warnings': warnings}
        
        nodes = dag_config['nodes']
        edges = dag_config['edges']
        
        # 妫€鏌ヨ妭鐐瑰垪琛?        if not isinstance(nodes, list) or len(nodes) == 0:
            errors.append('"nodes" must be a non-empty list')
        
        # 妫€鏌ヨ竟鍒楄〃
        if not isinstance(edges, list):
            errors.append('"edges" must be a list')
        
        # 妫€鏌ヨ妭鐐瑰敮涓€鎬?        node_codes = [node.get('code') for node in nodes]
        if len(node_codes) != len(set(node_codes)):
            errors.append('Duplicate node codes found')
        
        # 妫€鏌ヨ妭鐐圭被鍨嬬櫧鍚嶅崟
        valid_action_types = {'API', 'SQL', 'BASH', 'LLM', 'PYTHON', 'FILE'}
        for node in nodes:
            action_type = node.get('action_type')
            if not action_type:
                errors.append(f"Node '{node.get('code')}' missing action_type")
            elif action_type not in valid_action_types:
                errors.append(f"Invalid action_type '{action_type}' in node '{node.get('code')}'")
            
            # 妫€鏌ュ繀闇€瀛楁
            if not node.get('code'):
                errors.append('Node missing required field: code')
            if not node.get('name'):
                warnings.append(f"Node '{node.get('code')}' missing recommended field: name")
        
        # 妫€鏌ヨ竟寮曠敤鐨勮妭鐐规槸鍚﹀瓨鍦?        node_code_set = set(node_codes)
        for edge in edges:
            if 'from' not in edge or 'to' not in edge:
                errors.append('Edge missing required fields: from/to')
                continue
            
            if edge['from'] not in node_code_set:
                errors.append(f"Edge references non-existent node '{edge['from']}'")
            if edge['to'] not in node_code_set:
                errors.append(f"Edge references non-existent node '{edge['to']}'")
        
        # 妫€鏌ョ幆
        has_cycle, cycle_path = DagValidator.detect_cycle(nodes, edges)
        if has_cycle:
            errors.append(f'Cycle detected: {" -> ".join(cycle_path)}')
        
        return {
            'valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings
        }
    
    @staticmethod
    def detect_cycle(nodes: List[Dict[str, Any]], edges: List[Dict[str, str]]) -> Tuple[bool, Optional[List[str]]]:
        """
        妫€娴?DAG 涓槸鍚﹀瓨鍦ㄧ幆
        
        Args:
            nodes: 鑺傜偣鍒楄〃
            edges: 杈瑰垪琛?            
        Returns:
            (鏄惁瀛樺湪鐜紝鐜殑璺緞)
        """
        # 鏋勫缓閭绘帴琛?        node_codes = {node['code'] for node in nodes}
        adj = {code: [] for code in node_codes}
        
        for edge in edges:
            adj[edge['from']].append(edge['to'])
        
        # DFS 妫€娴嬬幆
        visited = set()
        rec_stack = set()
        parent = {}
        
        def dfs(node: str) -> Optional[List[str]]:
            visited.add(node)
            rec_stack.add(node)
            
            for neighbor in adj.get(node, []):
                if neighbor not in visited:
                    parent[neighbor] = node
                    cycle = dfs(neighbor)
                    if cycle:
                        return cycle
                elif neighbor in rec_stack:
                    # 鎵惧埌鐜?                    cycle = [neighbor]
                    current = node
                    while current != neighbor:
                        cycle.append(current)
                        current = parent.get(current, neighbor)
                    cycle.append(neighbor)
                    return cycle[::-1]
            
            rec_stack.remove(node)
            return None
        
        for node in node_codes:
            if node not in visited:
                cycle = dfs(node)
                if cycle:
                    return True, cycle
        
        return False, None
    
    @staticmethod
    def topological_sort(nodes: List[Dict[str, Any]], edges: List[Dict[str, str]]) -> List[str]:
        """
        鎷撴墤鎺掑簭
        
        Args:
            nodes: 鑺傜偣鍒楄〃
            edges: 杈瑰垪琛?            
        Returns:
            鎺掑簭鍚庣殑鑺傜偣浠ｇ爜鍒楄〃
            
        Raises:
            ValueError: 濡傛灉瀛樺湪鐜?        """
        # 鏋勫缓閭绘帴琛ㄥ拰鍏ュ害琛?        node_codes = {node['code'] for node in nodes}
        adj = {code: [] for code in node_codes}
        in_degree = {code: 0 for code in node_codes}
        
        for edge in edges:
            adj[edge['from']].append(edge['to'])
            in_degree[edge['to']] += 1
        
        # Kahn 绠楁硶
        queue = [code for code in node_codes if in_degree[code] == 0]
        result = []
        
        while queue:
            node = queue.pop(0)
            result.append(node)
            
            for neighbor in adj[node]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)
        
        if len(result) != len(node_codes):
            raise ValueError('DAG contains a cycle')
        
        return result
    
    @staticmethod
    def build_dependency_graph(nodes: List[Dict[str, Any]], edges: List[Dict[str, str]]) -> Dict[str, List[str]]:
        """
        鏋勫缓渚濊禆鍥?        
        Args:
            nodes: 鑺傜偣鍒楄〃
            edges: 杈瑰垪琛?            
        Returns:
            渚濊禆鍥撅細{node_code: [渚濊禆鐨?node_codes]}
        """
        graph = {node['code']: [] for node in nodes}
        
        for edge in edges:
            graph[edge['to']].append(edge['from'])
        
        return graph
    
    @staticmethod
    def find_ready_nodes(
        nodes: List[Dict[str, Any]], 
        edges: List[Dict[str, str]],
        completed_nodes: Set[str]
    ) -> List[str]:
        """
        鏌ユ壘灏辩华鑺傜偣锛堟墍鏈変緷璧栧凡瀹屾垚鐨勮妭鐐癸級
        
        Args:
            nodes: 鑺傜偣鍒楄〃
            edges: 杈瑰垪琛?            completed_nodes: 宸插畬鎴愮殑鑺傜偣浠ｇ爜闆嗗悎
            
        Returns:
            灏辩华鑺傜偣浠ｇ爜鍒楄〃
        """
        # 鏋勫缓渚濊禆鍥?        dependencies = DagValidator.build_dependency_graph(nodes, edges)
        
        ready_nodes = []
        for node in nodes:
            node_code = node['code']
            
            # 宸插畬鎴愮殑鑺傜偣涓嶆槸灏辩华鑺傜偣
            if node_code in completed_nodes:
                continue
            
            # 妫€鏌ユ墍鏈変緷璧栨槸鍚﹀凡瀹屾垚
            deps = dependencies.get(node_code, [])
            if all(dep in completed_nodes for dep in deps):
                ready_nodes.append(node_code)
        
        return ready_nodes
