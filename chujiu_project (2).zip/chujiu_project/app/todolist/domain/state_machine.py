﻿# -*- coding: utf-8 -*-

"""
鐘舵€佹満瀹氫箟
"""
from enum import Enum


class TaskRunStatus(str, Enum):
    """TaskRun 鐘舵€佹灇涓?""
    CREATED = "CREATED"
    READY = "READY"
    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    PARTIAL_SUCCESS = "PARTIAL_SUCCESS"
    CANCELED = "CANCELED"
    RETRYING = "RETRYING"


class JobRunStatus(str, Enum):
    """JobRun 鐘舵€佹灇涓?""
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    WAITING_SUBJOB = "WAITING_SUBJOB"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    RETRYING = "RETRYING"
    SKIPPED = "SKIPPED"


class NodeRunStatus(str, Enum):
    """NodeRun 鐘舵€佹灇涓?""
    PENDING = "PENDING"
    READY = "READY"
    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    RETRYING = "RETRYING"
    SKIPPED = "SKIPPED"


class ActionType(str, Enum):
    """Node 鍔ㄤ綔绫诲瀷鏋氫妇"""
    API = "API"
    SQL = "SQL"
    BASH = "BASH"
    LLM = "LLM"
    PYTHON = "PYTHON"
    FILE = "FILE"


class ArtifactType(str, Enum):
    """浜х墿绫诲瀷鏋氫妇"""
    SOURCE = "SOURCE"
    AST = "AST"
    REPORT = "REPORT"
    TESTCASE = "TESTCASE"
    OUTPUT_FILE = "OUTPUT_FILE"
    LOG = "LOG"
    RULE = "RULE"


# 鐘舵€佽浆鎹㈣鍒?TASK_RUN_TRANSITIONS = {
    TaskRunStatus.CREATED: [TaskRunStatus.READY],
    TaskRunStatus.READY: [TaskRunStatus.RUNNING],
    TaskRunStatus.RUNNING: [TaskRunStatus.SUCCESS, TaskRunStatus.FAILED, TaskRunStatus.PARTIAL_SUCCESS, TaskRunStatus.CANCELED],
    TaskRunStatus.FAILED: [TaskRunStatus.RETRYING],
    TaskRunStatus.RETRYING: [TaskRunStatus.RUNNING],
    TaskRunStatus.PARTIAL_SUCCESS: [TaskRunStatus.SUCCESS, TaskRunStatus.FAILED],
}

JOB_RUN_TRANSITIONS = {
    JobRunStatus.PENDING: [JobRunStatus.RUNNING],
    JobRunStatus.RUNNING: [JobRunStatus.WAITING_SUBJOB, JobRunStatus.SUCCESS, JobRunStatus.FAILED, JobRunStatus.SKIPPED],
    JobRunStatus.WAITING_SUBJOB: [JobRunStatus.RUNNING, JobRunStatus.FAILED],
    JobRunStatus.FAILED: [JobRunStatus.RETRYING],
    JobRunStatus.RETRYING: [JobRunStatus.RUNNING],
}

NODE_RUN_TRANSITIONS = {
    NodeRunStatus.PENDING: [NodeRunStatus.READY],
    NodeRunStatus.READY: [NodeRunStatus.RUNNING],
    NodeRunStatus.RUNNING: [NodeRunStatus.SUCCESS, NodeRunStatus.FAILED, NodeRunStatus.RETRYING],
    NodeRunStatus.FAILED: [NodeRunStatus.SKIPPED, NodeRunStatus.RETRYING],
    NodeRunStatus.RETRYING: [NodeRunStatus.RUNNING],
}


def can_transition(current_status: Enum, new_status: Enum) -> bool:
    """
    妫€鏌ョ姸鎬佽浆鎹㈡槸鍚﹀悎娉?    
    Args:
        current_status: 褰撳墠鐘舵€?        new_status: 鏂扮姸鎬?    
    Returns:
        鏄惁鍏佽杞崲
    """
    # 鏍规嵁鐘舵€佺被鍨嬮€夋嫨杞崲瑙勫垯
    if isinstance(current_status, TaskRunStatus):
        transitions = TASK_RUN_TRANSITIONS
    elif isinstance(current_status, JobRunStatus):
        transitions = JOB_RUN_TRANSITIONS
    elif isinstance(current_status, NodeRunStatus):
        transitions = NODE_RUN_TRANSITIONS
    else:
        return False
    
    allowed = transitions.get(current_status, [])
    return new_status in allowed
