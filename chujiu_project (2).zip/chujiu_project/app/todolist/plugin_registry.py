﻿# -*- coding: utf-8 -*-

"""
Plugin DAG Registry Module

Manages plugin DAG registration and retrieval.
"""
from typing import Dict, Any, Optional, List


class PluginDagRegistry:
    """
    Registry for plugin DAG configurations.
    
    Singleton pattern to ensure single instance across the application.
    """
    
    _instance: Optional['PluginDagRegistry'] = None
    
    def __new__(cls) -> 'PluginDagRegistry':
        """Create or return singleton instance."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.plugin_dags: Dict[str, Dict[str, Any]] = {}
        return cls._instance
    
    def register_plugin_dag(self, plugin_code: str, dag_config: Dict[str, Any]) -> None:
        """
        Register a plugin DAG configuration.
        
        Args:
            plugin_code: Plugin code identifier
            dag_config: DAG configuration dictionary
        """
        self.plugin_dags[plugin_code] = {
            'dag': dag_config,
            'registered': True
        }
    
    def get_plugin_dag(self, plugin_code: str) -> Optional[Dict[str, Any]]:
        """
        Get plugin DAG configuration.
        
        Args:
            plugin_code: Plugin code identifier
            
        Returns:
            DAG configuration dictionary or None if not found
        """
        plugin = self.plugin_dags.get(plugin_code)
        if plugin:
            return plugin.get('dag')
        return None
    
    def has_plugin_dag(self, plugin_code: str) -> bool:
        """
        Check if plugin DAG is registered.
        
        Args:
            plugin_code: Plugin code identifier
            
        Returns:
            True if registered, False otherwise
        """
        return plugin_code in self.plugin_dags
    
    def list_plugin_dags(self) -> List[str]:
        """
        List all registered plugin codes.
        
        Returns:
            List of plugin codes
        """
        return list(self.plugin_dags.keys())
    
    def unregister_plugin_dag(self, plugin_code: str) -> bool:
        """
        Unregister a plugin DAG.
        
        Args:
            plugin_code: Plugin code identifier
            
        Returns:
            True if unregistered, False if not found
        """
        if plugin_code in self.plugin_dags:
            del self.plugin_dags[plugin_code]
            return True
        return False


# Global singleton instance
plugin_dag_registry = PluginDagRegistry()
