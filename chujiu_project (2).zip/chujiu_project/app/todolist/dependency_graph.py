﻿# -*- coding: utf-8 -*-

"""
Dependency Graph Module

Provides DAG (Directed Acyclic Graph) structure and operations.
"""
from typing import Dict, Set, List, Tuple, Any, Optional
from collections import defaultdict


class DependencyGraph:
    """
    Dependency graph for task scheduling.
    
    Supports:
    - Node and edge management
    - Topological sorting
    - Cycle detection
    - Ready node finding
    """
    
    def __init__(self, dag: Optional[Dict[str, Any]] = None):
        """
        Initialize dependency graph.
        
        Args:
            dag: DAG configuration with 'nodes' and 'edges' keys
        """
        self.nodes_map: Dict[str, Dict[str, Any]] = {}  # node_code -> node_data
        self.edges: List[Tuple[str, str]] = []  # (from_code, to_code)
        self.adj: Dict[str, Set[str]] = defaultdict(set)  # node -> downstream nodes
        self.reverse_adj: Dict[str, Set[str]] = defaultdict(set)  # node -> upstream nodes
        
        if dag:
            self.build_from_dag(dag)
    
    def build_from_dag(self, dag: Dict[str, Any]) -> None:
        """
        Build graph from DAG configuration.
        
        Args:
            dag: DAG configuration dictionary
        """
        # Add nodes
        for node in dag.get('nodes', []):
            node_code = node.get('code')
            if node_code:
                self.nodes_map[node_code] = node
        
        # Add edges
        for edge in dag.get('edges', []):
            from_code = edge.get('from')
            to_code = edge.get('to')
            
            if from_code and to_code:
                self.edges.append((from_code, to_code))
                self.adj[from_code].add(to_code)
                self.reverse_adj[to_code].add(from_code)
    
    def add_node(self, node_code: str, node_data: Optional[Dict[str, Any]] = None) -> None:
        """Add a node to the graph."""
        self.nodes_map[node_code] = node_data or {}
    
    def add_edge(self, from_code: str, to_code: str) -> None:
        """Add an edge to the graph."""
        self.edges.append((from_code, to_code))
        self.adj[from_code].add(to_code)
        self.reverse_adj[to_code].add(from_code)
    
    def get_upstream_nodes(self, node_code: str) -> Set[str]:
        """
        Get all upstream nodes (dependencies) of a node.
        
        Args:
            node_code: Target node code
            
        Returns:
            Set of upstream node codes
        """
        return self.reverse_adj.get(node_code, set())
    
    def get_downstream_nodes(self, node_code: str) -> Set[str]:
        """
        Get all downstream nodes (dependents) of a node.
        
        Args:
            node_code: Target node code
            
        Returns:
            Set of downstream node codes
        """
        return self.adj.get(node_code, set())
    
    def get_node(self, node_code: str) -> Optional[Dict[str, Any]]:
        """Get node data by code."""
        return self.nodes_map.get(node_code)
    
    def get_all_nodes(self) -> List[str]:
        """Get all node codes."""
        return list(self.nodes_map.keys())
    
    def get_all_edges(self) -> List[Tuple[str, str]]:
        """Get all edges."""
        return self.edges.copy()
    
    def has_node(self, node_code: str) -> bool:
        """Check if node exists."""
        return node_code in self.nodes_map
    
    def has_edge(self, from_code: str, to_code: str) -> bool:
        """Check if edge exists."""
        return (from_code, to_code) in self.edges
    
    def node_count(self) -> int:
        """Get number of nodes."""
        return len(self.nodes_map)
    
    def edge_count(self) -> int:
        """Get number of edges."""
        return len(self.edges)
    
    def find_ready_nodes(self, completed: Set[str]) -> List[str]:
        """
        Find nodes that are ready to execute.
        
        A node is ready if all its upstream nodes are completed.
        
        Args:
            completed: Set of completed node codes
            
        Returns:
            List of ready node codes
        """
        ready = []
        for node_code in self.nodes_map.keys():
            if node_code in completed:
                continue
            
            upstream = self.get_upstream_nodes(node_code)
            if upstream.issubset(completed):
                ready.append(node_code)
        
        return ready
    
    def topological_sort(self) -> List[str]:
        """
        Perform topological sort on the graph.
        
        Returns:
            List of node codes in topological order
            
        Raises:
            ValueError: If graph contains a cycle
        """
        in_degree = defaultdict(int)
        for node_code in self.nodes_map.keys():
            in_degree[node_code] = len(self.get_upstream_nodes(node_code))
        
        # Start with nodes that have no dependencies
        queue = [node for node, degree in in_degree.items() if degree == 0]
        result = []
        
        while queue:
            node = queue.pop(0)
            result.append(node)
            
            for downstream in self.get_downstream_nodes(node):
                in_degree[downstream] -= 1
                if in_degree[downstream] == 0:
                    queue.append(downstream)
        
        if len(result) != len(self.nodes_map):
            raise ValueError("Graph contains a cycle! Topological sort failed.")
        
        return result
    
    def detect_cycle(self) -> Tuple[bool, Optional[List[str]]]:
        """
        Detect if the graph contains a cycle.
        
        Returns:
            Tuple of (has_cycle, cycle_path)
            cycle_path is None if no cycle exists
        """
        visited = set()
        rec_stack = set()
        parent = {}
        
        def dfs(node: str) -> Optional[List[str]]:
            visited.add(node)
            rec_stack.add(node)
            
            for neighbor in self.get_downstream_nodes(node):
                if neighbor not in visited:
                    parent[neighbor] = node
                    cycle = dfs(neighbor)
                    if cycle:
                        return cycle
                elif neighbor in rec_stack:
                    # Found cycle
                    cycle = [neighbor]
                    current = node
                    while current != neighbor:
                        cycle.append(current)
                        current = parent.get(current, neighbor)
                    cycle.append(neighbor)
                    return cycle[::-1]
            
            rec_stack.remove(node)
            return None
        
        for node in self.nodes_map.keys():
            if node not in visited:
                cycle = dfs(node)
                if cycle:
                    return True, cycle
        
        return False, None
    
    def validate(self) -> Dict[str, Any]:
        """
        Validate the graph structure.
        
        Returns:
            Validation result dictionary
        """
        errors = []
        warnings = []
        
        # Check for cycles
        has_cycle, cycle_path = self.detect_cycle()
        if has_cycle:
            errors.append(f"Graph contains cycle: {' -> '.join(cycle_path)}")
        
        # Check for orphaned edges
        for from_code, to_code in self.edges:
            if from_code not in self.nodes_map:
                errors.append(f"Edge references non-existent node: {from_code}")
            if to_code not in self.nodes_map:
                errors.append(f"Edge references non-existent node: {to_code}")
        
        return {
            'valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings,
            'node_count': self.node_count(),
            'edge_count': self.edge_count()
        }


# Convenience functions
def validate_dag(dag: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate a DAG configuration.
    
    Args:
        dag: DAG configuration dictionary
        
    Returns:
        Validation result dictionary
    """
    graph = DependencyGraph(dag)
    return graph.validate()


def detect_cycle(nodes: List[Dict[str, Any]], edges: List[Dict[str, str]]) -> Tuple[bool, Optional[List[str]]]:
    """
    Detect cycle in a graph.
    
    Args:
        nodes: List of node dictionaries
        edges: List of edge dictionaries
        
    Returns:
        Tuple of (has_cycle, cycle_path)
    """
    dag = {'nodes': nodes, 'edges': edges}
    graph = DependencyGraph(dag)
    return graph.detect_cycle()


def topological_sort(nodes: List[Dict[str, Any]], edges: List[Dict[str, str]]) -> List[str]:
    """
    Perform topological sort.
    
    Args:
        nodes: List of node dictionaries
        edges: List of edge dictionaries
        
    Returns:
        List of node codes in topological order
    """
    dag = {'nodes': nodes, 'edges': edges}
    graph = DependencyGraph(dag)
    return graph.topological_sort()
