﻿# -*- coding: utf-8 -*-

"""
TodoEngine - 任务执行引擎
"""
from typing import List, Tuple
from app.todolist.task_context import TaskContext, TaskResult
from app.todolist.task_registry import TaskRegistry
from app.extensions import db
from app.models import TaskRun, NodeRun
import logging
import json

logger = logging.getLogger(__name__)


# 默认执行步骤（Excel VBA -> WPS JS 示例）
TODO_STEPS: List[Tuple[str, int]] = [
    ("EXTRACT_VBA", 1),
    ("FIND_SIMILAR", 2),
    ("REUSE_OR_CONTINUE", 3),
    ("GENERATE_AST", 4),
    ("GENERATE_VBA_TEST", 5),
    ("GENERATE_JS", 6),
    ("GENERATE_JS_TEST", 7),
    ("RUN_VBA_TEST", 8),
    ("RUN_JS_TEST", 9),
    ("COMPARE_RESULT", 10),
    ("LEARN_ON_FAILURE", 11),
    ("RETRY_CONVERSION", 12),
    ("WRITE_WPS", 13),
    ("FINALIZE", 14),
]


class DependencyNotReadyError(Exception):
    """依赖未就绪异常"""
    pass


class TodoEngine:
    """
    任务执行引擎
    
    负责执行单个任务的完整生命周期（步骤链）
    处理步骤跳转和重试逻辑
    """
    
    def __init__(
        self,
        registry: TaskRegistry,
        max_macro_retry: int = 3,
    ):
        self.registry = registry
        self.max_macro_retry = max_macro_retry
    
    def run_macro(self, context: TaskContext) -> TaskResult:
        """
        运行单个宏的任务链
        
        Args:
            context: 任务上下文
        
        Returns:
            执行结果
        """
        logger.info(f"[TodoEngine] Starting macro_id={context.macro_id}")
        
        # 获取步骤列表（从数据库或配置）
        steps = TODO_STEPS
        
        # 如果上下文中指定了起始步骤（用于断点续传或特定重试）
        step_index = 0
        if context.current_step and context.current_step in [s[0] for s in steps]:
            step_index = next(i for i, s in enumerate(steps) if s[0] == context.current_step)
        
        while step_index < len(steps):
            step_name, step_order = steps[step_index]
            context.current_step = step_name
            
            try:
                # 获取处理器
                handler = self.registry.get_handler(step_name)
                
                if not handler:
                    logger.warning(f"[TodoEngine] Handler not found for step {step_name}, skipping")
                    step_index += 1
                    continue
                
                # 执行处理器
                logger.info(f"[TodoEngine] Executing step {step_name}")
                result: TaskResult = handler(context)
                
                if not result.success:
                    # 更新节点状态为 FAILED
                    from app.todolist.node_status_updater import update_node_status
                    try:
                        update_node_status(
                            node_code=step_name,
                            job_run_id=context.job_run_id,
                            status='FAILED',
                            error_json=result.message
                        )
                    except Exception as update_error:
                        logger.error(f"Failed to update node status: {str(update_error)}")
                    
                    if result.retry:
                        # 请求重试，保持当前步骤索引
                        logger.warning(f"[TodoEngine] Retry requested at step {step_name}")
                        
                        # 更新节点状态为 RETRYING
                        try:
                            update_node_status(
                                node_code=step_name,
                                job_run_id=context.job_run_id,
                                status='RETRYING'
                            )
                        except Exception as update_error:
                            logger.error(f"Failed to update node status: {str(update_error)}")
                        
                        continue
                    else:
                        # 彻底失败
                        logger.error(f"[TodoEngine] Step {step_name} failed: {result.message}")
                        
                        # 尝试错误恢复
                        from app.todolist.error_recovery import handle_node_error
                        recovery_result = handle_node_error(context, step_name, result.message)
                        
                        if recovery_result.retry:
                            logger.info(f"[TodoEngine] Recovery successful, retrying at {recovery_result.jump_to_step}")
                            if recovery_result.jump_to_step:
                                step_name = recovery_result.jump_to_step
                                continue
                        
                        return result
                
                logger.info(f"[TodoEngine] Step {step_name} completed: {result.message}")
                
                # 更新节点状态为 SUCCESS
                from app.todolist.node_status_updater import update_node_status
                try:
                    update_node_status(
                        node_code=step_name,
                        job_run_id=context.job_run_id,
                        status='SUCCESS',
                        output_json=json.dumps(result.data) if result.data else None
                    )
                except Exception as update_error:
                    logger.error(f"Failed to update node status: {str(update_error)}")
                
                # 处理跳转指令
                if result.jump_to_step:
                    if result.jump_to_step in [s[0] for s in steps]:
                        step_index = next(i for i, s in enumerate(steps) if s[0] == result.jump_to_step)
                        continue
                    else:
                        raise ValueError(f"Invalid jump target: {result.jump_to_step}")
                
                # 正常流转到下一步
                step_index += 1
                
            except Exception as e:
                logger.exception(f"[TodoEngine] Exception at step {step_name}: {str(e)}")
                return TaskResult(success=False, message=f"Exception at {step_name}: {str(e)}")
        
        logger.info(f"[TodoEngine] Finished macro_id={context.macro_id}")
        return TaskResult(success=True, message="Macro chain completed")
