﻿# -*- coding: utf-8 -*-

"""
ToDoList Core Engine Module

Contains:
- dependency_scheduler: Dependency scheduler
- dependency_graph: Dependency graph model
- todo_engine: Task execution engine
- task_registry: Task registry
- plugin_registry: Plugin DAG registry
- task_context: Task context data structures
"""

from app.todolist.dependency_graph import DependencyGraph, validate_dag
from app.todolist.plugin_registry import PluginDagRegistry, plugin_dag_registry
from app.todolist.task_context import TaskContext, TaskResult, DependencyMacroContext

__all__ = [
    'DependencyGraph',
    'validate_dag',
    'PluginDagRegistry',
    'plugin_dag_registry',
    'TaskContext',
    'TaskResult',
    'DependencyMacroContext',
]
