﻿# -*- coding: utf-8 -*-

"""
todolist 宸ュ叿鍑芥暟

鍔熻兘锛?1. 鏃ュ織璁板綍杈呭姪鍑芥暟
2. 鏃堕棿鏍煎紡鍖?3. 閫氱敤杈呭姪鍑芥暟
"""
import logging
from datetime import datetime
from typing import Any, Optional


def format_duration(start_time: datetime, end_time: Optional[datetime] = None) -> str:
    """
    鏍煎紡鍖栨寔缁椂闂?    
    Args:
        start_time: 寮€濮嬫椂闂?        end_time: 缁撴潫鏃堕棿锛岄粯璁ゅ綋鍓嶆椂闂?        
    Returns:
        鏍煎紡鍖栫殑鎸佺画鏃堕棿瀛楃涓诧紙濡?"1m 23s"锛?    """
    if end_time is None:
        end_time = datetime.utcnow()
    
    delta = end_time - start_time
    total_seconds = int(delta.total_seconds())
    
    if total_seconds < 60:
        return f"{total_seconds}s"
    elif total_seconds < 3600:
        minutes = total_seconds // 60
        seconds = total_seconds % 60
        return f"{minutes}m {seconds}s"
    else:
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        return f"{hours}h {minutes}m"


def truncate_string(text: str, max_length: int = 100, suffix: str = "...") -> str:
    """
    鎴柇瀛楃涓?    
    Args:
        text: 鍘熷鏂囨湰
        max_length: 鏈€澶ч暱搴?        suffix: 鎴柇鍚庣紑
        
    Returns:
        鎴柇鍚庣殑鏂囨湰
    """
    if len(text) <= max_length:
        return text
    
    return text[:max_length - len(suffix)] + suffix


def safe_json_loads(text: Optional[str], default: Any = None) -> Any:
    """
    瀹夊叏鍦拌В鏋?JSON 瀛楃涓?    
    Args:
        text: JSON 鏂囨湰
        default: 瑙ｆ瀽澶辫触鏃剁殑榛樿鍊?        
    Returns:
        瑙ｆ瀽鍚庣殑瀵硅薄
    """
    import json
    
    if not text:
        return default
    
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return default


def safe_json_dumps(obj: Any, default: str = "") -> str:
    """
    瀹夊叏鍦板簭鍒楀寲 JSON 瀵硅薄
    
    Args:
        obj: 瀵硅薄
        default: 搴忓垪鍖栧け璐ユ椂鐨勯粯璁ゅ€?        
    Returns:
        JSON 瀛楃涓?    """
    import json
    
    try:
        return json.dumps(obj, ensure_ascii=False, default=str)
    except (TypeError, ValueError):
        return default


def get_logger(name: str, level: int = logging.INFO) -> logging.Logger:
    """
    鑾峰彇鏃ュ織璁板綍鍣?    
    Args:
        name: 鏃ュ織鍚嶇О
        level: 鏃ュ織绾у埆
        
    Returns:
        鏃ュ織璁板綍鍣?    """
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # 濡傛灉娌℃湁澶勭悊鍣紝娣诲姞鎺у埗鍙板鐞嗗櫒
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setLevel(level)
        
        # 鏍煎紡鍖栧櫒
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    
    return logger


def retry_on_exception(max_retries: int = 3, delay: float = 1.0, exceptions: tuple = (Exception,)):
    """
    閲嶈瘯瑁呴グ鍣?    
    Args:
        max_retries: 鏈€澶ч噸璇曟鏁?        delay: 閲嶈瘯寤惰繜锛堢锛?        exceptions: 闇€瑕侀噸璇曠殑寮傚父绫诲瀷
        
    Returns:
        瑁呴グ鍣ㄥ嚱鏁?    """
    import time
    from functools import wraps
    
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        time.sleep(delay * (2 ** attempt))  # 鎸囨暟閫€閬?                    continue
            
            # 鎵€鏈夐噸璇曞け璐?            raise last_exception
        
        return wrapper
    return decorator
