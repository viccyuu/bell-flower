﻿# -*- coding: utf-8 -*-

"""
TaskRegistry - 浠诲姟澶勭悊鍣ㄦ敞鍐屼腑蹇?"""
from typing import Callable, Dict, Any


class TaskRegistry:
    """
    浠诲姟澶勭悊鍣ㄦ敞鍐屼腑蹇?    
    绠＄悊 Node 澶勭悊鍣ㄤ笌 Node 绫诲瀷鐨勬槧灏勫叧绯?    """
    
    def __init__(self):
        self._handlers: Dict[str, Callable] = {}
    
    def register(self, step_name: str, handler: Callable) -> None:
        """
        娉ㄥ唽澶勭悊鍣?        
        Args:
            step_name: 姝ラ鍚嶇О锛堝 parse_vba, convert_to_js锛?            handler: 澶勭悊鍑芥暟锛屾帴鏀?TaskContext锛岃繑鍥?TaskResult
        """
        self._handlers[step_name] = handler
    
    def get_handler(self, step_name: str) -> Callable:
        """
        鑾峰彇澶勭悊鍣?        
        Args:
            step_name: 姝ラ鍚嶇О
        
        Returns:
            澶勭悊鍑芥暟
        
        Raises:
            ValueError: 澶勭悊鍣ㄦ湭娉ㄥ唽
        """
        if step_name not in self._handlers:
            raise ValueError(f"No handler registered for step: {step_name}")
        return self._handlers[step_name]
    
    def unregister(self, step_name: str) -> bool:
        """
        娉ㄩ攢澶勭悊鍣?        
        Args:
            step_name: 姝ラ鍚嶇О
        
        Returns:
            鏄惁鎴愬姛娉ㄩ攢
        """
        if step_name in self._handlers:
            del self._handlers[step_name]
            return True
        return False
    
    def list_handlers(self) -> list:
        """
        鍒楀嚭鎵€鏈夊凡娉ㄥ唽鐨勫鐞嗗櫒
        
        Returns:
            姝ラ鍚嶇О鍒楄〃
        """
        return list(self._handlers.keys())


# 鍏ㄥ眬瀹炰緥
task_registry = TaskRegistry()
