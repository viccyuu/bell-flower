﻿# -*- coding: utf-8 -*-

"""
APIExecutor - API 执行器
"""
import requests
from typing import Dict, Any
from app.todolist.task_context import TaskContext, TaskResult
from app.todolist.executors.base_executor import BaseExecutor
from app.todolist.domain.exceptions import APITimeoutError


class APIExecutor(BaseExecutor):
    """
    API 执行器
    
    执行 HTTP API 调用
    """
    
    def execute(self, context: TaskContext) -> TaskResult:
        """执行 API 调用"""
        config = context.extra.get('api_config', {})
        
        method = config.get('method', 'GET')
        url = config.get('url')
        headers = config.get('headers', {})
        body = config.get('body')
        timeout = self.get_timeout(context)
        
        if not url:
            return TaskResult(success=False, message="URL is required")
        
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=headers,
                json=body,
                timeout=timeout
            )
            
            context.extra['api_response'] = {
                'status_code': response.status_code,
                'headers': dict(response.headers),
                'body': response.text
            }
            
            if response.status_code >= 400:
                return TaskResult(
                    success=False,
                    message=f"API returned status {response.status_code}"
                )
            
            return TaskResult(
                success=True,
                message="API call successful",
                data={'response': response.json() if response.content else None}
            )
        
        except requests.Timeout:
            raise APITimeoutError(url)
        except Exception as e:
            return TaskResult(success=False, message=f"API call failed: {str(e)}")
