"""
LLM Executor with SubJob Support

Executes LLM tasks and can create SubJobs for complex planning.
"""
from app.todolist.executors.base_executor import BaseExecutor
from app.llm.provider_config import llm_provider_config
from app.models import JobRun
from app.extensions import db
from datetime import datetime
import json
import requests


class LLMExecutor(BaseExecutor):
    """
    LLM Executor
    
    Executes LLM tasks and supports SubJob creation.
    """
    
    def __init__(self):
        """Initialize LLM executor"""
        self.config = llm_provider_config
    
    def execute(self, config):
        """
        Execute LLM task
        
        Args:
            config: Execution config with prompt and parameters
            
        Returns:
            dict: LLM response
        """
        prompt = config.get('prompt', '')
        system_prompt = config.get('system_prompt', '')
        model = config.get('model') or self.config.get_model()
        api_key = config.get('api_key') or self.config.get_api_key()
        timeout = config.get('timeout', 120)
        
        # Call LLM API
        response = self._call_llm_api(
            prompt=prompt,
            system_prompt=system_prompt,
            model=model,
            api_key=api_key,
            timeout=timeout
        )
        
        # Check if SubJob should be created
        if config.get('planning_enabled', False):
            subjob_plan = self._parse_subjob_plan(response)
            if subjob_plan:
                return {
                    'response': response,
                    'subjob_plan': subjob_plan,
                    'requires_subjob': True
                }
        
        return {
            'response': response,
            'requires_subjob': False
        }
    
    def _call_llm_api(self, prompt, system_prompt='', model='gpt-3.5-turbo', api_key='', timeout=120):
        """
        Call LLM API
        
        Args:
            prompt: User prompt
            system_prompt: System prompt
            model: Model name
            api_key: API key
            timeout: Timeout in seconds
            
        Returns:
            str: LLM response
        """
        if not api_key:
            return "Error: API key not configured"
        
        # Use LiteLLM or direct API call
        try:
            # Example: OpenAI API
            if 'gpt' in model.lower():
                return self._call_openai_api(prompt, system_prompt, model, api_key, timeout)
            elif 'claude' in model.lower():
                return self._call_anthropic_api(prompt, system_prompt, model, api_key, timeout)
            else:
                # Default to LiteLLM
                return self._call_litellm(prompt, system_prompt, model, api_key, timeout)
        except Exception as e:
            return f"Error calling LLM API: {str(e)}"
    
    def _call_openai_api(self, prompt, system_prompt, model, api_key, timeout):
        """Call OpenAI API"""
        url = 'https://api.openai.com/v1/chat/completions'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {api_key}'
        }
        
        messages = []
        if system_prompt:
            messages.append({'role': 'system', 'content': system_prompt})
        messages.append({'role': 'user', 'content': prompt})
        
        data = {
            'model': model,
            'messages': messages,
            'temperature': 0.7
        }
        
        response = requests.post(url, headers=headers, json=data, timeout=timeout)
        response.raise_for_status()
        
        result = response.json()
        return result['choices'][0]['message']['content']
    
    def _call_anthropic_api(self, prompt, system_prompt, model, api_key, timeout):
        """Call Anthropic API"""
        url = 'https://api.anthropic.com/v1/messages'
        headers = {
            'Content-Type': 'application/json',
            'x-api-key': api_key,
            'anthropic-version': '2023-06-01'
        }
        
        data = {
            'model': model,
            'max_tokens': 4096,
            'system': system_prompt,
            'messages': [{'role': 'user', 'content': prompt}]
        }
        
        response = requests.post(url, headers=headers, json=data, timeout=timeout)
        response.raise_for_status()
        
        result = response.json()
        return result['content'][0]['text']
    
    def _call_litellm(self, prompt, system_prompt, model, api_key, timeout):
        """Call via LiteLLM (placeholder)"""
        # LiteLLM integration would go here
        return f"LiteLLM call to {model} (not implemented)"
    
    def _parse_subjob_plan(self, response):
        """
        Parse SubJob plan from LLM response
        
        Args:
            response: LLM response text
            
        Returns:
            dict: SubJob plan or None
        """
        # Look for JSON plan in response
        import re
        json_match = re.search(r'\{.*\}', response, re.DOTALL)
        if json_match:
            try:
                plan = json.loads(json_match.group())
                if 'subjobs' in plan:
                    return plan
            except:
                pass
        return None
    
    def create_subjobs(self, task_run_id, parent_job_id, subjob_plan):
        """
        Create SubJobs from plan
        
        Args:
            task_run_id: TaskRun ID
            parent_job_id: Parent JobRun ID
            subjob_plan: SubJob plan from LLM
            
        Returns:
            list: Created SubJobs
        """
        from app.models import JobTemplate, JobRun
        
        subjobs = []
        for i, subjob_def in enumerate(subjob_plan.get('subjobs', [])):
            # Create JobTemplate
            job_template = JobTemplate(
                task_template_id=None,  # Will be set from parent
                parent_job_template_id=None,
                code=subjob_def.get('code', f'subjob_{i}'),
                name=subjob_def.get('name', f'SubJob {i}'),
                is_sub_job=1,
                dag_json=json.dumps(subjob_def.get('dag', {}))
            )
            db.session.add(job_template)
            db.session.flush()
            
            # Create JobRun
            subjob = JobRun(
                task_run_id=task_run_id,
                job_template_id=job_template.id,
                parent_job_run_id=parent_job_id,
                code=subjob_def.get('code', f'subjob_{i}'),
                name=subjob_def.get('name', f'SubJob {i}'),
                is_sub_job=1,
                status='PENDING'
            )
            db.session.add(subjob)
            subjobs.append(subjob)
        
        db.session.commit()
        return subjobs
