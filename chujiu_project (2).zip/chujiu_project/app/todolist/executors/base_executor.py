﻿# -*- coding: utf-8 -*-

"""
BaseExecutor - 执行器基类
"""
from abc import ABC, abstractmethod
from typing import Any, Dict
from app.todolist.task_context import TaskContext, TaskResult


class BaseExecutor(ABC):
    """
    执行器基类
    
    所有执行器必须继承此类并实现 execute 方法
    """
    
    def __init__(self, name: str = None):
        self.name = name or self.__class__.__name__
    
    @abstractmethod
    def execute(self, context: TaskContext) -> TaskResult:
        """
        执行动作
        
        Args:
            context: 任务上下文
        
        Returns:
            执行结果
        """
        pass
    
    def validate_input(self, context: TaskContext) -> bool:
        """
        验证输入
        
        Args:
            context: 任务上下文
        
        Returns:
            是否有效
        """
        return True
    
    def get_timeout(self, context: TaskContext) -> int:
        """
        获取超时时间
        
        Args:
            context: 任务上下文
        
        Returns:
            超时时间（秒），默认 120 秒
        """
        return 120
