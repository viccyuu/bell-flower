# -*- coding: utf-8 -*-
"""
BashExecutor - Bash 执行器

迁移自 app/agent/tools/shell.py
"""
import asyncio
from typing import Dict, Any
from app.todolist.task_context import TaskContext, TaskResult
from app.todolist.executors.base_executor import BaseExecutor

# 导入 Agent Tools
from app.agent.tools.shell import ExecTool


class BashExecutor(BaseExecutor):
    """Bash 执行器"""
    
    def __init__(
        self,
        timeout: int = 60,
        working_dir: str | None = None,
        restrict_to_workspace: bool = False,
    ):
        """
        初始化
        
        Args:
            timeout: 超时时间（秒）
            working_dir: 工作目录
            restrict_to_workspace: 限制在工作目录内
        """
        self.exec_tool = ExecTool(
            timeout=timeout,
            working_dir=working_dir,
            restrict_to_workspace=restrict_to_workspace,
        )
    
    def execute(self, context: TaskContext) -> TaskResult:
        """
        执行 Bash 命令
        
        Args:
            context: 任务上下文
        
        Returns:
            TaskResult
        """
        # 从 context 获取参数
        command = context.extra.get('command')
        timeout = context.extra.get('timeout', 60)
        working_dir = context.extra.get('working_dir')
        
        if not command:
            return TaskResult(success=False, error='command is required')
        
        try:
            # 执行命令
            result = asyncio.run(self.exec_tool.execute(
                command=command,
                timeout=timeout,
                working_dir=working_dir
            ))
            
            # 解析结果
            if result.startswith('Error:'):
                return TaskResult(success=False, error=result)
            
            return TaskResult(success=True, output={'output': result})
        
        except Exception as e:
            return TaskResult(success=False, error=str(e))
