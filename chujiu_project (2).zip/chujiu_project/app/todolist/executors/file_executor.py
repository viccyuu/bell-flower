# -*- coding: utf-8 -*-
"""
FileExecutor - 文件执行器

迁移自 app/agent/tools/filesystem.py
"""
import asyncio
from typing import Dict, Any
from app.todolist.task_context import TaskContext, TaskResult
from app.todolist.executors.base_executor import BaseExecutor

# 导入 Agent Tools
from app.agent.tools.filesystem import (
    ReadFileTool,
    WriteFileTool,
    EditFileTool,
    ListDirTool,
)


class FileExecutor(BaseExecutor):
    """文件执行器"""
    
    def __init__(self):
        """初始化工具"""
        self.read_tool = ReadFileTool()
        self.write_tool = WriteFileTool()
        self.edit_tool = EditFileTool()
        self.list_tool = ListDirTool()
    
    def execute(self, context: TaskContext) -> TaskResult:
        """
        执行文件操作
        
        Args:
            context: 任务上下文
        
        Returns:
            TaskResult
        """
        # 从 context 获取参数
        operation = context.extra.get('operation', 'read')
        path = context.extra.get('path')
        
        if not path:
            return TaskResult(success=False, error='path is required')
        
        try:
            # 根据操作类型调用对应的工具
            if operation == 'read':
                offset = context.extra.get('offset', 1)
                limit = context.extra.get('limit', 2000)
                result = asyncio.run(self.read_tool.execute(
                    path=path,
                    offset=offset,
                    limit=limit
                ))
            
            elif operation == 'write':
                content = context.extra.get('content')
                if not content:
                    return TaskResult(success=False, error='content is required')
                result = asyncio.run(self.write_tool.execute(
                    path=path,
                    content=content
                ))
            
            elif operation == 'edit':
                old_text = context.extra.get('old_text')
                new_text = context.extra.get('new_text')
                replace_all = context.extra.get('replace_all', False)
                
                if not old_text or not new_text:
                    return TaskResult(success=False, error='old_text and new_text are required')
                
                result = asyncio.run(self.edit_tool.execute(
                    path=path,
                    old_text=old_text,
                    new_text=new_text,
                    replace_all=replace_all
                ))
            
            elif operation == 'list':
                recursive = context.extra.get('recursive', False)
                max_entries = context.extra.get('max_entries', 200)
                result = asyncio.run(self.list_tool.execute(
                    path=path,
                    recursive=recursive,
                    max_entries=max_entries
                ))
            
            else:
                return TaskResult(success=False, error=f'Unknown operation: {operation}')
            
            return TaskResult(success=True, output={'result': result})
        
        except Exception as e:
            return TaskResult(success=False, error=str(e))
