﻿# -*- coding: utf-8 -*-

"""
Configuration Management Module
"""
import os
from pathlib import Path
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    """Application Settings"""
    
    # Basic settings
    APP_NAME: str = "Chujiu Design TodoList"
    APP_VERSION: str = "1.4.1"
    DEBUG: bool = True
    SECRET_KEY: str = "dev-secret-key-change-in-production"
    
    # Database settings
    BASE_DIR: Path = Path(__file__).parent
    DATABASE_PATH: Path = BASE_DIR / "instance" / "app.db"
    DATABASE_URL: str = Field(
        default_factory=lambda: f"sqlite:///{Path(__file__).parent / 'instance' / 'app.db'}",
        description="SQLite database URL"
    )
    
    # File storage settings
    UPLOAD_FOLDER: Path = BASE_DIR / "uploads"
    ARTIFACTS_FOLDER: Path = BASE_DIR / "artifacts"
    LOGS_FOLDER: Path = BASE_DIR / "logs"
    LEARNING_FOLDER: Path = BASE_DIR / "learning"
    MAX_UPLOAD_SIZE: int = 50 * 1024 * 1024  # 50MB
    
    # Allowed file extensions
    ALLOWED_EXTENSIONS: set = {'.xlsm', '.xls', '.xlsx', '.et', '.wps'}
    
    # Development auth switch
    DEV_AUTH_ENABLED: bool = False
    
    # API settings
    API_PREFIX: str = "/api"
    
    # LLM settings (placeholder)
    LLM_API_KEY: str = ""
    LLM_MODEL: str = "default"
    LLM_TIMEOUT: int = 120
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


# Global settings instance
settings = Settings()


# Ensure necessary directories exist
def ensure_directories():
    """Ensure necessary directories exist"""
    directories = [
        settings.UPLOAD_FOLDER,
        settings.ARTIFACTS_FOLDER,
        settings.LOGS_FOLDER,
        settings.LEARNING_FOLDER,
        settings.DATABASE_PATH.parent,
    ]
    for directory in directories:
        directory.mkdir(parents=True, exist_ok=True)


ensure_directories()
