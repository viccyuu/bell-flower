﻿# -*- coding: utf-8 -*-

# Global settings instance
settings = Settings()


# Ensure necessary directories exist
def ensure_directories():
    """Ensure necessary directories exist"""
    directories = [
        settings.UPLOAD_FOLDER,
        settings.ARTIFACTS_FOLDER,
        settings.LOGS_FOLDER,
        settings.LEARNING_FOLDER,
        settings.DATABASE_PATH.parent,
    ]
    for directory in directories:
        directory.mkdir(parents=True, exist_ok=True)


ensure_directories()
