# -*- coding: utf-8 -*-
"""
Recovery Service - 恢复服务 ⭐

扫描并恢复中断的任务，支持：
- 扫描 RUNNING 状态任务
- 重置 RUNNING 节点为 PENDING
- 重建 runtime_context
- 恢复执行
"""
from typing import Any, Dict, List, Optional
from app.scheduler.dag_scheduler import DagScheduler
from app.scheduler.exceptions import RecoveryError


class RecoveryService:
    """
    恢复服务 ⭐
    
    扫描并恢复中断的任务，支持：
    - 扫描 RUNNING 状态任务
    - 重置 RUNNING 节点为 PENDING
    - 重建 runtime_context
    - 恢复执行
    """
    
    def __init__(
        self,
        scheduler: DagScheduler,
        task_repo = None,
        job_repo = None,
        node_repo = None,
        log_repo = None,
        dag_registry: Dict[str, Dict[str, Any]] = None
    ):
        """
        初始化恢复服务
        
        Args:
            scheduler: DAG 调度器
            task_repo: TaskRunRepository
            job_repo: JobRunRepository
            node_repo: NodeRunRepository
            log_repo: ExecutionLogRepository
            dag_registry: DAG 注册表 {job_code: dag_def}
        """
        self.scheduler = scheduler
        self.task_repo = task_repo
        self.job_repo = job_repo
        self.node_repo = node_repo
        self.log_repo = log_repo
        self.dag_registry = dag_registry or {}
    
    def recover_all(self) -> List[Dict[str, Any]]:
        """
        恢复所有可恢复任务
        
        Returns:
            恢复结果列表
        """
        recovered = []
        
        # 1. 扫描可恢复任务
        task_runs = self._list_recoverable_task_runs()
        
        for task_row in task_runs:
            task_run_id = task_row['id']
            
            # 2. 获取关联的 Job
            jobs = self._list_running_jobs(task_run_id)
            
            for job_row in jobs:
                job_run_id = job_row['id']
                job_code = job_row.get('job_code', 'unknown')
                
                # 3. 检查 DAG 是否存在
                if job_code not in self.dag_registry:
                    self._log_recovery_error(
                        task_run_id, job_run_id,
                        f"DAG not found for job_code={job_code}",
                        'DAG_NOT_FOUND'
                    )
                    continue
                
                # 4. 获取 runtime_context
                runtime_context = task_row.get('context')
                if not runtime_context:
                    self._log_recovery_error(
                        task_run_id, job_run_id,
                        f"Task context missing",
                        'CONTEXT_MISSING'
                    )
                    continue
                
                # 5. 恢复执行
                try:
                    result = self._recover_job(
                        task_run_id, job_run_id, job_code, runtime_context
                    )
                    recovered.append({
                        'task_run_id': task_run_id,
                        'job_run_id': job_run_id,
                        'job_code': job_code,
                        'result': result
                    })
                except Exception as e:
                    self._log_recovery_error(
                        task_run_id, job_run_id,
                        f"Recovery failed: {str(e)}",
                        'RECOVERY_FAILED'
                    )
        
        return recovered
    
    def _list_recoverable_task_runs(self) -> List[Dict[str, Any]]:
        """
        列出可恢复的 TaskRuns
        
        Returns:
            TaskRun 列表
        """
        if self.task_repo:
            return self.task_repo.list_recoverable_task_runs()
        
        # 简化实现：返回空列表
        return []
    
    def _list_running_jobs(self, task_run_id: int) -> List[Dict[str, Any]]:
        """
        列出 Task 下 RUNNING 状态的 Jobs
        
        Args:
            task_run_id: Task Run ID
        
        Returns:
            Job 列表
        """
        if self.job_repo:
            return self.job_repo.list_running_jobs_by_task_run_id(task_run_id)
        
        # 简化实现：返回空列表
        return []
    
    def _recover_job(
        self,
        task_run_id: int,
        job_run_id: int,
        job_code: str,
        runtime_context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        恢复单个 Job
        
        Args:
            task_run_id: Task Run ID
            job_run_id: Job Run ID
            job_code: Job Code
            runtime_context: 运行时上下文
        
        Returns:
            恢复结果
        """
        # 1. 记录日志
        self._log_event(
            level='INFO',
            event_type='RECOVERY_STARTED',
            message=f"Start recovery for task_run_id={task_run_id}, job_run_id={job_run_id}",
            task_run_id=task_run_id,
            job_run_id=job_run_id,
            detail={'job_code': job_code}
        )
        
        # 2. 准备 runtime_context
        runtime_context.setdefault('task', {})
        runtime_context.setdefault('job', {})
        runtime_context.setdefault('node', {})
        
        runtime_context['task']['id'] = task_run_id
        runtime_context['job']['id'] = job_run_id
        
        # 3. 重置 RUNNING 节点
        interrupted_count = self._reset_interrupted_nodes(job_run_id)
        
        if interrupted_count > 0:
            self._log_event(
                level='WARN',
                event_type='RECOVERY_RESET_RUNNING_NODES',
                message=f"Reset interrupted RUNNING nodes to PENDING, count={interrupted_count}",
                task_run_id=task_run_id,
                job_run_id=job_run_id,
                detail={'count': interrupted_count}
            )
        
        # 4. 恢复执行
        dag_def = self.dag_registry[job_code]
        result = self.scheduler.run(
            dag_def=dag_def,
            runtime_context=runtime_context,
            resume=True
        )
        
        # 5. 记录日志
        self._log_event(
            level='INFO',
            event_type='RECOVERY_COMPLETED',
            message=f"Recovery completed for job_run_id={job_run_id}",
            task_run_id=task_run_id,
            job_run_id=job_run_id,
            detail={'job_status': result.get('state', {}).get('job_status')}
        )
        
        return result
    
    def _reset_interrupted_nodes(self, job_run_id: int) -> int:
        """
        重置中断的 RUNNING 节点
        
        Args:
            job_run_id: Job Run ID
        
        Returns:
            重置的节点数量
        """
        if self.node_repo:
            return self.node_repo.reset_interrupted_running_nodes(job_run_id)
        
        # 简化实现
        return 0
    
    def _log_recovery_error(
        self,
        task_run_id: int,
        job_run_id: int,
        message: str,
        error_type: str
    ) -> None:
        """
        记录恢复错误日志
        
        Args:
            task_run_id: Task Run ID
            job_run_id: Job Run ID
            message: 错误消息
            error_type: 错误类型
        """
        self._log_event(
            level='ERROR',
            event_type=f'RECOVERY_{error_type}',
            message=message,
            task_run_id=task_run_id,
            job_run_id=job_run_id
        )
    
    def _log_event(
        self,
        level: str,
        event_type: str,
        message: str,
        task_run_id: int = None,
        job_run_id: int = None,
        detail: Dict[str, Any] = None
    ) -> None:
        """记录事件日志"""
        if self.log_repo:
            self.log_repo.log(level, event_type, message, detail, task_run_id, job_run_id)
        else:
            # 控制台输出
            print(f"[{level}] {event_type}: {message}")
