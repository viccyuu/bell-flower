# -*- coding: utf-8 -*-
"""
DAG Scheduler - DAG 调度器 ⭐

核心调度逻辑，负责：
- DAG 验证
- 节点调度
- 状态管理
- 重试/跳过逻辑
"""
import copy
import time
from typing import Any, Dict, List, Optional
from app.scheduler.models import NodeExecutionRequest, NodeExecutionResult, ExecutionContext
from app.scheduler.executors.registry import ExecutorRegistry
from app.scheduler.resolver.input_resolver import InputResolver
from app.scheduler.utils.retry import merge_retry_policy, should_retry
from app.scheduler.exceptions import DAGValidationError, NodeExecutionError, SchedulerError


class DagScheduler:
    """
    DAG 调度器 ⭐
    
    核心调度逻辑，支持：
    - DAG 验证（无环、节点存在）
    - 节点调度（拓扑排序）
    - 条件边判断
    - 重试/跳过逻辑
    - 状态持久化
    """
    
    TERMINAL_STATUSES = {'SUCCESS', 'FAILED', 'SKIPPED'}
    """终止状态集合"""
    
    def __init__(
        self,
        executor_registry: ExecutorRegistry,
        input_resolver: InputResolver = None,
        task_repo = None,
        job_repo = None,
        node_repo = None,
        log_repo = None
    ):
        """
        初始化 DAG 调度器
        
        Args:
            executor_registry: 执行器注册表
            input_resolver: 输入解析器
            task_repo: TaskRunRepository (可选)
            job_repo: JobRunRepository (可选)
            node_repo: NodeRunRepository (可选)
            log_repo: ExecutionLogRepository (可选)
        """
        self.executor_registry = executor_registry
        self.input_resolver = input_resolver or InputResolver()
        self.task_repo = task_repo
        self.job_repo = job_repo
        self.node_repo = node_repo
        self.log_repo = log_repo
    
    def run(
        self,
        dag_def: Dict[str, Any],
        runtime_context: Dict[str, Any],
        resume: bool = False
    ) -> Dict[str, Any]:
        """
        运行 DAG
        
        Args:
            dag_def: DAG 定义 {job, nodes, edges, defaults}
            runtime_context: 运行时上下文 {task, job, node}
            resume: 是否恢复模式
        
        Returns:
            {state, context}
        
        Raises:
            DAGValidationError: DAG 验证失败
            SchedulerError: 调度错误
        """
        # 1. 深度复制 DAG，避免修改原数据
        dag = copy.deepcopy(dag_def)
        
        # 2. 应用默认值
        self._apply_defaults(dag)
        
        # 3. 解析节点和边
        nodes = {node['code']: node for node in dag.get('nodes', [])}
        edges = dag.get('edges', [])
        
        # 4. 获取运行时信息
        task_run_id = runtime_context.get('task', {}).get('id')
        job_run_id = runtime_context.get('job', {}).get('id')
        job_code = dag.get('job', {}).get('code', 'unknown')
        
        # 5. 验证 DAG
        self._validate_dag(nodes, edges)
        
        # 6. 初始化状态
        if not resume:
            state = self._build_fresh_state(nodes, task_run_id, job_run_id)
            self._persist_initial_state(task_run_id, job_run_id, runtime_context)
        else:
            state = self._build_resume_state(nodes, runtime_context)
            self._persist_resume_state(task_run_id, job_run_id, runtime_context)
        
        # 7. 记录日志
        self._log_event(
            level='INFO',
            event_type='JOB_STARTED' if not resume else 'JOB_RESUMED',
            message=f"Job {'started' if not resume else 'resumed'}: {job_code}",
            task_run_id=task_run_id,
            job_run_id=job_run_id,
            detail={'job_code': job_code, 'resume': resume}
        )
        
        # 8. 执行循环
        try:
            while True:
                # 8.1 标记跳过节点
                self._mark_skipped_nodes(nodes, edges, state, runtime_context)
                
                # 8.2 获取就绪节点
                ready_nodes = self._get_ready_nodes(nodes, edges, state, runtime_context)
                if not ready_nodes:
                    break
                
                # 8.3 执行节点
                for node_code in ready_nodes:
                    self._execute_single_node(
                        node_def=nodes[node_code],
                        dag_def=dag,
                        runtime_context=runtime_context,
                        state=state
                    )
                    self._persist_task_state(task_run_id, runtime_context)
            
            # 9. 确定 Job 状态
            job_status = self._determine_job_status(state)
            state['job_status'] = job_status
            
            # 10. 持久化最终状态
            self._persist_final_state(task_run_id, job_run_id, job_status, runtime_context)
            
            # 11. 记录日志
            self._log_event(
                level='INFO',
                event_type='JOB_FINISHED',
                message=f"Job finished: {job_code}",
                task_run_id=task_run_id,
                job_run_id=job_run_id,
                detail={'job_status': job_status}
            )
            
            return {'state': state, 'context': runtime_context}
        
        except Exception as e:
            # 12. 处理异常
            self._persist_final_state(task_run_id, job_run_id, 'FAILED', runtime_context)
            self._log_event(
                level='ERROR',
                event_type='JOB_FAILED',
                message=str(e),
                task_run_id=task_run_id,
                job_run_id=job_run_id,
                detail={'traceback': str(e)}
            )
            raise
    
    def _apply_defaults(self, dag: Dict[str, Any]) -> None:
        """
        应用默认值
        
        Args:
            dag: DAG 定义
        """
        defaults = dag.get('defaults', {})
        for node in dag.get('nodes', []):
            if 'continue_on_error' not in node:
                node['continue_on_error'] = defaults.get('continue_on_error', False)
            if 'timeout_seconds' not in node:
                node['timeout_seconds'] = defaults.get('timeout_seconds', 60)
            if 'retry_policy' not in node:
                node['retry_policy'] = defaults.get('retry_policy', {})
    
    def _validate_dag(self, nodes: Dict[str, dict], edges: List[Dict[str, Any]]) -> None:
        """
        验证 DAG
        
        Args:
            nodes: 节点字典
            edges: 边列表
        
        Raises:
            DAGValidationError: 验证失败
        """
        # 1. 检查边引用的节点是否存在
        for edge in edges:
            from_node = edge.get('from')
            to_node = edge.get('to')
            
            if from_node not in nodes:
                raise DAGValidationError(f"Edge from unknown node: {from_node}", error_type='UNKNOWN_FROM_NODE')
            if to_node not in nodes:
                raise DAGValidationError(f"Edge to unknown node: {to_node}", error_type='UNKNOWN_TO_NODE')
        
        # 2. 检查环
        if self._has_cycle(nodes, edges):
            raise DAGValidationError("DAG contains cycle", error_type='CYCLE_DETECTED')
    
    def _has_cycle(self, nodes: Dict[str, dict], edges: List[Dict[str, Any]]) -> bool:
        """
        检查 DAG 是否有环
        
        Args:
            nodes: 节点字典
            edges: 边列表
        
        Returns:
            是否有环
        """
        # 拓扑排序检测环
        indegree = {k: 0 for k in nodes}
        graph = {k: [] for k in nodes}
        
        for edge in edges:
            graph[edge['from']].append(edge['to'])
            indegree[edge['to']] += 1
        
        queue = [n for n, d in indegree.items() if d == 0]
        visited = 0
        
        while queue:
            node = queue.pop(0)
            visited += 1
            for neighbor in graph[node]:
                indegree[neighbor] -= 1
                if indegree[neighbor] == 0:
                    queue.append(neighbor)
        
        return visited != len(nodes)
    
    def _build_fresh_state(
        self,
        nodes: Dict[str, dict],
        task_run_id: int,
        job_run_id: int
    ) -> Dict[str, Any]:
        """
        构建全新状态
        
        Args:
            nodes: 节点字典
            task_run_id: Task Run ID
            job_run_id: Job Run ID
        
        Returns:
            状态字典
        """
        state = {
            'job_status': 'RUNNING',
            'nodes': {}
        }
        
        for node_code, node_def in nodes.items():
            state['nodes'][node_code] = {
                'node_run_id': f"{job_run_id}_{node_code}",  # 简化实现
                'status': 'PENDING',
                'attempt_count': 0,
                'retry_history': []
            }
        
        return state
    
    def _build_resume_state(
        self,
        nodes: Dict[str, dict],
        runtime_context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        构建恢复状态
        
        Args:
            nodes: 节点字典
            runtime_context: 运行时上下文
        
        Returns:
            状态字典
        """
        state = {
            'job_status': 'RUNNING',
            'nodes': {}
        }
        
        # 从 runtime_context 恢复节点状态
        persisted_nodes = runtime_context.get('node', {})
        
        for node_code, node_def in nodes.items():
            persisted = persisted_nodes.get(node_code, {})
            status = persisted.get('status', 'PENDING')
            
            # RUNNING 节点重置为 PENDING
            if status == 'RUNNING':
                status = 'PENDING'
            
            state['nodes'][node_code] = {
                'node_run_id': f"resumed_{node_code}",
                'status': status,
                'attempt_count': 0,
                'retry_history': []
            }
            
            # 恢复 SUCCESS/FAILED/SKIPPED 节点到 runtime_context
            if status in ('SUCCESS', 'FAILED', 'SKIPPED'):
                runtime_context.setdefault('node', {})
                runtime_context['node'][node_code] = persisted
        
        return state
    
    def _edge_condition_passed(self, edge: Dict[str, Any], runtime_context: Dict[str, Any]) -> bool:
        """
        判断边条件是否通过
        
        Args:
            edge: 边定义
            runtime_context: 运行时上下文
        
        Returns:
            是否通过
        """
        condition_expr = edge.get('condition_expr')
        if not condition_expr:
            return True
        
        try:
            result = self.input_resolver._eval_expr(condition_expr, runtime_context)
            return bool(result)
        except Exception as e:
            # 记录错误但返回 True 以避免阻塞
            import logging
            logging.warning(f"Condition expr evaluation failed: {condition_expr}, error: {e}")
            return True
    
    def _get_ready_nodes(
        self,
        nodes: Dict[str, dict],
        edges: List[Dict[str, Any]],
        state: Dict[str, Any],
        runtime_context: Dict[str, Any]
    ) -> List[str]:
        """
        获取就绪节点
        
        Args:
            nodes: 节点字典
            edges: 边列表
            state: 状态
            runtime_context: 运行时上下文
        
        Returns:
            就绪节点列表
        """
        ready = []
        
        for node_code in nodes:
            # 1. 跳过非 PENDING 节点
            if state['nodes'][node_code]['status'] != 'PENDING':
                continue
            
            # 2. 获取入边
            incoming = [e for e in edges if e['to'] == node_code]
            if not incoming:
                # 无入边，直接就绪
                ready.append(node_code)
                continue
            
            # 3. 检查前置节点
            parents_terminal = True
            active_parent_found = False
            
            for edge in incoming:
                parent_code = edge['from']
                parent_status = state['nodes'][parent_code]['status']
                
                # 前置节点未终止
                if parent_status not in self.TERMINAL_STATUSES:
                    parents_terminal = False
                    break
                
                # 检查条件边
                if parent_status == 'SUCCESS' and self._edge_condition_passed(edge, runtime_context):
                    active_parent_found = True
            
            # 所有前置终止且有激活的前置
            if parents_terminal and active_parent_found:
                ready.append(node_code)
        
        return ready
    
    def _mark_skipped_nodes(
        self,
        nodes: Dict[str, dict],
        edges: List[Dict[str, Any]],
        state: Dict[str, Any],
        runtime_context: Dict[str, Any]
    ) -> None:
        """
        标记跳过节点
        
        Args:
            nodes: 节点字典
            edges: 边列表
            state: 状态
            runtime_context: 运行时上下文
        """
        changed = True
        while changed:
            changed = False
            
            for node_code in nodes:
                if state['nodes'][node_code]['status'] != 'PENDING':
                    continue
                
                incoming = [e for e in edges if e['to'] == node_code]
                if not incoming:
                    continue
                
                # 检查所有前置是否终止
                all_parents_terminal = True
                any_activating_edge = False
                
                for edge in incoming:
                    parent_code = edge['from']
                    parent_status = state['nodes'][parent_code]['status']
                    
                    if parent_status not in self.TERMINAL_STATUSES:
                        all_parents_terminal = False
                        break
                    
                    if parent_status == 'SUCCESS' and self._edge_condition_passed(edge, runtime_context):
                        any_activating_edge = True
                
                # 所有前置终止但无激活边，跳过
                if all_parents_terminal and not any_activating_edge:
                    state['nodes'][node_code]['status'] = 'SKIPPED'
                    
                    runtime_context.setdefault('node', {})
                    runtime_context['node'][node_code] = {
                        'status': 'SKIPPED',
                        'output': None,
                        'error': {
                            'code': 'NODE_SKIPPED',
                            'message': 'No activating incoming edge'
                        }
                    }
                    
                    self._log_event(
                        level='INFO',
                        event_type='NODE_SKIPPED',
                        message=f"Node skipped: {node_code}",
                        detail={'reason': 'no_activating_edge'}
                    )
                    
                    changed = True
    
    def _execute_single_node(
        self,
        node_def: Dict[str, Any],
        dag_def: Dict[str, Any],
        runtime_context: Dict[str, Any],
        state: Dict[str, Any]
    ) -> None:
        """
        执行单个节点
        
        Args:
            node_def: 节点定义
            dag_def: DAG 定义
            runtime_context: 运行时上下文
            state: 状态
        
        Raises:
            NodeExecutionError: 节点执行失败
        """
        node_code = node_def['code']
        node_state = state['nodes'][node_code]
        node_run_id = node_state['node_run_id']
        
        # 1. 获取执行器
        executor_name = node_def.get('executor', 'python_executor')
        executor = self.executor_registry.get(executor_name)
        
        # 2. 合并重试策略
        retry_policy = merge_retry_policy(
            dag_def.get('defaults', {}).get('retry_policy'),
            node_def.get('retry_policy')
        )
        
        # 3. 执行循环
        attempt_index = 0
        final_result = None
        
        while True:
            attempt_index += 1
            node_state['attempt_count'] += 1
            node_state['status'] = 'RUNNING'
            
            # 4. 构建执行请求
            request = NodeExecutionRequest(
                task_run_id=runtime_context.get('task', {}).get('id', 0),
                job_run_id=runtime_context.get('job', {}).get('id', 0),
                node_run_id=node_run_id,
                node_code=node_code,
                action_type=node_def.get('action_type', 'PYTHON'),
                executor=executor_name,
                config=node_def.get('config', {}),
                input_mapping=node_def.get('input_mapping', {}),
                output_schema=node_def.get('output_schema'),
                timeout_seconds=node_def.get('timeout_seconds', 60),
                context=runtime_context
            )
            
            # 5. 记录日志
            self._log_event(
                level='INFO',
                event_type='NODE_ATTEMPT_STARTED',
                message=f"Node attempt started: {node_code}",
                detail={
                    'attempt': attempt_index,
                    'timeout_seconds': request.timeout_seconds
                }
            )
            
            # 6. 执行
            result = executor.execute(request)
            final_result = result
            
            # 7. 处理结果
            if result.success:
                # 成功
                node_state['status'] = 'SUCCESS'
                runtime_context.setdefault('node', {})
                runtime_context['node'][node_code] = {
                    'status': 'SUCCESS',
                    'output': result.output
                }
                
                self._log_event(
                    level='INFO',
                    event_type='NODE_SUCCEEDED',
                    message=f"Node succeeded: {node_code}",
                    detail={'attempt': attempt_index, 'output': result.output}
                )
                return
            
            # 失败记录
            node_state['retry_history'].append({
                'attempt': attempt_index,
                'error_code': result.error_code,
                'error_message': result.error_message
            })
            
            self._log_event(
                level='WARN',
                event_type='NODE_ATTEMPT_FAILED',
                message=f"Node attempt failed: {node_code}",
                detail={
                    'attempt': attempt_index,
                    'error_code': result.error_code
                }
            )
            
            # 8. 检查重试
            if should_retry(result, retry_policy, attempt_index):
                backoff_seconds = retry_policy.get('backoff_seconds', 0)
                self._log_event(
                    level='INFO',
                    event_type='NODE_RETRY_SCHEDULED',
                    message=f"Retry scheduled for node: {node_code}",
                    detail={
                        'attempt': attempt_index,
                        'next_attempt': attempt_index + 1,
                        'backoff_seconds': backoff_seconds
                    }
                )
                if backoff_seconds > 0:
                    time.sleep(backoff_seconds)
                continue
            
            break
        
        # 9. 最终失败
        error_data = {
            'code': final_result.error_code if final_result else 'UNKNOWN',
            'message': final_result.error_message if final_result else 'Unknown error'
        }
        
        runtime_context.setdefault('node', {})
        runtime_context['node'][node_code] = {
            'status': 'FAILED',
            'output': None,
            'error': error_data
        }
        node_state['status'] = 'FAILED'
        
        self._log_event(
            level='ERROR',
            event_type='NODE_FAILED',
            message=f"Node failed: {node_code}",
            detail={
                'attempts': attempt_index,
                'error': error_data
            }
        )
        
        # 10. 检查 continue_on_error
        if node_def.get('continue_on_error', False):
            return
        
        # 抛出异常，终止 Job
        raise NodeExecutionError(
            f"Node {node_code} failed after {attempt_index} attempt(s): {error_data['message']}",
            node_code=node_code,
            attempt_count=attempt_index
        )
    
    def _determine_job_status(self, state: Dict[str, Any]) -> str:
        """
        确定 Job 状态
        
        Args:
            state: 状态
        
        Returns:
            Job 状态
        """
        failed_nodes = [n for n, s in state['nodes'].items() if s['status'] == 'FAILED']
        pending_nodes = [n for n, s in state['nodes'].items() if s['status'] == 'PENDING']
        running_nodes = [n for n, s in state['nodes'].items() if s['status'] == 'RUNNING']
        
        if failed_nodes:
            return 'FAILED'
        elif pending_nodes or running_nodes:
            return 'PARTIAL_OR_BLOCKED'
        else:
            return 'SUCCESS'
    
    def _persist_initial_state(self, task_run_id: int, job_run_id: int, context: Dict[str, Any]) -> None:
        """持久化初始状态"""
        if self.task_repo:
            self.task_repo.create(task_run_id, 'RUNNING', context)
        if self.job_repo:
            self.job_repo.create(job_run_id, task_run_id, 'unknown', 'RUNNING')
    
    def _persist_resume_state(self, task_run_id: int, job_run_id: int, context: Dict[str, Any]) -> None:
        """持久化恢复状态"""
        if self.task_repo:
            self.task_repo.update_status(task_run_id, 'RUNNING', context)
        if self.job_repo:
            self.job_repo.update_status(job_run_id, 'RUNNING')
    
    def _persist_task_state(self, task_run_id: int, context: Dict[str, Any]) -> None:
        """持久化任务状态"""
        if self.task_repo:
            self.task_repo.update_status(task_run_id, 'RUNNING', context)
    
    def _persist_final_state(self, task_run_id: int, job_run_id: int, status: str, context: Dict[str, Any]) -> None:
        """持久化最终状态"""
        if self.task_repo:
            self.task_repo.update_status(task_run_id, status, context)
        if self.job_repo:
            self.job_repo.update_status(job_run_id, status)
    
    def _log_event(
        self,
        level: str,
        event_type: str,
        message: str,
        task_run_id: int = None,
        job_run_id: int = None,
        detail: Dict[str, Any] = None
    ) -> None:
        """记录事件日志"""
        if self.log_repo:
            self.log_repo.log(level, event_type, message, detail, task_run_id, job_run_id)
        else:
            # 控制台输出
            print(f"[{level}] {event_type}: {message}")
