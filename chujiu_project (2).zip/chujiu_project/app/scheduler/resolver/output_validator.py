# -*- coding: utf-8 -*-
"""
Output Validator - 输出验证器 ⭐

支持 JSON Schema 验证:
{
    "type": "object",
    "required": ["field1", "field2"],
    "properties": {
        "field1": {"type": "string"},
        "field2": {"type": "integer"},
        "field3": {"type": "boolean"},
        "field4": {"type": "array"},
        "field5": {"type": "object"}
    }
}
"""
from typing import Any, Dict, List, Optional
from app.scheduler.exceptions import OutputValidationError


class OutputValidator:
    """输出验证器"""
    
    def validate(self, output: Dict[str, Any], schema: Optional[Dict[str, Any]]) -> None:
        """
        验证输出
        
        Args:
            output: 输出字典
            schema: JSON Schema
        
        Raises:
            OutputValidationError: 验证失败
        """
        if schema is None:
            return
        
        if schema.get('type') == 'object':
            if not isinstance(output, dict):
                raise OutputValidationError(
                    f"Output must be dict, got {type(output).__name__}"
                )
            
            # 检查 required 字段
            for field in schema.get('required', []):
                if field not in output:
                    raise OutputValidationError(f"Missing required field: {field}")
            
            # 检查字段类型
            for field, field_schema in schema.get('properties', {}).items():
                if field in output:
                    self._validate_type(field, output[field], field_schema)
    
    def _validate_type(self, field: str, value: Any, field_schema: Dict[str, Any]) -> None:
        """
        验证字段类型
        
        Args:
            field: 字段名
            value: 字段值
            field_schema: 字段 Schema
        
        Raises:
            OutputValidationError: 类型不匹配
        """
        expected_type = field_schema.get('type')
        if expected_type is None:
            return
        
        type_map = {
            'string': str,
            'boolean': bool,
            'integer': int,
            'number': (int, float),
            'object': dict,
            'array': list
        }
        
        py_type = type_map.get(expected_type)
        if py_type and not isinstance(value, py_type):
            raise OutputValidationError(
                f"Field '{field}' expected '{expected_type}', got '{type(value).__name__}'",
                field=field,
                expected_type=expected_type
            )
        
        # 嵌套验证 (object/array)
        if expected_type == 'object' and isinstance(value, dict):
            nested_schema = field_schema.get('properties')
            if nested_schema:
                nested_output = value
                for nested_field, nested_field_schema in nested_schema.items():
                    if nested_field in nested_output:
                        self._validate_type(nested_field, nested_output[nested_field], nested_field_schema)
        
        if expected_type == 'array' and isinstance(value, list):
            items_schema = field_schema.get('items')
            if items_schema:
                for idx, item in enumerate(value):
                    self._validate_type(f"{field}[{idx}]", item, items_schema)
