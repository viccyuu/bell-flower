# -*- coding: utf-8 -*-
"""
Input Resolver - 输入映射解析器 ⭐

支持多种表达式:
- {{ task.id }}
- {{ job.id }}
- {{ task.vars.xxx }}
- {{ job.vars.xxx }}
- {{ node.xxx.output.yyy }}
- {{ node.xxx.error.zzz }}
- {{ true/false/null }}
- {{ 'string' / "string" }}
- {{ 123 / 12.34 }}
- {{ left == right }}
- {{ left != right }}
"""
import re
from typing import Any, Dict, List, Optional, Union
from app.scheduler.exceptions import InputResolveError


class InputResolver:
    """输入映射解析器"""
    
    TEMPLATE_PATTERN = re.compile(r'^\{\{\s*(.*?)\s*\}\}$')
    """模板表达式正则：{{ expression }}"""
    
    def resolve(self, input_mapping: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        """
        解析输入映射
        
        Args:
            input_mapping: 输入映射字典
            context: 运行时上下文 {task, job, node}
        
        Returns:
            解析后的字典
        
        Raises:
            InputResolveError: 解析失败
        """
        if not input_mapping:
            return {}
        
        return {k: self._resolve_value(v, context) for k, v in input_mapping.items()}
    
    def _resolve_value(self, value: Any, context: Dict[str, Any]) -> Any:
        """
        递归解析值
        
        Args:
            value: 值 (dict/list/str/any)
            context: 运行时上下文
        
        Returns:
            解析后的值
        
        Raises:
            InputResolveError: 解析失败
        """
        if isinstance(value, dict):
            return {k: self._resolve_value(v, context) for k, v in value.items()}
        
        if isinstance(value, list):
            return [self._resolve_value(v, context) for v in value]
        
        if isinstance(value, str):
            match = self.TEMPLATE_PATTERN.match(value)
            if match:
                return self._eval_expr(match.group(1), context)
            return value
        
        return value
    
    def _eval_expr(self, expr: str, context: Dict[str, Any]) -> Any:
        """
        评估表达式
        
        Args:
            expr: 表达式字符串
            context: 运行时上下文
        
        Returns:
            评估结果
        
        Raises:
            InputResolveError: 评估失败
        """
        expr = expr.strip()
        
        # 字面量
        if expr == 'true':
            return True
        if expr == 'false':
            return False
        if expr == 'null':
            return None
        
        # 比较运算符
        if '==' in expr:
            left, right = expr.split('==', 1)
            return self._eval_expr(left.strip(), context) == self._parse_literal(right.strip())
        
        if '!=' in expr:
            left, right = expr.split('!=', 1)
            return self._eval_expr(left.strip(), context) != self._parse_literal(right.strip())
        
        # 内置变量
        if expr == 'task.id':
            return context.get('task', {}).get('id')
        
        if expr == 'job.id':
            return context.get('job', {}).get('id')
        
        # task.vars / job.vars
        if expr.startswith('task.vars.'):
            return self._get_by_path(context.get('task', {}).get('vars', {}), expr[len('task.vars.'):])
        
        if expr.startswith('job.vars.'):
            return self._get_by_path(context.get('job', {}).get('vars', {}), expr[len('job.vars.'):])
        
        # node.xxx.output.yyy / node.xxx.error.zzz
        if expr.startswith('node.'):
            parts = expr.split('.')
            if len(parts) < 4:
                raise InputResolveError(f"Invalid node expression: {expr}", expression=expr)
            
            node_code = parts[1]
            section = parts[2]  # output / error
            path = '.'.join(parts[3:])
            
            node_data = context.get('node', {}).get(node_code)
            if node_data is None:
                raise InputResolveError(f"Node not found in context: {node_code}", expression=expr)
            
            base = node_data.get(section)
            return self._get_by_path(base, path)
        
        # 字面量
        return self._parse_literal(expr)
    
    def _parse_literal(self, value: str) -> Any:
        """
        解析字面量
        
        Args:
            value: 字符串值
        
        Returns:
            解析后的值
        """
        value = value.strip()
        
        # 布尔值和 null
        if value in ('true', 'false', 'null'):
            return {'true': True, 'false': False, 'null': None}[value]
        
        # 字符串
        if (value.startswith("'") and value.endswith("'")) or \
           (value.startswith('"') and value.endswith('"')):
            return value[1:-1]
        
        # 整数
        try:
            return int(value)
        except ValueError:
            pass
        
        # 浮点数
        try:
            return float(value)
        except ValueError:
            pass
        
        # 返回原值
        return value
    
    def _get_by_path(self, obj: Any, path: str) -> Any:
        """
        通过路径获取嵌套值
        
        Args:
            obj: 对象 (dict)
            path: 路径字符串 (如 "a.b.c")
        
        Returns:
            嵌套值
        
        Raises:
            InputResolveError: 路径不存在
        """
        if not path:
            return obj
        
        if obj is None:
            raise InputResolveError(f"Cannot access path '{path}' on None")
        
        current = obj
        for part in path.split('.'):
            if current is None:
                raise InputResolveError(f"Path '{path}': current is None at '{part}'")
            
            if isinstance(current, dict):
                if part not in current:
                    raise InputResolveError(f"Key '{part}' not found in path '{path}'")
                current = current[part]
            else:
                raise InputResolveError(f"Cannot access '{part}' on non-dict (type={type(current).__name__})")
        
        return current
