# -*- coding: utf-8 -*-
"""
Python Executor - Python 节点执行器 ⭐

执行 Python callable 函数，支持超时控制和输出验证。
"""
import importlib
import inspect
from typing import Any, Dict
from app.scheduler.executors.base_executor import BaseExecutor, TimeoutRunner
from app.scheduler.models import NodeExecutionRequest, NodeExecutionResult
from app.scheduler.resolver.input_resolver import InputResolver
from app.scheduler.resolver.output_validator import OutputValidator


class PythonExecutor(BaseExecutor):
    """
    Python 节点执行器 ⭐
    
    执行 Python callable 函数，支持：
    - 动态导入 callable
    - 输入映射解析
    - 签名验证
    - 超时控制
    - 输出 Schema 验证
    """
    
    def __init__(self, input_resolver: InputResolver = None, output_validator: OutputValidator = None):
        """
        初始化 Python 执行器
        
        Args:
            input_resolver: 输入解析器
            output_validator: 输出验证器
        """
        self.input_resolver = input_resolver or InputResolver()
        self.output_validator = output_validator or OutputValidator()
        self.timeout_runner = TimeoutRunner()
    
    def execute(self, request: NodeExecutionRequest) -> NodeExecutionResult:
        """
        执行 Python 节点
        
        Args:
            request: 执行请求
        
        Returns:
            执行结果
        """
        try:
            # 1. 解析输入
            kwargs = self.input_resolver.resolve(request.input_mapping, request.context)
            
            # 2. 加载 callable
            callable_path = request.config.get('callable', '')
            if not callable_path:
                return NodeExecutionResult.error_result(
                    error_code='CONFIG_ERROR',
                    error_message='Missing callable in config'
                )
            
            func = self._load_callable(callable_path)
            
            # 3. 验证签名
            self._validate_signature(func, kwargs)
            
            # 4. 执行 (带超时)
            def _call():
                return func(**kwargs)
            
            raw_output = self.timeout_runner.run_with_timeout(_call, request.timeout_seconds)
            
            # 5. 规范化输出
            output = self._normalize_output(raw_output)
            
            # 6. 验证输出
            self.output_validator.validate(output, request.output_schema)
            
            # 7. 返回成功结果
            return NodeExecutionResult.success_result(
                output=output,
                metrics={
                    'timeout_seconds': request.timeout_seconds,
                    'callable': callable_path
                }
            )
        
        except Exception as e:
            # 获取错误代码
            error_code = getattr(e, 'error_code', type(e).__name__)
            
            return NodeExecutionResult.error_result(
                error_code=error_code,
                error_message=str(e),
                metrics={
                    'timeout_seconds': request.timeout_seconds,
                    'callable': request.config.get('callable', '')
                }
            )
    
    def _load_callable(self, dotted_path: str):
        """
        加载可调用对象
        
        Args:
            dotted_path: 点分路径 (如 "app.plugins.excel_vba_to_wps_js.validate_upload")
        
        Returns:
            可调用对象
        
        Raises:
            ImportError: 模块导入失败
            AttributeError: 属性不存在
        """
        try:
            module_path, func_name = dotted_path.rsplit('.', 1)
            module = importlib.import_module(module_path)
            return getattr(module, func_name)
        except ValueError:
            raise ImportError(f"Invalid callable path: {dotted_path}")
    
    def _validate_signature(self, func, kwargs: Dict[str, Any]) -> None:
        """
        验证函数签名
        
        Args:
            func: 可调用对象
            kwargs: 关键字参数
        
        Raises:
            TypeError: 签名不匹配
        """
        try:
            inspect.signature(func).bind(**kwargs)
        except TypeError as e:
            raise TypeError(f"Signature mismatch for {func.__name__}: {str(e)}")
    
    def _normalize_output(self, raw_output: Any) -> Dict[str, Any]:
        """
        规范化输出为 dict
        
        Args:
            raw_output: 原始输出
        
        Returns:
            规范化后的 dict
        """
        if raw_output is None:
            return {}
        if isinstance(raw_output, dict):
            return raw_output
        return {'result': raw_output}
