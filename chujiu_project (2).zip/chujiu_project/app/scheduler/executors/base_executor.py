# -*- coding: utf-8 -*-
"""
Base Executor - 执行器基类 ⭐

所有执行器的抽象基类，定义统一接口。
"""
from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError
from typing import Any
from app.scheduler.models import NodeExecutionRequest, NodeExecutionResult
from app.scheduler.exceptions import TimeoutExecutionError


class BaseExecutor(ABC):
    """
    执行器抽象基类 ⭐
    
    所有执行器必须实现此接口。
    """
    
    @abstractmethod
    def execute(self, request: NodeExecutionRequest) -> NodeExecutionResult:
        """
        执行节点
        
        Args:
            request: 执行请求
        
        Returns:
            执行结果
        
        Raises:
            Exception: 执行失败
        """
        raise NotImplementedError


class TimeoutRunner:
    """
    超时执行器 ⭐
    
    使用 ThreadPoolExecutor 实现超时控制。
    """
    
    def run_with_timeout(self, func, timeout_seconds: int, *args, **kwargs) -> Any:
        """
        在超时限制内执行函数
        
        Args:
            func: 要执行的函数
            timeout_seconds: 超时时间 (秒)
            *args: 函数参数
            **kwargs: 函数关键字参数
        
        Returns:
            函数返回值
        
        Raises:
            TimeoutExecutionError: 执行超时
        """
        with ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(func, *args, **kwargs)
            try:
                return future.result(timeout=timeout_seconds)
            except FuturesTimeoutError:
                raise TimeoutExecutionError(
                    f"Execution exceeded timeout_seconds={timeout_seconds}",
                    timeout_seconds=timeout_seconds
                )
