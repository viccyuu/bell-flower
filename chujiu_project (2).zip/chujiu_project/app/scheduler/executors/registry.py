# -*- coding: utf-8 -*-
"""
Executor Registry - 执行器注册表 ⭐

统一管理所有执行器的注册和获取。
"""
from typing import Dict, Type
from app.scheduler.executors.base_executor import BaseExecutor
from app.scheduler.exceptions import ExecutorNotFoundError


class ExecutorRegistry:
    """
    执行器注册表 ⭐
    
    单例模式，统一管理所有执行器。
    """
    
    _instance = None
    _executors: Dict[str, BaseExecutor] = {}
    
    def __new__(cls):
        """单例模式"""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def register(self, name: str, executor: BaseExecutor) -> None:
        """
        注册执行器
        
        Args:
            name: 执行器名称 (如 "python_executor")
            executor: 执行器实例
        
        Raises:
            ValueError: 名称已存在
        """
        if name in self._executors:
            raise ValueError(f"Executor already registered: {name}")
        self._executors[name] = executor
    
    def get(self, name: str) -> BaseExecutor:
        """
        获取执行器
        
        Args:
            name: 执行器名称
        
        Returns:
            执行器实例
        
        Raises:
            ExecutorNotFoundError: 执行器不存在
        """
        if name not in self._executors:
            raise ExecutorNotFoundError(name)
        return self._executors[name]
    
    def unregister(self, name: str) -> None:
        """
        注销执行器
        
        Args:
            name: 执行器名称
        """
        if name in self._executors:
            del self._executors[name]
    
    def list_executors(self) -> list:
        """
        列出所有已注册的执行器
        
        Returns:
            执行器名称列表
        """
        return list(self._executors.keys())
    
    def clear(self) -> None:
        """清空所有注册"""
        self._executors.clear()
