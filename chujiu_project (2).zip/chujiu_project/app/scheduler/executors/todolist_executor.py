# -*- coding: utf-8 -*-
"""
Todolist Executor - Todolist 执行器 ⭐

调用现有的 Todolist 17 环节引擎，实现集成。
"""
import json
from pathlib import Path
from typing import Any, Dict
from app.scheduler.executors.base_executor import BaseExecutor, TimeoutRunner
from app.scheduler.models import NodeExecutionRequest, NodeExecutionResult
from app.scheduler.resolver.input_resolver import InputResolver
from app.scheduler.resolver.output_validator import OutputValidator


class TodolistExecutor(BaseExecutor):
    """
    Todolist 节点执行器 ⭐
    
    调用现有的 Todolist 17 环节引擎，支持：
    - 输入映射解析
    - 调用 17 环节
    - 超时控制
    - 输出验证
    """
    
    def __init__(
        self,
        input_resolver: InputResolver = None,
        output_validator: OutputValidator = None,
        config_path: Path = None
    ):
        """
        初始化 Todolist 执行器
        
        Args:
            input_resolver: 输入解析器
            output_validator: 输出验证器
            config_path: LLM 配置文件路径
        """
        self.input_resolver = input_resolver or InputResolver()
        self.output_validator = output_validator or OutputValidator()
        self.timeout_runner = TimeoutRunner()
        self.config_path = config_path
    
    def execute(self, request: NodeExecutionRequest) -> NodeExecutionResult:
        """
        执行 Todolist 节点
        
        Args:
            request: 执行请求
        
        Returns:
            执行结果
        """
        try:
            # 1. 解析输入
            inputs = self.input_resolver.resolve(request.input_mapping, request.context)
            
            # 2. 获取操作类型
            config = request.config
            operation = config.get('operation', 'vba_to_js')
            
            # 3. 执行操作 (带超时)
            def _call():
                if operation == 'vba_to_js':
                    return self._execute_vba_to_js(inputs, config)
                else:
                    raise ValueError(f"Unsupported todolist operation: {operation}")
            
            result = self.timeout_runner.run_with_timeout(_call, request.timeout_seconds)
            
            # 4. 验证输出
            self.output_validator.validate(result, request.output_schema)
            
            # 5. 返回成功结果
            return NodeExecutionResult.success_result(
                output=result,
                metrics={
                    'timeout_seconds': request.timeout_seconds,
                    'operation': operation
                }
            )
        
        except Exception as e:
            error_code = getattr(e, 'error_code', type(e).__name__)
            
            return NodeExecutionResult.error_result(
                error_code=error_code,
                error_message=str(e),
                metrics={
                    'timeout_seconds': request.timeout_seconds,
                    'operation': request.config.get('operation', '')
                }
            )
    
    def _execute_vba_to_js(self, inputs: Dict[str, Any], config: Dict[str, Any]) -> Dict[str, Any]:
        """
        执行 VBA 转 JS 17 环节
        
        Args:
            inputs: 输入数据
            config: 配置
        
        Returns:
            转换结果
        
        Raises:
            Exception: 执行失败
        """
        # 使用现有的 LLMExecutor 执行 17 环节
        # 这里简化实现，实际应该调用完整的 17 环节流程
        
        from app.todolist.llm_executor import LLMExecutor as TodoLLMExecutor
        
        try:
            config_path = self.config_path or Path('.chujiu/config.json')
            if not config_path.exists():
                config_path = Path(__file__).parent.parent.parent / '.chujiu' / 'config.json'
            
            llm_executor = TodoLLMExecutor(
                config_path=config_path,
                model='dashscope/glm-5',
                max_tokens=8192,
                temperature=0.1,
            )
            
            import asyncio
            
            # 简化实现：只执行 VBA 转 AST 和 AST 转 JS
            async def _execute():
                # 1. VBA 转 AST
                vba_code = inputs.get('vba_code', '')
                if vba_code:
                    result1 = await llm_executor.convert_vba_to_ast(
                        task_id=f'todolist_{id(self)}_1',
                        vba_code=vba_code,
                    )
                    if not result1.success:
                        raise Exception(f"VBA to AST failed: {result1.message}")
                    
                    vba_ast = result1.data.get('ast', {})
                    
                    # 2. AST 转 JS
                    result2 = await llm_executor.convert_ast_to_wps_js(
                        task_id=f'todolist_{id(self)}_2',
                        ast=vba_ast,
                    )
                    if not result2.success:
                        raise Exception(f"AST to JS failed: {result2.message}")
                    
                    js_code = result2.data.get('js_code', '')
                    
                    await llm_executor.close()
                    
                    return {
                        'vba_ast': vba_ast,
                        'js_code': js_code,
                        'success': True
                    }
                
                return {'success': False, 'error': 'No vba_code provided'}
            
            return asyncio.run(_execute())
        
        except Exception as e:
            raise Exception(f"Todolist execution failed: {str(e)}")
