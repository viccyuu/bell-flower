# -*- coding: utf-8 -*-
"""
LLM Executor - LLM 节点执行器 ⭐

调用 LLM API (DashScope/OpenAI 等)，支持超时控制和输出验证。
"""
import json
import re
from pathlib import Path
from typing import Any, Dict, Optional
from app.scheduler.executors.base_executor import BaseExecutor, TimeoutRunner
from app.scheduler.models import NodeExecutionRequest, NodeExecutionResult
from app.scheduler.resolver.input_resolver import InputResolver
from app.scheduler.resolver.output_validator import OutputValidator


class LLMExecutor(BaseExecutor):
    """
    LLM 节点执行器 ⭐
    
    调用 LLM API，支持：
    - 输入映射解析
    - Prompt 模板渲染
    - 超时控制
    - JSON 输出解析
    - 输出 Schema 验证
    """
    
    def __init__(
        self,
        input_resolver: InputResolver = None,
        output_validator: OutputValidator = None,
        config_path: Optional[Path] = None
    ):
        """
        初始化 LLM 执行器
        
        Args:
            input_resolver: 输入解析器
            output_validator: 输出验证器
            config_path: LLM 配置文件路径
        """
        self.input_resolver = input_resolver or InputResolver()
        self.output_validator = output_validator or OutputValidator()
        self.timeout_runner = TimeoutRunner()
        self.config_path = config_path
        self._llm_client = None
    
    def execute(self, request: NodeExecutionRequest) -> NodeExecutionResult:
        """
        执行 LLM 节点
        
        Args:
            request: 执行请求
        
        Returns:
            执行结果
        """
        try:
            # 1. 解析输入
            inputs = self.input_resolver.resolve(request.input_mapping, request.context)
            
            # 2. 构建 Prompt
            config = request.config
            system_prompt = config.get('system_prompt_template', '')
            user_prompt = self._render_user_prompt(system_prompt, inputs)
            
            # 3. 获取 LLM 配置
            model = config.get('model', 'dashscope/glm-5')
            
            # 4. 执行 LLM 调用 (带超时)
            def _call():
                return self._call_llm(model, system_prompt, user_prompt, request.output_schema)
            
            output = self.timeout_runner.run_with_timeout(_call, request.timeout_seconds)
            
            # 5. 验证输出
            self.output_validator.validate(output, request.output_schema)
            
            # 6. 返回成功结果
            return NodeExecutionResult.success_result(
                output=output,
                metrics={
                    'timeout_seconds': request.timeout_seconds,
                    'model': model
                }
            )
        
        except Exception as e:
            error_code = getattr(e, 'error_code', type(e).__name__)
            
            return NodeExecutionResult.error_result(
                error_code=error_code,
                error_message=str(e),
                metrics={
                    'timeout_seconds': request.timeout_seconds,
                    'model': request.config.get('model', '')
                }
            )
    
    def _render_user_prompt(self, system_prompt: str, inputs: Dict[str, Any]) -> str:
        """
        渲染用户 Prompt
        
        Args:
            system_prompt: 系统 Prompt
            inputs: 输入数据
        
        Returns:
            渲染后的用户 Prompt
        """
        # 简单实现：将 inputs 转为 JSON 作为用户 Prompt
        return f"请处理以下输入：\n\n```json\n{json.dumps(inputs, ensure_ascii=False, indent=2)}\n```"
    
    def _call_llm(
        self,
        model: str,
        system_prompt: str,
        user_prompt: str,
        output_schema: Optional[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        调用 LLM API (直接调用 litellm)
        
        Args:
            model: 模型名称
            system_prompt: 系统 Prompt
            user_prompt: 用户 Prompt
            output_schema: 输出 Schema
        
        Returns:
            LLM 响应 (dict)
        
        Raises:
            Exception: LLM 调用失败
        """
        # 直接调用 litellm
        import litellm
        from litellm import completion
        
        try:
            # 加载配置
            config_path = self.config_path or Path('.chujiu/config.json')
            if not config_path.exists():
                config_path = Path(__file__).parent.parent.parent / '.chujiu' / 'config.json'
            
            config_data = {}
            if config_path.exists():
                import json
                with open(config_path, 'r', encoding='utf-8') as f:
                    config_data = json.load(f)
            
            # 获取 API Key
            api_key = config_data.get('providers', {}).get('dashscope', {}).get('apiKey', '')
            if not api_key:
                api_key = os.environ.get('DASHSCOPE_API_KEY', '')
            
            # 调用 LLM
            response = completion(
                model=model,
                messages=[
                    {'role': 'system', 'content': system_prompt},
                    {'role': 'user', 'content': user_prompt}
                ],
                api_key=api_key,
                max_tokens=8192,
                temperature=0.1,
            )
            
            import asyncio
            
            # 异步调用
            async def _call():
                result = await llm_executor.execute(
                    task_id=f'llm_{id(self)}',
                    system_prompt=system_prompt,
                    user_prompt=user_prompt,
                )
                await llm_executor.close()
                return result
            
            result = asyncio.run(_call())
            
            if not result.success:
                raise Exception(f"LLM execution failed: {result.message}")
            
            response = result.data.get('response', '')
            
            # 尝试解析 JSON
            if output_schema:
                json_match = re.search(r'\{[\s\S]*\}', response)
                if json_match:
                    try:
                        return json.loads(json_match.group())
                    except:
                        pass
                raise Exception("Failed to parse JSON response")
            
            # 非 JSON 响应
            return {'response': response}
        
        except Exception as e:
            raise Exception(f"LLM call failed: {str(e)}")
