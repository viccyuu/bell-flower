# -*- coding: utf-8 -*-
"""
File Executor - 文件节点执行器 ⭐

执行文件操作 (读写/发布 artifact)，支持超时控制。
"""
import os
from pathlib import Path
from typing import Any, Dict
from app.scheduler.executors.base_executor import BaseExecutor, TimeoutRunner
from app.scheduler.models import NodeExecutionRequest, NodeExecutionResult
from app.scheduler.resolver.input_resolver import InputResolver
from app.scheduler.resolver.output_validator import OutputValidator


class FileExecutor(BaseExecutor):
    """
    文件节点执行器 ⭐
    
    执行文件操作，支持：
    - 输入映射解析
    - 文件读写
    - Artifact 发布
    - 超时控制
    """
    
    def __init__(
        self,
        input_resolver: InputResolver = None,
        output_validator: OutputValidator = None,
        base_dir: str = None
    ):
        """
        初始化文件执行器
        
        Args:
            input_resolver: 输入解析器
            output_validator: 输出验证器
            base_dir: 基础目录
        """
        self.input_resolver = input_resolver or InputResolver()
        self.output_validator = output_validator or OutputValidator()
        self.timeout_runner = TimeoutRunner()
        self.base_dir = Path(base_dir) if base_dir else Path.cwd()
    
    def execute(self, request: NodeExecutionRequest) -> NodeExecutionResult:
        """
        执行文件节点
        
        Args:
            request: 执行请求
        
        Returns:
            执行结果
        """
        try:
            # 1. 解析输入
            inputs = self.input_resolver.resolve(request.input_mapping, request.context)
            
            # 2. 获取操作类型
            config = request.config
            operation = config.get('operation', '')
            
            # 3. 执行操作 (带超时)
            def _call():
                if operation == 'write_text_artifact':
                    return self._write_text_artifact(inputs, config, request.context)
                elif operation == 'read_learning_rules':
                    return self._read_learning_rules(inputs, config)
                elif operation == 'publish_artifact':
                    return self._publish_artifact(inputs, config)
                else:
                    raise ValueError(f"Unsupported file operation: {operation}")
            
            result = self.timeout_runner.run_with_timeout(_call, request.timeout_seconds)
            
            # 4. 验证输出
            self.output_validator.validate(result, request.output_schema)
            
            # 5. 返回成功结果
            return NodeExecutionResult.success_result(
                output=result,
                metrics={
                    'timeout_seconds': request.timeout_seconds,
                    'operation': operation
                }
            )
        
        except Exception as e:
            error_code = getattr(e, 'error_code', type(e).__name__)
            
            return NodeExecutionResult.error_result(
                error_code=error_code,
                error_message=str(e),
                metrics={
                    'timeout_seconds': request.timeout_seconds,
                    'operation': request.config.get('operation', '')
                }
            )
    
    def _write_text_artifact(
        self,
        inputs: Dict[str, Any],
        config: Dict[str, Any],
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        写入文本 artifact
        
        Args:
            inputs: 输入数据
            config: 配置
            context: 上下文
        
        Returns:
            artifact 信息
        """
        task_run_id = inputs.get('task_run_id')
        content = inputs.get('content', '')
        artifact_type = config.get('artifact_type', 'REPORT')
        file_name_template = config.get('file_name_template', 'artifact_{{ task.id }}.txt')
        
        # 渲染文件名
        file_name = file_name_template.replace('{{ task.id }}', str(task_run_id))
        
        # 创建目录
        task_dir = self.base_dir / 'artifacts' / str(task_run_id)
        task_dir.mkdir(parents=True, exist_ok=True)
        
        # 写入文件
        file_path = task_dir / file_name
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        # 返回 artifact 信息
        artifact_id = abs(hash(str(file_path))) % 1000000
        return {
            'artifact_id': artifact_id,
            'file_path': str(file_path),
            'download_url': f'/api/artifacts/{artifact_id}/download',
            'artifact_type': artifact_type
        }
    
    def _read_learning_rules(self, inputs: Dict[str, Any], config: Dict[str, Any]) -> Dict[str, Any]:
        """
        读取学习规则
        
        Args:
            inputs: 输入数据
            config: 配置
        
        Returns:
            学习规则文本
        """
        plugin_code = config.get('plugin_code', '')
        
        # 查找 learning 目录
        learning_dir = self.base_dir / 'app' / 'plugins' / plugin_code / 'learning'
        
        if not learning_dir.exists():
            return {'rules_text': ''}
        
        # 读取所有 markdown 文件
        rules = []
        for md_file in learning_dir.glob('*.md'):
            with open(md_file, 'r', encoding='utf-8') as f:
                rules.append(f.read())
        
        return {'rules_text': '\n\n---\n\n'.join(rules)}
    
    def _publish_artifact(self, inputs: Dict[str, Any], config: Dict[str, Any]) -> Dict[str, Any]:
        """
        发布 artifact
        
        Args:
            inputs: 输入数据
            config: 配置
        
        Returns:
            artifact 信息
        """
        file_path = inputs.get('file_path', '')
        publish_enabled = inputs.get('publish_enabled', True)
        
        if not publish_enabled or not file_path:
            return {'published': False}
        
        # 简单实现：返回文件信息
        return {
            'published': True,
            'file_path': file_path,
            'download_url': f'/api/artifacts/download?path={file_path}'
        }
