# -*- coding: utf-8 -*-
"""
Task Scheduler - 任务调度器

支持：
1. 插件来源主 Job 调度
2. LLM 来源主 Job 调度
3. SubJob 调度
4. LLM 自主规划触发
5. 条件边判断
6. 重试策略
"""
from app.extensions import db
from app.models import TaskRun, JobRun, NodeRun
import json
from datetime import datetime
from typing import List, Dict, Any, Optional


class TaskScheduler:
    """
    统一任务调度器
    
    支持所有 Job 来源（插件、LLM）和 SubJob 调度
    """
    
    def __init__(self):
        self.max_concurrent_jobs = 5
    
    def execute_task(self, task_run_id: int):
        """
        执行任务（支持所有 Job 来源）
        
        Args:
            task_run_id: TaskRun ID
        """
        task_run = TaskRun.query.get(task_run_id)
        if not task_run:
            return
        
        # 更新任务状态为 RUNNING
        task_run.status = 'RUNNING'
        task_run.started_at = datetime.utcnow()
        db.session.commit()
        
        # 获取所有主 Job（不包括 SubJob）
        main_jobs = JobRun.query.filter_by(
            task_run_id=task_run.id,
            is_sub_job=False
        ).all()
        
        for main_job in main_jobs:
            # 执行主 Job（无论来源是插件还是 LLM）
            self.execute_job(main_job)
    
    def execute_job(self, job_run: JobRun):
        """
        执行 Job（支持主 Job 和 SubJob）
        
        Args:
            job_run: JobRun 实例
        """
        # 更新 Job 状态为 RUNNING
        job_run.status = 'RUNNING'
        job_run.started_at = datetime.utcnow()
        db.session.commit()
        
        # 获取所有 NodeRuns
        node_runs = NodeRun.query.filter_by(job_run_id=job_run.id).all()
        
        # 拓扑排序，获取执行顺序
        sorted_nodes = self._topological_sort(node_runs, job_run.dag_json)
        
        # 按顺序执行节点
        for node_run in sorted_nodes:
            # 检查前置条件（条件边）
            if not self._check_conditions(node_run, job_run.dag_json):
                node_run.status = 'SKIPPED'
                node_run.finished_at = datetime.utcnow()
                db.session.commit()
                continue
            
            # 执行节点
            self.execute_node(node_run)
            
            # 检查节点执行结果
            if node_run.status == 'FAILED':
                # 检查重试策略
                if self._should_retry(node_run):
                    self.retry_node(node_run)
                else:
                    # 触发 LLM 自主规划（仅主 Job）
                    if self._should_trigger_llm_planning(node_run, job_run):
                        self.trigger_llm_planning(job_run, node_run)
                    else:
                        # Job 失败
                        job_run.status = 'FAILED'
                        job_run.finished_at = datetime.utcnow()
                        db.session.commit()
                        return
            
            # 检查 Job 是否完成
            if self._is_job_complete(job_run):
                job_run.status = 'SUCCESS'
                job_run.finished_at = datetime.utcnow()
                db.session.commit()
                break
    
    def execute_node(self, node_run: NodeRun):
        """
        执行节点
        
        Args:
            node_run: NodeRun 实例
        """
        # 更新状态为 RUNNING
        node_run.status = 'RUNNING'
        node_run.started_at = datetime.utcnow()
        db.session.commit()
        
        # 根据节点类型选择执行器
        action_type = node_run.action_type
        
        try:
            if action_type == 'PYTHON':
                result = self._execute_python_node(node_run)
            elif action_type == 'LLM':
                result = self._execute_llm_node(node_run)
            elif action_type == 'FILE':
                result = self._execute_file_node(node_run)
            elif action_type == 'API':
                result = self._execute_api_node(node_run)
            elif action_type == 'SQL':
                result = self._execute_sql_node(node_run)
            elif action_type == 'BASH':
                result = self._execute_bash_node(node_run)
            else:
                result = {'status': 'FAILED', 'error': f'Unknown action type: {action_type}'}
            
            # 更新节点状态
            if result.get('status') == 'SUCCESS':
                node_run.status = 'SUCCESS'
                node_run.output_json = json.dumps(result.get('output', {}))
            else:
                node_run.status = 'FAILED'
                node_run.error_json = json.dumps(result.get('error', {}))
        
        except Exception as e:
            node_run.status = 'FAILED'
            node_run.error_json = json.dumps({'error': str(e)})
        
        node_run.finished_at = datetime.utcnow()
        node_run.attempt_count += 1
        db.session.commit()
    
    def _execute_python_node(self, node_run: NodeRun) -> Dict[str, Any]:
        """
        执行 Python 节点
        
        Args:
            node_run: NodeRun 实例
        
        Returns:
            dict: {status: 'SUCCESS' | 'FAILED', output: {...}, error: str}
        """
        # TODO: 调用 python_executor
        config = json.loads(node_run.config_json or '{}')
        callable_path = config.get('callable', '')
        
        # 模拟执行成功
        return {'status': 'SUCCESS', 'output': {'result': 'Python execution completed'}}
    
    def _execute_llm_node(self, node_run: NodeRun) -> Dict[str, Any]:
        """
        执行 LLM 节点（支持 planning_enabled）
        
        Args:
            node_run: NodeRun 实例
        
        Returns:
            dict: {status: 'SUCCESS' | 'FAILED', output: {...}, error: str}
        """
        # 解析配置
        config = json.loads(node_run.config_json or '{}')
        
        # 检查是否启用自主规划
        planning_enabled = config.get('planning_enabled', False)
        
        if planning_enabled:
            # LLM 可以生成 SubJob
            # TODO: 调用 llm_executor，传入 planning_enabled=True
            pass
        
        # TODO: 调用 llm_executor
        return {'status': 'SUCCESS', 'output': {'result': 'LLM execution completed'}}
    
    def _execute_file_node(self, node_run: NodeRun) -> Dict[str, Any]:
        """执行 FILE 节点"""
        # TODO: 调用 file_executor
        return {'status': 'SUCCESS', 'output': {'result': 'File operation completed'}}
    
    def _execute_api_node(self, node_run: NodeRun) -> Dict[str, Any]:
        """执行 API 节点"""
        # TODO: 调用 api_executor
        return {'status': 'SUCCESS', 'output': {'result': 'API call completed'}}
    
    def _execute_sql_node(self, node_run: NodeRun) -> Dict[str, Any]:
        """执行 SQL 节点"""
        # TODO: 调用 sql_executor
        return {'status': 'SUCCESS', 'output': {'result': 'SQL execution completed'}}
    
    def _execute_bash_node(self, node_run: NodeRun) -> Dict[str, Any]:
        """执行 BASH 节点"""
        # TODO: 调用 bash_executor
        return {'status': 'SUCCESS', 'output': {'result': 'Bash script completed'}}
    
    def trigger_llm_planning(self, job_run: JobRun, failed_node: NodeRun):
        """
        触发 LLM 自主规划（生成 SubJob）
        
        支持：
        - 插件来源主 Job
        - LLM 来源主 Job
        
        Args:
            job_run: JobRun 实例（主 Job）
            failed_node: 失败的 NodeRun 实例
        """
        # 验证是主 Job（不是 SubJob）
        if job_run.is_sub_job:
            from flask import current_app
            current_app.logger.warning(f'JobRun {job_run.id} is a SubJob, cannot trigger LLM planning')
            return
        
        # 1. 准备错误上下文
        error_context = {
            'node_code': failed_node.code,
            'node_name': failed_node.node_name,
            'error': json.loads(failed_node.error_json or '{}'),
            'input': json.loads(failed_node.input_mapping_json or '{}'),
            'task_run_id': job_run.task_run_id,
            'job_source': job_run.job_source
        }
        
        # 2. 调用 LLM 生成恢复方案
        # TODO: 调用 llm_executor.generate_recovery_plan(error_context)
        # subjob_dag = llm_response.get('subjob_dag')
        
        # 3. 创建 SubJob
        # TODO: 调用 create_subjob API
        
        from flask import current_app
        current_app.logger.info(f'Triggered LLM planning for job {job_run.id}, source={job_run.job_source}')
    
    def retry_node(self, node_run: NodeRun):
        """
        重试节点
        
        Args:
            node_run: NodeRun 实例
        """
        # 重置节点状态为 READY
        node_run.status = 'READY'
        db.session.commit()
    
    def _topological_sort(self, node_runs: List[NodeRun], dag_json: Optional[str]) -> List[NodeRun]:
        """
        拓扑排序，返回执行顺序
        
        Args:
            node_runs: NodeRun 列表
            dag_json: DAG JSON 定义
        
        Returns:
            List[NodeRun]: 排序后的节点列表
        """
        # TODO: 实现 DAG 拓扑排序
        # 简化实现：直接返回原列表
        return node_runs
    
    def _check_conditions(self, node_run: NodeRun, dag_json: Optional[str]) -> bool:
        """
        检查条件边
        
        Args:
            node_run: NodeRun 实例
            dag_json: DAG JSON 定义
        
        Returns:
            bool: 是否满足条件
        """
        # TODO: 解析 condition_expr 并判断
        # 简化实现：返回 True
        return True
    
    def _should_retry(self, node_run: NodeRun) -> bool:
        """
        检查是否应该重试
        
        Args:
            node_run: NodeRun 实例
        
        Returns:
            bool: 是否应该重试
        """
        retry_policy = json.loads(node_run.retry_policy_json or '{}')
        max_retries = retry_policy.get('max_retries', 0)
        return node_run.attempt_count < max_retries
    
    def _should_trigger_llm_planning(self, node_run: NodeRun, job_run: JobRun) -> bool:
        """
        检查是否应该触发 LLM 自主规划
        
        Args:
            node_run: NodeRun 实例
            job_run: JobRun 实例
        
        Returns:
            bool: 是否应该触发 LLM 规划
        """
        config = json.loads(node_run.config_json or '{}')
        return config.get('planning_enabled', False)
    
    def _is_job_complete(self, job_run: JobRun) -> bool:
        """
        检查 Job 是否完成
        
        Args:
            job_run: JobRun 实例
        
        Returns:
            bool: Job 是否完成
        """
        # TODO: 检查所有节点是否执行完成
        node_runs = NodeRun.query.filter_by(job_run_id=job_run.id).all()
        
        for node in node_runs:
            if node.status not in ['SUCCESS', 'SKIPPED']:
                return False
        
        return True
    
    def _get_all_nodes(self, job_run: JobRun) -> List[NodeRun]:
        """获取 Job 的所有节点"""
        return NodeRun.query.filter_by(job_run_id=job_run.id).all()
    
    def _evaluate_condition(self, condition_expr: str, context: Dict[str, Any]) -> bool:
        """
        评估条件表达式
        
        Args:
            condition_expr: 条件表达式
            context: 上下文数据
        
        Returns:
            bool: 评估结果
        """
        # TODO: 实现条件表达式评估
        # 简化实现：返回 True
        return True


# 全局调度器实例
scheduler = TaskScheduler()
