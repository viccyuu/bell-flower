# -*- coding: utf-8 -*-
"""
TaskRun Repository - TaskRun 数据访问 ⭐

TaskRun CRUD 操作。
"""
import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


class TaskRunRepository:
    """
    TaskRun Repository ⭐
    
    TaskRun CRUD 操作，支持：
    - 创建 TaskRun
    - 更新状态
    - 根据 ID 获取
    - 列出可恢复的 TaskRuns
    """
    
    def __init__(self, db_session = None):
        """
        初始化 TaskRunRepository
        
        Args:
            db_session: 数据库会话
        """
        self.db = db_session
    
    def create(self, task_run_id: int, status: str, context: Dict[str, Any]) -> None:
        """
        创建 TaskRun
        
        Args:
            task_run_id: Task Run ID
            status: 状态
            context: 运行时上下文
        
        Raises:
            Exception: 创建失败
        """
        if self.db:
            # 使用数据库
            from app.models import TaskRun
            task_run = TaskRun(
                id=task_run_id,
                status=status,
                context_json=json.dumps(context, ensure_ascii=False) if context else None,
                created_at=datetime.now(timezone.utc),
                updated_at=datetime.now(timezone.utc),
                started_at=datetime.now(timezone.utc) if status == 'RUNNING' else None
            )
            self.db.add(task_run)
            self.db.commit()
    
    def update_status(self, task_run_id: int, status: str, context: Optional[Dict[str, Any]] = None) -> None:
        """
        更新 TaskRun 状态
        
        Args:
            task_run_id: Task Run ID
            status: 状态
            context: 运行时上下文 (可选)
        
        Raises:
            Exception: 更新失败
        """
        if self.db:
            from app.models import TaskRun
            task_run = self.db.query(TaskRun).filter(TaskRun.id == task_run_id).first()
            if task_run:
                task_run.status = status
                task_run.updated_at = datetime.now(timezone.utc)
                if status in ('SUCCESS', 'FAILED', 'PARTIAL_OR_BLOCKED'):
                    task_run.finished_at = datetime.now(timezone.utc)
                if context:
                    task_run.context_json = json.dumps(context, ensure_ascii=False)
                self.db.commit()
    
    def get_by_id(self, task_run_id: int) -> Optional[Dict[str, Any]]:
        """
        根据 ID 获取 TaskRun
        
        Args:
            task_run_id: Task Run ID
        
        Returns:
            TaskRun 数据，不存在返回 None
        """
        if self.db:
            from app.models import TaskRun
            task_run = self.db.query(TaskRun).filter(TaskRun.id == task_run_id).first()
            if task_run:
                return {
                    'id': task_run.id,
                    'status': task_run.status,
                    'context': json.loads(task_run.context_json) if task_run.context_json else None,
                    'created_at': task_run.created_at.isoformat() if task_run.created_at else None,
                    'updated_at': task_run.updated_at.isoformat() if task_run.updated_at else None,
                    'started_at': task_run.started_at.isoformat() if task_run.started_at else None,
                    'finished_at': task_run.finished_at.isoformat() if task_run.finished_at else None
                }
        return None
    
    def list_recoverable_task_runs(self) -> List[Dict[str, Any]]:
        """
        列出可恢复的 TaskRuns (status=RUNNING)
        
        Returns:
            TaskRun 列表
        """
        if self.db:
            from app.models import TaskRun
            task_runs = self.db.query(TaskRun).filter(TaskRun.status == 'RUNNING').all()
            return [
                {
                    'id': tr.id,
                    'status': tr.status,
                    'context': json.loads(tr.context_json) if tr.context_json else None
                }
                for tr in task_runs
            ]
        return []
