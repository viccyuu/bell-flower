# -*- coding: utf-8 -*-
"""
NodeRun Repository - NodeRun 数据访问 ⭐

NodeRun CRUD 操作。
"""
import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


class NodeRunRepository:
    """
    NodeRun Repository ⭐
    
    NodeRun CRUD 操作，支持：
    - 创建或忽略 (create_if_not_exists)
    - 标记 RUNNING
    - 标记 SUCCESS
    - 标记 FAILED
    - 标记 SKIPPED
    - 根据 JobRun ID 列出
    - 重置中断的 RUNNING 节点
    """
    
    def __init__(self, db_session = None):
        """
        初始化 NodeRunRepository
        
        Args:
            db_session: 数据库会话
        """
        self.db = db_session
    
    def create_if_not_exists(
        self,
        task_run_id: int,
        job_run_id: int,
        node_code: str,
        action_type: str,
        executor: str
    ) -> int:
        """
        创建 NodeRun (如果不存在)
        
        Args:
            task_run_id: Task Run ID
            job_run_id: Job Run ID
            node_code: Node Code
            action_type: Action Type
            executor: Executor Name
        
        Returns:
            NodeRun ID
        """
        if self.db:
            from app.models import NodeRun
            node_run = self.db.query(NodeRun).filter(
                NodeRun.job_run_id == job_run_id,
                NodeRun.node_code == node_code
            ).first()
            
            if node_run:
                return node_run.id
            
            node_run = NodeRun(
                task_run_id=task_run_id,
                job_run_id=job_run_id,
                node_code=node_code,
                action_type=action_type,
                executor=executor,
                status='PENDING',
                attempt_count=0,
                created_at=datetime.now(timezone.utc),
                updated_at=datetime.now(timezone.utc)
            )
            self.db.add(node_run)
            self.db.commit()
            return node_run.id
        
        # 简化实现：返回生成的 ID
        return hash(f"{job_run_id}_{node_code}") % 1000000
    
    def mark_running(self, node_run_id: int, attempt_count: int, input_data: Dict[str, Any]) -> None:
        """
        标记节点为 RUNNING
        
        Args:
            node_run_id: Node Run ID
            attempt_count: 尝试次数
            input_data: 输入数据
        
        Raises:
            Exception: 更新失败
        """
        if self.db:
            from app.models import NodeRun
            node_run = self.db.query(NodeRun).filter(NodeRun.id == node_run_id).first()
            if node_run:
                node_run.status = 'RUNNING'
                node_run.attempt_count = attempt_count
                node_run.input_json = json.dumps(input_data, ensure_ascii=False) if input_data else None
                node_run.started_at = node_run.started_at or datetime.now(timezone.utc)
                node_run.updated_at = datetime.now(timezone.utc)
                node_run.finished_at = None
                self.db.commit()
    
    def mark_success(self, node_run_id: int, output_data: Dict[str, Any], retry_history: List[Dict[str, Any]]) -> None:
        """
        标记节点为 SUCCESS
        
        Args:
            node_run_id: Node Run ID
            output_data: 输出数据
            retry_history: 重试历史
        
        Raises:
            Exception: 更新失败
        """
        if self.db:
            from app.models import NodeRun
            node_run = self.db.query(NodeRun).filter(NodeRun.id == node_run_id).first()
            if node_run:
                node_run.status = 'SUCCESS'
                node_run.output_json = json.dumps(output_data, ensure_ascii=False) if output_data else None
                node_run.error_json = None
                node_run.retry_history_json = json.dumps(retry_history, ensure_ascii=False) if retry_history else None
                node_run.finished_at = datetime.now(timezone.utc)
                node_run.updated_at = datetime.now(timezone.utc)
                self.db.commit()
    
    def mark_failed(self, node_run_id: int, error_data: Dict[str, Any], retry_history: List[Dict[str, Any]]) -> None:
        """
        标记节点为 FAILED
        
        Args:
            node_run_id: Node Run ID
            error_data: 错误数据
            retry_history: 重试历史
        
        Raises:
            Exception: 更新失败
        """
        if self.db:
            from app.models import NodeRun
            node_run = self.db.query(NodeRun).filter(NodeRun.id == node_run_id).first()
            if node_run:
                node_run.status = 'FAILED'
                node_run.error_json = json.dumps(error_data, ensure_ascii=False) if error_data else None
                node_run.retry_history_json = json.dumps(retry_history, ensure_ascii=False) if retry_history else None
                node_run.finished_at = datetime.now(timezone.utc)
                node_run.updated_at = datetime.now(timezone.utc)
                self.db.commit()
    
    def mark_skipped(self, node_run_id: int, reason: Dict[str, Any]) -> None:
        """
        标记节点为 SKIPPED
        
        Args:
            node_run_id: Node Run ID
            reason: 跳过原因
        
        Raises:
            Exception: 更新失败
        """
        if self.db:
            from app.models import NodeRun
            node_run = self.db.query(NodeRun).filter(NodeRun.id == node_run_id).first()
            if node_run:
                node_run.status = 'SKIPPED'
                node_run.error_json = json.dumps(reason, ensure_ascii=False) if reason else None
                node_run.finished_at = datetime.now(timezone.utc)
                node_run.updated_at = datetime.now(timezone.utc)
                self.db.commit()
    
    def list_by_job_run_id(self, job_run_id: int) -> List[Dict[str, Any]]:
        """
        根据 JobRun ID 列出 NodeRuns
        
        Args:
            job_run_id: Job Run ID
        
        Returns:
            NodeRun 列表
        """
        if self.db:
            from app.models import NodeRun
            node_runs = self.db.query(NodeRun).filter(NodeRun.job_run_id == job_run_id).all()
            result = []
            for nr in node_runs:
                data = {
                    'id': nr.id,
                    'task_run_id': nr.task_run_id,
                    'job_run_id': nr.job_run_id,
                    'node_code': nr.node_code,
                    'action_type': nr.action_type,
                    'executor': nr.executor,
                    'status': nr.status,
                    'attempt_count': nr.attempt_count
                }
                if nr.input_json:
                    data['input'] = json.loads(nr.input_json)
                if nr.output_json:
                    data['output'] = json.loads(nr.output_json)
                if nr.error_json:
                    data['error'] = json.loads(nr.error_json)
                if nr.retry_history_json:
                    data['retry_history'] = json.loads(nr.retry_history_json)
                result.append(data)
            return result
        return []
    
    def reset_interrupted_running_nodes(self, job_run_id: int) -> int:
        """
        重置中断的 RUNNING 节点为 PENDING
        
        Args:
            job_run_id: Job Run ID
        
        Returns:
            重置的节点数量
        """
        if self.db:
            from app.models import NodeRun
            node_runs = self.db.query(NodeRun).filter(
                NodeRun.job_run_id == job_run_id,
                NodeRun.status == 'RUNNING'
            ).all()
            
            count = 0
            for nr in node_runs:
                nr.status = 'PENDING'
                nr.updated_at = datetime.now(timezone.utc)
                nr.finished_at = None
                count += 1
            
            self.db.commit()
            return count
        
        return 0
    
    def reset_node_to_pending(self, node_run_id: int) -> None:
        """
        重置单个节点为 PENDING
        
        Args:
            node_run_id: Node Run ID
        """
        if self.db:
            from app.models import NodeRun
            node_run = self.db.query(NodeRun).filter(NodeRun.id == node_run_id).first()
            if node_run:
                node_run.status = 'PENDING'
                node_run.updated_at = datetime.now(timezone.utc)
                node_run.error_json = None
                node_run.finished_at = None
                self.db.commit()
