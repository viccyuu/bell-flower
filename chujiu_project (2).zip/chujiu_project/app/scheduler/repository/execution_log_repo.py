# -*- coding: utf-8 -*-
"""
ExecutionLog Repository - ExecutionLog 数据访问 ⭐

ExecutionLog CRUD 操作。
"""
import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


class ExecutionLogRepository:
    """
    ExecutionLog Repository ⭐
    
    ExecutionLog CRUD 操作，支持：
    - 记录日志
    - 根据 TaskRun ID 查询
    - 根据 JobRun ID 查询
    - 根据 NodeRun ID 查询
    """
    
    def __init__(self, db_session = None):
        """
        初始化 ExecutionLogRepository
        
        Args:
            db_session: 数据库会话
        """
        self.db = db_session
    
    def log(
        self,
        level: str,
        event_type: str,
        message: str,
        detail: Optional[Dict[str, Any]] = None,
        task_run_id: Optional[int] = None,
        job_run_id: Optional[int] = None,
        node_run_id: Optional[int] = None
    ) -> None:
        """
        记录日志
        
        Args:
            level: 日志级别 (INFO/WARN/ERROR)
            event_type: 事件类型
            message: 消息
            detail: 详细信息
            task_run_id: Task Run ID
            job_run_id: Job Run ID
            node_run_id: Node Run ID
        
        Raises:
            Exception: 记录失败
        """
        if self.db:
            from app.models import ExecutionLog
            log = ExecutionLog(
                task_run_id=task_run_id,
                job_run_id=job_run_id,
                node_run_id=node_run_id,
                level=level,
                event_type=event_type,
                message=message,
                detail_json=json.dumps(detail, ensure_ascii=False) if detail else None,
                created_at=datetime.now(timezone.utc)
            )
            self.db.add(log)
            self.db.commit()
    
    def list_by_task_run_id(self, task_run_id: int, limit: int = 100) -> List[Dict[str, Any]]:
        """
        根据 TaskRun ID 查询日志
        
        Args:
            task_run_id: Task Run ID
            limit: 限制数量
        
        Returns:
            日志列表
        """
        if self.db:
            from app.models import ExecutionLog
            logs = self.db.query(ExecutionLog).filter(
                ExecutionLog.task_run_id == task_run_id
            ).order_by(ExecutionLog.created_at.desc()).limit(limit).all()
            
            return [self._to_dict(log) for log in logs]
        return []
    
    def list_by_job_run_id(self, job_run_id: int, limit: int = 100) -> List[Dict[str, Any]]:
        """
        根据 JobRun ID 查询日志
        
        Args:
            job_run_id: Job Run ID
            limit: 限制数量
        
        Returns:
            日志列表
        """
        if self.db:
            from app.models import ExecutionLog
            logs = self.db.query(ExecutionLog).filter(
                ExecutionLog.job_run_id == job_run_id
            ).order_by(ExecutionLog.created_at.desc()).limit(limit).all()
            
            return [self._to_dict(log) for log in logs]
        return []
    
    def list_by_node_run_id(self, node_run_id: int, limit: int = 100) -> List[Dict[str, Any]]:
        """
        根据 NodeRun ID 查询日志
        
        Args:
            node_run_id: Node Run ID
            limit: 限制数量
        
        Returns:
            日志列表
        """
        if self.db:
            from app.models import ExecutionLog
            logs = self.db.query(ExecutionLog).filter(
                ExecutionLog.node_run_id == node_run_id
            ).order_by(ExecutionLog.created_at.desc()).limit(limit).all()
            
            return [self._to_dict(log) for log in logs]
        return []
    
    def _to_dict(self, log) -> Dict[str, Any]:
        """
        转换为字典
        
        Args:
            log: ExecutionLog 对象
        
        Returns:
            字典
        """
        data = {
            'id': log.id,
            'task_run_id': log.task_run_id,
            'job_run_id': log.job_run_id,
            'node_run_id': log.node_run_id,
            'level': log.level,
            'event_type': log.event_type,
            'message': log.message,
            'created_at': log.created_at.isoformat() if log.created_at else None
        }
        if log.detail_json:
            data['detail'] = json.loads(log.detail_json)
        return data
