# -*- coding: utf-8 -*-
"""
JobRun Repository - JobRun 数据访问 ⭐

JobRun CRUD 操作。
"""
import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


class JobRunRepository:
    """
    JobRun Repository ⭐
    
    JobRun CRUD 操作，支持：
    - 创建 JobRun
    - 更新状态
    - 根据 ID 获取
    - 根据 TaskRun ID 列出 RUNNING Jobs
    """
    
    def __init__(self, db_session = None):
        """
        初始化 JobRunRepository
        
        Args:
            db_session: 数据库会话
        """
        self.db = db_session
    
    def create(self, job_run_id: int, task_run_id: int, job_code: str, status: str) -> None:
        """
        创建 JobRun
        
        Args:
            job_run_id: Job Run ID
            task_run_id: Task Run ID
            job_code: Job Code
            status: 状态
        
        Raises:
            Exception: 创建失败
        """
        if self.db:
            from app.models import JobRun
            job_run = JobRun(
                id=job_run_id,
                task_run_id=task_run_id,
                code=job_code,
                status=status,
                created_at=datetime.now(timezone.utc),
                updated_at=datetime.now(timezone.utc),
                started_at=datetime.now(timezone.utc) if status == 'RUNNING' else None
            )
            self.db.add(job_run)
            self.db.commit()
    
    def update_status(self, job_run_id: int, status: str) -> None:
        """
        更新 JobRun 状态
        
        Args:
            job_run_id: Job Run ID
            status: 状态
        
        Raises:
            Exception: 更新失败
        """
        if self.db:
            from app.models import JobRun
            job_run = self.db.query(JobRun).filter(JobRun.id == job_run_id).first()
            if job_run:
                job_run.status = status
                job_run.updated_at = datetime.now(timezone.utc)
                if status in ('SUCCESS', 'FAILED', 'PARTIAL_OR_BLOCKED'):
                    job_run.finished_at = datetime.now(timezone.utc)
                self.db.commit()
    
    def get_by_id(self, job_run_id: int) -> Optional[Dict[str, Any]]:
        """
        根据 ID 获取 JobRun
        
        Args:
            job_run_id: Job Run ID
        
        Returns:
            JobRun 数据，不存在返回 None
        """
        if self.db:
            from app.models import JobRun
            job_run = self.db.query(JobRun).filter(JobRun.id == job_run_id).first()
            if job_run:
                return {
                    'id': job_run.id,
                    'task_run_id': job_run.task_run_id,
                    'job_code': job_run.code,
                    'status': job_run.status,
                    'created_at': job_run.created_at.isoformat() if job_run.created_at else None,
                    'updated_at': job_run.updated_at.isoformat() if job_run.updated_at else None,
                    'started_at': job_run.started_at.isoformat() if job_run.started_at else None,
                    'finished_at': job_run.finished_at.isoformat() if job_run.finished_at else None
                }
        return None
    
    def list_running_jobs_by_task_run_id(self, task_run_id: int) -> List[Dict[str, Any]]:
        """
        根据 TaskRun ID 列出 RUNNING 状态的 Jobs
        
        Args:
            task_run_id: Task Run ID
        
        Returns:
            Job 列表
        """
        if self.db:
            from app.models import JobRun
            jobs = self.db.query(JobRun).filter(
                JobRun.task_run_id == task_run_id,
                JobRun.status == 'RUNNING'
            ).all()
            return [
                {
                    'id': job.id,
                    'task_run_id': job.task_run_id,
                    'job_code': job.code,
                    'status': job.status
                }
                for job in jobs
            ]
        return []
