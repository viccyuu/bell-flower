# -*- coding: utf-8 -*-
"""
Log Service - 日志服务 ⭐

结构化日志记录，支持：
- 控制台 JSON 日志
- 数据库持久化
- 事件分类
"""
import json
from datetime import datetime, timezone
from typing import Any, Dict, Optional


class LogService:
    """
    日志服务 ⭐
    
    结构化日志记录，支持：
    - 控制台 JSON 日志
    - 数据库持久化
    - 事件分类
    """
    
    def __init__(self, log_repo = None):
        """
        初始化日志服务
        
        Args:
            log_repo: ExecutionLogRepository
        """
        self.log_repo = log_repo
    
    def log(
        self,
        level: str,
        event_type: str,
        message: str,
        detail: Optional[Dict[str, Any]] = None,
        task_run_id: Optional[int] = None,
        job_run_id: Optional[int] = None,
        node_run_id: Optional[int] = None
    ) -> None:
        """
        记录日志
        
        Args:
            level: 日志级别 (INFO/WARN/ERROR)
            event_type: 事件类型
            message: 消息
            detail: 详细信息
            task_run_id: Task Run ID
            job_run_id: Job Run ID
            node_run_id: Node Run ID
        """
        created_at = datetime.now(timezone.utc).isoformat()
        
        # 1. 控制台输出 (JSON 格式)
        console_log = {
            'ts': created_at,
            'level': level,
            'event_type': event_type,
            'message': message,
            'task_run_id': task_run_id,
            'job_run_id': job_run_id,
            'node_run_id': node_run_id,
            'detail': detail
        }
        print(json.dumps(console_log, ensure_ascii=False))
        
        # 2. 数据库持久化
        if self.log_repo:
            self.log_repo.log(
                level, event_type, message, detail,
                task_run_id, job_run_id, node_run_id
            )
    
    def log_job_started(
        self,
        job_code: str,
        task_run_id: int,
        job_run_id: int,
        resume: bool = False
    ) -> None:
        """
        记录 Job 开始日志
        
        Args:
            job_code: Job Code
            task_run_id: Task Run ID
            job_run_id: Job Run ID
            resume: 是否恢复
        """
        self.log(
            level='INFO',
            event_type='JOB_STARTED' if not resume else 'JOB_RESUMED',
            message=f"Job {'started' if not resume else 'resumed'}: {job_code}",
            task_run_id=task_run_id,
            job_run_id=job_run_id,
            detail={'job_code': job_code, 'resume': resume}
        )
    
    def log_job_finished(
        self,
        job_code: str,
        task_run_id: int,
        job_run_id: int,
        job_status: str
    ) -> None:
        """
        记录 Job 结束日志
        
        Args:
            job_code: Job Code
            task_run_id: Task Run ID
            job_run_id: Job Run ID
            job_status: Job 状态
        """
        self.log(
            level='INFO',
            event_type='JOB_FINISHED',
            message=f"Job finished: {job_code}",
            task_run_id=task_run_id,
            job_run_id=job_run_id,
            detail={'job_status': job_status}
        )
    
    def log_job_failed(
        self,
        job_code: str,
        task_run_id: int,
        job_run_id: int,
        error: str
    ) -> None:
        """
        记录 Job 失败日志
        
        Args:
            job_code: Job Code
            task_run_id: Task Run ID
            job_run_id: Job Run ID
            error: 错误消息
        """
        self.log(
            level='ERROR',
            event_type='JOB_FAILED',
            message=f"Job failed: {job_code}",
            task_run_id=task_run_id,
            job_run_id=job_run_id,
            detail={'error': error}
        )
    
    def log_node_started(
        self,
        node_code: str,
        task_run_id: int,
        job_run_id: int,
        node_run_id: int,
        detail: Dict[str, Any] = None
    ) -> None:
        """
        记录 Node 开始日志
        
        Args:
            node_code: Node Code
            task_run_id: Task Run ID
            job_run_id: Job Run ID
            node_run_id: Node Run ID
            detail: 详细信息
        """
        self.log(
            level='INFO',
            event_type='NODE_STARTED',
            message=f"Node started: {node_code}",
            task_run_id=task_run_id,
            job_run_id=job_run_id,
            node_run_id=node_run_id,
            detail=detail
        )
    
    def log_node_succeeded(
        self,
        node_code: str,
        task_run_id: int,
        job_run_id: int,
        node_run_id: int,
        attempt: int,
        output: Any
    ) -> None:
        """
        记录 Node 成功日志
        
        Args:
            node_code: Node Code
            task_run_id: Task Run ID
            job_run_id: Job Run ID
            node_run_id: Node Run ID
            attempt: 尝试次数
            output: 输出
        """
        self.log(
            level='INFO',
            event_type='NODE_SUCCEEDED',
            message=f"Node succeeded: {node_code}",
            task_run_id=task_run_id,
            job_run_id=job_run_id,
            node_run_id=node_run_id,
            detail={'attempt': attempt, 'output': output}
        )
    
    def log_node_failed(
        self,
        node_code: str,
        task_run_id: int,
        job_run_id: int,
        node_run_id: int,
        attempts: int,
        error: Dict[str, Any]
    ) -> None:
        """
        记录 Node 失败日志
        
        Args:
            node_code: Node Code
            task_run_id: Task Run ID
            job_run_id: Job Run ID
            node_run_id: Node Run ID
            attempts: 尝试次数
            error: 错误信息
        """
        self.log(
            level='ERROR',
            event_type='NODE_FAILED',
            message=f"Node failed: {node_code}",
            task_run_id=task_run_id,
            job_run_id=job_run_id,
            node_run_id=node_run_id,
            detail={'attempts': attempts, 'error': error}
        )
    
    def log_node_skipped(
        self,
        node_code: str,
        task_run_id: int,
        job_run_id: int,
        node_run_id: int,
        reason: str
    ) -> None:
        """
        记录 Node 跳过日志
        
        Args:
            node_code: Node Code
            task_run_id: Task Run ID
            job_run_id: Job Run ID
            node_run_id: Node Run ID
            reason: 跳过原因
        """
        self.log(
            level='INFO',
            event_type='NODE_SKIPPED',
            message=f"Node skipped: {node_code}",
            task_run_id=task_run_id,
            job_run_id=job_run_id,
            node_run_id=node_run_id,
            detail={'reason': reason}
        )
