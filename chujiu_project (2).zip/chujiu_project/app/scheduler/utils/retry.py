# -*- coding: utf-8 -*-
"""
Retry Utils - 重试工具函数 ⭐

merge_retry_policy: 合并默认和节点级重试策略
should_retry: 判断是否应该重试
"""
from typing import Any, Dict, Optional
from app.scheduler.models import NodeExecutionResult


def merge_retry_policy(
    default_policy: Optional[Dict[str, Any]],
    node_policy: Optional[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    合并默认和节点级重试策略
    
    节点级策略覆盖默认策略。
    
    Args:
        default_policy: 默认策略 (来自 DAG defaults)
        node_policy: 节点级策略 (来自 node 定义)
    
    Returns:
        合并后的策略
    """
    policy = {
        'max_retries': 0,
        'backoff_seconds': 0,
        'retry_on': []
    }
    
    # 应用默认策略
    if default_policy:
        policy.update(default_policy)
    
    # 应用节点级策略 (覆盖)
    if node_policy:
        policy.update(node_policy)
    
    # 确保类型正确
    policy['max_retries'] = int(policy.get('max_retries', 0) or 0)
    policy['backoff_seconds'] = int(policy.get('backoff_seconds', 0) or 0)
    
    if not isinstance(policy.get('retry_on'), list):
        policy['retry_on'] = []
    
    return policy


def should_retry(
    result: NodeExecutionResult,
    retry_policy: Dict[str, Any],
    current_attempt: int
) -> bool:
    """
    判断是否应该重试
    
    Args:
        result: 执行结果
        retry_policy: 重试策略
        current_attempt: 当前尝试次数 (从 1 开始)
    
    Returns:
        是否应该重试
    """
    # 成功不重试
    if result.success:
        return False
    
    # 检查最大重试次数
    max_retries = retry_policy.get('max_retries', 0)
    if current_attempt > max_retries:
        return False
    
    # 检查错误代码是否在 retry_on 中
    retry_on = retry_policy.get('retry_on', [])
    error_code = result.error_code
    
    if error_code is None:
        return False
    
    return error_code in retry_on
