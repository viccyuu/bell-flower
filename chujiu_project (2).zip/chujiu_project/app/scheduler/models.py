# -*- coding: utf-8 -*-
"""
DAG Scheduler Data Models - 数据模型定义 ⭐

统一的数据传输对象 (DTO)。
"""
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from datetime import datetime


@dataclass
class NodeExecutionRequest:
    """
    节点执行请求 ⭐
    
    统一的执行请求对象，传递给所有 Executor。
    """
    task_run_id: int
    """Task Run ID"""
    
    job_run_id: int
    """Job Run ID"""
    
    node_run_id: int
    """Node Run ID"""
    
    node_code: str
    """节点代码"""
    
    action_type: str
    """节点类型：PYTHON/LLM/FILE/TODOLIST"""
    
    executor: str
    """执行器名称：python_executor/llm_executor/file_executor/todolist_executor"""
    
    config: Dict[str, Any]
    """节点配置：callable/model/operation 等"""
    
    input_mapping: Dict[str, Any]
    """输入映射模板"""
    
    output_schema: Optional[Dict[str, Any]]
    """输出 Schema 验证"""
    
    timeout_seconds: int
    """超时时间 (秒)"""
    
    context: Dict[str, Any]
    """运行时上下文：{task, job, node}"""
    
    def __post_init__(self):
        """初始化后处理"""
        if not isinstance(self.config, dict):
            self.config = {}
        if not isinstance(self.input_mapping, dict):
            self.input_mapping = {}
        if not isinstance(self.context, dict):
            self.context = {}


@dataclass
class NodeExecutionResult:
    """
    节点执行结果 ⭐
    
    统一的执行结果对象，所有 Executor 返回此对象。
    """
    success: bool
    """是否成功"""
    
    status: str
    """状态：SUCCESS/FAILED"""
    
    output: Optional[Dict[str, Any]] = None
    """成功时的输出数据"""
    
    error_code: Optional[str] = None
    """错误代码：TIMEOUT/TEMPORARY_ERROR/ImportError 等"""
    
    error_message: Optional[str] = None
    """错误消息"""
    
    raw: Optional[Any] = None
    """原始返回值 (可选)"""
    
    metrics: Optional[Dict[str, Any]] = None
    """执行指标：{timeout_seconds, duration_ms, ...}"""
    
    def __post_init__(self):
        """初始化后处理"""
        if self.metrics is None:
            self.metrics = {}
        if self.success and self.status != 'SUCCESS':
            self.status = 'SUCCESS'
        if not self.success and self.status != 'FAILED':
            self.status = 'FAILED'
    
    @classmethod
    def success_result(cls, output: Dict[str, Any] = None, metrics: Dict[str, Any] = None):
        """
        创建成功结果
        
        Args:
            output: 输出数据
            metrics: 执行指标
        
        Returns:
            NodeExecutionResult
        """
        return cls(
            success=True,
            status='SUCCESS',
            output=output or {},
            metrics=metrics or {}
        )
    
    @classmethod
    def error_result(cls, error_code: str, error_message: str, metrics: Dict[str, Any] = None):
        """
        创建错误结果
        
        Args:
            error_code: 错误代码
            error_message: 错误消息
            metrics: 执行指标
        
        Returns:
            NodeExecutionResult
        """
        return cls(
            success=False,
            status='FAILED',
            error_code=error_code,
            error_message=error_message,
            metrics=metrics or {}
        )


@dataclass
class RetryHistory:
    """
    重试历史记录 ⭐
    
    记录每次重试的详细信息。
    """
    attempt: int
    """尝试次数"""
    
    error_code: str
    """错误代码"""
    
    error_message: str
    """错误消息"""
    
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    """时间戳"""
    
    backoff_seconds: int = 0
    """等待时间 (秒)"""


@dataclass
class ExecutionContext:
    """
    执行上下文 ⭐
    
    包含 task/job/node 的完整上下文信息。
    """
    task: Dict[str, Any]
    """Task 上下文：{id, vars, ...}"""
    
    job: Dict[str, Any]
    """Job 上下文：{id, vars, ...}"""
    
    node: Dict[str, Any]
    """Node 上下文：{node_code: {status, output, error}, ...}"""
    
    def __post_init__(self):
        """初始化后处理"""
        if not isinstance(self.task, dict):
            self.task = {}
        if not isinstance(self.job, dict):
            self.job = {}
        if not isinstance(self.node, dict):
            self.node = {}
    
    @classmethod
    def create(cls, task_run_id: int, job_run_id: int):
        """
        创建空上下文
        
        Args:
            task_run_id: Task Run ID
            job_run_id: Job Run ID
        
        Returns:
            ExecutionContext
        """
        return cls(
            task={'id': task_run_id, 'vars': {}},
            job={'id': job_run_id, 'vars': {}},
            node={}
        )
