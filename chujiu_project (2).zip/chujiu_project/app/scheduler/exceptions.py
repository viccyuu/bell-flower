# -*- coding: utf-8 -*-
"""
DAG Scheduler Exceptions - 统一异常定义 ⭐

所有调度相关异常的基类和具体实现。
"""


class SchedulerError(Exception):
    """
    调度器基础异常
    
    所有调度相关异常的基类。
    """
    def __init__(self, message: str, details: dict = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}


class NodeExecutionError(SchedulerError):
    """
    节点执行错误
    
    当节点执行失败时抛出。
    """
    def __init__(self, message: str, node_code: str = None, attempt_count: int = 0):
        super().__init__(message)
        self.node_code = node_code
        self.attempt_count = attempt_count


class InputResolveError(SchedulerError):
    """
    输入解析错误
    
    当 InputResolver 无法解析 input_mapping 时抛出。
    """
    def __init__(self, message: str, expression: str = None):
        super().__init__(message)
        self.expression = expression


class OutputValidationError(SchedulerError):
    """
    输出验证错误
    
    当 OutputValidator 验证 output_schema 失败时抛出。
    """
    def __init__(self, message: str, field: str = None, expected_type: str = None):
        super().__init__(message)
        self.field = field
        self.expected_type = expected_type


class TimeoutExecutionError(SchedulerError):
    """
    超时执行错误
    
    当节点执行超过 timeout_seconds 时抛出。
    """
    error_code = "TIMEOUT"
    
    def __init__(self, message: str, timeout_seconds: int = 0):
        super().__init__(message)
        self.timeout_seconds = timeout_seconds


class TemporaryError(SchedulerError):
    """
    临时错误
    
    可重试的临时错误，如网络抖动、服务暂时不可用等。
    """
    error_code = "TEMPORARY_ERROR"
    
    def __init__(self, message: str, retry_after: int = 0):
        super().__init__(message)
        self.retry_after = retry_after


class ExecutorNotFoundError(SchedulerError):
    """
    执行器未找到错误
    
    当 ExecutorRegistry 中找不到指定的 executor 时抛出。
    """
    def __init__(self, executor_name: str):
        super().__init__(f"Executor not found: {executor_name}")
        self.executor_name = executor_name


class DAGValidationError(SchedulerError):
    """
    DAG 验证错误
    
    当 DAG 验证失败时抛出（如存在环、节点不存在等）。
    """
    def __init__(self, message: str, error_type: str = None):
        super().__init__(message)
        self.error_type = error_type


class RecoveryError(SchedulerError):
    """
    恢复服务错误
    
    当 RecoveryService 执行恢复失败时抛出。
    """
    def __init__(self, message: str, task_run_id: int = None, job_run_id: int = None):
        super().__init__(message)
        self.task_run_id = task_run_id
        self.job_run_id = job_run_id
