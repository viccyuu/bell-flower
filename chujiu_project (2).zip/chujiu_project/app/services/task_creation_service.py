# -*- coding: utf-8 -*-
"""
Task Creation Service - 任务创建服务 ⭐

职责：
1. 根据模板创建 TaskRun
2. 从插件 DAG 创建 JobRun/NodeRun
3. 从 LLM DAG 创建 TaskRun/JobRun/NodeRun

注意：纯业务逻辑层，不包含 HTTP 处理
"""
from typing import Optional, Dict, Any
import json
import logging

logger = logging.getLogger(__name__)


class TaskCreationService:
    """任务创建服务"""
    
    def __init__(self, task_repo=None, job_repo=None, node_repo=None, db=None):
        """
        初始化服务
        
        Args:
            task_repo: TaskRunRepository (可选，默认使用全局实例)
            job_repo: JobRunRepository (可选)
            node_repo: NodeRunRepository (可选)
            db: 数据库会话 (可选)
        """
        self.task_repo = task_repo
        self.job_repo = job_repo
        self.node_repo = node_repo
        self.db = db
    
    def _get_db(self):
        """获取数据库会话"""
        if self.db:
            return self.db
        from app.extensions import db
        return db
    
    def _get_repos(self):
        """获取 Repository 实例"""
        if not self.task_repo:
            from app.repository.task_repository import task_run_repository
            self.task_repo = task_run_repository
        
        if not self.job_repo:
            from app.repository.job_repository import job_run_repository
            self.job_repo = job_run_repository
        
        if not self.node_repo:
            from app.repository.node_repository import node_run_repository
            self.node_repo = node_run_repository
    
    def create_task_from_template(
        self,
        template_code: str,
        upload_id: Optional[int] = None,
        runtime_params: Optional[Dict[str, Any]] = None
    ):
        """
        根据模板创建 TaskRun 并初始化 JobRun/NodeRun
        
        Args:
            template_code: 模板代码
            upload_id: 上传文件 ID
            runtime_params: 运行时参数
        
        Returns:
            TaskRun 实例
        
        Raises:
            ValueError: 模板不存在
        """
        from app.models import TaskTemplate, JobRun, NodeRun
        db = self._get_db()
        self._get_repos()
        
        # 1. 获取模板
        template = TaskTemplate.query.filter_by(code=template_code).first()
        if not template:
            raise ValueError(f"TaskTemplate '{template_code}' not found")
        
        # 2. 注册插件 DAG（如果有）
        if template.plugin_code:
            self._register_plugin_dag(template.plugin_code)
        
        # 3. 创建 TaskRun（纯 CRUD，委托给 Repository）
        task_run = self.task_repo.create(
            task_template_id=template.id,
            upload_file_id=upload_id,
            runtime_params=runtime_params,
            status='READY'
        )
        
        # 4. 创建 JobRun 和 NodeRun（业务逻辑）
        if template.plugin_code:
            self._create_job_from_plugin_dag(task_run.id, template.plugin_code)
        
        return task_run
    
    def _register_plugin_dag(self, plugin_code: str) -> None:
        """
        注册插件 DAG
        
        Args:
            plugin_code: 插件代码
        """
        try:
            from app.scheduler import plugin_dag_registry
            if not plugin_dag_registry.has_plugin_dag(plugin_code):
                from app.plugins.plugin_registry import plugin_registry
                plugin_info = plugin_registry.get_plugin(plugin_code)
                if plugin_info and plugin_info.get('dag'):
                    plugin_dag_registry.register_plugin_dag(plugin_code, plugin_info['dag'])
                    logger.info(f"Auto-registered DAG for plugin {plugin_code}")
        except Exception as e:
            logger.warning(f"Failed to auto-register DAG: {e}")
    
    def _create_job_from_plugin_dag(self, task_run_id: int, plugin_code: str) -> None:
        """
        从插件 DAG 创建 JobRun 和 NodeRun
        
        Args:
            task_run_id: TaskRun ID
            plugin_code: 插件代码
        """
        db = self._get_db()
        
        try:
            # 导入插件 DAG 配置
            module = __import__(f'app.plugins.{plugin_code}.config', fromlist=['PLUGIN_DAG'])
            if hasattr(module, 'PLUGIN_DAG'):
                plugin_dag = module.PLUGIN_DAG
                
                # 创建 JobRun
                job_info = plugin_dag.get('job', {})
                job_run = JobRun(
                    task_run_id=task_run_id,
                    code=job_info.get('code', f'{plugin_code}_job'),
                    name=job_info.get('name', 'Job'),
                    status='READY'
                )
                db.session.add(job_run)
                db.session.commit()
                
                # 创建 NodeRun
                nodes = plugin_dag.get('nodes', [])
                for node in nodes:
                    node_run = NodeRun(
                        job_run_id=job_run.id,
                        code=node.get('code', ''),
                        action_type=node.get('action_type', 'PYTHON'),
                        status='PENDING'
                    )
                    db.session.add(node_run)
                
                db.session.commit()
                logger.info(f"Created JobRun and {len(nodes)} NodeRuns for task {task_run_id}")
        except Exception as e:
            logger.error(f"Failed to create JobRun/NodeRun: {e}")
            # 不影响 TaskRun 创建
    
    def create_task_from_llm_dag(
        self,
        llm_dag: Dict[str, Any],
        upload_id: Optional[int] = None,
        runtime_params: Optional[Dict[str, Any]] = None
    ):
        """
        从 LLM DAG 创建 TaskRun（主 Job 来源：LLM 规划）
        
        Args:
            llm_dag: LLM 生成的 DAG 定义
            upload_id: 上传文件 ID
            runtime_params: 运行时参数
        
        Returns:
            TaskRun 实例
        """
        from app.models import TaskTemplate, JobRun, NodeRun
        db = self._get_db()
        self._get_repos()
        
        # 1. 获取或创建 LLM 模板
        template = TaskTemplate.query.filter_by(code='llm_planned_task').first()
        if not template:
            template = TaskTemplate(
                code='llm_planned_task',
                name='LLM Planned Task',
                description='Task created from LLM planning',
                is_builtin=0,
                version=1
            )
            db.session.add(template)
            db.session.commit()
        
        # 2. 创建 TaskRun（纯 CRUD）
        task_run = self.task_repo.create(
            task_template_id=template.id,
            upload_file_id=upload_id,
            runtime_params=runtime_params or {},
            status='READY'
        )
        
        # 3. 创建主 Job（来源：LLM）
        job_info = llm_dag.get('job', {})
        main_job = JobRun(
            task_run_id=task_run.id,
            code=job_info.get('code', 'llm_job'),
            name=job_info.get('name', 'LLM Planned Job'),
            status='READY',
            job_source='LLM',  # 标记为 LLM 来源
            is_sub_job=False   # 主 Job
        )
        db.session.add(main_job)
        
        # 4. 创建 NodeRun
        nodes = llm_dag.get('nodes', [])
        for node in nodes:
            node_run = NodeRun(
                job_run_id=main_job.id,
                code=node.get('code', ''),
                action_type=node.get('action_type', 'PYTHON'),
                status='PENDING'
            )
            db.session.add(node_run)
        
        db.session.commit()
        logger.info(f"Created LLM planned task with {len(nodes)} nodes")
        
        return task_run


# 全局服务实例
task_creation_service = TaskCreationService()
