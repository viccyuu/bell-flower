"""
Task Execution Service

Integrates DependencyScheduler with API to execute tasks.
"""
from app.todolist.dependency_scheduler import DependencyScheduler
from app.todolist.todo_engine import TodoEngine
from app.todolist.dependency_graph import DependencyGraph
from app.todolist.executors.api_executor import APIExecutor
from app.todolist.executors.sql_executor import SQLExecutor
from app.todolist.executors.bash_executor import BashExecutor
from app.todolist.executors.llm_executor import LLMExecutor
from app.todolist.executors.python_executor import PythonExecutor
from app.todolist.executors.file_executor import FileExecutor
from app.models import TaskRun, JobRun, NodeRun, NodeTemplate, EdgeTemplate
from app.extensions import db
from datetime import datetime
import json


class TaskExecutionService:
    """
    Task Execution Service
    
    Integrates scheduler with API to execute tasks.
    """
    
    def __init__(self, task_run_id):
        """
        Initialize execution service
        
        Args:
            task_run_id: TaskRun ID to execute
        """
        self.task_run_id = task_run_id
        self.task_run = TaskRun.query.get(task_run_id)
        self.scheduler = DependencyScheduler()
        self.engine = TodoEngine()
        
        # Initialize executors
        self.executors = {
            'API': APIExecutor(),
            'SQL': SQLExecutor(),
            'BASH': BashExecutor(),
            'LLM': LLMExecutor(),
            'PYTHON': PythonExecutor(),
            'FILE': FileExecutor()
        }
    
    def execute(self):
        """
        Execute the task
        
        Returns:
            dict: Execution result
        """
        if not self.task_run:
            return {'success': False, 'error': 'TaskRun not found'}
        
        # Get JobRuns for this TaskRun
        job_runs = JobRun.query.filter_by(
            task_run_id=self.task_run_id,
            is_sub_job=0
        ).all()
        
        if not job_runs:
            # Auto-create JobRuns from template
            job_runs = self._create_job_runs()
        
        results = []
        for job_run in job_runs:
            result = self._execute_job(job_run)
            results.append(result)
        
        # Update TaskRun status
        all_success = all(r.get('success', False) for r in results)
        if all_success:
            self.task_run.status = 'SUCCESS'
        else:
            self.task_run.status = 'FAILED'
        
        self.task_run.finished_at = datetime.utcnow()
        db.session.commit()
        
        return {
            'success': all_success,
            'job_results': results
        }
    
    def _create_job_runs(self):
        """
        Create JobRuns from TaskTemplate
        
        Returns:
            list: Created JobRuns
        """
        from app.models import JobTemplate
        
        job_templates = JobTemplate.query.filter_by(
            task_template_id=self.task_run.task_template_id,
            is_sub_job=0
        ).all()
        
        job_runs = []
        for job_template in job_templates:
            job_run = JobRun(
                task_run_id=self.task_run_id,
                job_template_id=job_template.id,
                code=job_template.code,
                name=job_template.name,
                is_sub_job=0,
                status='PENDING'
            )
            db.session.add(job_run)
            job_runs.append(job_run)
        
        db.session.commit()
        return job_runs
    
    def _execute_job(self, job_run):
        """
        Execute a single JobRun
        
        Args:
            job_run: JobRun instance
            
        Returns:
            dict: Execution result
        """
        try:
            # Update status
            job_run.status = 'RUNNING'
            job_run.started_at = datetime.utcnow()
            db.session.commit()
            
            # Get NodeRuns for this JobRun
            node_runs = NodeRun.query.filter_by(job_run_id=job_run.id).all()
            
            if not node_runs:
                # Auto-create NodeRuns from template
                node_runs = self._create_node_runs(job_run)
            
            # Build dependency graph
            dag_data = self._build_dag_data(job_run)
            graph = DependencyGraph(dag_data)
            
            # Execute nodes in topological order
            completed = set()
            failed = False
            
            while len(completed) < len(node_runs):
                # Find ready nodes
                ready_nodes = []
                for node_run in node_runs:
                    if node_run.id in completed:
                        continue
                    if node_run.status != 'PENDING':
                        continue
                    
                    # Check dependencies
                    deps = graph.get_upstream_nodes(node_run.code)
                    if all(dep in completed for dep in deps):
                        ready_nodes.append(node_run)
                
                if not ready_nodes:
                    if failed:
                        break
                    # No ready nodes but not all completed - might be a cycle
                    break
                
                # Execute ready nodes
                for node_run in ready_nodes:
                    result = self._execute_node(node_run)
                    if result.get('success', False):
                        completed.add(node_run.id)
                    else:
                        failed = True
                        node_run.status = 'FAILED'
                        db.session.commit()
                        break
            
            # Update JobRun status
            if failed:
                job_run.status = 'FAILED'
            else:
                job_run.status = 'SUCCESS'
            
            job_run.finished_at = datetime.utcnow()
            db.session.commit()
            
            return {
                'success': not failed,
                'job_id': job_run.id,
                'job_code': job_run.code
            }
            
        except Exception as e:
            job_run.status = 'FAILED'
            db.session.commit()
            return {
                'success': False,
                'error': str(e)
            }
    
    def _create_node_runs(self, job_run):
        """
        Create NodeRuns from JobTemplate
        
        Args:
            job_run: JobRun instance
            
        Returns:
            list: Created NodeRuns
        """
        from app.models import NodeTemplate
        
        node_templates = NodeTemplate.query.filter_by(
            job_template_id=job_run.job_template_id
        ).all()
        
        node_runs = []
        for node_template in node_templates:
            node_run = NodeRun(
                job_run_id=job_run.id,
                node_template_id=node_template.id,
                code=node_template.code,
                action_type=node_template.action_type,
                status='PENDING',
                version=1
            )
            db.session.add(node_run)
            node_runs.append(node_run)
        
        db.session.commit()
        return node_runs
    
    def _build_dag_data(self, job_run):
        """
        Build DAG data from templates
        
        Args:
            job_run: JobRun instance
            
        Returns:
            dict: DAG data with nodes and edges
        """
        from app.models import NodeTemplate, EdgeTemplate
        
        node_templates = NodeTemplate.query.filter_by(
            job_template_id=job_run.job_template_id
        ).all()
        
        edge_templates = EdgeTemplate.query.filter_by(
            job_template_id=job_run.job_template_id
        ).all()
        
        nodes = []
        for node in node_templates:
            config = json.loads(node.config_json) if node.config_json else {}
            nodes.append({
                'code': node.code,
                'name': node.name,
                'action_type': node.action_type,
                'config': config
            })
        
        edges = []
        for edge in edge_templates:
            edges.append({
                'from': edge.from_node_code,
                'to': edge.to_node_code,
                'condition_expr': edge.condition_expr
            })
        
        return {
            'nodes': nodes,
            'edges': edges
        }
    
    def _execute_node(self, node_run):
        """
        Execute a single NodeRun
        
        Args:
            node_run: NodeRun instance
            
        Returns:
            dict: Execution result
        """
        try:
            # Update status
            node_run.status = 'RUNNING'
            node_run.started_at = datetime.utcnow()
            db.session.commit()
            
            # Get executor
            executor = self.executors.get(node_run.action_type)
            if not executor:
                raise ValueError(f"Unknown action type: {node_run.action_type}")
            
            # Get node config
            node_template = NodeTemplate.query.get(node_run.node_template_id)
            config = json.loads(node_template.config_json) if node_template.config_json else {}
            
            # Execute
            result = executor.execute(config)
            
            # Update status
            node_run.status = 'SUCCESS'
            node_run.output_json = json.dumps(result) if result else None
            node_run.finished_at = datetime.utcnow()
            db.session.commit()
            
            return {
                'success': True,
                'node_id': node_run.id,
                'output': result
            }
            
        except Exception as e:
            # Check retry policy
            if self._should_retry(node_run):
                node_run.attempt_count += 1
                db.session.commit()
                return {
                    'success': False,
                    'retry': True,
                    'error': str(e)
                }
            
            # Mark as failed
            node_run.status = 'FAILED'
            node_run.error_json = json.dumps({'error': str(e)})
            node_run.finished_at = datetime.utcnow()
            db.session.commit()
            
            return {
                'success': False,
                'node_id': node_run.id,
                'error': str(e)
            }
    
    def _should_retry(self, node_run):
        """
        Check if node should be retried
        
        Args:
            node_run: NodeRun instance
            
        Returns:
            bool: Should retry
        """
        node_template = NodeTemplate.query.get(node_run.node_template_id)
        if not node_template or not node_template.retry_policy_json:
            return False
        
        retry_policy = json.loads(node_template.retry_policy_json)
        max_retries = retry_policy.get('max_retries', 0)
        
        return node_run.attempt_count < max_retries


def execute_task(task_run_id):
    """
    Execute a task by ID
    
    Args:
        task_run_id: TaskRun ID
        
    Returns:
        dict: Execution result
    """
    service = TaskExecutionService(task_run_id)
    return service.execute()
