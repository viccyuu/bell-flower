# -*- coding: utf-8 -*-
"""
数据模型定义 - SQLAlchemy Async ⭐

FastAPI 异步数据库模型
"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Boolean, Float
from sqlalchemy.orm import relationship
from app.database import Base


class User(Base):
    """用户表"""
    __tablename__ = 'user'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(80), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False, default='user')
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)


class UploadFile(Base):
    """上传文件表"""
    __tablename__ = 'upload_file'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('user.id'), nullable=True)
    original_name = Column(String(255), nullable=False)
    stored_name = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=False)
    mime_type = Column(String(100), nullable=True)
    size_bytes = Column(Integer, nullable=False)
    checksum_sha256 = Column(String(64), nullable=False, index=True)
    plugin_code = Column(String(100), nullable=False)
    status = Column(String(20), nullable=False, default='UPLOADED')
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)


class TaskTemplate(Base):
    """任务模板表"""
    __tablename__ = 'task_template'
    
    id = Column(Integer, primary_key=True)
    code = Column(String(100), unique=True, nullable=False, index=True)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    plugin_code = Column(String(100), nullable=True)
    params_schema_json = Column(Text, nullable=True)
    is_builtin = Column(Integer, nullable=False, default=0)
    version = Column(Integer, nullable=False, default=1)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)


class TaskRun(Base):
    """任务运行实例表"""
    __tablename__ = 'task_run'
    
    id = Column(Integer, primary_key=True)
    task_template_id = Column(Integer, ForeignKey('task_template.id'), nullable=False)
    user_id = Column(Integer, ForeignKey('user.id'), nullable=True)
    upload_file_id = Column(Integer, ForeignKey('upload_file.id'), nullable=True)
    status = Column(String(20), nullable=False, default='CREATED')
    runtime_params_json = Column(Text, nullable=True)
    context_json = Column(Text, nullable=True)
    started_at = Column(DateTime, nullable=True)
    finished_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)


class JobRun(Base):
    """Job 运行实例表"""
    __tablename__ = 'job_run'
    
    id = Column(Integer, primary_key=True)
    task_run_id = Column(Integer, ForeignKey('task_run.id'), nullable=False)
    job_template_id = Column(Integer, ForeignKey('job_template.id'), nullable=True)
    parent_job_run_id = Column(Integer, ForeignKey('job_run.id'), nullable=True)
    code = Column(String(100), nullable=False)
    name = Column(String(255), nullable=False)
    source = Column(String(20), nullable=False, default='TEMPLATE')
    is_sub_job = Column(Boolean, nullable=False, default=False)
    status = Column(String(20), nullable=False, default='PENDING')
    context_json = Column(Text, nullable=True)
    recovery_node_code = Column(String(100), nullable=True)
    started_at = Column(DateTime, nullable=True)
    finished_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)


class NodeRun(Base):
    """Node 运行实例表"""
    __tablename__ = 'node_run'
    
    id = Column(Integer, primary_key=True)
    job_run_id = Column(Integer, ForeignKey('job_run.id'), nullable=False)
    node_template_id = Column(Integer, ForeignKey('node_template.id'), nullable=True)
    code = Column(String(100), nullable=False)
    action_type = Column(String(20), nullable=False)
    status = Column(String(20), nullable=False, default='PENDING')
    input_json = Column(Text, nullable=True)
    output_json = Column(Text, nullable=True)
    error_json = Column(Text, nullable=True)
    attempt_count = Column(Integer, nullable=False, default=0)
    version = Column(Integer, nullable=False, default=0)
    started_at = Column(DateTime, nullable=True)
    finished_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)


class Artifact(Base):
    """产物表"""
    __tablename__ = 'artifact'
    
    id = Column(Integer, primary_key=True)
    task_run_id = Column(Integer, ForeignKey('task_run.id'), nullable=False)
    job_run_id = Column(Integer, ForeignKey('job_run.id'), nullable=True)
    node_run_id = Column(Integer, ForeignKey('node_run.id'), nullable=True)
    artifact_type = Column(String(20), nullable=False)
    name = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=True)
    content_text = Column(Text, nullable=True)
    content_json = Column(Text, nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)


class ExecutionLog(Base):
    """执行日志表"""
    __tablename__ = 'execution_log'
    
    id = Column(Integer, primary_key=True)
    task_run_id = Column(Integer, ForeignKey('task_run.id'), nullable=False)
    job_run_id = Column(Integer, ForeignKey('job_run.id'), nullable=True)
    node_run_id = Column(Integer, ForeignKey('node_run.id'), nullable=True)
    level = Column(String(10), nullable=False)
    event_type = Column(String(50), nullable=False)
    message = Column(Text, nullable=False)
    detail_json = Column(Text, nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)


class LearningRule(Base):
    """学习规则表"""
    __tablename__ = 'learning_rule'
    
    id = Column(Integer, primary_key=True)
    task_run_id = Column(Integer, ForeignKey('task_run.id'), nullable=False)
    plugin_code = Column(String(100), nullable=False)
    error_id = Column(String(50), nullable=False)
    scenario = Column(Text, nullable=False)
    root_cause = Column(Text, nullable=False)
    forbidden_patterns = Column(Text, nullable=False)
    correct_pattern = Column(Text, nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)


class JobTemplate(Base):
    """Job 模板表"""
    __tablename__ = 'job_template'
    
    id = Column(Integer, primary_key=True)
    task_template_id = Column(Integer, ForeignKey('task_template.id'), nullable=False)
    parent_job_template_id = Column(Integer, ForeignKey('job_template.id'), nullable=True)
    code = Column(String(100), nullable=False)
    name = Column(String(255), nullable=False)
    is_sub_job = Column(Boolean, nullable=False, default=False)
    dag_json = Column(Text, nullable=False)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)


class NodeTemplate(Base):
    """Node 模板表"""
    __tablename__ = 'node_template'
    
    id = Column(Integer, primary_key=True)
    job_template_id = Column(Integer, ForeignKey('job_template.id'), nullable=False)
    code = Column(String(100), nullable=False)
    name = Column(String(255), nullable=False)
    action_type = Column(String(20), nullable=False)
    config_json = Column(Text, nullable=False)
    input_mapping_json = Column(Text, nullable=True)
    output_schema_json = Column(Text, nullable=True)
    retry_policy_json = Column(Text, nullable=True)
    continue_on_error = Column(Integer, nullable=False, default=0)
    timeout_seconds = Column(Integer, nullable=True)
    order_hint = Column(Integer, nullable=True)


class EdgeTemplate(Base):
    """Edge 模板表（DAG 边）"""
    __tablename__ = 'edge_template'
    
    id = Column(Integer, primary_key=True)
    job_template_id = Column(Integer, ForeignKey('job_template.id'), nullable=False)
    from_node_code = Column(String(100), nullable=False)
    to_node_code = Column(String(100), nullable=False)
    condition_expr = Column(Text, nullable=True)
