# Chujiu TodoList 测试运行脚本
# 用法：.\run_tests.ps1 [-TestType "all|unit|integration|regression"] [-Verbose]

param(
    [Parameter(Mandatory=$false)]
    [ValidateSet("all", "unit", "integration", "regression")]
    [string]$TestType = "all",
    
    [Parameter(Mandatory=$false)]
    [switch]$Verbose
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$TestsDir = Join-Path $ProjectRoot "tests"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Chujiu TodoList 测试运行器" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 检查服务是否运行
Write-Host "[1/3] 检查服务状态..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://127.0.0.1:5001/health" -TimeoutSec 3 -UseBasicParsing
    if ($response.StatusCode -eq 200) {
        Write-Host "✅ 服务运行正常 (http://127.0.0.1:5001)" -ForegroundColor Green
    } else {
        Write-Host "❌ 服务响应异常" -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "❌ 服务未运行！请先启动 Flask 应用：" -ForegroundColor Red
    Write-Host "   cd chujiu_project" -ForegroundColor Gray
    Write-Host "   py app.py" -ForegroundColor Gray
    exit 1
}

Write-Host ""

# 检查依赖
Write-Host "[2/3] 检查测试依赖..." -ForegroundColor Yellow
try {
    $null = Get-Command pytest -ErrorAction Stop
    Write-Host "✅ pytest 已安装" -ForegroundColor Green
} catch {
    Write-Host "❌ pytest 未安装！安装命令：" -ForegroundColor Red
    Write-Host "   pip install pytest requests pytest-cov" -ForegroundColor Gray
    exit 1
}

Write-Host ""

# 运行测试
Write-Host "[3/3] 运行测试..." -ForegroundColor Yellow
Write-Host ""

$pytestArgs = @()

switch ($TestType) {
    "unit" {
        $pytestArgs = @("tests/unit/", "-v", "--tb=short")
        Write-Host "📋 运行单元测试..." -ForegroundColor Cyan
    }
    "integration" {
        $pytestArgs = @("tests/integration/", "-v", "--tb=short")
        Write-Host "📋 运行集成测试..." -ForegroundColor Cyan
    }
    "regression" {
        $pytestArgs = @("tests/integration/test_regression.py", "-v", "--tb=short")
        Write-Host "📋 运行回归测试..." -ForegroundColor Cyan
    }
    "all" {
        $pytestArgs = @("tests/", "-v", "--tb=short")
        Write-Host "📋 运行所有测试..." -ForegroundColor Cyan
    }
}

if ($Verbose) {
    $pytestArgs += "--tb=long"
}

# 执行 pytest
Set-Location $ProjectRoot
try {
    & pytest $pytestArgs
    $exitCode = $LASTEXITCODE
} catch {
    Write-Host "❌ 测试执行失败：$_" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan

if ($exitCode -eq 0) {
    Write-Host "  ✅ 所有测试通过！" -ForegroundColor Green
} else {
    Write-Host "  ❌ 有测试失败，请检查输出" -ForegroundColor Red
}

Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

exit $exitCode
