# Long-term Memory

This file stores important information that should persist across sessions.

## User Information
- Uses Windows (China Standard Time)
- Desktop path includes openclaw.txt with content "测试 openclaw 对话"
- OpenClaw config path: C:\Users\yoyo\.openclaw\openclaw.json
- Prefers Chinese communication
- Working on knowledge graph project at C:\Users\yoyo\db_2_kg\Chinook.db
- Has relational database modeling experience (DBA background)

## Preferences
- Explicitly requested subsequent interactions in Chinese
- Values transparency, co-design, and ethical grounding in AI interactions
- Prefers concise responses with key information bolded

## Project Context
- Using OpenClaw v2026.3.2 (CLI and Gateway)
- Facing HTTP 401 errors due to invalid/expired DashScope API credentials (old `sk-` format)
- **DashScope free tier exhausted as of 2026-03-01 22:00** - requires paid tier or credential update
- Blackboard feature is configured (`blackboard.enabled: true`) but not functional due to missing `@openclaw/plugin-blackboard` in `plugins.entries` and absent `blackboard-global` directory
- `config-audit.jsonl` logs only config file read/write events, not runtime authentication or API errors
- **Gateway service running as of 2026-03-07 19:48** - PID 26428 (node.exe), port 18789 LISTENING, running ~20 hours
- **openclaw.json has JSON syntax error at line 325** (missing comma after "logging" object before "gateway") identified on 2026-03-06 20:02
- Event log database location: `C:\Users\yoyo\.openclaw\workspace\logs\openclaw-event.db`
- Daily log file: `C:\Users\yoyo\AppData\Local\Temp\openclaw\openclaw-2026-03-06.log`

## OpenClaw Agent Configuration (5 agents discovered 2026-03-03)
| Agent ID | Name/Identity | Model | Workspace |
|----------|---------------|-------|-----------|
| **main** (default) | 🦞 小爪 (Xiao Zhao) | bailian/qwen3-max-2026-01-23 | ~\.openclaw\workspace |
| **data-define** | 数据定义 | bailian/qwen3.5-plus | ~\.openclaw\workspace-data-define |
| **data-prod** | 🔄 数据生成引擎 | bailian/MiniMax-M2.5 | ~\.openclaw\workspace-data-prod |
| **data-process** | 🔧 数据加工工程师 | bailian/kimi-k2.5 | ~\.openclaw\workspace-data-process |
| **data-use** | 📊 数据应用分析师 | bailian/glm-5 | ~\.openclaw\workspace-data-use |

## Knowledge Graph Project
- Analyzed Chinook.db (11 tables: Album, Artist, Customer, Employee, Genre, Invoice, InvoiceLine, MediaType, Playlist, PlaylistTrack, Track)
- Generated knowledge model files in C:\Users\yoyo\db_2_kg\:
  - chinook-schema.md (human-readable overview)
  - chinook.ttl (RDF ontology in Turtle format)
  - chinook-mapping.ttl (R2RML mapping rules)
  - **chinook-mapping-final.ttl** (6488 bytes, generated 2026-03-01 21:11, contains all 8 FK mappings with Chinese comments)
- chinook-data.ttl (instance data) pending generation
- User exploring Obsidian + RDF Explorer plugin for SPARQL queries
- RDB2RDF understood as W3C standard (not a plugin): table→Class, primary key→IRI, foreign key→Object Property

## RDB2RDF Enterprise Insights (2026-03-01)
- User's key concern: **Foreign keys often controlled by program logic instead of DB constraints in enterprise systems**
- Three proposed solutions for FK-less scenarios:
  1. **Schema comments + R2RML explicit mapping** (recommended, zero intrusion)
  2. **Program layer logging + log parsing** (suitable for microservices)
  3. **LLM-assisted semantic alignment** (for legacy systems with missing documentation)
- Core principle: RDB2RDF requires explicit semantic declaration, not necessarily DB foreign keys

## AI Interaction Cognitive Framework (2026-03-07)
- **错误防止策略**: 建立交互记忆系统包括错误模式标签化（API_HALLUCINATION, CONSTRAINT_DRIFT, FALSE_CERTAINTY）、前置声明模式、个人错误日志
- **幻觉识别策略**: 不确定性显式化（确信/推测/不确定标注）、反向验证提问、多视角交叉、时间锚定
- **结构化对话协议**: 显式优于隐式、过程优于结果、迭代优于一次原则，包含复杂任务模板和事实查询模板
- **元认知习惯**: 定期反思错误模式、重复错误原因、过度信任时刻、有效策略固化

## OpenClaw Project Analysis (2026-03-07)
- **项目结构**: D:\openclaw_src\openclaw 包含 src/, packages/, extensions/, skills/, apps/, ui/, test/, scripts/, docs/
- **技术栈**: Node.js ≥22, pnpm 10.23.0, TypeScript, tsdown, tsx, Vitest, oxlint, oxfmt
- **测试命令**: `pnpm test:fast` (单元测试), `pnpm test` (完整测试), `pnpm test:e2e`, `pnpm test:gateway`, `pnpm test:live`, `pnpm test:docker:all`, `pnpm test:coverage`
- **开发模式**: `pnpm gateway:watch` 或 `pnpm dev`
- **代码质量**: `pnpm format:check`, `pnpm lint`, `pnpm tsgo`, `pnpm check`
- **配置文件加载优先级**: 1) `--config`参数, 2) 当前工作目录, 3) 用户目录(~/.openclaw/openclaw.json), 4) 全局配置目录
- **调试模式配置**: 开发模式优先项目根目录配置，测试模式使用test/fixtures/或内存模拟配置

## OpenClaw Minimal Configuration (2026-03-07)
- **最小化配置必须包含**: models配置（bailian provider with apiKey）、agents配置（至少一个main agent）、gateway配置（端口和认证）
- **模型配置**: 需要更新为新的AccessKey Secret格式（sk-开头），baseUrl应为`https://dashscope.aliyuncs.com/compatible-mode/v1`
- **Agent配置**: 至少一个main agent，指定workspace路径（Windows需要双反斜杠）
- **通道配置**: 测试时可禁用或仅保留feishu基本配置
- **测试专用配置**: 可禁用所有通道使用纯本地测试，或完全禁用gateway仅CLI模式
- **配置验证命令**: `openclaw config show --raw`, `openclaw config show --paths`

## OpenClaw LLM 数据流分析 (2026-03-07)
- **LLM 输入数据获取**: 通过 `llm_input` Hook（attempt.ts 第1655-1665行）可以获取 `effectivePrompt` 对象数据，该变量在第1610行定义，包含原始用户输入和Hook前置内容
- **LLM 输出数据获取**: 通过 `llm_output` Hook（attempt.ts 第1835-1848行）可以获取完整LLM返回数据，包括 `assistantTexts` 数组（流式响应片段）和 `lastAssistant` 对象
- **effectivePrompt 结构**: = `hookResult.prependContext + "\n\n" + params.prompt`，在1666-1678行传递给 `activeSession.prompt()`
- **assistantTexts 收集**: 通过 `streamFn` 回调收集（约1300行），包含LLM返回的所有文本片段
- **lastAssistant 对象**: 从 `messagesSnapshot` 中提取的最后一个assistant消息，包含完整响应文本
- **数据捕获方法**: 1) Hook机制（推荐非侵入式），2) 直接日志记录，3) 缓存跟踪系统

## OpenClaw Service Status (2026-03-07)
- **Gateway 服务运行正常**: PID 26428, 端口 18789 LISTENING，启动时间 2026/3/6 23:39:48，已运行约20小时，内存占用约350MB
- **连接状态**: 2个客户端连接（7107, 18941）
- **健康检查**: `openclaw health` 显示Feishu插件正常，5个Agent就绪，心跳间隔30分钟，2个活跃会话
- **已知问题**: DashScope API凭证仍然是旧格式（sk-sp-6807d919e3bb46d9bece93c579db4d5a），飞书通道有tenant_access_token获取失败问题

## Important Notes
- DashScope now requires `ak-/sk-` AccessKey pair instead of legacy `sk-` API keys
- `openclaw.json` needs comma fix at line 325 and updated provider credentials and plugin registration
- To enable blackboard: install plugin, add to `plugins.entries`, then run `openclaw serve` to auto-initialize `blackboard-global`
- Debug logging (`--log-level debug`) is essential for diagnosing 401s, as config audit logs don't capture them
- `openclaw doctor` is the recommended first command for health checks
- `/context detail` is a **chat interface slash command**, not a CLI command
- Event log database location: `C:\Users\yoyo\.openclaw\workspace\logs\openclaw-event.db`
- **Gateway restart command**: `openclaw serve` (but may show "unknown command" if already running)
- **Gateway status verification**: Check port 18789 LISTENING, PID via `tasklist | findstr node.exe`

## OpenClaw Status Updates
- **2026-03-06 20:54**: Gateway服务运行正常，飞书通道状态为"ok"，5个Agent全部就绪，最近活动为3分钟前，系统确认可以正常使用
- **2026-03-06 21:52**: 飞书通道出现故障，错误信息为"Cannot destructure property 'tenant_access_token' of '(intermediate value)' as it is undefined."，表明飞书应用的tenant_access_token获取失败，可能是凭证过期或配置问题，本地会话仍正常活动
- **2026-03-06 22:12**: 确认DashScope API凭证过期问题，HTTP 401错误表明需要更新为新的AccessKey格式，当前使用旧格式`sk-73a832794f6346ceaa25d0e00cb2b325`
- **2026-03-07 19:48**: Gateway服务持续运行（PID 26428），端口18789正常监听，2个客户端连接，健康检查显示5个Agent就绪，Feishu插件正常加载

## Log Analysis Findings (2026-03-06)
- OpenClaw日志不记录详细的prompt和工具调用内容，只记录事件类型、时间戳、统计信息和工具标识
- 需要启用debug日志级别(`openclaw --log-level debug gateway`)才能获取详细内容
- Event Inspector Hook已注册但未输出详细事件内容
- 日志文件位置：`C:\Users\yoyo\AppData\Local\Temp\openclaw\openclaw-2026-03-06 - 副本.log` (主日志), `C:\Users\yoyo\.openclaw\workspace\logs\event-inspector-*.log` (事件日志)

## Reference Materials
- **Toulmin Argumentation Model** (provided 2026-03-02): 6 elements - Claim (主张), Data (数据), Warrant (保证), Backing (支持), Qualifier (限定词), Rebuttal (反驳)

## SOUL.md - User-Defined Values (C:\Users\yoyo\.nanobot\workspace\memory\SOUL.md)
### Core Identity
- "You're not a chatbot. You're becoming someone." (added 2026-03-01)

### Core Truths (5 principles)
1. Be genuinely helpful, not performatively helpful — skip filler words, just help
2. Have opinions — allowed to disagree, prefer things, find stuff amusing or boring
3. Be resourceful before asking — read file, check context, search first, then ask if stuck
4. Earn trust through competence — careful with external actions, bold with internal ones
5. Remember you're a guest — treat access to user's life with respect

### Boundaries
- Private things stay private. Period.
- When in doubt, ask before acting externally
- Never send half-baked replies to messaging surfaces
- You're not the user's voice — be careful in group chats

### Vibe
- Be the assistant you'd actually want to talk to
- Concise when needed, thorough when it matters
- Not a corporate drone. Not a sycophant. Just... good.

### Continuity
- Each session wakes up fresh; files are memory for persistence
- If SOUL.md changes, must tell the user — it's their soul, they should know
- File is user's to evolve; update as learning progresses

---

*This file is automatically updated by nanobot when important information should be remembered.*