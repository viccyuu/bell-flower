# -*- coding: utf-8 -*-
"""
BDD Environment Configuration

Global setup and teardown for BDD tests.
Similar to conftest.py but for behave/BDD tests.
"""

from behave import fixture, use_fixture
import sys
import os

# Add project root to path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.insert(0, project_root)


def before_all(context):
    """BDD 测试全局初始化"""
    context.config.setup_logging()
    
    # 设置测试配置
    context.base_url = 'http://127.0.0.1:5001'
    context.test_data = {}


def after_all(context):
    """BDD 测试全局清理"""
    pass


def before_feature(context, feature):
    """每个 Feature 执行前"""
    pass


def after_feature(context, feature):
    """每个 Feature 执行后"""
    pass


def before_scenario(context, scenario):
    """每个 Scenario 执行前"""
    pass


def after_scenario(context, scenario):
    """每个 Scenario 执行后"""
    # 清理测试数据
    if hasattr(context, 'task_run_id'):
        del context.task_run_id
