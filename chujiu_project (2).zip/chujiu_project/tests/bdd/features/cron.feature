# -*- coding: utf-8 -*-
"""
Feature: Cron 定时调度

测试 Cron 服务的功能
"""


Feature: Cron 定时调度
  作为系统
  我希望定时调度任务执行
  以便按计划执行任务
  
  Scenario: Cron 添加定时任务
    Given Cron 服务已启动
    When 添加一个定时任务
    Then 任务应该被添加
    And 任务应该有正确的调度时间
  
  Scenario: Cron 执行定时任务
    Given 有已调度的任务
    When 到达调度时间
    Then 任务应该被执行
    And 执行结果应该被记录
  
  Scenario: Cron 列出任务
    Given 有多个定时任务
    When 列出所有任务
    Then 应该返回所有任务列表
    And 每个任务应该有正确的状态
  
  Scenario: Cron 删除任务
    Given 有已存在的任务
    When 删除任务
    Then 任务应该被删除
    And 不应该再出现在列表中
  
  Scenario: Cron 启用/禁用任务
    Given 有已存在的任务
    When 禁用任务
    Then 任务应该被禁用
    And 不应该再被调度
  
  Scenario: Cron 重试调度
    Given 任务执行失败
    When 调度重试任务
    Then 重试任务应该被添加
    And 应该有正确的延迟时间
