# -*- coding: utf-8 -*-
"""
Feature: 文件上传功能

用户通过上传文件来启动任务执行流程。

【SDD 1.2 已实现】
- POST /api/uploads ✅
- 文件验证 ✅
- 插件选择 ✅
"""

Feature: 文件上传
  作为用户
  我希望上传文件并选择插件
  以便系统处理文件并准备任务执行

  Scenario: 成功上传 Excel 文件
    Given 用户访问上传页面
    When 用户选择一个有效的 .xlsm 文件
    And 选择 "Excel VBA 转 WPS JS" 插件
    And 点击上传按钮
    Then 文件应该上传成功
    And 系统应返回 uploadId
    And 文件状态应为 "UPLOADED"

  Scenario: 上传空文件
    Given 用户访问上传页面
    When 用户上传一个空文件
    Then 系统应提示 "文件不能为空"
    And 文件不应被保存

  Scenario: 上传不支持的文件类型
    Given 用户访问上传页面
    When 用户上传一个 .txt 文件
    Then 系统应提示 "不支持的文件类型"
    And 文件不应被保存

  Scenario: 上传文件超过大小限制
    Given 用户访问上传页面
    When 用户上传一个超过 50MB 的文件
    Then 系统应提示 "文件大小超过限制"
    And 文件不应被保存

  Scenario: 未选择插件上传
    Given 用户访问上传页面
    When 用户上传文件但未选择插件
    Then 系统应提示 "请选择插件"
    And 文件不应被保存
