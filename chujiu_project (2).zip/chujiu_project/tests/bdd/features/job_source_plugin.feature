# -*- coding: utf-8 -*-
"""
Feature: 插件来源主 Job

验证从插件管理引入的主 Job 创建和执行流程。

【设计依据】
- 任务运行模块完整设计_v2.md - 方案 1
- 主 Job 来源：插件管理引入
- job_source='PLUGIN'
- is_sub_job=False

【测试范围】
1. 创建插件来源主 Job
2. 加载 PLUGIN_DAG（17 个节点）
3. 创建 JobRun 和 NodeRun
4. 执行主 Job
5. 触发 LLM 自主规划
"""

Feature: 插件来源主 Job

  背景:
    Given 数据库已初始化
    And 插件 "excel_vba_to_wps_js" 已注册
    And PLUGIN_DAG 包含 17 个节点

  场景 1: 成功创建插件来源主 Job
    当 用户上传 Excel 文件
    And 选择插件 "excel_vba_to_wps_js"
    And 点击"创建任务"
    那么 TaskRun 应该创建成功
    And 主 Job 应该创建成功
    And job_source 应该为 "PLUGIN"
    And is_sub_job 应该为 False
    And 应该创建 17 个 NodeRun
    And 所有节点状态应该为 "PENDING"

  场景 2: 主 Job 包含正确的节点配置
    当 创建插件来源主 Job
    那么 每个 NodeRun 应该包含 input_mapping
    And 每个 NodeRun 应该包含 output_schema
    And 每个 NodeRun 应该包含 config
    And 每个 NodeRun 应该包含 retry_policy

  场景 3: 主 Job 节点配置正确
    当 创建插件来源主 Job
    那么 节点 "upload_validate" 应该存在
    And 节点 "extract_vba_macros" 应该存在
    And 节点 "vba_to_vba_ast" 应该存在
    And 节点 "write_js_to_wps_file" 应该存在
    And 节点 "publish_download_artifact" 应该存在

  场景 4: 执行插件来源主 Job 成功
    当 创建插件来源主 Job
    And 启动任务执行
    那么 主 Job 状态应该变为 "RUNNING"
    And 节点应该按 DAG 顺序执行
    And 主 Job 状态应该变为 "SUCCESS"

  场景 5: 节点失败触发 LLM 自主规划
    当 创建插件来源主 Job
    And 节点 "vba_to_vba_ast" 执行失败
    And 节点配置 planning_enabled=True
    那么 应该触发 LLM 自主规划
    And 应该生成 SubJob DAG
    And 应该创建 SubJob
    And SubJob 的 is_sub_job 应该为 True
    And SubJob 的 parent_job_id 应该为主 Job ID

  场景 6: SubJob 完成后恢复主 Job
    当 主 Job 节点失败触发 SubJob
    And SubJob 执行成功
    And SubJob 完成回调
    那么 主 Job 的失败节点状态应该重置为 "READY"
    And 主 Job 应该继续执行
    And 主 Job 状态应该变为 "SUCCESS"

  场景 7: 验证 DAG 边定义
    当 创建插件来源主 Job
    那么 边 "upload_validate -> extract_vba_macros" 应该存在
    And 边 "extract_vba_macros -> analyze_macro_dependencies" 应该存在
    And 边 "vba_to_vba_ast -> review_vba_ast" 应该存在
    And 条件边应该正确配置

  场景 8: 验证节点重试策略
    当 创建插件来源主 Job
    And 节点执行失败
    And retry_policy.max_retries > 0
    那么 节点应该重试执行
    And 重试次数应该正确记录
