# -*- coding: utf-8 -*-
"""
Feature: 插件管理功能

用户查看和管理已安装的插件。

【SDD 1.2 已实现】
- GET /api/plugins ✅
- GET /api/plugins/<code>/dag ✅
- GET/POST /api/plugins/<code>/learning ✅
"""

Feature: 插件管理
  作为用户
  我希望查看和管理插件
  以便了解可用功能和配置

  Scenario: 查看插件列表
    Given 系统已安装多个插件
    When 用户访问插件管理页面
    Then 应显示所有已安装插件
    And 每个插件应显示名称和描述
    And 应显示插件状态（启用/禁用）

  Scenario: 查看插件 DAG
    Given 用户已选择一个插件
    When 用户点击 "查看 DAG"
    Then 应显示插件的 DAG 结构
    And 应显示所有节点
    And 应显示节点间的依赖关系

  Scenario: 查看插件 Learning 规则
    Given 插件已有 Learning 规则
    When 用户点击 "查看 Learning"
    Then 应显示所有 Learning 规则
    And 每条规则应显示场景和错因
    And 应显示禁止行为和正确范式

  Scenario: 启用/禁用插件
    Given 一个已启用的插件
    When 用户点击禁用开关
    Then 插件状态应变为 "DISABLED"
    And 该插件不应再被选择

  Scenario: 查看插件详情
    Given 用户已选择一个插件
    When 用户点击 "详情"
    Then 应显示插件配置信息
    And 应显示支持的参数
    And 应显示执行历史
