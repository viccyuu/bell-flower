# -*- coding: utf-8 -*-
"""
Feature: LLM 自主规划 SubJob

验证主 Job 节点失败时 LLM 自行规划 SubJob 的流程。

【设计依据】
- 任务运行模块完整设计_v2.md - 方案 3
- 支持所有主 Job 来源（插件、LLM）
- is_sub_job=True
- parent_job_id 关联主 Job

【测试范围】
1. 节点执行失败
2. 触发 LLM 自主规划
3. 生成 SubJob DAG
4. 创建 SubJob
5. 执行 SubJob
6. SubJob 完成回调
7. 恢复主 Job 执行
"""

Feature: LLM 自主规划 SubJob

  背景:
    Given 数据库已初始化
    And 主 Job 已创建（来源："PLUGIN" 或 "LLM"）
    And 主 Job 正在执行

  规则 1: 只有主 Job 可以触发 SubJob
    场景 1: 主 Job 节点失败触发 SubJob
      当 主 Job 的节点执行失败
      And 节点配置 planning_enabled=True
      那么 应该触发 LLM 自主规划
      And 应该生成 SubJob DAG
      And 应该创建 SubJob
    
    场景 2: SubJob 不应该触发 SubJob
      当 SubJob 的节点执行失败
      那么 不应该触发 LLM 自主规划
      And 不应该创建 SubJob

  规则 2: SubJob 创建验证
    场景 3: SubJob 正确关联父 Job
      当 创建 SubJob
      那么 SubJob 的 is_sub_job 应该为 True
      And SubJob 的 parent_job_id 应该为主 Job ID
      And SubJob 的 job_source 应该为 "LLM"
      And SubJob 的 failed_node_code 应该记录
    
    场景 4: SubJob 验证父 Job 是主 Job
      当 尝试为 SubJob 创建 SubJob
      那么 应该返回错误 "NOT_MAIN_JOB"
      And 不应该创建 SubJob

  规则 3: SubJob 执行流程
    场景 5: SubJob 执行成功
      当 SubJob 创建成功
      And 启动 SubJob 执行
      那么 SubJob 状态应该变为 "RUNNING"
      And SubJob 的节点应该执行
      And SubJob 状态应该变为 "SUCCESS"
    
    场景 6: SubJob 执行失败
      当 SubJob 创建成功
      And 启动 SubJob 执行
      And SubJob 节点执行失败
      那么 SubJob 状态应该变为 "FAILED"
      And 主 Job 应该保持失败状态

  规则 4: SubJob 完成回调
    场景 7: SubJob 成功完成回调
      当 SubJob 执行成功
      And 调用 SubJob 完成回调
      And recovery_node_code="vba_to_vba_ast"
      那么 SubJob 状态应该更新为 "SUCCESS"
      And 主 Job 的失败节点状态应该重置为 "READY"
      And 主 Job 应该继续执行
    
    场景 8: SubJob 失败完成回调
      当 SubJob 执行失败
      And 调用 SubJob 完成回调
      那么 SubJob 状态应该更新为 "FAILED"
      And 主 Job 状态应该变为 "FAILED"

  规则 5: 主 Job 恢复执行
    场景 9: 主 Job 从恢复点继续执行
      当 SubJob 完成回调成功
      And recovery_node_code="vba_to_vba_ast"
      那么 主 Job 的 "vba_to_vba_ast" 节点应该重置为 "READY"
      And 调度器应该继续执行主 Job
      And 主 Job 状态应该变为 "SUCCESS"
    
    场景 10: 主 Job 恢复后再次失败
      当 主 Job 恢复执行
      And 恢复节点再次失败
      And 重试次数已用尽
      那么 主 Job 状态应该变为 "FAILED"
      And 不应该再次触发 SubJob

  规则 6: 错误上下文传递
    场景 11: SubJob 包含错误上下文
      当 创建 SubJob
      那么 error_context_json 应该包含 node_code
      And error_context_json 应该包含 error 信息
      And error_context_json 应该包含 input 信息
      And error_context_json 应该包含 task_run_id

  规则 7: 多 SubJob 场景
    场景 12: 主 Job 多次触发 SubJob
      当 主 Job 的多个节点失败
      And 每个节点都配置 planning_enabled=True
      那么 应该为每个失败节点创建 SubJob
      And SubJob 应该按顺序执行
      And 主 Job 应该在所有 SubJob 完成后恢复
