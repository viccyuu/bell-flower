# -*- coding: utf-8 -*-
"""
Feature: 产物下载功能

用户下载任务执行产生的产物文件。

【SDD 1.2 已实现】
- GET /api/artifacts ✅
- GET /api/artifacts/<id>/download ✅
"""

Feature: 产物下载
  作为用户
  我希望下载任务执行产生的产物
  以便获取转换或处理结果

  Scenario: 查看产物列表
    Given 任务执行完成
    And 已生成多个产物
    When 用户访问产物下载页面
    Then 应显示所有产物
    And 每个产物应显示文件名和大小
    And 应显示产物类型

  Scenario: 下载产物文件
    Given 用户已选择一个产物
    When 用户点击 "下载"
    Then 浏览器应开始下载
    And 文件名应正确
    And 文件内容应完整

  Scenario: 预览产物内容
    Given 产物是文本文件
    When 用户点击 "预览"
    Then 应显示文件内容
    And 内容应格式正确

  Scenario: 删除产物
    Given 用户已选择一个产物
    When 用户点击 "删除"
    Then 产物应被删除
    And 不应再出现在列表中

  Scenario: 批量下载产物
    Given 用户已选择多个产物
    When 用户点击 "批量下载"
    Then 系统应打包所有产物
    And 应下载 ZIP 文件
    And ZIP 内应包含所有文件
