# -*- coding: utf-8 -*-
"""
Feature: 任务创建与执行功能

用户创建任务并启动执行。

【SDD 1.2 已实现】
- POST /api/task-runs ✅
- POST /api/task-runs/<id>/start ✅
- GET /api/task-runs ✅
"""

Feature: 任务创建与执行
  作为用户
  我希望创建任务并启动执行
  以便系统自动完成文件转换或处理

  Scenario: 成功创建任务
    Given 用户已上传一个文件
    When 用户选择 "Excel VBA 转 WPS JS" 模板
    And 点击 "创建任务" 按钮
    Then 任务应该创建成功
    And 任务状态应为 "CREATED"
    And 系统应返回 taskRunId

  Scenario: 成功启动任务
    Given 存在一个状态为 "CREATED" 的任务
    When 用户点击 "启动任务" 按钮
    Then 任务状态应变为 "READY"
    And 系统应开始执行 DAG 节点

  Scenario: 任务执行成功
    Given 任务正在执行中
    When 所有 DAG 节点执行成功
    Then 任务状态应变为 "SUCCESS"
    And 系统应生成产物文件
    And 用户应能下载产物

  Scenario: 任务执行失败
    Given 任务正在执行中
    When 某个 DAG 节点执行失败
    And 重试次数已达上限
    Then 任务状态应变为 "FAILED"
    And 系统应记录错误日志
    And 用户应能查看失败原因

  Scenario: 任务部分成功
    Given 任务包含多个 DAG 节点
    When 部分节点执行成功
    And 部分节点执行失败
    Then 任务状态应变为 "PARTIAL_SUCCESS"
    And 系统应保存已成功的产物

  Scenario: 查看任务列表
    Given 系统中存在多个任务
    When 用户访问任务列表页面
    Then 应显示所有任务
    And 每个任务应显示状态标签
    And 用户应能点击查看详情

  Scenario: 查看任务详情
    Given 用户已选择一个任务
    When 用户点击 "查看详情"
    Then 应显示任务基本信息
    And 应显示 DAG 节点列表
    And 应显示每个节点的状态
    And 应显示执行日志
