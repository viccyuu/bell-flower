# -*- coding: utf-8 -*-
"""
Feature: LLM 自主规划与 SubJob 功能

LLM 在节点失败时可自主规划 SubJob 进行恢复。

【SDD 1.2 部分实现】
- POST /api/task-runs/<id>/generate-learning ✅
- POST /api/task-runs/<id>/subjobs ✅
- POST /api/subjobs/<id>/recover ✅
"""

Feature: LLM 自主规划与 SubJob
  作为系统
  我希望 LLM 在失败时自主规划恢复流程
  以便提高任务成功率

  Scenario: 节点失败触发 LLM 规划
    Given 一个 Node 执行失败
    And 该节点配置为"可 LLM 规划"
    When 系统检测到失败
    Then 应调用 LLM 分析错误
    And LLM 应生成恢复方案

  Scenario: 创建 SubJob
    Given LLM 已生成恢复方案
    When 系统创建 SubJob
    Then SubJob 应关联到主 TaskRun
    And SubJob 应有独立的 DAG
    And SubJob 状态应为 "CREATED"

  Scenario: 执行 SubJob
    Given SubJob 已创建
    When 系统启动 SubJob
    Then SubJob 应独立执行
    And 执行结果应返回给主 Job

  Scenario: SubJob 执行成功
    Given SubJob 正在执行
    When SubJob 所有节点成功
    Then SubJob 状态应变为 "SUCCESS"
    And 主 Job 应获得恢复指令
    And 主 Job 应从恢复点继续执行

  Scenario: SubJob 执行失败
    Given SubJob 正在执行
    When SubJob 执行失败
    Then SubJob 状态应变为 "FAILED"
    And 主 Job 应保持失败状态
    And 系统应记录失败日志

  Scenario: 主 Job 恢复执行
    Given SubJob 执行成功
    And 返回了恢复点 Node C
    When 主 Job 从 Node C 恢复
    Then Node C 状态应变为 "READY"
    And 主 Job 应继续执行后续节点

  Scenario: 生成 Learning 规则
    Given 任务执行失败
    When 用户或系统触发 Learning 生成
    Then 应调用 LLM 分析错误原因
    And 应生成 Learning 规则
    And 规则应保存到 learning.md

  Scenario: 应用 Learning 规则
    Given 存在一条 Learning 规则
    When 相同场景再次发生
    Then 系统应读取 Learning 规则
    And 应应用规则中的正确范式
    And 应避免重复错误
