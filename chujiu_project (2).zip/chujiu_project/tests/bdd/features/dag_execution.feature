# -*- coding: utf-8 -*-
"""
DAG Execution Feature - BDD 测试 ⭐

功能：DAG 执行流程
"""

Feature: DAG Execution
  DAG 调度模块的 DAG 执行功能
  
  Scenario: 执行简单 DAG
    Given 一个定义的 DAG
    When 执行该 DAG
    Then 所有节点应该成功执行
  
  Scenario: 执行带条件边的 DAG
    Given 一个带条件边的 DAG
    When 条件满足时执行该 DAG
    Then 满足条件的节点应该执行
    And 不满足条件的节点应该跳过
  
  Scenario: 执行带重试的 DAG
    Given 一个带重试策略的 DAG
    When 节点执行失败但可重试
    Then 节点应该重试直到成功
  
  Scenario: 执行带跳过的 DAG
    Given 一个 DAG
    When 前置节点失败且 continue_on_error=false
    Then 后续节点应该跳过
  
  Scenario: 恢复中断的 DAG
    Given 一个中断的 DAG 执行
    When 执行恢复服务
    Then RUNNING 节点应该重置为 PENDING
    And DAG 应该继续执行
