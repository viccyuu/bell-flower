# -*- coding: utf-8 -*-
"""
Gherkin Feature Files

Define acceptance tests in Gherkin syntax (.feature files).
"""
