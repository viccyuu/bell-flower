# -*- coding: utf-8 -*-
"""
Feature: VBA 到 WPS JS 转换流程

验证从文件上传到转换完成的完整流程。

【设计依据】
- three-plugins-dag-json-define.MD
- 插件 DAG 定义（17 节点）

【测试范围】
1. 文件上传
2. 任务创建
3. 任务执行
4. 结果下载
"""

Feature: VBA 到 WPS JS 转换流程

  背景:
    Given 服务正常运行
    And 插件 "excel_vba_to_wps_js" 已注册
    And 用户已访问系统

  场景 1: 成功上传 Excel 文件
    当 用户上传 Excel 文件 "vba2js3-chujiu.xlsm"
    And 选择插件 "excel_vba_to_wps_js"
    那么 文件应该上传成功
    And 应该返回 uploadId

  场景 2: 创建转换任务
    当 文件已上传
    And 用户点击"创建任务"
    那么 任务应该创建成功
    And 应该返回 taskRunId
    And 任务状态应该为 "CREATED" 或 "READY"

  场景 3: 查看任务详情和 DAG
    当 任务已创建
    And 用户点击"详情"按钮
    那么 任务详情弹窗应该显示
    And DAG 节点应该显示
    And 应该显示 3 个或更多节点
    And 节点状态应该为 "PENDING"

  场景 4: 启动任务执行
    当 任务详情已查看
    And 用户点击"启动"按钮
    那么 任务应该启动成功
    And 任务状态应该变为 "RUNNING"
    And 应该显示成功提示

  场景 5: 监控任务执行进度
    当 任务正在执行
    And 用户刷新任务列表
    那么 任务状态应该更新
    And 应该显示执行进度

  场景 6: 任务执行完成
    当 任务执行完成
    那么 任务状态应该为 "SUCCESS" 或 "PARTIAL_SUCCESS"
    And 应该生成转换产物
    And 产物应该可下载

  场景 7: 下载转换结果
    当 任务已完成
    And 用户点击下载按钮
    那么 应该开始下载
    And 下载文件应该是 WPS JS 格式

  场景 8: 查看插件 DAG 定义
    当 用户访问插件管理页面
    And 点击 "DAG" 按钮
    那么 DAG 弹窗应该显示
    And 应该显示节点列表
    And 应该显示边列表
    And 节点数应该为 3 个或更多

  场景 9: 查看插件 Learning 规则
    当 用户访问插件管理页面
    And 点击 "Learning" 按钮
    那么 Learning 弹窗应该显示
    And 应该显示规则列表
    And 规则应该包含场景和错因

  场景 10: 完整转换工作流
    当 用户上传 Excel 文件
    And 创建转换任务
    And 启动任务执行
    And 等待任务完成
    And 下载转换结果
    那么 完整流程应该成功
    And 转换结果应该可用

  场景 11: 任务执行失败处理
    当 任务执行失败
    那么 任务状态应该为 "FAILED"
    And 应该显示错误信息
    And 应该可以查看失败原因

  场景 12: 重新执行失败任务
    当 任务执行失败
    And 用户点击"重试"按钮
    那么 任务应该重新执行
    And 任务状态应该变为 "RUNNING"
