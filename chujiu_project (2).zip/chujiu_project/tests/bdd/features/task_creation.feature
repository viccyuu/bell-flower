# -*- coding: utf-8 -*-
"""
Feature: 任务创建功能

用户通过上传文件并选择模板来创建任务。
"""

Feature: 任务创建
  作为用户
  我希望上传文件并选择模板来创建任务
  以便系统自动执行转换任务

  Scenario: 成功创建任务
    Given 用户已登录系统
    When 用户上传一个有效的 Excel 文件
    And 选择 "VBA 转 WPS JS" 模板
    And 点击 "创建任务" 按钮
    Then 任务应该创建成功
    And 任务状态应为 "READY"

  Scenario: 上传空文件
    Given 用户已登录系统
    When 用户上传一个空文件
    Then 系统应提示 "文件不能为空"
    And 任务不应被创建

  Scenario: 上传不支持的文件类型
    Given 用户已登录系统
    When 用户上传一个 .txt 文件
    Then 系统应提示 "不支持的文件类型"
    And 任务不应被创建
