# -*- coding: utf-8 -*-
"""
Feature: LLM 来源主 Job

验证从 LLM 规划的主线任务创建和执行流程。

【设计依据】
- 任务运行模块完整设计_v2.md - 方案 2
- 主 Job 来源：LLM 规划
- job_source='LLM'
- is_sub_job=False

【测试范围】
1. 创建 LLM 来源主 Job
2. 加载 LLM 生成的 DAG
3. 创建 JobRun 和 NodeRun
4. 执行主 Job
5. 触发 LLM 自主规划
"""

Feature: LLM 来源主 Job

  背景:
    Given 数据库已初始化
    And LLM executor 可用
    And 用户请求 "帮我转换这个 Excel 文件"

  场景 1: 成功创建 LLM 来源主 Job
    当 LLM 分析用户需求
    And LLM 生成任务 DAG
    And 点击"创建任务"
    那么 TaskRun 应该创建成功
    And 主 Job 应该创建成功
    And job_source 应该为 "LLM"
    And is_sub_job 应该为 False
    And 应该创建 N 个 NodeRun
    And 所有节点状态应该为 "PENDING"

  场景 2: 主 Job 包含 LLM 生成的 DAG
    当 创建 LLM 来源主 Job
    那么 dag_json 应该正确存储
    And DAG 应该包含 job 定义
    And DAG 应该包含 nodes 定义
    And DAG 应该包含 edges 定义

  场景 3: LLM 生成的节点配置正确
    当 创建 LLM 来源主 Job
    那么 每个 NodeRun 应该包含 input_mapping
    And 每个 NodeRun 应该包含 output_schema
    And 每个 NodeRun 应该包含 config
    And 节点类型应该正确设置

  场景 4: 执行 LLM 来源主 Job 成功
    当 创建 LLM 来源主 Job
    And 启动任务执行
    那么 主 Job 状态应该变为 "RUNNING"
    And 节点应该按 DAG 顺序执行
    And 主 Job 状态应该变为 "SUCCESS"

  场景 5: 节点失败触发 LLM 自主规划
    当 创建 LLM 来源主 Job
    And 节点执行失败
    And 节点配置 planning_enabled=True
    那么 应该触发 LLM 自主规划
    And 应该生成 SubJob DAG
    And 应该创建 SubJob
    And SubJob 的 is_sub_job 应该为 True
    And SubJob 的 parent_job_id 应该为主 Job ID

  场景 6: SubJob 完成后恢复主 Job 执行
    当 主 Job 节点失败触发 SubJob
    And SubJob 执行成功
    And SubJob 完成回调
    那么 主 Job 的失败节点状态应该重置为 "READY"
    And 主 Job 应该继续执行
    And 主 Job 状态应该变为 "SUCCESS"

  场景 7: 验证 LLM DAG 的灵活性
    当 LLM 生成不同的任务 DAG
    那么 节点数量可以不同
    And 节点类型可以不同
    And 边定义可以不同
    And 主 Job 都应该正确创建

  场景 8: 验证主 Job 来源标记
    当 创建 LLM 来源主 Job
    那么 job_source 应该为 "LLM"
    And is_sub_job 应该为 False
    And parent_job_id 应该为 None
