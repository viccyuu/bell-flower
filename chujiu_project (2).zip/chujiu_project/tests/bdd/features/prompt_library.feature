# -*- coding: utf-8 -*-
"""
Feature: 提示词库管理功能

用户管理提示词模板和分类。

【SDD 1.2 已实现】
- GET/POST /api/prompts ✅
- GET /api/prompt-categories ✅
- PUT /api/prompts/<id> ✅
- POST /api/prompts/<id>/render ✅
"""

Feature: 提示词库管理
  作为用户
  我希望管理提示词模板
  以便在任务执行中使用

  Scenario: 查看提示词列表
    Given 系统中存在多个提示词
    When 用户访问提示词库页面
    Then 应显示所有提示词
    And 每个提示词应显示分类
    And 应显示提示词名称和描述

  Scenario: 按分类筛选提示词
    Given 提示词有多个分类
    When 用户选择某个分类
    Then 应只显示该分类的提示词
    And 分类列表应准确

  Scenario: 创建新提示词
    Given 用户已填写提示词信息
    When 用户点击 "创建"
    Then 提示词应创建成功
    And 系统应分配唯一 code
    And 提示词应出现在列表中

  Scenario: 编辑提示词
    Given 用户已选择一个提示词
    When 用户修改内容并保存
    Then 提示词应更新成功
    And 版本号应递增
    And 应保留历史版本

  Scenario: 删除提示词
    Given 用户已选择一个提示词
    When 用户点击 "删除"
    Then 提示词应被删除
    And 不应再出现在列表中

  Scenario: 渲染提示词
    Given 一个包含变量的提示词
    When 用户提供变量值
    And 点击 "渲染"
    Then 应生成渲染后的内容
    And 变量应被正确替换

  Scenario: 查看提示词分类
    Given 系统有多个提示词分类
    When 用户访问分类管理页面
    Then 应显示所有分类
    And 应显示每个分类的提示词数量
    And 用户应能创建新分类
