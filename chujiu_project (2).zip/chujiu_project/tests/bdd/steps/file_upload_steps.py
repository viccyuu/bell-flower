# -*- coding: utf-8 -*-
"""
文件上传步骤定义（异步版本）⭐
"""
from behave import given, when, then
import asyncio
import httpx


def get_async_client():
    """获取异步 HTTP 客户端"""
    if not hasattr(given, '_async_client'):
        given._async_client = httpx.AsyncClient(timeout=30.0)
    return given._async_client


@given('用户已登录系统')
async def step_impl(context):
    """前置条件：用户已登录（异步）⭐"""
    context.user_logged_in = True


@when('用户选择文件上传功能')
def step_impl(context):
    """操作：选择文件上传功能"""
    context.upload_viewed = True


@when('用户上传文件 "{filename}"')
async def step_impl(context):
    """操作：上传文件（异步）⭐"""
    client = get_async_client()
    
    # 模拟文件上传
    test_content = b'PK\x03\x04' + b'\x00' * 100
    files = {'file': (filename, test_content, 'application/octet-stream')}
    data = {'pluginCode': 'excel_vba_to_wps_js'}
    
    response = await client.post(f'{context.base_url}/api/uploads', files=files, data=data)
    context.upload_response = response.json()


@then('文件应该上传成功')
def step_impl(context):
    """验证：文件上传成功"""
    assert context.upload_response.get('code') == 'OK'
    assert 'uploadId' in context.upload_response.get('data', {})


@then('系统应该返回文件 ID')
def step_impl(context):
    """验证：返回文件 ID"""
    upload_id = context.upload_response.get('data', {}).get('uploadId')
    assert upload_id is not None
    context.upload_id = upload_id


# 清理
def cleanup():
    """清理异步客户端"""
    if hasattr(given, '_async_client'):
        asyncio.run(given._async_client.aclose())
        del given._async_client
