# -*- coding: utf-8 -*-
"""
SubJob 规划步骤定义（异步版本）⭐
"""
from behave import given, when, then
import asyncio
import httpx


def get_async_client():
    """获取异步 HTTP 客户端"""
    if not hasattr(given, '_async_client'):
        given._async_client = httpx.AsyncClient(timeout=30.0)
    return given._async_client


@given('主任务执行失败')
def step_impl(context):
    """前置条件：主任务执行失败"""
    context.main_job_failed = True


@when('系统触发 LLM 自主规划')
async def step_impl(context):
    """操作：触发 LLM 自主规划（异步）⭐"""
    client = get_async_client()
    
    payload = {
        'job_run_id': context.job_id,
        'failed_node': context.failed_node
    }
    
    response = await client.post(f'{context.base_url}/api/jobs/plan-recovery', json=payload)
    context.recovery_plan = response.json()


@then('系统应该生成 SubJob')
def step_impl(context):
    """验证：生成 SubJob"""
    assert context.recovery_plan.get('code') == 'OK'
    assert 'subjob_id' in context.recovery_plan.get('data', {})


@then('SubJob 应该继承主任务上下文')
def step_impl(context):
    """验证：SubJob 继承上下文"""
    # SubJob 上下文验证
    context.subjob_inherits_context = True


@then('SubJob 执行完成后应该回归主流程')
async def step_impl(context):
    """验证：SubJob 完成后回归主流程（异步）⭐"""
    client = get_async_client()
    
    # 轮询 SubJob 状态
    for _ in range(20):
        await asyncio.sleep(0.5)
        
        response = await client.get(f'{context.base_url}/api/subjobs/{context.subjob_id}')
        if response.status_code == 200:
            subjob_data = response.json()
            status = subjob_data.get('data', {}).get('status')
            
            if status == 'SUCCESS':
                break
    
    assert status == 'SUCCESS'


# 清理
def cleanup():
    """清理异步客户端"""
    if hasattr(given, '_async_client'):
        asyncio.run(given._async_client.aclose())
        del given._async_client
