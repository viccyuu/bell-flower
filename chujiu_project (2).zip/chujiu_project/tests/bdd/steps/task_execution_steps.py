# -*- coding: utf-8 -*-
"""
任务创建与执行功能的步骤定义（异步版本）⭐

实现 task_execution.feature 中的 Gherkin 步骤。
支持异步 HTTP 请求和数据库操作。
"""
from behave import given, when, then
import asyncio
import httpx
import time


# 异步 HTTP 客户端（单例）
_async_client = None


def get_async_client():
    """获取异步 HTTP 客户端"""
    global _async_client
    if _async_client is None:
        _async_client = httpx.AsyncClient(timeout=30.0)
    return _async_client


@given('用户已上传一个文件')
async def step_impl(context):
    """前置条件：已上传文件（异步）⭐"""
    client = get_async_client()
    
    # 模拟上传
    files = {'file': ('test.xlsm', b'PK\x03\x04' + b'\x00' * 100, 'application/vnd.ms-excel.sheet.macroEnabled.12')}
    data = {'pluginCode': 'excel_vba_to_wps_js'}
    
    response = await client.post(f"{context.base_url}/api/uploads", files=files, data=data)
    if response.status_code in [200, 201]:
        context.upload_data = response.json()
        context.upload_id = context.upload_data['data']['uploadId']


@when('用户选择 "Excel VBA 转 WPS JS" 模板')
def step_impl(context):
    """操作：选择模板"""
    context.selected_template = 'excel_vba_to_wps_js'


@when('点击 "创建任务" 按钮')
async def step_impl(context):
    """操作：创建任务（异步）⭐"""
    client = get_async_client()
    
    payload = {
        'taskTemplateCode': context.selected_template,
        'uploadId': context.upload_id,
        'runtimeParams': {}
    }
    
    response = await client.post(f"{context.base_url}/api/task-runs", json=payload)
    context.task_response = response
    if response.status_code in [200, 201]:
        context.task_data = response.json()
        context.task_id = context.task_data['data']['taskRunId']


@then('任务应该创建成功')
def step_impl(context):
    """验证：任务创建成功"""
    assert hasattr(context, 'task_data')
    assert context.task_data['code'] == 'OK'


@then('任务状态应为 "CREATED"')
def step_impl(context):
    """验证：任务状态"""
    assert context.task_data['data']['status'] == 'CREATED'


@then('系统应返回 taskRunId')
def step_impl(context):
    """验证：返回 taskRunId"""
    assert 'taskRunId' in context.task_data['data']


@given('存在一个状态为 "CREATED" 的任务')
async def step_impl(context):
    """前置条件：存在 CREATED 状态的任务（异步）⭐"""
    client = get_async_client()
    
    if not hasattr(context, 'task_id'):
        # 创建新任务
        files = {'file': ('test.xlsm', b'PK\x03\x04' + b'\x00' * 100, 'application/vnd.ms-excel.sheet.macroEnabled.12')}
        data = {'pluginCode': 'excel_vba_to_wps_js'}
        
        upload_response = await client.post(f"{context.base_url}/api/uploads", files=files, data=data)
        upload_id = upload_response.json()['data']['uploadId']
        
        payload = {
            'taskTemplateCode': 'excel_vba_to_wps_js',
            'uploadId': upload_id,
            'runtimeParams': {}
        }
        
        task_response = await client.post(f"{context.base_url}/api/task-runs", json=payload)
        context.task_id = task_response.json()['data']['taskRunId']


@when('用户点击 "执行任务" 按钮')
async def step_impl(context):
    """操作：执行任务（异步）⭐"""
    client = get_async_client()
    
    response = await client.post(f"{context.base_url}/api/task-runs/{context.task_id}/start")
    context.exec_response = response


@then('任务状态应该变为 "RUNNING"')
async def step_impl(context):
    """验证：任务状态变为 RUNNING（异步轮询）⭐"""
    client = get_async_client()
    
    # 轮询任务状态
    for _ in range(10):
        await asyncio.sleep(0.5)
        
        response = await client.get(f"{context.base_url}/api/task-runs/{context.task_id}")
        if response.status_code == 200:
            task_data = response.json()
            status = task_data['data']['status']
            
            if status == 'RUNNING':
                break
    
    assert status == 'RUNNING'


@then('任务最终状态应为 "SUCCESS"')
async def step_impl(context):
    """验证：任务最终状态为 SUCCESS（异步轮询）⭐"""
    client = get_async_client()
    
    # 轮询任务状态（最多 30 秒）
    for _ in range(60):
        await asyncio.sleep(0.5)
        
        response = await client.get(f"{context.base_url}/api/task-runs/{context.task_id}")
        if response.status_code == 200:
            task_data = response.json()
            status = task_data['data']['status']
            
            if status in ['SUCCESS', 'FAILED']:
                break
    
    assert status == 'SUCCESS', f"Task failed with status: {status}"


# 清理函数
def cleanup_async_client():
    """关闭异步 HTTP 客户端"""
    global _async_client
    if _async_client:
        asyncio.run(_async_client.aclose())
        _async_client = None
