# -*- coding: utf-8 -*-
"""
插件管理步骤定义（异步版本）⭐
"""
from behave import given, when, then
import asyncio
import httpx


def get_async_client():
    """获取异步 HTTP 客户端"""
    if not hasattr(given, '_async_client'):
        given._async_client = httpx.AsyncClient(timeout=30.0)
    return given._async_client


@given('插件目录存在')
def step_impl(context):
    """前置条件：插件目录存在"""
    context.plugin_dir_exists = True


@when('系统加载插件')
async def step_impl(context):
    """操作：系统加载插件（异步）⭐"""
    client = get_async_client()
    
    response = await client.get(f'{context.base_url}/api/plugins')
    context.plugins_response = response.json()


@then('插件列表应该包含内置插件')
def step_impl(context):
    """验证：插件列表包含内置插件"""
    plugins = context.plugins_response.get('data', [])
    plugin_codes = [p.get('code') for p in plugins]
    
    assert 'excel_vba_to_wps_js' in plugin_codes


@then('插件 DAG 应该正确加载')
def step_impl(context):
    """验证：插件 DAG 正确加载"""
    plugins = context.plugins_response.get('data', [])
    vba_plugin = next((p for p in plugins if p.get('code') == 'excel_vba_to_wps_js'), None)
    
    assert vba_plugin is not None
    assert 'dag' in vba_plugin or 'has_dag' in vba_plugin


# 清理
def cleanup():
    """清理异步客户端"""
    if hasattr(given, '_async_client'):
        asyncio.run(given._async_client.aclose())
        del given._async_client
