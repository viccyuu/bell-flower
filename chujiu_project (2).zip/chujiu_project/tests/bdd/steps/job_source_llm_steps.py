# -*- coding: utf-8 -*-
"""
LLM 来源 Job 步骤定义（异步版本）⭐
"""
from behave import given, when, then
import asyncio
import httpx


def get_async_client():
    """获取异步 HTTP 客户端"""
    if not hasattr(given, '_async_client'):
        given._async_client = httpx.AsyncClient(timeout=30.0)
    return given._async_client


@given('LLM 服务可用')
async def step_impl(context):
    """前置条件：LLM 服务可用（异步）⭐"""
    client = get_async_client()
    
    response = await client.get(f'{context.base_url}/health')
    assert response.status_code == 200
    context.llm_available = True


@when('用户请求 LLM 规划任务')
async def step_impl(context):
    """操作：请求 LLM 规划（异步）⭐"""
    client = get_async_client()
    
    payload = {
        'task_run_id': context.task_id,
        'prompt': '请规划任务执行步骤'
    }
    
    response = await client.post(f'{context.base_url}/api/llm/plan', json=payload)
    context.plan_response = response.json()


@then('系统应该返回规划结果')
def step_impl(context):
    """验证：返回规划结果"""
    assert context.plan_response.get('code') == 'OK'
    assert 'plan' in context.plan_response.get('data', {})


@then('规划结果应该包含子任务列表')
def step_impl(context):
    """验证：规划结果包含子任务"""
    plan = context.plan_response.get('data', {}).get('plan', {})
    assert 'subjobs' in plan or 'tasks' in plan


# 清理
def cleanup():
    """清理异步客户端"""
    if hasattr(given, '_async_client'):
        asyncio.run(given._async_client.aclose())
        del given._async_client
