# -*- coding: utf-8 -*-
"""
DAG Execution Steps - BDD 步骤定义 ⭐
"""
from behave import given, when, then
from app.scheduler import (
    DagScheduler,
    ExecutorRegistry,
    PythonExecutor,
    RecoveryService
)


@given('一个定义的 DAG')
def step_impl(context):
    """定义一个简单 DAG"""
    context.dag = {
        'job': {
            'code': 'test_job',
            'name': 'Test Job',
            'version': 1
        },
        'defaults': {
            'timeout_seconds': 60
        },
        'nodes': [
            {
                'code': 'step1',
                'name': 'Step 1',
                'action_type': 'PYTHON',
                'executor': 'python_executor',
                'config': {
                    'callable': 'tests.bdd.steps.dag_execution_steps.mock_success_function'
                }
            }
        ],
        'edges': []
    }


@given('一个带条件边的 DAG')
def step_impl(context):
    """定义一个带条件边的 DAG"""
    context.dag = {
        'job': {
            'code': 'conditional_job',
            'name': 'Conditional Job',
            'version': 1
        },
        'defaults': {
            'timeout_seconds': 60
        },
        'nodes': [
            {
                'code': 'step1',
                'name': 'Step 1',
                'action_type': 'PYTHON',
                'executor': 'python_executor',
                'config': {
                    'callable': 'tests.bdd.steps.dag_execution_steps.mock_success_function'
                }
            },
            {
                'code': 'step2',
                'name': 'Step 2',
                'action_type': 'PYTHON',
                'executor': 'python_executor',
                'config': {
                    'callable': 'tests.bdd.steps.dag_execution_steps.mock_success_function'
                }
            }
        ],
        'edges': [
            {'from': 'step1', 'to': 'step2', 'condition_expr': '{{ task.vars.enabled == true }}'}
        ]
    }


@given('一个带重试策略的 DAG')
def step_impl(context):
    """定义一个带重试策略的 DAG"""
    context.dag = {
        'job': {
            'code': 'retry_job',
            'name': 'Retry Job',
            'version': 1
        },
        'defaults': {
            'timeout_seconds': 60,
            'retry_policy': {
                'max_retries': 2,
                'backoff_seconds': 0,
                'retry_on': ['TEMPORARY_ERROR']
            }
        },
        'nodes': [
            {
                'code': 'step1',
                'name': 'Step 1',
                'action_type': 'PYTHON',
                'executor': 'python_executor',
                'config': {
                    'callable': 'tests.bdd.steps.dag_execution_steps.mock_retry_function'
                }
            }
        ],
        'edges': []
    }


@given('一个 DAG')
def step_impl(context):
    """定义一个通用 DAG"""
    context.dag = {
        'job': {
            'code': 'generic_job',
            'name': 'Generic Job',
            'version': 1
        },
        'defaults': {
            'timeout_seconds': 60,
            'continue_on_error': False
        },
        'nodes': [
            {
                'code': 'step1',
                'name': 'Step 1',
                'action_type': 'PYTHON',
                'executor': 'python_executor',
                'config': {
                    'callable': 'tests.bdd.steps.dag_execution_steps.mock_success_function'
                }
            },
            {
                'code': 'step2',
                'name': 'Step 2',
                'action_type': 'PYTHON',
                'executor': 'python_executor',
                'config': {
                    'callable': 'tests.bdd.steps.dag_execution_steps.mock_success_function'
                }
            }
        ],
        'edges': [
            {'from': 'step1', 'to': 'step2'}
        ]
    }


@given('一个中断的 DAG 执行')
def step_impl(context):
    """定义一个中断的 DAG"""
    context.interrupted_dag = {
        'job': {
            'code': 'interrupted_job',
            'name': 'Interrupted Job',
            'version': 1
        },
        'nodes': [],
        'edges': []
    }
    context.runtime_context = {
        'task': {'id': 1001, 'vars': {}},
        'job': {'id': 2001, 'vars': {}},
        'node': {
            'step1': {'status': 'SUCCESS', 'output': {'result': 'success'}},
            'step2': {'status': 'RUNNING', 'output': None}
        }
    }


@when('执行该 DAG')
def step_impl(context):
    """执行 DAG"""
    registry = ExecutorRegistry()
    registry.register('python_executor', PythonExecutor())
    
    scheduler = DagScheduler(executor_registry=registry)
    
    context.runtime_context = {
        'task': {'id': 1001, 'vars': {}},
        'job': {'id': 2001, 'vars': {}},
        'node': {}
    }
    
    context.result = scheduler.run(context.dag, context.runtime_context)


@when('条件满足时执行该 DAG')
def step_impl(context):
    """条件满足时执行 DAG"""
    registry = ExecutorRegistry()
    registry.register('python_executor', PythonExecutor())
    
    scheduler = DagScheduler(executor_registry=registry)
    
    context.runtime_context = {
        'task': {'id': 1001, 'vars': {'enabled': True}},
        'job': {'id': 2001, 'vars': {}},
        'node': {}
    }
    
    context.result = scheduler.run(context.dag, context.runtime_context)


@when('节点执行失败但可重试')
def step_impl(context):
    """节点执行失败但可重试"""
    registry = ExecutorRegistry()
    registry.register('python_executor', PythonExecutor())
    
    scheduler = DagScheduler(executor_registry=registry)
    
    context.runtime_context = {
        'task': {'id': 1001, 'vars': {}},
        'job': {'id': 2001, 'vars': {}},
        'node': {}
    }
    
    context.result = scheduler.run(context.dag, context.runtime_context)


@when('前置节点失败且 continue_on_error=false')
def step_impl(context):
    """前置节点失败"""
    registry = ExecutorRegistry()
    registry.register('python_executor', PythonExecutor())
    
    scheduler = DagScheduler(executor_registry=registry)
    
    context.runtime_context = {
        'task': {'id': 1001, 'vars': {}},
        'job': {'id': 2001, 'vars': {}},
        'node': {}
    }
    
    try:
        context.result = scheduler.run(context.dag, context.runtime_context)
    except Exception:
        pass


@when('执行恢复服务')
def step_impl(context):
    """执行恢复服务"""
    registry = ExecutorRegistry()
    registry.register('python_executor', PythonExecutor())
    
    scheduler = DagScheduler(executor_registry=registry)
    
    recovery = RecoveryService(
        scheduler=scheduler,
        dag_registry={'interrupted_job': context.interrupted_dag}
    )
    
    context.recovery_result = recovery.recover_all()


@then('所有节点应该成功执行')
def step_impl(context):
    """验证所有节点成功"""
    assert context.result['state']['job_status'] == 'SUCCESS'
    
    for node_code, node_state in context.result['state']['nodes'].items():
        assert node_state['status'] == 'SUCCESS', f"Node {node_code} failed"


@then('满足条件的节点应该执行')
def step_impl(context):
    """验证满足条件的节点执行"""
    assert context.result['state']['nodes']['step2']['status'] == 'SUCCESS'


@then('不满足条件的节点应该跳过')
def step_impl(context):
    """验证不满足条件的节点跳过"""
    assert context.result['state']['nodes']['step2']['status'] == 'SKIPPED'


@then('节点应该重试直到成功')
def step_impl(context):
    """验证节点重试直到成功"""
    assert context.result['state']['nodes']['step1']['status'] == 'SUCCESS'
    assert len(context.result['state']['nodes']['step1']['retry_history']) >= 1


@then('后续节点应该跳过')
def step_impl(context):
    """验证后续节点跳过"""
    if hasattr(context, 'result'):
        assert context.result['state']['nodes']['step2']['status'] == 'SKIPPED'


@then('RUNNING 节点应该重置为 PENDING')
def step_impl(context):
    """验证 RUNNING 节点重置"""
    # 验证恢复逻辑
    assert context.recovery_result is not None


@then('DAG 应该继续执行')
def step_impl(context):
    """验证 DAG 继续执行"""
    # 验证恢复后执行
    assert context.recovery_result is not None


# Mock 函数

def mock_success_function(**kwargs):
    """模拟成功函数"""
    return {'result': 'success'}


def mock_retry_function(**kwargs):
    """模拟重试函数"""
    if not hasattr(mock_retry_function, 'called'):
        mock_retry_function.called = True
        raise Exception('TEMPORARY_ERROR')
    
    return {'result': 'success after retry'}
