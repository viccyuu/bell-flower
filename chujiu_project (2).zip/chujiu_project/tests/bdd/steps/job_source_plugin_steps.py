# -*- coding: utf-8 -*-
"""
插件来源 Job 步骤定义（异步版本）⭐
"""
from behave import given, when, then
import asyncio
import httpx


def get_async_client():
    """获取异步 HTTP 客户端"""
    if not hasattr(given, '_async_client'):
        given._async_client = httpx.AsyncClient(timeout=30.0)
    return given._async_client


@given('插件系统已初始化')
async def step_impl(context):
    """前置条件：插件系统已初始化（异步）⭐"""
    client = get_async_client()
    
    response = await client.get(f'{context.base_url}/api/plugins')
    assert response.status_code == 200
    context.plugins_initialized = True


@when('用户选择插件 "{plugin_code}"')
def step_impl(context):
    """操作：选择插件"""
    context.selected_plugin = plugin_code


@when('用户创建插件任务')
async def step_impl(context):
    """操作：创建插件任务（异步）⭐"""
    client = get_async_client()
    
    payload = {
        'taskTemplateCode': context.selected_plugin,
        'uploadId': context.upload_id,
        'runtimeParams': {}
    }
    
    response = await client.post(f'{context.base_url}/api/task-runs', json=payload)
    context.task_response = response.json()


@then('插件任务应该创建成功')
def step_impl(context):
    """验证：插件任务创建成功"""
    assert context.task_response.get('code') == 'OK'
    assert 'taskRunId' in context.task_response.get('data', {})


@then('DAG 应该正确初始化')
def step_impl(context):
    """验证：DAG 正确初始化"""
    # DAG 初始化验证逻辑
    context.dag_initialized = True


# 清理
def cleanup():
    """清理异步客户端"""
    if hasattr(given, '_async_client'):
        asyncio.run(given._async_client.aclose())
        del given._async_client
