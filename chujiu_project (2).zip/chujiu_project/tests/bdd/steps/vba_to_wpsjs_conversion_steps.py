# -*- coding: utf-8 -*-
"""
Steps: VBA 到 WPS JS 转换流程（异步版本）⭐

实现 vba_to_wpsjs_conversion.feature 中的 Gherkin 步骤。
支持异步 HTTP 请求。
"""
from behave import given, when, then
import asyncio
import httpx
import time
import os

BASE_URL = 'http://127.0.0.1:5001'

# 异步 HTTP 客户端（单例）
_async_client = None


def get_async_client():
    """获取异步 HTTP 客户端"""
    global _async_client
    if _async_client is None:
        _async_client = httpx.AsyncClient(timeout=30.0)
    return _async_client


@given('服务正常运行')
async def step_impl(context):
    """前置条件：服务正常运行（异步）⭐"""
    client = get_async_client()
    
    response = await client.get(f'{BASE_URL}/health', timeout=5)
    assert response.status_code == 200
    assert response.json().get('status') == 'healthy'
    context.service_healthy = True


@given('插件 "excel_vba_to_wps_js" 已注册')
async def step_impl(context):
    """前置条件：插件已注册（异步）⭐"""
    client = get_async_client()
    
    response = await client.get(f'{BASE_URL}/api/plugins', timeout=5)
    plugins = response.json().get('data', [])
    plugin = next((p for p in plugins if p.get('code') == 'excel_vba_to_wps_js'), None)
    assert plugin is not None
    context.plugin_registered = True


@given('用户已访问系统')
def step_impl(context):
    """前置条件：用户已访问系统"""
    context.user_logged_in = True


@when('用户上传 Excel 文件 "{filename}"')
async def step_impl(context):
    """操作：上传 Excel 文件（异步）⭐"""
    client = get_async_client()
    
    file_path = os.path.join(
        os.path.dirname(__file__),
        '..', '..', '..', '..',
        'chujiu_design',
        filename
    )
    
    if os.path.exists(file_path):
        with open(file_path, 'rb') as f:
            files = {'file': (filename, f, 'application/vnd.ms-excel.sheet.macroEnabled.12')}
            data = {'pluginCode': 'excel_vba_to_wps_js'}
            response = await client.post(f'{BASE_URL}/api/uploads', files=files, data=data)
            context.upload_response = response.json()
    else:
        # 使用模拟文件
        test_content = b'PK\x03\x04' + b'\x00' * 100
        files = {'file': ('test.xlsm', test_content, 'application/vnd.ms-excel.sheet.macroEnabled.12')}
        data = {'pluginCode': 'excel_vba_to_wps_js'}
        response = await client.post(f'{BASE_URL}/api/uploads', files=files, data=data)
        context.upload_response = response.json()


@when('选择插件 "excel_vba_to_wps_js"')
def step_impl(context):
    """操作：选择插件"""
    context.selected_plugin = 'excel_vba_to_wps_js'


@when('用户点击"创建任务"')
async def step_impl(context):
    """操作：点击创建任务（异步）⭐"""
    client = get_async_client()
    
    upload_id = context.upload_response.get('data', {}).get('uploadId')
    
    payload = {
        'taskTemplateCode': 'excel_vba_to_wps_js',
        'uploadId': upload_id,
        'runtimeParams': {}
    }
    
    response = await client.post(f'{BASE_URL}/api/task-runs', json=payload)
    context.task_response = response.json()


@when('任务已创建')
def step_impl(context):
    """前置条件：任务已创建"""
    # 任务已在之前步骤创建
    pass


@when('用户点击"详情"按钮')
def step_impl(context):
    """操作：点击详情按钮"""
    # E2E 测试中由 Playwright 处理
    context.detail_viewed = True


@when('任务详情已查看')
def step_impl(context):
    """前置条件：任务详情已查看"""
    context.detail_viewed = True


@when('用户点击"执行"按钮')
async def step_impl(context):
    """操作：点击执行按钮（异步）⭐"""
    client = get_async_client()
    
    task_id = context.task_response.get('data', {}).get('taskRunId')
    
    response = await client.post(f'{BASE_URL}/api/task-runs/{task_id}/start')
    context.exec_response = response


@then('转换流程应该成功完成')
async def step_impl(context):
    """验证：转换流程成功完成（异步轮询）⭐"""
    client = get_async_client()
    
    task_id = context.task_response.get('data', {}).get('taskRunId')
    
    # 轮询任务状态（最多 60 秒）
    for _ in range(120):
        await asyncio.sleep(0.5)
        
        response = await client.get(f'{BASE_URL}/api/task-runs/{task_id}')
        if response.status_code == 200:
            task_data = response.json()
            status = task_data['data']['status']
            
            if status in ['SUCCESS', 'FAILED']:
                break
    
    assert status == 'SUCCESS', f"Task failed with status: {status}"
    context.conversion_completed = True


@then('应该生成 WPS JS 文件')
async def step_impl(context):
    """验证：生成 WPS JS 文件（异步）⭐"""
    client = get_async_client()
    
    task_id = context.task_response.get('data', {}).get('taskRunId')
    
    # 获取任务详情
    response = await client.get(f'{BASE_URL}/api/task-runs/{task_id}')
    task_data = response.json()
    
    # 验证产物
    artifacts = task_data.get('data', {}).get('artifacts', [])
    js_artifact = next((a for a in artifacts if a.get('artifact_type') == 'OUTPUT_FILE'), None)
    
    assert js_artifact is not None, "No JS output file found"
    context.js_file_generated = True


@then('用户应该能够下载转换后的文件')
async def step_impl(context):
    """验证：用户可以下载文件（异步）⭐"""
    client = get_async_client()
    
    task_id = context.task_response.get('data', {}).get('taskRunId')
    
    # 获取任务详情
    response = await client.get(f'{BASE_URL}/api/task-runs/{task_id}')
    task_data = response.json()
    
    artifacts = task_data.get('data', {}).get('artifacts', [])
    js_artifact = next((a for a in artifacts if a.get('artifact_type') == 'OUTPUT_FILE'), None)
    
    assert js_artifact is not None
    assert 'download_url' in js_artifact or 'file_path' in js_artifact
    
    context.download_available = True


# 清理函数
def cleanup_async_client():
    """关闭异步 HTTP 客户端"""
    global _async_client
    if _async_client:
        asyncio.run(_async_client.aclose())
        _async_client = None
