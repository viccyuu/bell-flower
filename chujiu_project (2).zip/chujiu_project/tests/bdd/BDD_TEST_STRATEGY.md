# BDD 测试方案 - 任务运行模块

**版本**: v2.0  
**创建时间**: 2026-03-14 10:09  
**设计依据**: 任务运行模块完整设计_v2.md  
**测试范围**: 主 Job 双来源 + LLM 自主规划 SubJob

---

## 📋 测试目标

验证任务运行模块支持：
1. ✅ 插件管理引入的主 Job 创建和执行
2. ✅ LLM 规划的主线任务创建和执行
3. ✅ 两种来源的主 Job 都支持 LLM 自行规划 SubJob
4. ✅ SubJob 完成后恢复主 Job 执行
5. ✅ 统一调度器正确处理所有 Job 类型

---

## 🎯 测试策略

### 测试层次

| 层次 | 测试类型 | 覆盖范围 | 用例数 |
|------|---------|---------|--------|
| L1 | 单元件测试 | Repository、Scheduler | 20 |
| L2 | 集成测试 | API 端点 | 15 |
| L3 | BDD 测试 | 业务场景 | 12 |
| L4 | E2E 测试 | 完整流程 | 8 |

### 测试重点

**主 Job 来源 1: 插件管理引入**
- ✅ 从 PLUGIN_DAG 加载节点
- ✅ 创建 JobRun（job_source='PLUGIN'）
- ✅ 创建 NodeRun（17 个）
- ✅ 执行主 Job
- ✅ 触发 LLM 自主规划

**主 Job 来源 2: LLM 规划**
- ✅ 接收 LLM 生成的 DAG
- ✅ 创建 JobRun（job_source='LLM'）
- ✅ 创建 NodeRun（N 个）
- ✅ 执行主 Job
- ✅ 触发 LLM 自主规划

**SubJob 机制**
- ✅ 验证父 Job 是主 Job
- ✅ 创建 SubJob（is_sub_job=True）
- ✅ 执行 SubJob
- ✅ SubJob 完成回调
- ✅ 恢复主 Job 执行

---

## 📁 Feature 文件结构

```
tests/bdd/features/
├── job_source_plugin.feature      # 插件来源主 Job
├── job_source_llm.feature         # LLM 来源主 Job
├── subjob_planning.feature        # LLM 自主规划 SubJob
└── task_scheduler.feature         # 统一调度器
```

---

## 🧪 Feature 1: 插件来源主 Job

**文件**: `job_source_plugin.feature`

**场景**:
1. 成功创建插件来源主 Job
2. 主 Job 包含正确的节点数
3. 节点状态正确初始化
4. 执行主 Job 成功
5. 节点失败触发 LLM 规划

**覆盖方法**:
- `task_repository.create_with_plugin()`
- `task_scheduler.execute_job()`
- `task_scheduler.trigger_llm_planning()`

---

## 🧪 Feature 2: LLM 来源主 Job

**文件**: `job_source_llm.feature`

**场景**:
1. 成功创建 LLM 来源主 Job
2. 主 Job 包含 LLM 生成的节点
3. DAG 定义正确存储
4. 执行主 Job 成功
5. 节点失败触发 LLM 规划

**覆盖方法**:
- `task_repository.create_with_llm_dag()`
- `task_scheduler.execute_job()`
- `task_scheduler.trigger_llm_planning()`

---

## 🧪 Feature 3: LLM 自主规划 SubJob

**文件**: `subjob_planning.feature`

**场景**:
1. 主 Job 节点执行失败
2. 检查节点配置（planning_enabled=True）
3. 触发 LLM 自主规划
4. LLM 生成 SubJob DAG
5. 创建 SubJob（is_sub_job=True）
6. SubJob 关联父 Job
7. 执行 SubJob
8. SubJob 完成回调
9. 恢复主 Job 执行

**覆盖方法**:
- `routes_subjob.create_subjob()`
- `routes_subjob.complete_subjob()`
- `task_scheduler.trigger_llm_planning()`

---

## 🧪 Feature 4: 统一调度器

**文件**: `task_scheduler.feature`

**场景**:
1. 调度器执行插件来源主 Job
2. 调度器执行 LLM 来源主 Job
3. 调度器执行 SubJob
4. 条件边正确判断
5. 重试策略正确执行
6. SubJob 完成后恢复主 Job

**覆盖方法**:
- `task_scheduler.execute_task()`
- `task_scheduler.execute_job()`
- `task_scheduler._check_conditions()`
- `task_scheduler._should_retry()`

---

## 📊 测试数据

### 插件来源主 Job 数据

```python
{
    "plugin_code": "excel_vba_to_wps_js",
    "upload_id": 1,
    "expected_nodes": 17,
    "expected_job_source": "PLUGIN",
    "expected_is_sub_job": False
}
```

### LLM 来源主 Job 数据

```python
{
    "llm_dag": {
        "job": {"code": "llm_job", "name": "LLM Planned Job"},
        "nodes": [...],
        "edges": [...]
    },
    "upload_id": 1,
    "expected_job_source": "LLM",
    "expected_is_sub_job": False
}
```

### SubJob 数据

```python
{
    "parent_job_id": 1,
    "failed_node_code": "vba_to_vba_ast",
    "error_context": {...},
    "subjob_dag": {...},
    "expected_is_sub_job": True,
    "expected_parent_job_id": 1
}
```

---

## ✅ 验收标准

### 插件来源主 Job

- [ ] JobRun 创建成功
- [ ] job_source='PLUGIN'
- [ ] is_sub_job=False
- [ ] 创建 17 个 NodeRun
- [ ] 节点状态为 PENDING
- [ ] 执行成功

### LLM 来源主 Job

- [ ] JobRun 创建成功
- [ ] job_source='LLM'
- [ ] is_sub_job=False
- [ ] 创建 N 个 NodeRun
- [ ] dag_json 正确存储
- [ ] 执行成功

### SubJob 机制

- [ ] 验证父 Job 是主 Job
- [ ] SubJob 创建成功
- [ ] is_sub_job=True
- [ ] parent_job_id 正确关联
- [ ] SubJob 执行成功
- [ ] SubJob 完成回调成功
- [ ] 主 Job 恢复执行

### 统一调度器

- [ ] 执行插件来源主 Job
- [ ] 执行 LLM 来源主 Job
- [ ] 执行 SubJob
- [ ] 条件边判断正确
- [ ] 重试策略正确
- [ ] SubJob 完成后恢复主 Job

---

## 📝 测试执行

### 运行 BDD 测试

```bash
# 运行所有 BDD 测试
behave tests/bdd/features/

# 运行特定 Feature
behave tests/bdd/features/job_source_plugin.feature
behave tests/bdd/features/job_source_llm.feature
behave tests/bdd/features/subjob_planning.feature
behave tests/bdd/features/task_scheduler.feature

# 运行特定场景
behave tests/bdd/features/job_source_plugin.feature -n "成功创建插件来源主 Job"
```

### 生成测试报告

```bash
# HTML 报告
behave tests/bdd/features/ --format html --outfile tests/bdd/report.html

# JSON 报告
behave tests/bdd/features/ --format json --outfile tests/bdd/report.json
```

---

## 📋 依赖关系

### 前置条件

1. ✅ 数据库已初始化
2. ✅ 插件 DAG 已注册
3. ✅ LLM executor 可用
4. ✅ 测试数据准备完成

### 后置条件

1. ✅ 测试数据清理
2. ✅ JobRun/NodeRun 记录清理
3. ✅ 测试报告生成

---

**方案生成时间**: 2026-03-14 10:09  
**设计人**: 小爪 🦞  
**状态**: ✅ **方案完成**
