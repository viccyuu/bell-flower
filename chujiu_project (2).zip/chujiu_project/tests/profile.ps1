# PowerShell 配置文件
# 用于设置 UTF-8 编码和测试环境

# 设置输出编码为 UTF-8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 设置输入编码为 UTF-8
[Console]::InputEncoding = [System.Text.Encoding]::UTF8

# 设置当前目录
Set-Location C:\Users\yoyo\.openclaw\workspace\chujiu_design\chujiu_project

# 显示配置信息
Write-Host "PowerShell 编码配置已加载" -ForegroundColor Green
Write-Host "输出编码：$([Console]::OutputEncoding.EncodingName)" -ForegroundColor Cyan
Write-Host "输入编码：$([Console]::InputEncoding.EncodingName)" -ForegroundColor Cyan
Write-Host "当前目录：$(Get-Location)" -ForegroundColor Cyan

# 测试命令
function Test-E2E {
    param(
        [string]$TestFile = "tests/e2e/test_smoke.py"
    )
    Write-Host "运行 E2E 测试：$TestFile" -ForegroundColor Yellow
    py -m pytest $TestFile -v
}

# 帮助信息
Write-Host "`n可用命令:" -ForegroundColor Yellow
Write-Host "  Test-E2E              - 运行 E2E 测试（默认 test_smoke.py）" -ForegroundColor White
Write-Host "  Test-E2E -TestFile X  - 运行指定的 E2E 测试文件" -ForegroundColor White
