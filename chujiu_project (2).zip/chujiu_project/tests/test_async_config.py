# -*- coding: utf-8 -*-
"""
异步配置测试

验证 pytest-asyncio 配置是否正确
"""
import pytest
import asyncio


@pytest.mark.asyncio
async def test_async_fixture():
    """测试异步 fixture 是否工作"""
    # 简单的异步测试
    await asyncio.sleep(0.01)
    assert True


@pytest.mark.asyncio
async def test_async_basic():
    """测试基本异步功能"""
    async def async_add(a, b):
        await asyncio.sleep(0.001)
        return a + b
    
    result = await async_add(1, 2)
    assert result == 3


def test_sync_basic():
    """测试同步功能仍可用"""
    assert 1 + 1 == 2
