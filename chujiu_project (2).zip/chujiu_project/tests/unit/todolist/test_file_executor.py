# -*- coding: utf-8 -*-
"""
单元测试 - File Executor

测试 app/todolist/executors/file_executor.py
"""
import pytest
import tempfile
import os
from pathlib import Path
from app.todolist.executors.file_executor import FileExecutor
from app.todolist.task_context import TaskContext


class TestFileExecutor:
    """文件执行器测试"""
    
    def setup_method(self):
        """每个测试前执行"""
        self.executor = FileExecutor()
        self.test_dir = tempfile.mkdtemp()
        self.test_file = os.path.join(self.test_dir, 'test.txt')
    
    def teardown_method(self):
        """每个测试后执行"""
        if os.path.exists(self.test_dir):
            import shutil
            shutil.rmtree(self.test_dir)
    
    def test_write_file(self):
        """测试写入文件"""
        context = TaskContext(file_id=1, macro_id=1)
        context.extra = {
            'operation': 'write',
            'path': self.test_file,
            'content': 'test content'
        }
        
        result = self.executor.execute(context)
        
        assert result.success == True
        assert os.path.exists(self.test_file)
        with open(self.test_file, 'r') as f:
            assert f.read() == 'test content'
    
    def test_read_file(self):
        """测试读取文件"""
        # 先写入
        with open(self.test_file, 'w') as f:
            f.write('test content')
        
        # 再读取
        context = TaskContext(file_id=1, macro_id=1)
        context.extra = {
            'operation': 'read',
            'path': self.test_file
        }
        
        result = self.executor.execute(context)
        
        assert result.success == True
        assert 'test content' in result.output['result']
    
    def test_list_dir(self):
        """测试列出目录"""
        # 创建测试文件
        test_file1 = os.path.join(self.test_dir, 'file1.txt')
        test_file2 = os.path.join(self.test_dir, 'file2.txt')
        with open(test_file1, 'w') as f:
            f.write('test1')
        with open(test_file2, 'w') as f:
            f.write('test2')
        
        # 列出目录
        context = TaskContext(file_id=1, macro_id=1)
        context.extra = {
            'operation': 'list',
            'path': self.test_dir
        }
        
        result = self.executor.execute(context)
        
        assert result.success == True
        assert 'file1.txt' in result.output['result']
        assert 'file2.txt' in result.output['result']
    
    def test_read_file_not_found(self):
        """测试读取不存在的文件"""
        context = TaskContext(file_id=1, macro_id=1)
        context.extra = {
            'operation': 'read',
            'path': '/nonexistent/file.txt'
        }
        
        result = self.executor.execute(context)
        
        assert result.success == False
        assert 'not found' in result.error.lower()
    
    def test_write_file_missing_content(self):
        """测试写入文件缺少内容"""
        context = TaskContext(file_id=1, macro_id=1)
        context.extra = {
            'operation': 'write',
            'path': self.test_file
        }
        
        result = self.executor.execute(context)
        
        assert result.success == False
        assert 'content is required' in result.error
