# -*- coding: utf-8 -*-
"""
单元测试 - Bash Executor

测试 app/todolist/executors/bash_executor.py
"""
import pytest
from app.todolist.executors.bash_executor import BashExecutor
from app.todolist.task_context import TaskContext


class TestBashExecutor:
    """Bash 执行器测试"""
    
    def setup_method(self):
        """每个测试前执行"""
        self.executor = BashExecutor(timeout=10)
    
    def test_execute_echo(self):
        """测试执行 echo 命令"""
        context = TaskContext(file_id=1, macro_id=1)
        context.extra = {
            'command': 'echo hello'
        }
        
        result = self.executor.execute(context)
        
        assert result.success == True
        assert 'hello' in result.output['output']
    
    def test_execute_pwd(self):
        """测试执行 pwd 命令"""
        context = TaskContext(file_id=1, macro_id=1)
        context.extra = {
            'command': 'pwd'
        }
        
        result = self.executor.execute(context)
        
        assert result.success == True
        assert result.output['output'] != ''
    
    def test_execute_missing_command(self):
        """测试执行缺少命令"""
        context = TaskContext(file_id=1, macro_id=1)
        context.extra = {}
        
        result = self.executor.execute(context)
        
        assert result.success == False
        assert 'command is required' in result.error
    
    def test_execute_invalid_command(self):
        """测试执行无效命令"""
        context = TaskContext(file_id=1, macro_id=1)
        context.extra = {
            'command': 'nonexistent_command_xyz'
        }
        
        result = self.executor.execute(context)
        
        # 命令不存在应该失败
        assert result.success == False
