# -*- coding: utf-8 -*-
"""
单元测试 - Heartbeat Task Query

测试 app/heartbeat/task_query.py
"""
import pytest
from datetime import datetime, timedelta
from app.heartbeat.task_query import TaskRunQuery, task_query
from app.models import TaskRun
from app.extensions import db


class TestTaskRunQuery:
    """TaskRun 查询器测试"""
    
    def test_get_pending_tasks(self, app_context, db_session):
        """测试获取待执行任务"""
        # 创建测试任务
        task1 = TaskRun(
            task_template_id=1,
            status='RUNNING',
            started_at=datetime.utcnow()
        )
        task2 = TaskRun(
            task_template_id=1,
            status='RUNNING',
            started_at=datetime.utcnow() - timedelta(minutes=10)
        )
        task3 = TaskRun(
            task_template_id=1,
            status='SUCCESS',
            started_at=datetime.utcnow()
        )
        
        db_session.add_all([task1, task2, task3])
        db_session.commit()
        
        # 测试查询
        tasks = task_query.get_pending_tasks(cutoff_minutes=5)
        
        # 验证结果
        assert len(tasks) >= 1
        assert all(t.status == 'RUNNING' for t in tasks)
    
    def test_get_task_with_jobs(self, app_context, db_session):
        """测试获取任务及其 Jobs"""
        # 创建测试任务
        task = TaskRun(
            task_template_id=1,
            status='RUNNING'
        )
        db_session.add(task)
        db_session.commit()
        
        # 测试查询
        result = task_query.get_task_with_jobs(task.id)
        
        # 验证结果
        assert result != {}
        assert 'task_run' in result
        assert 'job_runs' in result
        assert 'node_runs' in result
    
    def test_get_task_with_jobs_not_found(self, app_context, db_session):
        """测试获取不存在的任务"""
        result = task_query.get_task_with_jobs(99999)
        assert result == {}


class TestTaskRunQueryGlobal:
    """全局查询器实例测试"""
    
    def test_global_instance_exists(self):
        """测试全局实例存在"""
        assert task_query is not None
        assert isinstance(task_query, TaskRunQuery)
