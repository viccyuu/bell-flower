# -*- coding: utf-8 -*-
"""
第三阶段测试：内置插件实现

异步测试版本（FastAPI 迁移准备）⭐
"""
import pytest
import sys
import os
import asyncio

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestPlugin1Config:
    """V3.1: 插件一 DAG 定义测试"""
    
    def test_plugin1_dag_structure(self):
        """测试插件一 DAG 结构"""
        from app.plugins.excel_vba_to_wps_js.config import PLUGIN_DAG
        
        assert 'nodes' in PLUGIN_DAG
        assert 'edges' in PLUGIN_DAG
        assert len(PLUGIN_DAG['nodes']) > 0
        assert len(PLUGIN_DAG['edges']) > 0
    
    def test_plugin1_meta(self):
        """测试插件一元数据"""
        from app.plugins.excel_vba_to_wps_js.config import PLUGIN_META
        
        assert PLUGIN_META['code'] == 'excel_vba_to_wps_js'
        assert 'allowed_extensions' in PLUGIN_META


class TestPlugin1Handlers:
    """V3.2: 插件一 Node 处理器测试"""
    
    def test_handlers_import(self):
        """测试处理器导入"""
        from app.plugins.excel_vba_to_wps_js.handler import (
            validate_upload,
            extract_vba_macros,
            analyze_macro_dependencies,
        )
        assert validate_upload is not None
        assert extract_vba_macros is not None
        assert analyze_macro_dependencies is not None
    
    @pytest.mark.asyncio
    async def test_validate_upload_handler(self):
        """测试 validate_upload 处理器（异步）⭐"""
        from app.plugins.excel_vba_to_wps_js.handler import validate_upload
        
        # 模拟输入数据
        input_data = {
            'upload_id': 1,
            'allowed_extensions': ['.xlsm', '.xls', '.xlsx']
        }
        
        # 处理器现在是同步函数，可以直接调用
        result = validate_upload(input_data)
        
        # 验证结果结构
        assert isinstance(result, dict)
        assert 'validated' in result or 'error' in result


class TestPluginDAGValidation:
    """V3.3: DAG 验证测试"""
    
    def test_dag_validator_import(self):
        """测试 DAG 验证器导入"""
        from app.todolist.domain.dag import DagValidator
        assert DagValidator is not None
    
    def test_dag_validation(self):
        """测试 DAG 验证"""
        from app.todolist.domain.dag import DagValidator
        
        dag = {
            'job': {'code': 'test', 'name': 'Test'},
            'nodes': [
                {'code': 'node1', 'action_type': 'PYTHON', 'name': 'Node 1'}
            ],
            'edges': []
        }
        
        result = DagValidator.validate_dag(dag)
        
        assert result['valid'] is True
        assert len(result['errors']) == 0


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
