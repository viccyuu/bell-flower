# -*- coding: utf-8 -*-
"""
第二阶段测试：todolist 核心引擎

异步测试版本（FastAPI 迁移准备）⭐
"""
import pytest
import sys
import os
import asyncio

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestDependencyGraph:
    """V2.1: DAG 拓扑排序测试"""
    
    def test_topological_sort(self):
        """测试拓扑排序"""
        from app.todolist.dependency_graph import DependencyGraph
        
        graph = DependencyGraph()
        graph.add_node(1)
        graph.add_node(2)
        graph.add_node(3)
        graph.add_dependency(2, 1)  # 2 依赖 1
        graph.add_dependency(3, 2)  # 3 依赖 2
        
        order, has_cycle = graph.topological_sort()
        
        assert not has_cycle
        assert order == [1, 2, 3]
    
    def test_topological_sort_parallel(self):
        """测试并行节点拓扑排序"""
        from app.todolist.dependency_graph import DependencyGraph
        
        graph = DependencyGraph()
        graph.add_node(1)
        graph.add_node(2)
        graph.add_node(3)
        graph.add_node(4)
        graph.add_dependency(3, 1)  # 3 依赖 1
        graph.add_dependency(3, 2)  # 3 依赖 2
        graph.add_dependency(4, 3)  # 4 依赖 3
        
        order, has_cycle = graph.topological_sort()
        
        assert not has_cycle
        assert order.index(1) < order.index(3)
        assert order.index(2) < order.index(3)


class TestScheduler:
    """V2.2: 调度器测试"""
    
    @pytest.mark.asyncio
    async def test_scheduler_import(self):
        """测试调度器可以导入（异步）⭐"""
        from app.scheduler.task_scheduler import TaskScheduler
        assert TaskScheduler is not None
    
    @pytest.mark.asyncio
    async def test_execute_node_async(self, db_session):
        """测试节点执行（异步）⭐"""
        from app.scheduler.task_scheduler import TaskScheduler
        
        scheduler = TaskScheduler()
        # 异步测试可以 await 异步方法
        # 具体测试逻辑根据实际实现调整
        assert scheduler is not None


class TestLLMExecutor:
    """V2.3: LLM Executor 测试"""
    
    @pytest.mark.asyncio
    async def test_llm_executor_import(self):
        """测试 LLMExecutor 可以导入（异步）⭐"""
        from app.todolist.llm_executor import LLMExecutor
        assert LLMExecutor is not None
    
    @pytest.mark.asyncio
    async def test_llm_executor_init(self):
        """测试 LLMExecutor 初始化（异步）⭐"""
        from app.todolist.llm_executor import LLMExecutor
        from pathlib import Path
        
        executor = LLMExecutor(
            config_path=Path(".chujiu/config.json"),
            workspace=Path.cwd(),
        )
        assert executor is not None


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
