# -*- coding: utf-8 -*-
"""
单元测试 - Cron Task Execution

测试 app/cron/task_execution.py
"""
import pytest
from app.cron.task_execution import TaskExecutionService, task_execution
from app.models import TaskRun, JobRun, NodeRun
from app.extensions import db


class TestTaskExecutionService:
    """任务执行服务测试"""
    
    def test_execute_task_run_not_found(self, app_context, db_session):
        """测试执行不存在的 TaskRun"""
        result = task_execution.execute_task_run(99999)
        assert result['success'] == False
        assert 'not found' in result['error']
    
    def test_execute_job_run_not_found(self, app_context, db_session):
        """测试执行不存在的 JobRun"""
        result = task_execution.execute_job_run(99999)
        assert result['success'] == False
        assert 'not found' in result['error']
    
    def test_execute_node_run_not_found(self, app_context, db_session):
        """测试执行不存在的 NodeRun"""
        result = task_execution.execute_node_run(99999)
        assert result['success'] == False
        assert 'not found' in result['error']
    
    def test_execute_task_run_with_jobs(self, app_context, db_session):
        """测试执行有 Jobs 的 TaskRun"""
        # 创建测试数据
        task = TaskRun(
            task_template_id=1,
            status='RUNNING'
        )
        db_session.add(task)
        db_session.commit()
        
        # 测试执行
        result = task_execution.execute_task_run(task.id)
        
        # 验证结果
        assert result['success'] == True
        assert result['task_run_id'] == task.id


class TestTaskExecutionServiceGlobal:
    """全局执行服务实例测试"""
    
    def test_global_instance_exists(self):
        """测试全局实例存在"""
        assert task_execution is not None
        assert isinstance(task_execution, TaskExecutionService)
