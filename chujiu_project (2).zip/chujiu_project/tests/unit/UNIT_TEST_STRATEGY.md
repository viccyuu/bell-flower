# 单元测试方案 - 任务运行模块

**版本**: v2.0  
**创建时间**: 2026-03-14 10:09  
**设计依据**: 任务运行模块完整设计_v2.md  
**测试范围**: 主 Job 双来源 + LLM 自主规划 SubJob

---

## 📋 测试目标

验证任务运行模块的单元测试覆盖：
1. ✅ Repository 层（task_repository.py）
2. ✅ Scheduler 层（task_scheduler.py）
3. ✅ Routes 层（routes_task.py, routes_subjob.py）
4. ✅ Models 层（JobRun, NodeRun）

---

## 🎯 测试策略

### 测试分层

| 层次 | 测试对象 | 测试类型 | 用例数 |
|------|---------|---------|--------|
| L1 | Repository | 单元测试 | 10 |
| L2 | Scheduler | 单元测试 | 8 |
| L3 | Routes | 集成测试 | 12 |
| L4 | Models | 单元测试 | 5 |

### 测试重点

**Repository 层**:
- ✅ create_with_plugin() - 插件来源主 Job
- ✅ create_with_llm_dag() - LLM 来源主 Job
- ✅ _create_job_from_plugin_dag() - 从插件 DAG 创建 Job

**Scheduler 层**:
- ✅ execute_task() - 执行任务
- ✅ execute_job() - 执行 Job
- ✅ trigger_llm_planning() - 触发 LLM 规划
- ✅ _check_conditions() - 条件边判断

**Routes 层**:
- ✅ create_task_run() - 创建任务
- ✅ start_task_run() - 启动任务
- ✅ create_subjob() - 创建 SubJob
- ✅ complete_subjob() - SubJob 完成回调

---

## 📁 测试文件结构

```
tests/unit/
├── service/
│   ├── test_task_repository.py       # Repository 测试
│   ├── test_task_scheduler.py        # Scheduler 测试
│   └── test_job_models.py            # Models 测试
└── api/
    ├── test_task_routes.py           # Task Routes 测试
    └── test_subjob_routes.py         # SubJob Routes 测试
```

---

## 🧪 单元测试用例

### 1. test_task_repository.py

**测试类**: TestTaskRepository

| 用例 ID | 测试方法 | 测试场景 | 优先级 |
|--------|---------|---------|--------|
| UT-REPO-001 | test_create_with_plugin_success | 成功创建插件来源主 Job | P0 |
| UT-REPO-002 | test_create_with_plugin_job_source | 验证 job_source='PLUGIN' | P0 |
| UT-REPO-003 | test_create_with_plugin_nodes_count | 验证创建 17 个 NodeRun | P0 |
| UT-REPO-004 | test_create_with_llm_dag_success | 成功创建 LLM 来源主 Job | P0 |
| UT-REPO-005 | test_create_with_llm_dag_job_source | 验证 job_source='LLM' | P0 |
| UT-REPO-006 | test_create_with_llm_dag_stores_dag | 验证 dag_json 正确存储 | P1 |
| UT-REPO-007 | test_create_job_from_plugin_dag | 从插件 DAG 创建 Job | P0 |
| UT-REPO-008 | test_create_job_from_plugin_dag_nodes | 创建 NodeRun | P0 |
| UT-REPO-009 | test_create_with_plugin_not_found | 插件不存在 | P1 |
| UT-REPO-010 | test_create_with_invalid_dag | DAG 定义无效 | P1 |

---

### 2. test_task_scheduler.py

**测试类**: TestTaskScheduler

| 用例 ID | 测试方法 | 测试场景 | 优先级 |
|--------|---------|---------|--------|
| UT-SCHED-001 | test_execute_task_plugin_job | 执行插件来源主 Job | P0 |
| UT-SCHED-002 | test_execute_task_llm_job | 执行 LLM 来源主 Job | P0 |
| UT-SCHED-003 | test_execute_job_success | Job 执行成功 | P0 |
| UT-SCHED-004 | test_execute_job_node_failed | 节点执行失败 | P1 |
| UT-SCHED-005 | test_trigger_llm_planning_main_job | 主 Job 触发 LLM 规划 | P0 |
| UT-SCHED-006 | test_trigger_llm_planning_subjob | SubJob 不触发 LLM 规划 | P1 |
| UT-SCHED-007 | test_check_conditions_true | 条件边判断为真 | P1 |
| UT-SCHED-008 | test_check_conditions_false | 条件边判断为假 | P1 |

---

### 3. test_job_models.py

**测试类**: TestJobRunModel

| 用例 ID | 测试方法 | 测试场景 | 优先级 |
|--------|---------|---------|--------|
| UT-MODEL-001 | test_job_run_create_plugin | 创建插件来源 JobRun | P0 |
| UT-MODEL-002 | test_job_run_create_llm | 创建 LLM 来源 JobRun | P0 |
| UT-MODEL-003 | test_job_run_is_sub_job | 创建 SubJob | P0 |
| UT-MODEL-004 | test_job_run_parent_job_relation | SubJob 关联父 Job | P0 |
| UT-MODEL-005 | test_job_run_status_transitions | JobRun 状态转换 | P1 |

---

### 4. test_task_routes.py

**测试类**: TestTaskRoutes

| 用例 ID | 测试方法 | 测试场景 | 优先级 |
|--------|---------|---------|--------|
| UT-ROUTE-001 | test_create_task_run_plugin | 创建插件来源任务 | P0 |
| UT-ROUTE-002 | test_create_task_run_llm | 创建 LLM 来源任务 | P0 |
| UT-ROUTE-003 | test_start_task_run | 启动任务 | P0 |
| UT-ROUTE-004 | test_get_task_run_detail | 获取任务详情 | P0 |
| UT-ROUTE-005 | test_list_task_runs | 获取任务列表 | P1 |
| UT-ROUTE-006 | test_create_task_run_template_not_found | 模板不存在 | P1 |
| UT-ROUTE-007 | test_create_task_run_upload_not_found | 上传文件不存在 | P1 |
| UT-ROUTE-008 | test_create_task_run_idempotency | 幂等性检查 | P1 |

---

### 5. test_subjob_routes.py

**测试类**: TestSubJobRoutes

| 用例 ID | 测试方法 | 测试场景 | 优先级 |
|--------|---------|---------|--------|
| UT-SUBJOB-001 | test_create_subjob_success | 成功创建 SubJob | P0 |
| UT-SUBJOB-002 | test_create_subjob_is_sub_job | SubJob 标记正确 | P0 |
| UT-SUBJOB-003 | test_create_subjob_parent_job | SubJob 关联父 Job | P0 |
| UT-SUBJOB-004 | test_create_subjob_from_subjob | SubJob 创建 SubJob（应失败） | P1 |
| UT-SUBJOB-005 | test_complete_subjob_success | SubJob 成功完成 | P0 |
| UT-SUBJOB-006 | test_complete_subjob_failed | SubJob 失败完成 | P1 |
| UT-SUBJOB-007 | test_complete_subjob_resume_main_job | SubJob 完成恢复主 Job | P0 |
| UT-SUBJOB-008 | test_start_subjob | 启动 SubJob | P1 |

---

## 📊 测试覆盖要求

| 模块 | 覆盖率要求 | 实际覆盖 | 状态 |
|------|-----------|---------|------|
| task_repository.py | ≥90% | 待测试 | ⏳ |
| task_scheduler.py | ≥85% | 待测试 | ⏳ |
| routes_task.py | ≥80% | 待测试 | ⏳ |
| routes_subjob.py | ≥80% | 待测试 | ⏳ |
| models.py (JobRun/NodeRun) | ≥90% | 待测试 | ⏳ |

---

## 🚀 测试执行

### 运行单元测试

```bash
# 运行所有单元测试
pytest tests/unit/ -v

# 运行 Repository 测试
pytest tests/unit/service/test_task_repository.py -v

# 运行 Scheduler 测试
pytest tests/unit/service/test_task_scheduler.py -v

# 运行 Routes 测试
pytest tests/unit/api/test_task_routes.py -v
pytest tests/unit/api/test_subjob_routes.py -v

# 生成覆盖率报告
pytest tests/unit/ --cov=app --cov-report=html
```

### 生成测试报告

```bash
# HTML 报告
pytest tests/unit/ --html=tests/unit/report.html --self-contained-html

# XML 报告（CI/CD）
pytest tests/unit/ --junitxml=tests/unit/report.xml
```

---

## ✅ 验收标准

### Repository 层

- [ ] create_with_plugin() 测试通过
- [ ] create_with_llm_dag() 测试通过
- [ ] _create_job_from_plugin_dag() 测试通过
- [ ] 覆盖率 ≥90%

### Scheduler 层

- [ ] execute_task() 测试通过
- [ ] execute_job() 测试通过
- [ ] trigger_llm_planning() 测试通过
- [ ] 覆盖率 ≥85%

### Routes 层

- [ ] create_task_run() 测试通过
- [ ] start_task_run() 测试通过
- [ ] create_subjob() 测试通过
- [ ] complete_subjob() 测试通过
- [ ] 覆盖率 ≥80%

### Models 层

- [ ] JobRun 创建测试通过
- [ ] NodeRun 创建测试通过
- [ ] 关系测试通过
- [ ] 覆盖率 ≥90%

---

## 📝 测试数据

### 插件来源主 Job 测试数据

```python
{
    "plugin_code": "excel_vba_to_wps_js",
    "upload_id": 1,
    "expected_job_source": "PLUGIN",
    "expected_is_sub_job": False,
    "expected_nodes_count": 17
}
```

### LLM 来源主 Job 测试数据

```python
{
    "llm_dag": {
        "job": {"code": "llm_job", "name": "LLM Job"},
        "nodes": [...],
        "edges": [...]
    },
    "expected_job_source": "LLM",
    "expected_is_sub_job": False
}
```

### SubJob 测试数据

```python
{
    "parent_job_id": 1,
    "failed_node_code": "vba_to_vba_ast",
    "expected_is_sub_job": True,
    "expected_parent_job_id": 1
}
```

---

**方案生成时间**: 2026-03-14 10:09  
**设计人**: 小爪 🦞  
**状态**: ✅ **方案完成**
