# -*- coding: utf-8 -*-
"""
重试管理功能测试用例 ⭐

测试范围：
1. 单个节点重试 API
2. 批量重试 API
3. 重试历史查询
4. 重试策略更新
"""
import pytest
import asyncio
from typing import AsyncGenerator
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from fastapi.testclient import TestClient

from app import create_app
from app.database import Base, get_db
from app.models import TaskRun, JobRun, NodeRun
import json


# ========== Fixtures ==========

@pytest.fixture
def client():
    """创建测试客户端"""
    app = create_app()
    with TestClient(app) as client:
        yield client


@pytest.fixture
async def db_session():
    """创建测试数据库会话"""
    # 使用内存 SQLite 进行测试
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    async_session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    
    async with async_session() as session:
        yield session
    
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


@pytest.fixture
async def sample_task(db_session):
    """创建示例任务"""
    task_run = TaskRun(
        task_template_id=1,
        status='RUNNING',
        runtime_params_json=json.dumps({})
    )
    db_session.add(task_run)
    await db_session.commit()
    await db_session.refresh(task_run)
    
    return task_run


@pytest.fixture
async def sample_job(db_session, sample_task):
    """创建示例 Job"""
    job_run = JobRun(
        task_run_id=sample_task.id,
        code='main_job',
        name='Main Job',
        status='RUNNING',
        job_source='PLUGIN',
        is_sub_job=False
    )
    db_session.add(job_run)
    await db_session.commit()
    await db_session.refresh(job_run)
    
    return job_run


@pytest.fixture
async def sample_failed_node(db_session, sample_job):
    """创建失败的示例节点"""
    node_run = NodeRun(
        job_run_id=sample_job.id,
        code='test_node',
        node_name='Test Node',
        action_type='LLM',
        status='FAILED',
        attempt_count=1,
        error_json=json.dumps({'error': 'Test error message'})
    )
    db_session.add(node_run)
    await db_session.commit()
    await db_session.refresh(node_run)
    
    return node_run


# ========== 测试用例 ==========

class TestRetryNode:
    """测试单个节点重试"""
    
    def test_retry_node_success(self, client, sample_task, sample_failed_node):
        """测试成功重试节点"""
        response = client.post(
            f'/api/retry/nodes',
            json={
                'task_run_id': sample_task.id,
                'node_code': 'test_node'
            }
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data['code'] == 200
        assert data['data']['success'] is True
        assert data['data']['node_code'] == 'test_node'
        assert data['data']['new_status'] == 'RETRYING'
    
    def test_retry_node_not_found(self, client, sample_task):
        """测试节点不存在"""
        response = client.post(
            f'/api/retry/nodes',
            json={
                'task_run_id': sample_task.id,
                'node_code': 'nonexistent_node'
            }
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data['code'] == 404
    
    def test_retry_node_invalid_status(self, client, sample_task, sample_job, db_session):
        """测试节点状态不是 FAILED"""
        # 创建 SUCCESS 状态的节点
        node_run = NodeRun(
            job_run_id=sample_job.id,
            code='success_node',
            node_name='Success Node',
            action_type='LLM',
            status='SUCCESS',
            attempt_count=1
        )
        db_session.add(node_run)
        await db_session.commit()
        
        response = client.post(
            f'/api/retry/nodes',
            json={
                'task_run_id': sample_task.id,
                'node_code': 'success_node'
            }
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data['code'] != 200
        assert 'INVALID_STATUS' in data.get('message', '')


class TestBatchRetry:
    """测试批量重试"""
    
    def test_batch_retry_success(self, client, sample_task, sample_job, db_session):
        """测试批量重试"""
        # 创建多个失败节点
        for i in range(3):
            node_run = NodeRun(
                job_run_id=sample_job.id,
                code=f'failed_node_{i}',
                node_name=f'Failed Node {i}',
                action_type='LLM',
                status='FAILED',
                attempt_count=1
            )
            db_session.add(node_run)
        
        await db_session.commit()
        
        response = client.post(
            f'/api/retry/nodes/batch',
            json={
                'task_run_id': sample_task.id,
                'node_codes': ['failed_node_0', 'failed_node_1', 'failed_node_2']
            }
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data['code'] == 200
        assert data['data']['success_count'] == 3
        assert data['data']['failed_count'] == 0


class TestRetryHistory:
    """测试重试历史"""
    
    def test_get_retry_history(self, client, sample_task, sample_failed_node):
        """测试获取重试历史"""
        # 先进行一次重试
        client.post(
            f'/api/retry/nodes',
            json={
                'task_run_id': sample_task.id,
                'node_code': 'test_node'
            }
        )
        
        # 获取历史
        response = client.get(
            f'/api/retry/history',
            params={
                'task_run_id': sample_task.id,
                'node_code': 'test_node'
            }
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data['code'] == 200
        assert len(data['data']['history']) >= 1


class TestRetryStatus:
    """测试重试状态查询"""
    
    def test_get_retry_status(self, client, sample_task, sample_failed_node):
        """测试获取重试状态"""
        response = client.get(
            f'/api/retry/status/{sample_task.id}/test_node'
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data['code'] == 200
        assert data['data']['node_code'] == 'test_node'
        assert data['data']['current_status'] == 'FAILED'
        assert data['data']['can_retry'] is True


# ========== 运行测试 ==========

if __name__ == '__main__':
    pytest.main([__file__, '-v', '-s'])
