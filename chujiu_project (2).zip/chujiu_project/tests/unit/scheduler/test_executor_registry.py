# -*- coding: utf-8 -*-
"""
ExecutorRegistry 单元测试 ⭐

测试执行器注册表的所有功能。
"""
import pytest
from app.scheduler.executors.registry import ExecutorRegistry
from app.scheduler.exceptions import ExecutorNotFoundError
from app.scheduler.executors.base_executor import BaseExecutor, NodeExecutionRequest, NodeExecutionResult


class MockExecutor(BaseExecutor):
    """模拟执行器用于测试"""
    
    def execute(self, request: NodeExecutionRequest) -> NodeExecutionResult:
        return NodeExecutionResult.success_result({'mock': 'result'})


class TestExecutorRegistry:
    """ExecutorRegistry 测试类"""
    
    @pytest.fixture
    def registry(self):
        """创建 ExecutorRegistry 实例"""
        # 清除单例
        ExecutorRegistry._instance = None
        ExecutorRegistry._executors = {}
        return ExecutorRegistry()
    
    @pytest.fixture
    def mock_executor(self):
        """创建模拟执行器"""
        return MockExecutor()
    
    def test_register_executor(self, registry, mock_executor):
        """测试注册执行器"""
        registry.register('mock_executor', mock_executor)
        
        # 验证执行器已注册
        assert 'mock_executor' in registry.list_executors()
    
    def test_register_duplicate_executor(self, registry, mock_executor):
        """测试注册重复的执行器"""
        registry.register('mock_executor', mock_executor)
        
        with pytest.raises(ValueError) as exc_info:
            registry.register('mock_executor', mock_executor)
        
        assert 'already registered' in str(exc_info.value)
    
    def test_get_executor(self, registry, mock_executor):
        """测试获取执行器"""
        registry.register('mock_executor', mock_executor)
        
        executor = registry.get('mock_executor')
        assert executor is mock_executor
    
    def test_get_non_existent_executor(self, registry):
        """测试获取不存在的执行器"""
        with pytest.raises(ExecutorNotFoundError) as exc_info:
            registry.get('non_existent')
        
        assert 'non_existent' in str(exc_info.value)
    
    def test_list_executors_empty(self, registry):
        """测试列出空执行器列表"""
        executors = registry.list_executors()
        assert executors == []
    
    def test_list_executors(self, registry, mock_executor):
        """测试列出执行器"""
        registry.register('mock_executor', mock_executor)
        
        executors = registry.list_executors()
        assert executors == ['mock_executor']
    
    def test_unregister_executor(self, registry, mock_executor):
        """测试注销执行器"""
        registry.register('mock_executor', mock_executor)
        registry.unregister('mock_executor')
        
        assert 'mock_executor' not in registry.list_executors()
        
        with pytest.raises(ExecutorNotFoundError):
            registry.get('mock_executor')
    
    def test_unregister_non_existent_executor(self, registry):
        """测试注销不存在的执行器"""
        # 不应抛出异常
        registry.unregister('non_existent')
    
    def test_clear_executors(self, registry, mock_executor):
        """测试清空所有执行器"""
        registry.register('mock_executor', mock_executor)
        registry.clear()
        
        assert registry.list_executors() == []
    
    def test_singleton_pattern(self):
        """测试单例模式"""
        registry1 = ExecutorRegistry()
        registry2 = ExecutorRegistry()
        
        assert registry1 is registry2
    
    def test_register_multiple_executors(self, registry):
        """测试注册多个执行器"""
        executor1 = MockExecutor()
        executor2 = MockExecutor()
        
        registry.register('executor1', executor1)
        registry.register('executor2', executor2)
        
        assert len(registry.list_executors()) == 2
        assert registry.get('executor1') is executor1
        assert registry.get('executor2') is executor2
    
    def test_get_executor_after_unregister(self, registry, mock_executor):
        """测试注销后获取执行器"""
        registry.register('mock_executor', mock_executor)
        registry.unregister('mock_executor')
        
        with pytest.raises(ExecutorNotFoundError):
            registry.get('mock_executor')
    
    def test_execute_mock_executor(self, registry, mock_executor):
        """测试执行模拟执行器"""
        registry.register('mock_executor', mock_executor)
        
        executor = registry.get('mock_executor')
        result = executor.execute(None)
        
        assert result.success is True
        assert result.output == {'mock': 'result'}
