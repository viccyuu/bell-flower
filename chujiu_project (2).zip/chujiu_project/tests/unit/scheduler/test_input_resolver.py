# -*- coding: utf-8 -*-
"""
InputResolver 单元测试 ⭐

测试输入映射解析器的所有功能。
"""
import pytest
from app.scheduler.resolver.input_resolver import InputResolver, InputResolveError


class TestInputResolver:
    """InputResolver 测试类"""
    
    @pytest.fixture
    def resolver(self):
        """创建 InputResolver 实例"""
        return InputResolver()
    
    @pytest.fixture
    def context(self):
        """创建测试上下文"""
        return {
            'task': {
                'id': 1001,
                'vars': {
                    'value': 42,
                    'name': 'test',
                    'enabled': True
                }
            },
            'job': {
                'id': 2001,
                'vars': {
                    'config': {'key': 'value'}
                }
            },
            'node': {
                'step1': {
                    'status': 'SUCCESS',
                    'output': {
                        'result': 'success',
                        'data': {'key': 'value'}
                    },
                    'error': None
                },
                'step2': {
                    'status': 'FAILED',
                    'output': None,
                    'error': {
                        'code': 'ERROR',
                        'message': 'Test error'
                    }
                }
            }
        }
    
    def test_resolve_empty_mapping(self, resolver):
        """测试空映射"""
        result = resolver.resolve({}, {})
        assert result == {}
    
    def test_resolve_literal_values(self, resolver, context):
        """测试字面量值"""
        input_mapping = {
            'str_val': 'hello',
            'int_val': 123,
            'float_val': 12.34,
            'bool_val': True,
            'null_val': None
        }
        
        result = resolver.resolve(input_mapping, context)
        
        assert result['str_val'] == 'hello'
        assert result['int_val'] == 123
        assert result['float_val'] == 12.34
        assert result['bool_val'] is True
        assert result['null_val'] is None
    
    def test_resolve_task_id(self, resolver, context):
        """测试 {{ task.id }} 表达式"""
        input_mapping = {
            'task_id': '{{ task.id }}'
        }
        
        result = resolver.resolve(input_mapping, context)
        assert result['task_id'] == 1001
    
    def test_resolve_job_id(self, resolver, context):
        """测试 {{ job.id }} 表达式"""
        input_mapping = {
            'job_id': '{{ job.id }}'
        }
        
        result = resolver.resolve(input_mapping, context)
        assert result['job_id'] == 2001
    
    def test_resolve_task_vars(self, resolver, context):
        """测试 {{ task.vars.xxx }} 表达式"""
        input_mapping = {
            'value': '{{ task.vars.value }}',
            'name': '{{ task.vars.name }}',
            'enabled': '{{ task.vars.enabled }}'
        }
        
        result = resolver.resolve(input_mapping, context)
        
        assert result['value'] == 42
        assert result['name'] == 'test'
        assert result['enabled'] is True
    
    def test_resolve_job_vars(self, resolver, context):
        """测试 {{ job.vars.xxx }} 表达式"""
        input_mapping = {
            'config': '{{ job.vars.config }}'
        }
        
        result = resolver.resolve(input_mapping, context)
        assert result['config'] == {'key': 'value'}
    
    def test_resolve_node_output(self, resolver, context):
        """测试 {{ node.xxx.output.yyy }} 表达式"""
        input_mapping = {
            'step1_result': '{{ node.step1.output.result }}',
            'step1_data': '{{ node.step1.output.data }}'
        }
        
        result = resolver.resolve(input_mapping, context)
        
        assert result['step1_result'] == 'success'
        assert result['step1_data'] == {'key': 'value'}
    
    def test_resolve_node_error(self, resolver, context):
        """测试 {{ node.xxx.error.zzz }} 表达式"""
        input_mapping = {
            'step2_error_code': '{{ node.step2.error.code }}',
            'step2_error_message': '{{ node.step2.error.message }}'
        }
        
        result = resolver.resolve(input_mapping, context)
        
        assert result['step2_error_code'] == 'ERROR'
        assert result['step2_error_message'] == 'Test error'
    
    def test_resolve_boolean_literals(self, resolver, context):
        """测试布尔值字面量"""
        input_mapping = {
            'true_val': '{{ true }}',
            'false_val': '{{ false }}',
            'null_val': '{{ null }}'
        }
        
        result = resolver.resolve(input_mapping, context)
        
        assert result['true_val'] is True
        assert result['false_val'] is False
        assert result['null_val'] is None
    
    def test_resolve_string_literals(self, resolver, context):
        """测试字符串字面量"""
        input_mapping = {
            'single_quote': "{{ 'hello' }}",
            'double_quote': '{{ "world" }}'
        }
        
        result = resolver.resolve(input_mapping, context)
        
        assert result['single_quote'] == 'hello'
        assert result['double_quote'] == 'world'
    
    def test_resolve_number_literals(self, resolver, context):
        """测试数字字面量"""
        input_mapping = {
            'int_val': '{{ 123 }}',
            'float_val': '{{ 12.34 }}'
        }
        
        result = resolver.resolve(input_mapping, context)
        
        assert result['int_val'] == 123
        assert result['float_val'] == 12.34
    
    def test_resolve_equality(self, resolver, context):
        """测试 == 比较"""
        input_mapping = {
            'is_enabled': '{{ task.vars.enabled == true }}',
            'is_42': '{{ task.vars.value == 42 }}'
        }
        
        result = resolver.resolve(input_mapping, context)
        
        assert result['is_enabled'] is True
        assert result['is_42'] is True
    
    def test_resolve_inequality(self, resolver, context):
        """测试 != 比较"""
        input_mapping = {
            'not_disabled': '{{ task.vars.enabled != false }}',
            'not_100': '{{ task.vars.value != 100 }}'
        }
        
        result = resolver.resolve(input_mapping, context)
        
        assert result['not_disabled'] is True
        assert result['not_100'] is True
    
    def test_resolve_nested_dict(self, resolver, context):
        """测试嵌套字典"""
        input_mapping = {
            'outer': {
                'inner': {
                    'value': '{{ task.vars.value }}'
                }
            }
        }
        
        result = resolver.resolve(input_mapping, context)
        
        assert result['outer']['inner']['value'] == 42
    
    def test_resolve_list(self, resolver, context):
        """测试列表"""
        input_mapping = {
            'values': ['{{ task.vars.value }}', '{{ job.id }}']
        }
        
        result = resolver.resolve(input_mapping, context)
        
        assert result['values'] == [42, 2001]
    
    def test_resolve_non_existent_node(self, resolver, context):
        """测试不存在的节点"""
        input_mapping = {
            'value': '{{ node.nonexistent.output.value }}'
        }
        
        with pytest.raises(InputResolveError) as exc_info:
            resolver.resolve(input_mapping, context)
        
        assert 'Node not found' in str(exc_info.value)
    
    def test_resolve_non_existent_key(self, resolver, context):
        """测试不存在的键"""
        input_mapping = {
            'value': '{{ task.vars.nonexistent }}'
        }
        
        with pytest.raises(InputResolveError) as exc_info:
            resolver.resolve(input_mapping, context)
        
        assert 'not found' in str(exc_info.value)
    
    def test_resolve_mixed_expressions(self, resolver, context):
        """测试混合表达式"""
        input_mapping = {
            'task_info': {
                'id': '{{ task.id }}',
                'name': '{{ task.vars.name }}'
            },
            'job_info': {
                'id': '{{ job.id }}'
            },
            'step1_output': '{{ node.step1.output.result }}'
        }
        
        result = resolver.resolve(input_mapping, context)
        
        assert result['task_info']['id'] == 1001
        assert result['task_info']['name'] == 'test'
        assert result['job_info']['id'] == 2001
        assert result['step1_output'] == 'success'
    
    def test_resolve_template_with_spaces(self, resolver, context):
        """测试带空格的模板"""
        input_mapping = {
            'value': '{{  task.vars.value  }}',
            'id': '{{  task.id  }}'
        }
        
        result = resolver.resolve(input_mapping, context)
        
        assert result['value'] == 42
        assert result['id'] == 1001
    
    def test_resolve_non_template_string(self, resolver, context):
        """测试非模板字符串"""
        input_mapping = {
            'static': 'This is a static string',
            'with_braces': 'Value is {not_a_template}'
        }
        
        result = resolver.resolve(input_mapping, context)
        
        assert result['static'] == 'This is a static string'
        assert result['with_braces'] == 'Value is {not_a_template}'
