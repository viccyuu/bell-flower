# -*- coding: utf-8 -*-
"""
OutputValidator 单元测试 ⭐

测试输出 Schema 验证器的所有功能。
"""
import pytest
from app.scheduler.resolver.output_validator import OutputValidator, OutputValidationError


class TestOutputValidator:
    """OutputValidator 测试类"""
    
    @pytest.fixture
    def validator(self):
        """创建 OutputValidator 实例"""
        return OutputValidator()
    
    def test_validate_no_schema(self, validator):
        """测试无 Schema 情况"""
        # 不应抛出异常
        validator.validate({'any': 'data'}, None)
    
    def test_validate_empty_schema(self, validator):
        """测试空 Schema"""
        validator.validate({'any': 'data'}, {})
    
    def test_validate_object_type_success(self, validator):
        """测试对象类型验证成功"""
        schema = {
            'type': 'object'
        }
        output = {'key': 'value'}
        
        # 不应抛出异常
        validator.validate(output, schema)
    
    def test_validate_object_type_failure(self, validator):
        """测试对象类型验证失败"""
        schema = {
            'type': 'object'
        }
        output = 'not a dict'
        
        with pytest.raises(OutputValidationError) as exc_info:
            validator.validate(output, schema)
        
        assert 'must be dict' in str(exc_info.value)
    
    def test_validate_required_fields_success(self, validator):
        """测试必填字段验证成功"""
        schema = {
            'type': 'object',
            'required': ['field1', 'field2']
        }
        output = {'field1': 'value1', 'field2': 'value2'}
        
        # 不应抛出异常
        validator.validate(output, schema)
    
    def test_validate_required_fields_failure(self, validator):
        """测试必填字段验证失败"""
        schema = {
            'type': 'object',
            'required': ['field1', 'field2']
        }
        output = {'field1': 'value1'}
        
        with pytest.raises(OutputValidationError) as exc_info:
            validator.validate(output, schema)
        
        assert 'Missing required field' in str(exc_info.value)
        assert 'field2' in str(exc_info.value)
    
    def test_validate_string_type_success(self, validator):
        """测试字符串类型验证成功"""
        schema = {
            'type': 'object',
            'properties': {
                'name': {'type': 'string'}
            }
        }
        output = {'name': 'test'}
        
        # 不应抛出异常
        validator.validate(output, schema)
    
    def test_validate_string_type_failure(self, validator):
        """测试字符串类型验证失败"""
        schema = {
            'type': 'object',
            'properties': {
                'name': {'type': 'string'}
            }
        }
        output = {'name': 123}
        
        with pytest.raises(OutputValidationError) as exc_info:
            validator.validate(output, schema)
        
        assert "expected 'string'" in str(exc_info.value)
    
    def test_validate_integer_type_success(self, validator):
        """测试整数类型验证成功"""
        schema = {
            'type': 'object',
            'properties': {
                'count': {'type': 'integer'}
            }
        }
        output = {'count': 42}
        
        # 不应抛出异常
        validator.validate(output, schema)
    
    def test_validate_integer_type_failure(self, validator):
        """测试整数类型验证失败"""
        schema = {
            'type': 'object',
            'properties': {
                'count': {'type': 'integer'}
            }
        }
        output = {'count': 'not a number'}
        
        with pytest.raises(OutputValidationError) as exc_info:
            validator.validate(output, schema)
        
        assert "expected 'integer'" in str(exc_info.value)
    
    def test_validate_number_type_success(self, validator):
        """测试数字类型验证成功 (int or float)"""
        schema = {
            'type': 'object',
            'properties': {
                'value': {'type': 'number'}
            }
        }
        
        # 整数
        validator.validate({'value': 42}, schema)
        # 浮点数
        validator.validate({'value': 12.34}, schema)
    
    def test_validate_number_type_failure(self, validator):
        """测试数字类型验证失败"""
        schema = {
            'type': 'object',
            'properties': {
                'value': {'type': 'number'}
            }
        }
        output = {'value': 'not a number'}
        
        with pytest.raises(OutputValidationError) as exc_info:
            validator.validate(output, schema)
        
        assert "expected 'number'" in str(exc_info.value)
    
    def test_validate_boolean_type_success(self, validator):
        """测试布尔类型验证成功"""
        schema = {
            'type': 'object',
            'properties': {
                'enabled': {'type': 'boolean'}
            }
        }
        
        validator.validate({'enabled': True}, schema)
        validator.validate({'enabled': False}, schema)
    
    def test_validate_boolean_type_failure(self, validator):
        """测试布尔类型验证失败"""
        schema = {
            'type': 'object',
            'properties': {
                'enabled': {'type': 'boolean'}
            }
        }
        output = {'enabled': 'yes'}
        
        with pytest.raises(OutputValidationError) as exc_info:
            validator.validate(output, schema)
        
        assert "expected 'boolean'" in str(exc_info.value)
    
    def test_validate_array_type_success(self, validator):
        """测试数组类型验证成功"""
        schema = {
            'type': 'object',
            'properties': {
                'items': {'type': 'array'}
            }
        }
        output = {'items': [1, 2, 3]}
        
        # 不应抛出异常
        validator.validate(output, schema)
    
    def test_validate_array_type_failure(self, validator):
        """测试数组类型验证失败"""
        schema = {
            'type': 'object',
            'properties': {
                'items': {'type': 'array'}
            }
        }
        output = {'items': 'not a list'}
        
        with pytest.raises(OutputValidationError) as exc_info:
            validator.validate(output, schema)
        
        assert "expected 'array'" in str(exc_info.value)
    
    def test_validate_nested_object_success(self, validator):
        """测试嵌套对象验证成功"""
        schema = {
            'type': 'object',
            'properties': {
                'user': {
                    'type': 'object',
                    'properties': {
                        'name': {'type': 'string'},
                        'age': {'type': 'integer'}
                    }
                }
            }
        }
        output = {
            'user': {
                'name': 'test',
                'age': 25
            }
        }
        
        # 不应抛出异常
        validator.validate(output, schema)
    
    def test_validate_nested_object_failure(self, validator):
        """测试嵌套对象验证失败"""
        schema = {
            'type': 'object',
            'properties': {
                'user': {
                    'type': 'object',
                    'properties': {
                        'name': {'type': 'string'},
                        'age': {'type': 'integer'}
                    }
                }
            }
        }
        output = {
            'user': {
                'name': 'test',
                'age': 'not a number'
            }
        }
        
        with pytest.raises(OutputValidationError) as exc_info:
            validator.validate(output, schema)
        
        assert "expected 'integer'" in str(exc_info.value)
    
    def test_validate_array_items_success(self, validator):
        """测试数组元素验证成功"""
        schema = {
            'type': 'object',
            'properties': {
                'numbers': {
                    'type': 'array',
                    'items': {'type': 'integer'}
                }
            }
        }
        output = {'numbers': [1, 2, 3]}
        
        # 不应抛出异常
        validator.validate(output, schema)
    
    def test_validate_array_items_failure(self, validator):
        """测试数组元素验证失败"""
        schema = {
            'type': 'object',
            'properties': {
                'numbers': {
                    'type': 'array',
                    'items': {'type': 'integer'}
                }
            }
        }
        output = {'numbers': [1, 'two', 3]}
        
        with pytest.raises(OutputValidationError) as exc_info:
            validator.validate(output, schema)
        
        assert "expected 'integer'" in str(exc_info.value)
    
    def test_validate_complex_schema_success(self, validator):
        """测试复杂 Schema 验证成功"""
        schema = {
            'type': 'object',
            'required': ['id', 'name', 'items'],
            'properties': {
                'id': {'type': 'integer'},
                'name': {'type': 'string'},
                'enabled': {'type': 'boolean'},
                'items': {
                    'type': 'array',
                    'items': {
                        'type': 'object',
                        'required': ['key', 'value'],
                        'properties': {
                            'key': {'type': 'string'},
                            'value': {'type': 'number'}
                        }
                    }
                }
            }
        }
        output = {
            'id': 1,
            'name': 'test',
            'enabled': True,
            'items': [
                {'key': 'a', 'value': 1},
                {'key': 'b', 'value': 2.5}
            ]
        }
        
        # 不应抛出异常
        validator.validate(output, schema)
    
    def test_validate_complex_schema_failure(self, validator):
        """测试复杂 Schema 验证失败"""
        schema = {
            'type': 'object',
            'required': ['id', 'name'],
            'properties': {
                'id': {'type': 'integer'},
                'name': {'type': 'string'}
            }
        }
        output = {
            'id': 'not a number',
            'name': 'test'
        }
        
        with pytest.raises(OutputValidationError) as exc_info:
            validator.validate(output, schema)
        
        assert "expected 'integer'" in str(exc_info.value)
    
    def test_validate_optional_fields(self, validator):
        """测试可选字段"""
        schema = {
            'type': 'object',
            'properties': {
                'required_field': {'type': 'string'},
                'optional_field': {'type': 'string'}
            }
        }
        
        # 只有必填字段
        validator.validate({'required_field': 'test'}, schema)
        
        # 包含可选字段
        validator.validate({
            'required_field': 'test',
            'optional_field': 'optional'
        }, schema)
    
    def test_validate_extra_fields(self, validator):
        """测试额外字段 (应允许)"""
        schema = {
            'type': 'object',
            'properties': {
                'name': {'type': 'string'}
            }
        }
        output = {
            'name': 'test',
            'extra_field': 'extra'
        }
        
        # 不应抛出异常 (额外字段允许)
        validator.validate(output, schema)
