# -*- coding: utf-8 -*-
"""
Retry Utils 单元测试 ⭐

测试重试工具函数。
"""
import pytest
from app.scheduler.models import NodeExecutionResult
from app.scheduler.utils.retry import merge_retry_policy, should_retry


class TestMergeRetryPolicy:
    """merge_retry_policy 测试"""
    
    def test_merge_with_none_policies(self):
        """测试两个 None 策略"""
        result = merge_retry_policy(None, None)
        
        assert result['max_retries'] == 0
        assert result['backoff_seconds'] == 0
        assert result['retry_on'] == []
    
    def test_merge_with_default_only(self):
        """测试只有默认策略"""
        default = {
            'max_retries': 3,
            'backoff_seconds': 5,
            'retry_on': ['TIMEOUT']
        }
        
        result = merge_retry_policy(default, None)
        
        assert result['max_retries'] == 3
        assert result['backoff_seconds'] == 5
        assert result['retry_on'] == ['TIMEOUT']
    
    def test_merge_with_node_only(self):
        """测试只有节点策略"""
        node = {
            'max_retries': 2,
            'backoff_seconds': 3,
            'retry_on': ['TEMPORARY_ERROR']
        }
        
        result = merge_retry_policy(None, node)
        
        assert result['max_retries'] == 2
        assert result['backoff_seconds'] == 3
        assert result['retry_on'] == ['TEMPORARY_ERROR']
    
    def test_merge_node_overrides_default(self):
        """测试节点策略覆盖默认策略"""
        default = {
            'max_retries': 5,
            'backoff_seconds': 10,
            'retry_on': ['TIMEOUT', 'ERROR']
        }
        node = {
            'max_retries': 2,
            'backoff_seconds': 3
        }
        
        result = merge_retry_policy(default, node)
        
        # 节点策略覆盖
        assert result['max_retries'] == 2
        assert result['backoff_seconds'] == 3
        # 默认策略保留
        assert result['retry_on'] == ['TIMEOUT', 'ERROR']
    
    def test_merge_with_invalid_values(self):
        """测试无效值处理"""
        default = {
            'max_retries': None,
            'backoff_seconds': None,
            'retry_on': None
        }
        
        result = merge_retry_policy(default, None)
        
        assert result['max_retries'] == 0
        assert result['backoff_seconds'] == 0
        assert result['retry_on'] == []


class TestShouldRetry:
    """should_retry 测试"""
    
    def test_should_not_retry_on_success(self):
        """测试成功时不重试"""
        result = NodeExecutionResult.success_result({'data': 'value'})
        retry_policy = {'max_retries': 3, 'retry_on': ['TIMEOUT']}
        
        assert should_retry(result, retry_policy, 1) is False
    
    def test_should_retry_on_error_in_retry_on(self):
        """测试错误在 retry_on 中时重试"""
        result = NodeExecutionResult.error_result(
            error_code='TIMEOUT',
            error_message='Timeout'
        )
        retry_policy = {'max_retries': 3, 'retry_on': ['TIMEOUT']}
        
        assert should_retry(result, retry_policy, 1) is True
    
    def test_should_not_retry_on_error_not_in_retry_on(self):
        """测试错误不在 retry_on 中时不重试"""
        result = NodeExecutionResult.error_result(
            error_code='PERMANENT_ERROR',
            error_message='Permanent error'
        )
        retry_policy = {'max_retries': 3, 'retry_on': ['TIMEOUT']}
        
        assert should_retry(result, retry_policy, 1) is False
    
    def test_should_not_retry_when_max_retries_exceeded(self):
        """测试超过最大重试次数时不重试"""
        result = NodeExecutionResult.error_result(
            error_code='TIMEOUT',
            error_message='Timeout'
        )
        retry_policy = {'max_retries': 2, 'retry_on': ['TIMEOUT']}
        
        # 第 3 次尝试（已经超过 max_retries=2）
        assert should_retry(result, retry_policy, 3) is False
    
    def test_should_retry_when_not_exceeded_max_retries(self):
        """测试未超过最大重试次数时重试"""
        result = NodeExecutionResult.error_result(
            error_code='TIMEOUT',
            error_message='Timeout'
        )
        retry_policy = {'max_retries': 3, 'retry_on': ['TIMEOUT']}
        
        # 第 2 次尝试（未超过 max_retries=3）
        assert should_retry(result, retry_policy, 2) is True
    
    def test_should_not_retry_with_zero_max_retries(self):
        """测试 max_retries=0 时不重试"""
        result = NodeExecutionResult.error_result(
            error_code='TIMEOUT',
            error_message='Timeout'
        )
        retry_policy = {'max_retries': 0, 'retry_on': ['TIMEOUT']}
        
        assert should_retry(result, retry_policy, 1) is False
    
    def test_should_not_retry_with_none_error_code(self):
        """测试 error_code 为 None 时不重试"""
        result = NodeExecutionResult.error_result(
            error_code=None,
            error_message='Unknown error'
        )
        retry_policy = {'max_retries': 3, 'retry_on': ['TIMEOUT']}
        
        assert should_retry(result, retry_policy, 1) is False
