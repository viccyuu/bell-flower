# -*- coding: utf-8 -*-
"""
第一阶段测试：项目骨架 + 数据模型 + API 框架

异步测试版本（FastAPI 迁移准备）⭐
"""
import pytest
import sys
import os
import asyncio

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestAppStartup:
    """TC-001: 项目启动测试"""
    
    def test_app_import(self):
        """测试应用可以导入"""
        from app import create_app
        assert create_app is not None
    
    def test_config_import(self):
        """测试配置可以导入"""
        from app.app_config import Settings
        assert Settings is not None
    
    @pytest.mark.asyncio
    async def test_models_import(self):
        """测试模型可以导入（异步）⭐"""
        from app.models import User, UploadFile, TaskTemplate, TaskRun
        assert User is not None
        assert UploadFile is not None
        assert TaskTemplate is not None
        assert TaskRun is not None


class TestDatabaseInit:
    """TC-002: 数据库初始化测试"""
    
    @pytest.mark.asyncio
    async def test_tables_exist(self, db_session):
        """测试数据库表存在（异步）⭐"""
        # db_session 现在是异步 fixture
        from app.models import User, UploadFile, TaskTemplate
        
        # 验证表已创建
        # 异步测试中，表已在 fixture 中创建
        assert True  # 如果 fixture 成功，表已创建


class TestFileUpload:
    """TC-003: 文件上传测试"""
    
    def test_upload_repository_import(self):
        """测试 UploadRepository 可以导入"""
        from app.repository.upload_repository import upload_file_repository
        assert upload_file_repository is not None
    
    @pytest.mark.asyncio
    async def test_checksum_calculation(self):
        """测试 checksum 计算（异步）⭐"""
        from app.routes.routes_upload import calculate_checksum
        import tempfile
        
        # 创建临时文件
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.write(b"test content")
            temp_path = f.name
        
        try:
            checksum = calculate_checksum(temp_path)
            assert len(checksum) == 64  # SHA256 是 64 个字符
        finally:
            os.unlink(temp_path)


class TestTaskRun:
    """TC-005: TaskRun 创建测试"""
    
    def test_task_repository_import(self):
        """测试 TaskRepository 可以导入"""
        from app.repository.task_repository import task_run_repository
        assert task_run_repository is not None
    
    def test_optimistic_update_import(self):
        """测试乐观锁工具类可以导入"""
        from app.repository.utils import optimistic_update, NotFoundError, MaxRetriesExceededError
        assert optimistic_update is not None
        assert NotFoundError is not None
        assert MaxRetriesExceededError is not None


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
