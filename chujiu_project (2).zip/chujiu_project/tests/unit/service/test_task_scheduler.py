# -*- coding: utf-8 -*-
"""
单元测试 - 任务 Scheduler

测试 task_scheduler.py 中的方法。

【测试范围】
1. execute_task() - 执行任务
2. execute_job() - 执行 Job
3. trigger_llm_planning() - 触发 LLM 规划
4. _check_conditions() - 条件边判断
"""
import pytest
from unittest.mock import Mock, patch, MagicMock
import json


class TestTaskScheduler:
    """TaskScheduler 单元测试"""
    
    def test_execute_task_plugin_job(self):
        """UT-SCHED-001: 执行插件来源主 Job"""
        # Arrange
        from app.scheduler.task_scheduler import TaskScheduler
        from app.models import TaskRun, JobRun
        
        scheduler = TaskScheduler()
        
        task_run = TaskRun(upload_file_id=1, status='READY')
        main_job = JobRun(
            task_run_id=task_run.id,
            code='main_job',
            status='READY',
            job_source='PLUGIN',
            is_sub_job=False
        )
        
        # Act
        with patch.object(scheduler, 'execute_job') as mock_execute_job:
            scheduler.execute_task(task_run.id)
            
            # Assert
            mock_execute_job.assert_called_once()
    
    def test_execute_task_llm_job(self):
        """UT-SCHED-002: 执行 LLM 来源主 Job"""
        # Arrange
        from app.scheduler.task_scheduler import TaskScheduler
        from app.models import TaskRun, JobRun
        
        scheduler = TaskScheduler()
        
        task_run = TaskRun(upload_file_id=1, status='READY')
        main_job = JobRun(
            task_run_id=task_run.id,
            code='main_job',
            status='READY',
            job_source='LLM',
            is_sub_job=False
        )
        
        # Act
        with patch.object(scheduler, 'execute_job') as mock_execute_job:
            scheduler.execute_task(task_run.id)
            
            # Assert
            mock_execute_job.assert_called_once()
    
    def test_execute_job_success(self):
        """UT-SCHED-003: Job 执行成功"""
        # Arrange
        from app.scheduler.task_scheduler import TaskScheduler
        from app.models import JobRun, NodeRun
        
        scheduler = TaskScheduler()
        
        main_job = JobRun(
            task_run_id=1,
            code='main_job',
            status='READY',
            job_source='PLUGIN',
            is_sub_job=False
        )
        
        node_run = NodeRun(
            job_run_id=main_job.id,
            code='node_1',
            status='PENDING'
        )
        
        # Act
        with patch.object(scheduler, 'execute_node') as mock_execute_node:
            mock_execute_node.return_value = {'status': 'SUCCESS'}
            scheduler.execute_job(main_job)
            
            # Assert
            mock_execute_node.assert_called()
            assert main_job.status == 'SUCCESS'
    
    def test_execute_job_node_failed(self):
        """UT-SCHED-004: 节点执行失败"""
        # Arrange
        from app.scheduler.task_scheduler import TaskScheduler
        from app.models import JobRun, NodeRun
        
        scheduler = TaskScheduler()
        
        main_job = JobRun(
            task_run_id=1,
            code='main_job',
            status='READY',
            job_source='PLUGIN',
            is_sub_job=False
        )
        
        node_run = NodeRun(
            job_run_id=main_job.id,
            code='node_1',
            status='PENDING'
        )
        
        # Act
        with patch.object(scheduler, 'execute_node') as mock_execute_node:
            mock_execute_node.return_value = {'status': 'FAILED', 'error': 'Test error'}
            with patch.object(scheduler, '_should_retry', return_value=False):
                with patch.object(scheduler, '_should_trigger_llm_planning', return_value=False):
                    scheduler.execute_job(main_job)
                    
                    # Assert
                    assert main_job.status == 'FAILED'
    
    def test_trigger_llm_planning_main_job(self):
        """UT-SCHED-005: 主 Job 触发 LLM 规划"""
        # Arrange
        from app.scheduler.task_scheduler import TaskScheduler
        from app.models import JobRun, NodeRun
        
        scheduler = TaskScheduler()
        
        main_job = JobRun(
            task_run_id=1,
            code='main_job',
            status='RUNNING',
            job_source='PLUGIN',
            is_sub_job=False
        )
        
        failed_node = NodeRun(
            job_run_id=main_job.id,
            code='failed_node',
            status='FAILED',
            config_json=json.dumps({'planning_enabled': True})
        )
        
        # Act
        with patch('app.scheduler.task_scheduler.current_app') as mock_app:
            scheduler.trigger_llm_planning(main_job, failed_node)
            
            # Assert
            mock_app.logger.info.assert_called()
    
    def test_trigger_llm_planning_subjob(self):
        """UT-SCHED-006: SubJob 不触发 LLM 规划"""
        # Arrange
        from app.scheduler.task_scheduler import TaskScheduler
        from app.models import JobRun, NodeRun
        
        scheduler = TaskScheduler()
        
        subjob = JobRun(
            task_run_id=1,
            code='subjob',
            status='RUNNING',
            job_source='LLM',
            is_sub_job=True
        )
        
        failed_node = NodeRun(
            job_run_id=subjob.id,
            code='failed_node',
            status='FAILED'
        )
        
        # Act
        with patch('app.scheduler.task_scheduler.current_app') as mock_app:
            scheduler.trigger_llm_planning(subjob, failed_node)
            
            # Assert
            mock_app.logger.warning.assert_called()
    
    def test_check_conditions_true(self):
        """UT-SCHED-007: 条件边判断为真"""
        # Arrange
        from app.scheduler.task_scheduler import TaskScheduler
        from app.models import NodeRun
        
        scheduler = TaskScheduler()
        
        node_run = NodeRun(
            job_run_id=1,
            code='node_1',
            status='PENDING',
            input_mapping_json=json.dumps({'prev_output': 'success'})
        )
        
        dag_json = json.dumps({
            "edges": [
                {"from": "prev_node", "to": "node_1", "condition_expr": "node.prev_node.output.passed == true"}
            ]
        })
        
        # Act
        # Mock the condition evaluation
        with patch.object(scheduler, '_evaluate_condition', return_value=True):
            result = scheduler._check_conditions(node_run, dag_json)
            
            # Assert
            assert result == True
    
    def test_check_conditions_false(self):
        """UT-SCHED-008: 条件边判断为假"""
        # Arrange
        from app.scheduler.task_scheduler import TaskScheduler
        from app.models import NodeRun
        
        scheduler = TaskScheduler()
        
        node_run = NodeRun(
            job_run_id=1,
            code='node_1',
            status='PENDING',
            input_mapping_json=json.dumps({'prev_output': 'failed'})
        )
        
        dag_json = json.dumps({
            "edges": [
                {"from": "prev_node", "to": "node_1", "condition_expr": "node.prev_node.output.passed == true"}
            ]
        })
        
        # Act
        with patch.object(scheduler, '_evaluate_condition', return_value=False):
            result = scheduler._check_conditions(node_run, dag_json)
            
            # Assert
            assert result == False
    
    def test_should_retry_true(self):
        """UT-SCHED-009: 应该重试"""
        # Arrange
        from app.scheduler.task_scheduler import TaskScheduler
        from app.models import NodeRun
        
        scheduler = TaskScheduler()
        
        node_run = NodeRun(
            job_run_id=1,
            code='node_1',
            status='FAILED',
            attempt_count=0,
            retry_policy_json=json.dumps({'max_retries': 3})
        )
        
        # Act
        result = scheduler._should_retry(node_run)
        
        # Assert
        assert result == True
    
    def test_should_retry_false(self):
        """UT-SCHED-010: 不应该重试"""
        # Arrange
        from app.scheduler.task_scheduler import TaskScheduler
        from app.models import NodeRun
        
        scheduler = TaskScheduler()
        
        node_run = NodeRun(
            job_run_id=1,
            code='node_1',
            status='FAILED',
            attempt_count=3,
            retry_policy_json=json.dumps({'max_retries': 3})
        )
        
        # Act
        result = scheduler._should_retry(node_run)
        
        # Assert
        assert result == False
    
    def test_should_trigger_llm_planning_true(self):
        """UT-SCHED-011: 应该触发 LLM 规划"""
        # Arrange
        from app.scheduler.task_scheduler import TaskScheduler
        from app.models import NodeRun, JobRun
        
        scheduler = TaskScheduler()
        
        main_job = JobRun(
            task_run_id=1,
            code='main_job',
            job_source='PLUGIN',
            is_sub_job=False
        )
        
        node_run = NodeRun(
            job_run_id=main_job.id,
            code='node_1',
            status='FAILED',
            config_json=json.dumps({'planning_enabled': True})
        )
        
        # Act
        result = scheduler._should_trigger_llm_planning(node_run, main_job)
        
        # Assert
        assert result == True
    
    def test_should_trigger_llm_planning_false(self):
        """UT-SCHED-012: 不应该触发 LLM 规划"""
        # Arrange
        from app.scheduler.task_scheduler import TaskScheduler
        from app.models import NodeRun, JobRun
        
        scheduler = TaskScheduler()
        
        main_job = JobRun(
            task_run_id=1,
            code='main_job',
            job_source='PLUGIN',
            is_sub_job=False
        )
        
        node_run = NodeRun(
            job_run_id=main_job.id,
            code='node_1',
            status='FAILED',
            config_json=json.dumps({'planning_enabled': False})
        )
        
        # Act
        result = scheduler._should_trigger_llm_planning(node_run, main_job)
        
        # Assert
        assert result == False
    
    def test_is_job_complete_true(self):
        """UT-SCHED-013: Job 完成判断为真"""
        # Arrange
        from app.scheduler.task_scheduler import TaskScheduler
        from app.models import JobRun, NodeRun
        
        scheduler = TaskScheduler()
        
        main_job = JobRun(
            task_run_id=1,
            code='main_job',
            status='RUNNING'
        )
        
        node_run = NodeRun(
            job_run_id=main_job.id,
            code='node_1',
            status='SUCCESS'
        )
        
        # Act
        with patch.object(scheduler, '_get_all_nodes', return_value=[node_run]):
            result = scheduler._is_job_complete(main_job)
            
            # Assert
            assert result == True
    
    def test_is_job_complete_false(self):
        """UT-SCHED-014: Job 完成判断为假"""
        # Arrange
        from app.scheduler.task_scheduler import TaskScheduler
        from app.models import JobRun, NodeRun
        
        scheduler = TaskScheduler()
        
        main_job = JobRun(
            task_run_id=1,
            code='main_job',
            status='RUNNING'
        )
        
        node_run = NodeRun(
            job_run_id=main_job.id,
            code='node_1',
            status='PENDING'
        )
        
        # Act
        with patch.object(scheduler, '_get_all_nodes', return_value=[node_run]):
            result = scheduler._is_job_complete(main_job)
            
            # Assert
            assert result == False
