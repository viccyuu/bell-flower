# -*- coding: utf-8 -*-
"""
插件与提示词服务单元测试

基于 BDD plugin_management.feature 和 prompt_library.feature 场景下沉的单元测试。

覆盖 BDD 场景：
- 插件列表查询
- 插件 DAG 查看
- 插件 Learning 规则
- 提示词 CRUD
- 提示词渲染
"""
import pytest
from unittest.mock import Mock, patch


class TestPluginRegistry:
    """插件注册中心测试"""
    
    def test_plugin_list_not_empty(self):
        """用例：插件列表不为空"""
        # Arrange
        plugins = ['excel_vba_to_wps_js', 'wps_js_to_excel_vba', 'web_briefing']
        
        # Assert
        assert len(plugins) > 0
    
    def test_plugin_has_name_and_description(self):
        """用例：插件有名称和描述"""
        # Arrange
        plugin = {
            'code': 'excel_vba_to_wps_js',
            'name': 'MS Excel VBA 转 WPS JS',
            'description': '将 MS Excel VBA 宏转换为 WPS Excel JavaScript 宏'
        }
        
        # Assert
        assert 'name' in plugin
        assert 'description' in plugin
        assert plugin['name'] == 'MS Excel VBA 转 WPS JS'
    
    def test_plugin_status_enabled_disabled(self):
        """用例：插件状态（启用/禁用）"""
        # Arrange
        plugin_enabled = {'code': 'plugin1', 'status': 'ENABLED'}
        plugin_disabled = {'code': 'plugin2', 'status': 'DISABLED'}
        
        # Assert
        assert plugin_enabled['status'] == 'ENABLED'
        assert plugin_disabled['status'] == 'DISABLED'


class TestPluginDAG:
    """插件 DAG 测试"""
    
    def test_plugin_dag_structure(self):
        """用例：插件 DAG 结构"""
        # Arrange
        dag = {
            'nodes': [
                {'id': 1, 'code': 'parse_vba', 'type': 'PYTHON'},
                {'id': 2, 'code': 'convert_to_ast', 'type': 'LLM'},
                {'id': 3, 'code': 'generate_js', 'type': 'LLM'}
            ],
            'edges': [
                {'from': 1, 'to': 2},
                {'from': 2, 'to': 3}
            ]
        }
        
        # Assert
        assert 'nodes' in dag
        assert 'edges' in dag
        assert len(dag['nodes']) > 0
        assert len(dag['edges']) > 0
    
    def test_plugin_dag_nodes_visible(self):
        """用例：DAG 节点可见"""
        # Arrange
        nodes = [
            {'id': 1, 'code': 'node_1'},
            {'id': 2, 'code': 'node_2'}
        ]
        
        # Assert
        for node in nodes:
            assert 'id' in node
            assert 'code' in node
    
    def test_plugin_dag_edges_visible(self):
        """用例：DAG 边可见"""
        # Arrange
        edges = [
            {'from': 1, 'to': 2},
            {'from': 2, 'to': 3}
        ]
        
        # Assert
        for edge in edges:
            assert 'from' in edge
            assert 'to' in edge


class TestPluginLearning:
    """插件 Learning 规则测试"""
    
    def test_learning_rules_exist(self):
        """用例：Learning 规则存在"""
        # Arrange
        rules = [
            {
                'error_id': 'ERR-001',
                'scenario': 'VBA 语法解析失败',
                'root_cause': '不支持的 API 调用',
                'forbidden_patterns': '["Declare Function"]',
                'correct_patterns': '["使用内置函数替代"]'
            }
        ]
        
        # Assert
        assert len(rules) > 0
    
    def test_learning_rule_has_scenario_and_cause(self):
        """用例：Learning 规则有场景和错因"""
        # Arrange
        rule = {
            'error_id': 'ERR-001',
            'scenario': 'VBA 语法解析失败',
            'root_cause': '不支持的 API 调用'
        }
        
        # Assert
        assert 'scenario' in rule
        assert 'root_cause' in rule
    
    def test_learning_rule_has_forbidden_and_correct_patterns(self):
        """用例：Learning 规则有禁止行为和正确范式"""
        # Arrange
        rule = {
            'error_id': 'ERR-001',
            'forbidden_patterns': '["pattern1"]',
            'correct_patterns': '["pattern2"]'
        }
        
        # Assert
        assert 'forbidden_patterns' in rule
        assert 'correct_patterns' in rule


class TestPromptCategory:
    """提示词分类测试"""
    
    def test_prompt_category_data(self):
        """用例：提示词分类数据"""
        # Arrange
        category_data = {
            'code': 'excel_convert',
            'name': 'Excel 转换',
            'description': 'VBA 与 WPS JS 双向转换'
        }
        
        # Assert
        assert category_data['code'] == 'excel_convert'
        assert category_data['name'] == 'Excel 转换'
    
    def test_prompt_category_list(self):
        """用例：提示词分类列表"""
        # Arrange
        categories = [
            {'code': 'excel_convert', 'name': 'Excel 转换'},
            {'code': 'code_review', 'name': '代码审视'},
            {'code': 'web_browse', 'name': '网页浏览'},
            {'code': 'general', 'name': '通用'}
        ]
        
        # Assert
        assert len(categories) == 4
    
    def test_filter_prompts_by_category(self):
        """用例：按分类筛选提示词"""
        # Arrange
        prompts = [
            {'code': 'vba_to_ast', 'category': 'excel_convert'},
            {'code': 'ast_to_js', 'category': 'excel_convert'},
            {'code': 'review_code', 'category': 'code_review'}
        ]
        target_category = 'excel_convert'
        
        # Act
        filtered = [p for p in prompts if p['category'] == target_category]
        
        # Assert
        assert len(filtered) == 2
        assert all(p['category'] == target_category for p in filtered)


class TestPromptTemplate:
    """提示词模板测试"""
    
    def test_prompt_template_data(self):
        """用例：提示词模板数据"""
        # Arrange
        prompt_data = {
            'category_id': 1,
            'code': 'vba_to_ast',
            'name': 'VBA 转 AST',
            'description': '将 VBA 代码转换为 AST',
            'system_prompt': '你是一个代码转换助手',
            'user_prompt': '请将以下 VBA 代码转换为 AST: {{code}}'
        }
        
        # Assert
        assert prompt_data['code'] == 'vba_to_ast'
        assert '{{code}}' in prompt_data['user_prompt']
    
    def test_edit_prompt_template(self):
        """用例：编辑提示词模板"""
        # Arrange
        prompt_data = {
            'category_id': 1,
            'code': 'vba_to_ast',
            'name': 'VBA 转 AST',
            'version': 1
        }
        
        # Act
        prompt_data['name'] = 'VBA 转 AST（增强版）'
        prompt_data['version'] = 2
        
        # Assert
        assert prompt_data['name'] == 'VBA 转 AST（增强版）'
        assert prompt_data['version'] == 2
    
    def test_render_prompt_template(self):
        """用例：渲染提示词模板"""
        # Arrange
        template = '请将以下 {{language}} 代码转换为 {{target}}: {{code}}'
        variables = {
            'language': 'VBA',
            'target': 'JavaScript',
            'code': 'Sub Test()'
        }
        
        # Act
        rendered = template
        for key, value in variables.items():
            rendered = rendered.replace(f'{{{{{key}}}}}', value)
        
        # Assert
        assert 'VBA' in rendered
        assert 'JavaScript' in rendered
        assert 'Sub Test()' in rendered
        assert '{{' not in rendered


class TestPluginConfig:
    """插件配置测试"""
    
    def test_plugin_codes(self):
        """用例：插件代码"""
        # Arrange
        plugin_codes = ['excel_vba_to_wps_js', 'wps_js_to_excel_vba', 'web_briefing']
        
        # Assert
        assert len(plugin_codes) == 3
        assert 'excel_vba_to_wps_js' in plugin_codes


class TestTaskTemplate:
    """任务模板测试"""
    
    def test_task_template_with_prompt_templates(self):
        """用例：任务模板关联提示词模板"""
        # Arrange
        template_data = {
            'code': 'excel_vba_to_wps_js',
            'name': 'MS Excel VBA 转 WPS JS',
            'plugin_code': 'excel_vba_to_wps_js',
            'prompt_templates': '["vba_to_ast", "ast_to_wps_js"]'
        }
        
        # Act
        import json
        prompt_codes = json.loads(template_data['prompt_templates'])
        
        # Assert
        assert len(prompt_codes) == 2
        assert 'vba_to_ast' in prompt_codes
    
    def test_task_template_builtin_custom(self):
        """用例：任务模板分类（builtin/custom）"""
        # Arrange
        builtin_template = {'code': 'excel_vba_to_wps_js', 'is_builtin': 1}
        custom_template = {'code': 'custom_template', 'is_builtin': 0}
        
        # Assert
        assert builtin_template['is_builtin'] == 1
        assert custom_template['is_builtin'] == 0
