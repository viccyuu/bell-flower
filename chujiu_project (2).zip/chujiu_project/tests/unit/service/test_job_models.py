# -*- coding: utf-8 -*-
"""
单元测试 - Job 模型

测试 models.py 中的 JobRun 和 NodeRun 模型。

【测试范围】
1. JobRun 创建
2. NodeRun 创建
3. 关系测试
4. 状态转换
"""
import pytest
from datetime import datetime
import json


class TestJobRunModel:
    """JobRun 模型单元测试"""
    
    def test_job_run_create_plugin(self):
        """UT-MODEL-001: 创建插件来源 JobRun"""
        # Arrange
        from app.models import JobRun
        
        # Act
        job_run = JobRun(
            task_run_id=1,
            code='excel_vba_to_wps_js_main',
            name='Main Job',
            status='READY',
            job_source='PLUGIN',
            is_sub_job=False
        )
        
        # Assert
        assert job_run is not None
        assert job_run.job_source == 'PLUGIN'
        assert job_run.is_sub_job == False
        assert job_run.parent_job_run_id is None
    
    def test_job_run_create_llm(self):
        """UT-MODEL-002: 创建 LLM 来源 JobRun"""
        # Arrange
        from app.models import JobRun
        
        # Act
        job_run = JobRun(
            task_run_id=1,
            code='llm_job',
            name='LLM Planned Job',
            status='READY',
            job_source='LLM',
            is_sub_job=False
        )
        
        # Assert
        assert job_run is not None
        assert job_run.job_source == 'LLM'
        assert job_run.is_sub_job == False
        assert job_run.parent_job_run_id is None
    
    def test_job_run_is_sub_job(self):
        """UT-MODEL-003: 创建 SubJob"""
        # Arrange
        from app.models import JobRun
        
        # Act
        subjob = JobRun(
            task_run_id=1,
            code='subjob',
            name='SubJob',
            status='CREATED',
            job_source='LLM',
            is_sub_job=True,
            parent_job_run_id=1,
            failed_node_code='failed_node'
        )
        
        # Assert
        assert subjob is not None
        assert subjob.is_sub_job == True
        assert subjob.parent_job_run_id == 1
        assert subjob.failed_node_code == 'failed_node'
    
    def test_job_run_parent_job_relation(self):
        """UT-MODEL-004: SubJob 关联父 Job"""
        # Arrange
        from app.models import JobRun
        
        main_job = JobRun(
            task_run_id=1,
            code='main_job',
            status='RUNNING',
            job_source='PLUGIN',
            is_sub_job=False
        )
        
        subjob = JobRun(
            task_run_id=1,
            code='subjob',
            status='CREATED',
            job_source='LLM',
            is_sub_job=True,
            parent_job_run_id=main_job.id
        )
        
        # Assert
        assert subjob.parent_job_run_id == main_job.id
    
    def test_job_run_status_transitions(self):
        """UT-MODEL-005: JobRun 状态转换"""
        # Arrange
        from app.models import JobRun
        
        job_run = JobRun(
            task_run_id=1,
            code='main_job',
            status='CREATED',
            job_source='PLUGIN',
            is_sub_job=False
        )
        
        # Act & Assert
        # CREATED -> READY
        job_run.status = 'READY'
        assert job_run.status == 'READY'
        
        # READY -> RUNNING
        job_run.status = 'RUNNING'
        assert job_run.status == 'RUNNING'
        
        # RUNNING -> SUCCESS
        job_run.status = 'SUCCESS'
        assert job_run.status == 'SUCCESS'
        
        # RUNNING -> FAILED
        job_run.status = 'RUNNING'
        job_run.status = 'FAILED'
        assert job_run.status == 'FAILED'
        
        # FAILED -> RETRYING
        job_run.status = 'RETRYING'
        assert job_run.status == 'RETRYING'


class TestNodeRunModel:
    """NodeRun 模型单元测试"""
    
    def test_node_run_create_success(self):
        """UT-MODEL-006: 创建 NodeRun 成功"""
        # Arrange
        from app.models import NodeRun
        
        # Act
        node_run = NodeRun(
            job_run_id=1,
            code='upload_validate',
            action_type='PYTHON',
            status='PENDING'
        )
        
        # Assert
        assert node_run is not None
        assert node_run.code == 'upload_validate'
        assert node_run.action_type == 'PYTHON'
        assert node_run.status == 'PENDING'
    
    def test_node_run_with_input_json(self):
        """UT-MODEL-007: NodeRun 包含 input_json"""
        # Arrange
        from app.models import NodeRun
        
        input_json = {'upload_id': 1}
        
        # Act
        node_run = NodeRun(
            job_run_id=1,
            code='upload_validate',
            action_type='PYTHON',
            status='PENDING',
            input_json=json.dumps(input_json)
        )
        
        # Assert
        assert node_run.input_json is not None
        stored_input = json.loads(node_run.input_json)
        assert stored_input['upload_id'] == 1
    
    def test_node_run_with_output_json(self):
        """UT-MODEL-008: NodeRun 包含 output_json"""
        # Arrange
        from app.models import NodeRun
        
        output_json = {'result': 'success'}
        
        # Act
        node_run = NodeRun(
            job_run_id=1,
            code='upload_validate',
            action_type='PYTHON',
            status='PENDING',
            output_json=json.dumps(output_json)
        )
        
        # Assert
        assert node_run.output_json is not None
        stored_output = json.loads(node_run.output_json)
        assert stored_output['result'] == 'success'
    
    def test_node_run_with_error_json(self):
        """UT-MODEL-009: NodeRun 包含 error_json"""
        # Arrange
        from app.models import NodeRun
        
        error_json = {'error': 'Test error'}
        
        # Act
        node_run = NodeRun(
            job_run_id=1,
            code='upload_validate',
            action_type='PYTHON',
            status='PENDING',
            error_json=json.dumps(error_json)
        )
        
        # Assert
        assert node_run.error_json is not None
        stored_error = json.loads(node_run.error_json)
        assert stored_error['error'] == 'Test error'
    
    def test_node_run_status_transitions(self):
        """UT-MODEL-010: NodeRun 状态转换"""
        # Arrange
        from app.models import NodeRun
        
        node_run = NodeRun(
            job_run_id=1,
            code='node_1',
            action_type='PYTHON',
            status='PENDING'
        )
        
        # Act & Assert
        # PENDING -> READY
        node_run.status = 'READY'
        assert node_run.status == 'READY'
        
        # READY -> RUNNING
        node_run.status = 'RUNNING'
        assert node_run.status == 'RUNNING'
        
        # RUNNING -> SUCCESS
        node_run.status = 'SUCCESS'
        assert node_run.status == 'SUCCESS'
        
        # RUNNING -> FAILED
        node_run.status = 'RUNNING'
        node_run.status = 'FAILED'
        assert node_run.status == 'FAILED'
        
        # FAILED -> RETRYING
        node_run.status = 'RETRYING'
        assert node_run.status == 'RETRYING'
        
        # RETRYING -> RUNNING
        node_run.status = 'RUNNING'
        assert node_run.status == 'RUNNING'
        
        # RUNNING -> SKIPPED
        node_run.status = 'SKIPPED'
        assert node_run.status == 'SKIPPED'
