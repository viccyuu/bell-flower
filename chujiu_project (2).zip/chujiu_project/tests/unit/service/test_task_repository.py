# -*- coding: utf-8 -*-
"""
单元测试 - 任务 Repository

测试 task_repository.py 中的方法。

【测试范围】
1. create_with_template() - 从模板创建（插件来源）
2. create_with_llm_dag() - LLM 来源主 Job
"""
import pytest
import json


class TestTaskRepository:
    """TaskRepository 单元测试"""
    
    def test_create_with_template_success(self, app_context, db_session):
        """UT-REPO-001: 成功创建插件来源主 Job"""
        # Arrange
        from app.repository.task_repository import task_run_repository
        from app.models import TaskTemplate
        
        # Create template first
        template = TaskTemplate(
            code='test_template_v2',
            name='Test Template',
            plugin_code='excel_vba_to_wps_js',
            is_builtin=1
        )
        db_session.add(template)
        db_session.commit()
        
        # Act
        task_run = task_run_repository.create_with_template(
            template_code='test_template_v2',
            upload_id=1
        )
        
        # Assert
        assert task_run is not None
        assert task_run.upload_file_id == 1
        assert task_run.status == 'READY'
    
    def test_create_with_template_creates_job(self, app_context, db_session):
        """UT-REPO-002: 验证创建 JobRun"""
        # Arrange
        from app.repository.task_repository import task_run_repository
        from app.models import TaskTemplate, JobRun
        
        # Create template first
        template = TaskTemplate(
            code='test_template_v3',
            name='Test Template',
            plugin_code='excel_vba_to_wps_js',
            is_builtin=1
        )
        db_session.add(template)
        db_session.commit()
        
        # Act
        task_run = task_run_repository.create_with_template(
            template_code='test_template_v3',
            upload_id=1
        )
        
        main_job = JobRun.query.filter_by(task_run_id=task_run.id, is_sub_job=False).first()
        
        # Assert
        assert main_job is not None
        assert main_job.task_run_id == task_run.id
    
    def test_create_with_llm_dag_success(self, app_context, db_session):
        """UT-REPO-003: 成功创建 LLM 来源主 Job"""
        # Arrange
        from app.repository.task_repository import task_run_repository
        
        mock_llm_dag = {
            "job": {"code": "llm_job", "name": "LLM Job"},
            "nodes": [{"code": f"node_{i}"} for i in range(5)],
            "edges": []
        }
        
        # Act
        task_run = task_run_repository.create_with_llm_dag(
            llm_dag=mock_llm_dag,
            upload_id=1
        )
        
        # Assert
        assert task_run is not None
        assert task_run.upload_file_id == 1
    
    def test_create_with_llm_dag_job_source(self, app_context, db_session):
        """UT-REPO-004: 验证 job_source='LLM'"""
        # Arrange
        from app.repository.task_repository import task_run_repository
        from app.models import JobRun
        
        mock_llm_dag = {
            "job": {"code": "llm_job", "name": "LLM Job"},
            "nodes": [],
            "edges": []
        }
        
        # Act
        task_run = task_run_repository.create_with_llm_dag(
            llm_dag=mock_llm_dag,
            upload_id=1
        )
        
        main_job = JobRun.query.filter_by(task_run_id=task_run.id, is_sub_job=False).first()
        
        # Assert
        assert main_job is not None
        assert main_job.job_source == 'LLM'
        assert main_job.is_sub_job == False
    
    def test_create_with_llm_dag_stores_dag(self, app_context, db_session):
        """UT-REPO-005: 验证 dag_json 正确存储"""
        # Arrange
        from app.repository.task_repository import task_run_repository
        from app.models import JobRun
        
        mock_llm_dag = {
            "job": {"code": "llm_job", "name": "LLM Job"},
            "nodes": [{"code": "node_1"}],
            "edges": []
        }
        
        # Act
        task_run = task_run_repository.create_with_llm_dag(
            llm_dag=mock_llm_dag,
            upload_id=1
        )
        
        main_job = JobRun.query.filter_by(task_run_id=task_run.id, is_sub_job=False).first()
        
        # Assert
        assert main_job is not None
        assert main_job.dag_json is not None
        
        stored_dag = json.loads(main_job.dag_json)
        assert stored_dag['job']['code'] == 'llm_job'
    
    def test_create_with_template_not_found(self, app_context, db_session):
        """UT-REPO-006: 模板不存在"""
        # Arrange
        from app.repository.task_repository import task_run_repository
        
        # Act & Assert
        with pytest.raises(ValueError):
            task_run_repository.create_with_template(
                template_code='non_existent_template',
                upload_id=1
            )
    
    def test_get_by_unique_key(self, app_context, db_session):
        """UT-REPO-007: 根据唯一键获取 TaskRun"""
        # Arrange
        from app.repository.task_repository import task_run_repository
        from app.models import TaskTemplate, TaskRun
        
        # Create template and task_run
        template = TaskTemplate(
            code='test_template_v4',
            name='Test Template',
            is_builtin=1
        )
        db_session.add(template)
        db_session.commit()
        
        task_run = TaskRun(
            task_template_id=template.id,
            upload_file_id=1,
            status='CREATED'
        )
        db_session.add(task_run)
        db_session.commit()
        
        # Act
        found_task = task_run_repository.get_by_unique_key(
            template_code='test_template_v4',
            upload_id=1
        )
        
        # Assert
        assert found_task is not None
        assert found_task.id == task_run.id
    
    def test_update_status(self, app_context, db_session):
        """UT-REPO-008: 更新 TaskRun 状态"""
        # Arrange
        from app.repository.task_repository import task_run_repository
        from app.models import TaskTemplate, TaskRun
        
        # Create template and task_run
        template = TaskTemplate(
            code='test_template_v5',
            name='Test Template',
            is_builtin=1
        )
        db_session.add(template)
        db_session.commit()
        
        task_run = TaskRun(
            task_template_id=template.id,
            upload_file_id=1,
            status='CREATED'
        )
        db_session.add(task_run)
        db_session.commit()
        
        # Act
        updated_task = task_run_repository.update_status(task_run.id, 'RUNNING')
        
        # Assert
        assert updated_task is not None
        assert updated_task.status == 'RUNNING'
    
    def test_create_with_llm_dag_creates_nodes(self, app_context, db_session):
        """UT-REPO-009: 验证创建 NodeRun"""
        # Arrange
        from app.repository.task_repository import task_run_repository
        from app.models import NodeRun
        
        mock_llm_dag = {
            "job": {"code": "llm_job", "name": "LLM Job"},
            "nodes": [
                {"code": "node_1", "action_type": "PYTHON"},
                {"code": "node_2", "action_type": "LLM"}
            ],
            "edges": []
        }
        
        # Act
        task_run = task_run_repository.create_with_llm_dag(
            llm_dag=mock_llm_dag,
            upload_id=1
        )
        
        main_job = NodeRun.query.filter_by(job_run_id=task_run.job_runs[0].id if task_run.job_runs else None).all()
        
        # Assert
        # 验证节点已创建（简化验证）
        assert task_run is not None
    
    def test_create_with_llm_dag_with_runtime_params(self, app_context, db_session):
        """UT-REPO-010: 验证 runtime_params 存储"""
        # Arrange
        from app.repository.task_repository import task_run_repository
        
        mock_llm_dag = {
            "job": {"code": "llm_job", "name": "LLM Job"},
            "nodes": [],
            "edges": []
        }
        
        runtime_params = {'key': 'value'}
        
        # Act
        task_run = task_run_repository.create_with_llm_dag(
            llm_dag=mock_llm_dag,
            upload_id=1,
            runtime_params=runtime_params
        )
        
        # Assert
        assert task_run is not None
        assert task_run.runtime_params_json is not None
