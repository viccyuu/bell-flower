# -*- coding: utf-8 -*-
"""
任务执行服务单元测试

基于 BDD task_execution.feature 和 dag_execution.feature 场景下沉的单元测试。

覆盖 BDD 场景：
- 成功创建任务
- 成功启动任务
- 任务执行成功/失败
- DAG 初始化与调度
- 节点执行与重试
"""
import pytest
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime


class TestTaskRunData:
    """TaskRun 数据测试"""
    
    def test_task_run_data_structure(self):
        """用例：任务运行数据结构"""
        # Arrange
        task_data = {
            'task_template_id': 1,
            'upload_file_id': 1,
            'status': 'CREATED',
            'runtime_params_json': '{}'
        }
        
        # Act & Assert
        assert task_data['status'] == 'CREATED'
        assert task_data['task_template_id'] == 1
    
    def test_task_status_transitions(self):
        """用例：任务状态转换规则"""
        # Arrange
        valid_transitions = {
            'CREATED': ['READY', 'CANCELLED'],
            'READY': ['RUNNING', 'CANCELLED'],
            'RUNNING': ['SUCCESS', 'FAILED', 'PARTIAL_SUCCESS', 'CANCELLED'],
            'SUCCESS': [],
            'FAILED': ['RETRYING'],
            'PARTIAL_SUCCESS': []
        }
        
        # Act & Assert
        assert 'READY' in valid_transitions['CREATED']
        assert valid_transitions['SUCCESS'] == []


class TestTaskCreation:
    """任务创建测试"""
    
    def test_create_task_with_valid_template(self):
        """用例：使用有效模板创建任务"""
        # Arrange
        template_data = {
            'code': 'excel_vba_to_wps_js',
            'name': 'MS Excel VBA 转 WPS JS',
            'plugin_code': 'excel_vba_to_wps_js',
            'is_builtin': 1,
            'version': 1
        }
        
        # Act & Assert
        assert template_data['code'] == 'excel_vba_to_wps_js'
        assert template_data['is_builtin'] == 1
    
    def test_create_task_with_invalid_template(self):
        """用例：使用无效模板创建任务"""
        # Arrange
        template_code = 'non_existent_template'
        valid_templates = ['excel_vba_to_wps_js', 'web_briefing', 'wps_js_to_excel_vba']
        
        # Act & Assert
        assert template_code not in valid_templates
    
    def test_create_task_without_upload_file(self):
        """用例：未上传文件时创建任务应失败"""
        # Arrange
        upload_file_id = 'test_upload_id_123'
        
        # Act & Assert
        assert upload_file_id is not None


class TestTaskExecution:
    """任务执行测试"""
    
    def test_start_task_from_created_state(self):
        """用例：从 CREATED 状态启动任务"""
        # Arrange
        task_data = {
            'task_template_id': 1,
            'upload_file_id': 1,
            'status': 'CREATED'
        }
        
        # Act
        task_data['status'] = 'READY'
        
        # Assert
        assert task_data['status'] == 'READY'
    
    def test_start_task_from_invalid_state(self):
        """用例：从无效状态启动任务应失败"""
        # Arrange
        task_data = {
            'task_template_id': 1,
            'upload_file_id': 1,
            'status': 'SUCCESS'  # 终止状态
        }
        
        # Act & Assert
        assert task_data['status'] not in ['CREATED', 'READY']
    
    def test_task_execution_success(self):
        """用例：任务执行成功"""
        # Arrange
        task_data = {
            'task_template_id': 1,
            'upload_file_id': 1,
            'status': 'RUNNING',
            'finished_at': None
        }
        
        # Act
        task_data['status'] = 'SUCCESS'
        task_data['finished_at'] = '2026-03-14T08:00:00Z'
        
        # Assert
        assert task_data['status'] == 'SUCCESS'
        assert task_data['finished_at'] is not None
    
    def test_task_execution_failure(self):
        """用例：任务执行失败"""
        # Arrange
        task_data = {
            'task_template_id': 1,
            'upload_file_id': 1,
            'status': 'RUNNING',
            'context_json': ''
        }
        error_message = "Node execution failed"
        
        # Act
        task_data['status'] = 'FAILED'
        task_data['context_json'] = f'{{"error": "{error_message}"}}'
        
        # Assert
        assert task_data['status'] == 'FAILED'
        assert 'error' in task_data['context_json']
    
    def test_task_partial_success(self):
        """用例：任务部分成功"""
        # Arrange
        task_data = {
            'task_template_id': 1,
            'upload_file_id': 1,
            'status': 'RUNNING'
        }
        
        # Act
        task_data['status'] = 'PARTIAL_SUCCESS'
        
        # Assert
        assert task_data['status'] == 'PARTIAL_SUCCESS'


class TestDAGLogic:
    """DAG 逻辑测试"""
    
    def test_dag_structure(self):
        """用例：DAG 结构"""
        # Arrange
        dag = {
            'nodes': [
                {'id': 1, 'code': 'node_1', 'dependencies': []},
                {'id': 2, 'code': 'node_2', 'dependencies': [1]},
            ],
            'edges': [
                {'from': 1, 'to': 2}
            ]
        }
        
        # Assert
        assert 'nodes' in dag
        assert 'edges' in dag
        assert len(dag['nodes']) == 2
    
    def test_find_ready_nodes(self):
        """用例：查找就绪节点"""
        # Arrange
        nodes = [
            {'id': 1, 'dependencies': []},
            {'id': 2, 'dependencies': [1]},
        ]
        
        # Act - 无依赖的节点为就绪
        ready = [n['id'] for n in nodes if len(n['dependencies']) == 0]
        
        # Assert
        assert 1 in ready
        assert 2 not in ready


class TestNodeExecution:
    """节点执行测试"""
    
    def test_node_status_ready(self):
        """用例：节点状态为 READY"""
        # Arrange
        node_data = {
            'job_id': 1,
            'node_code': 'test_node',
            'node_type': 'API',
            'status': 'READY'
        }
        
        # Assert
        assert node_data['status'] == 'READY'
    
    def test_node_status_success(self):
        """用例：节点执行成功"""
        # Arrange
        node_data = {
            'job_id': 1,
            'node_code': 'test_node',
            'node_type': 'API',
            'status': 'RUNNING',
            'output': None
        }
        
        # Act
        node_data['status'] = 'SUCCESS'
        node_data['output'] = '{"result": "success"}'
        
        # Assert
        assert node_data['status'] == 'SUCCESS'
        assert node_data['output'] is not None
    
    def test_node_status_failure(self):
        """用例：节点执行失败"""
        # Arrange
        node_data = {
            'job_id': 1,
            'node_code': 'test_node',
            'node_type': 'API',
            'status': 'RUNNING',
            'error_message': '',
            'retry_count': 0
        }
        
        # Act
        node_data['status'] = 'FAILED'
        node_data['error_message'] = 'Execution failed'
        
        # Assert
        assert node_data['status'] == 'FAILED'
        assert node_data['error_message'] == 'Execution failed'
    
    def test_node_retry_success(self):
        """用例：节点重试成功"""
        # Arrange
        node_data = {
            'job_id': 1,
            'node_code': 'test_node',
            'status': 'FAILED',
            'retry_count': 1,
            'max_retries': 3
        }
        
        # Act
        node_data['status'] = 'READY'
        node_data['status'] = 'SUCCESS'
        
        # Assert
        assert node_data['status'] == 'SUCCESS'
        assert node_data['retry_count'] < node_data['max_retries']
    
    def test_node_retry_exhausted(self):
        """用例：节点重试次数用尽"""
        # Arrange
        node_data = {
            'job_id': 1,
            'node_code': 'test_node',
            'status': 'FAILED',
            'retry_count': 3,
            'max_retries': 3
        }
        
        # Act & Assert
        assert node_data['retry_count'] >= node_data['max_retries']


class TestTaskContext:
    """任务上下文测试"""
    
    def test_context_variables(self):
        """用例：上下文变量"""
        # Arrange
        context = {'task_id': 1, 'job_id': 1, 'variables': {}}
        
        # Act
        context['variables']['key1'] = 'value1'
        
        # Assert
        assert context['variables']['key1'] == 'value1'
    
    def test_context_inheritance(self):
        """用例：上下文继承"""
        # Arrange
        parent = {'var1': 'value1'}
        child = {**parent, 'var2': 'value2'}
        
        # Assert
        assert 'var1' in child
        assert 'var2' in child
