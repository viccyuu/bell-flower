# -*- coding: utf-8 -*-
"""
单元测试 - SubJob Routes

测试 routes_subjob.py 中的 API 端点。

【测试范围】
1. create_subjob() - 创建 SubJob
2. complete_subjob() - SubJob 完成回调
3. start_subjob() - 启动 SubJob
"""
import pytest
import json
from unittest.mock import Mock, patch, MagicMock


class TestSubJobRoutes:
    """SubJob Routes 单元测试"""
    
    def test_create_subjob_success(self, client, db_session):
        """UT-SUBJOB-001: 成功创建 SubJob"""
        # Arrange
        from app.models import TaskRun, JobRun
        
        # Create main job
        task_run = TaskRun(upload_file_id=1, status='RUNNING')
        db_session.add(task_run)
        db_session.commit()
        
        main_job = JobRun(
            task_run_id=task_run.id,
            code='main_job',
            name='Main Job',
            status='RUNNING',
            job_source='PLUGIN',
            is_sub_job=False
        )
        db_session.add(main_job)
        db_session.commit()
        
        subjob_dag = {
            "job": {"code": "subjob", "name": "SubJob"},
            "nodes": [{"code": "sub_node_1"}],
            "edges": []
        }
        
        payload = {
            "parent_job_id": main_job.id,
            "failed_node_code": "vba_to_vba_ast",
            "error_message": "Test error",
            "error_context": {"scenario": "Test"},
            "subjob_dag": subjob_dag
        }
        
        # Act
        response = client.post(
            f'/api/task-runs/{task_run.id}/subjobs',
            data=json.dumps(payload),
            content_type='application/json'
        )
        
        # Assert
        assert response.status_code == 201
        data = response.get_json()
        assert data['code'] == 'OK'
        assert 'subjob_id' in data['data']
    
    def test_create_subjob_is_sub_job(self, client, db_session):
        """UT-SUBJOB-002: SubJob 标记正确"""
        # Arrange
        from app.models import TaskRun, JobRun
        
        task_run = TaskRun(upload_file_id=1, status='RUNNING')
        db_session.add(task_run)
        db_session.commit()
        
        main_job = JobRun(
            task_run_id=task_run.id,
            code='main_job',
            status='RUNNING',
            job_source='PLUGIN',
            is_sub_job=False
        )
        db_session.add(main_job)
        db_session.commit()
        
        payload = {
            "parent_job_id": main_job.id,
            "failed_node_code": "vba_to_vba_ast",
            "subjob_dag": {"job": {}, "nodes": [], "edges": []}
        }
        
        # Act
        response = client.post(
            f'/api/task-runs/{task_run.id}/subjobs',
            data=json.dumps(payload),
            content_type='application/json'
        )
        
        data = response.get_json()
        subjob_id = data['data']['subjob_id']
        
        subjob = JobRun.query.get(subjob_id)
        
        # Assert
        assert subjob is not None
        assert subjob.is_sub_job == True
    
    def test_create_subjob_parent_job(self, client, db_session):
        """UT-SUBJOB-003: SubJob 关联父 Job"""
        # Arrange
        from app.models import TaskRun, JobRun
        
        task_run = TaskRun(upload_file_id=1, status='RUNNING')
        db_session.add(task_run)
        db_session.commit()
        
        main_job = JobRun(
            task_run_id=task_run.id,
            code='main_job',
            status='RUNNING',
            job_source='PLUGIN',
            is_sub_job=False
        )
        db_session.add(main_job)
        db_session.commit()
        
        payload = {
            "parent_job_id": main_job.id,
            "failed_node_code": "vba_to_vba_ast",
            "subjob_dag": {"job": {}, "nodes": [], "edges": []}
        }
        
        # Act
        response = client.post(
            f'/api/task-runs/{task_run.id}/subjobs',
            data=json.dumps(payload),
            content_type='application/json'
        )
        
        data = response.get_json()
        subjob_id = data['data']['subjob_id']
        
        subjob = JobRun.query.get(subjob_id)
        
        # Assert
        assert subjob is not None
        assert subjob.parent_job_id == main_job.id
    
    def test_create_subjob_from_subjob(self, client, db_session):
        """UT-SUBJOB-004: SubJob 创建 SubJob（应失败）"""
        # Arrange
        from app.models import TaskRun, JobRun
        
        task_run = TaskRun(upload_file_id=1, status='RUNNING')
        db_session.add(task_run)
        db_session.commit()
        
        # Create SubJob
        subjob = JobRun(
            task_run_id=task_run.id,
            code='subjob',
            status='RUNNING',
            job_source='LLM',
            is_sub_job=True,
            parent_job_id=None
        )
        db_session.add(subjob)
        db_session.commit()
        
        payload = {
            "parent_job_id": subjob.id,
            "failed_node_code": "node_1",
            "subjob_dag": {"job": {}, "nodes": [], "edges": []}
        }
        
        # Act
        response = client.post(
            f'/api/task-runs/{task_run.id}/subjobs',
            data=json.dumps(payload),
            content_type='application/json'
        )
        
        # Assert
        assert response.status_code == 400
        data = response.get_json()
        assert data['code'] == 'NOT_MAIN_JOB'
    
    def test_complete_subjob_success(self, client, db_session):
        """UT-SUBJOB-005: SubJob 成功完成"""
        # Arrange
        from app.models import TaskRun, JobRun
        
        task_run = TaskRun(upload_file_id=1, status='RUNNING')
        db_session.add(task_run)
        db_session.commit()
        
        main_job = JobRun(
            task_run_id=task_run.id,
            code='main_job',
            status='RUNNING',
            job_source='PLUGIN',
            is_sub_job=False
        )
        db_session.add(main_job)
        db_session.commit()
        
        subjob = JobRun(
            task_run_id=task_run.id,
            code='subjob',
            status='RUNNING',
            job_source='LLM',
            is_sub_job=True,
            parent_job_id=main_job.id,
            failed_node_code='vba_to_vba_ast'
        )
        db_session.add(subjob)
        db_session.commit()
        
        payload = {
            "status": "SUCCESS",
            "output": {"result": "success"},
            "recovery_node_code": "vba_to_vba_ast"
        }
        
        # Act
        response = client.post(
            f'/api/subjobs/{subjob.id}/complete',
            data=json.dumps(payload),
            content_type='application/json'
        )
        
        # Assert
        assert response.status_code == 200
        data = response.get_json()
        assert data['code'] == 'OK'
        
        # Verify SubJob status updated
        subjob_updated = JobRun.query.get(subjob.id)
        assert subjob_updated.status == 'SUCCESS'
    
    def test_complete_subjob_failed(self, client, db_session):
        """UT-SUBJOB-006: SubJob 失败完成"""
        # Arrange
        from app.models import TaskRun, JobRun
        
        task_run = TaskRun(upload_file_id=1, status='RUNNING')
        db_session.add(task_run)
        db_session.commit()
        
        main_job = JobRun(
            task_run_id=task_run.id,
            code='main_job',
            status='RUNNING',
            job_source='PLUGIN',
            is_sub_job=False
        )
        db_session.add(main_job)
        db_session.commit()
        
        subjob = JobRun(
            task_run_id=task_run.id,
            code='subjob',
            status='RUNNING',
            job_source='LLM',
            is_sub_job=True,
            parent_job_id=main_job.id
        )
        db_session.add(subjob)
        db_session.commit()
        
        payload = {
            "status": "FAILED",
            "output": {},
            "recovery_node_code": None
        }
        
        # Act
        response = client.post(
            f'/api/subjobs/{subjob.id}/complete',
            data=json.dumps(payload),
            content_type='application/json'
        )
        
        # Assert
        assert response.status_code == 200
        
        # Verify SubJob status updated
        subjob_updated = JobRun.query.get(subjob.id)
        assert subjob_updated.status == 'FAILED'
    
    def test_complete_subjob_resume_main_job(self, client, db_session):
        """UT-SUBJOB-007: SubJob 完成恢复主 Job"""
        # Arrange
        from app.models import TaskRun, JobRun, NodeRun
        
        task_run = TaskRun(upload_file_id=1, status='RUNNING')
        db_session.add(task_run)
        db_session.commit()
        
        main_job = JobRun(
            task_run_id=task_run.id,
            code='main_job',
            status='RUNNING',
            job_source='PLUGIN',
            is_sub_job=False
        )
        db_session.add(main_job)
        db_session.commit()
        
        # Create failed node
        failed_node = NodeRun(
            job_run_id=main_job.id,
            code='vba_to_vba_ast',
            status='FAILED'
        )
        db_session.add(failed_node)
        db_session.commit()
        
        subjob = JobRun(
            task_run_id=task_run.id,
            code='subjob',
            status='RUNNING',
            job_source='LLM',
            is_sub_job=True,
            parent_job_id=main_job.id,
            failed_node_code='vba_to_vba_ast'
        )
        db_session.add(subjob)
        db_session.commit()
        
        payload = {
            "status": "SUCCESS",
            "output": {"result": "success"},
            "recovery_node_code": "vba_to_vba_ast"
        }
        
        # Act
        response = client.post(
            f'/api/subjobs/{subjob.id}/complete',
            data=json.dumps(payload),
            content_type='application/json'
        )
        
        # Assert
        assert response.status_code == 200
        
        # Verify failed node reset to READY
        failed_node_updated = NodeRun.query.get(failed_node.id)
        assert failed_node_updated.status == 'READY'
    
    def test_start_subjob(self, client, db_session):
        """UT-SUBJOB-008: 启动 SubJob"""
        # Arrange
        from app.models import TaskRun, JobRun
        
        task_run = TaskRun(upload_file_id=1, status='RUNNING')
        db_session.add(task_run)
        db_session.commit()
        
        subjob = JobRun(
            task_run_id=task_run.id,
            code='subjob',
            status='CREATED',
            job_source='LLM',
            is_sub_job=True
        )
        db_session.add(subjob)
        db_session.commit()
        
        # Act
        response = client.post(f'/api/subjobs/{subjob.id}/start')
        
        # Assert
        assert response.status_code == 200
        data = response.get_json()
        assert data['code'] == 'OK'
        
        # Verify SubJob status updated
        subjob_updated = JobRun.query.get(subjob.id)
        assert subjob_updated.status == 'RUNNING'
