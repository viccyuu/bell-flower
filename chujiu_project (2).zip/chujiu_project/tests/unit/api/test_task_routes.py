# -*- coding: utf-8 -*-
"""
单元测试 - Task Routes

测试 routes_task.py 中的 API 端点。

【测试范围】
1. create_task_run() - 创建任务
2. start_task_run() - 启动任务
3. get_task_run_detail() - 获取任务详情
4. list_task_runs() - 获取任务列表
"""
import pytest
import json
from unittest.mock import Mock, patch, MagicMock


class TestTaskRoutes:
    """Task Routes 单元测试"""
    
    def test_create_task_run_plugin(self, client, db_session):
        """UT-ROUTE-001: 创建插件来源任务"""
        # Arrange
        from app.models import TaskTemplate
        
        template = TaskTemplate(
            code='excel_vba_to_wps_js',
            name='MS Excel VBA 转 WPS JS',
            plugin_code='excel_vba_to_wps_js',
            is_builtin=1
        )
        db_session.add(template)
        db_session.commit()
        
        payload = {
            'taskTemplateCode': 'excel_vba_to_wps_js',
            'uploadId': 1
        }
        
        # Act
        response = client.post(
            '/api/task-runs',
            data=json.dumps(payload),
            content_type='application/json'
        )
        
        # Assert
        assert response.status_code == 201
        data = response.get_json()
        assert data['code'] == 'OK'
        assert 'taskRunId' in data['data']
    
    def test_create_task_run_llm(self, client, db_session):
        """UT-ROUTE-002: 创建 LLM 来源任务"""
        # Arrange
        llm_dag = {
            "job": {"code": "llm_job", "name": "LLM Job"},
            "nodes": [{"code": "node_1"}],
            "edges": []
        }
        
        payload = {
            'llm_dag': llm_dag,
            'uploadId': 1
        }
        
        # Act
        # TODO: Implement LLM task creation endpoint
        # response = client.post('/api/llm-tasks', ...)
        
        # Assert
        # assert response.status_code == 201
    
    def test_start_task_run(self, client, db_session):
        """UT-ROUTE-003: 启动任务"""
        # Arrange
        from app.models import TaskRun
        
        task_run = TaskRun(
            task_template_id=1,
            upload_file_id=1,
            status='CREATED'
        )
        db_session.add(task_run)
        db_session.commit()
        
        # Act
        response = client.post(f'/api/task-runs/{task_run.id}/start')
        
        # Assert
        assert response.status_code == 200
        data = response.get_json()
        assert data['code'] == 'OK'
        assert 'taskRunId' in data['data']
    
    def test_get_task_run_detail(self, client, db_session):
        """UT-ROUTE-004: 获取任务详情"""
        # Arrange
        from app.models import TaskRun, TaskTemplate, JobRun
        
        template = TaskTemplate(
            code='excel_vba_to_wps_js',
            name='MS Excel VBA 转 WPS JS'
        )
        db_session.add(template)
        db_session.commit()
        
        task_run = TaskRun(
            task_template_id=template.id,
            upload_file_id=1,
            status='RUNNING'
        )
        db_session.add(task_run)
        db_session.commit()
        
        main_job = JobRun(
            task_run_id=task_run.id,
            code='main_job',
            status='RUNNING',
            job_source='PLUGIN',
            is_sub_job=False
        )
        db_session.add(main_job)
        db_session.commit()
        
        # Act
        response = client.get(f'/api/task-runs/{task_run.id}')
        
        # Assert
        assert response.status_code == 200
        data = response.get_json()
        assert data['code'] == 'OK'
        assert 'data' in data
        assert 'dagNodes' in data['data']
        assert 'dagEdges' in data['data']
    
    def test_list_task_runs(self, client, db_session):
        """UT-ROUTE-005: 获取任务列表"""
        # Arrange
        from app.models import TaskRun
        
        for i in range(3):
            task_run = TaskRun(
                task_template_id=1,
                upload_file_id=i+1,
                status='RUNNING'
            )
            db_session.add(task_run)
        db_session.commit()
        
        # Act
        response = client.get('/api/task-runs')
        
        # Assert
        assert response.status_code == 200
        data = response.get_json()
        assert data['code'] == 'OK'
        assert isinstance(data['data'], list)
        assert len(data['data']) > 0
    
    def test_create_task_run_template_not_found(self, client, db_session):
        """UT-ROUTE-006: 模板不存在"""
        # Arrange
        payload = {
            'taskTemplateCode': 'non_existent_template',
            'uploadId': 1
        }
        
        # Act
        response = client.post(
            '/api/task-runs',
            data=json.dumps(payload),
            content_type='application/json'
        )
        
        # Assert
        assert response.status_code == 404
        data = response.get_json()
        assert data['code'] == 'TEMPLATE_NOT_FOUND'
    
    def test_create_task_run_upload_not_found(self, client, db_session):
        """UT-ROUTE-007: 上传文件不存在"""
        # Arrange
        from app.models import TaskTemplate
        
        template = TaskTemplate(
            code='excel_vba_to_wps_js',
            name='MS Excel VBA 转 WPS JS'
        )
        db_session.add(template)
        db_session.commit()
        
        payload = {
            'taskTemplateCode': 'excel_vba_to_wps_js',
            'uploadId': 999
        }
        
        # Act
        response = client.post(
            '/api/task-runs',
            data=json.dumps(payload),
            content_type='application/json'
        )
        
        # Assert
        assert response.status_code == 404
        data = response.get_json()
        assert data['code'] == 'UPLOAD_NOT_FOUND'
    
    def test_create_task_run_idempotency(self, client, db_session):
        """UT-ROUTE-008: 幂等性检查"""
        # Arrange
        from app.models import TaskTemplate, TaskRun
        
        template = TaskTemplate(
            code='excel_vba_to_wps_js',
            name='MS Excel VBA 转 WPS JS'
        )
        db_session.add(template)
        db_session.commit()
        
        # Create existing task
        existing_task = TaskRun(
            task_template_id=template.id,
            upload_file_id=1,
            status='RUNNING'
        )
        db_session.add(existing_task)
        db_session.commit()
        
        payload = {
            'taskTemplateCode': 'excel_vba_to_wps_js',
            'uploadId': 1
        }
        
        # Act - First request
        response1 = client.post(
            '/api/task-runs',
            data=json.dumps(payload),
            content_type='application/json'
        )
        
        # Act - Second request (should return existing task)
        response2 = client.post(
            '/api/task-runs',
            data=json.dumps(payload),
            content_type='application/json'
        )
        
        # Assert
        assert response1.status_code == 201
        assert response2.status_code == 200
        
        data2 = response2.get_json()
        assert data2['code'] == 'OK'
        assert data2['data']['duplicate'] == True
        assert data2['data']['taskRunId'] == existing_task.id
    
    def test_start_task_run_already_running(self, client, db_session):
        """UT-ROUTE-009: 启动已运行的任务"""
        # Arrange
        from app.models import TaskRun
        
        task_run = TaskRun(
            task_template_id=1,
            upload_file_id=1,
            status='RUNNING'
        )
        db_session.add(task_run)
        db_session.commit()
        
        # Act
        response = client.post(f'/api/task-runs/{task_run.id}/start')
        
        # Assert
        assert response.status_code == 200
        data = response.get_json()
        assert data['code'] == 'OK'
        assert data['data']['status'] == 'RUNNING'
    
    def test_start_task_run_not_found(self, client, db_session):
        """UT-ROUTE-010: 启动不存在的任务"""
        # Arrange
        # Act
        response = client.post('/api/task-runs/999/start')
        
        # Assert
        assert response.status_code == 404
        data = response.get_json()
        assert data['code'] == 'TASK_RUN_NOT_FOUND'
    
    def test_get_task_run_not_found(self, client, db_session):
        """UT-ROUTE-011: 获取不存在的任务详情"""
        # Act
        response = client.get('/api/task-runs/999')
        
        # Assert
        assert response.status_code == 404
        data = response.get_json()
        assert data['code'] == 'TASK_RUN_NOT_FOUND'
    
    def test_get_task_run_with_dag(self, client, db_session):
        """UT-ROUTE-012: 获取任务详情包含 DAG"""
        # Arrange
        from app.models import TaskRun, TaskTemplate, JobRun, NodeRun
        import json
        
        template = TaskTemplate(
            code='excel_vba_to_wps_js',
            name='MS Excel VBA 转 WPS JS',
            plugin_code='excel_vba_to_wps_js'
        )
        db_session.add(template)
        db_session.commit()
        
        task_run = TaskRun(
            task_template_id=template.id,
            upload_file_id=1,
            status='RUNNING'
        )
        db_session.add(task_run)
        db_session.commit()
        
        main_job = JobRun(
            task_run_id=task_run.id,
            code='main_job',
            status='RUNNING',
            job_source='PLUGIN',
            is_sub_job=False,
            dag_json=json.dumps({
                "nodes": [{"code": "node_1"}],
                "edges": []
            })
        )
        db_session.add(main_job)
        db_session.commit()
        
        node_run = NodeRun(
            job_run_id=main_job.id,
            code='node_1',
            status='PENDING'
        )
        db_session.add(node_run)
        db_session.commit()
        
        # Act
        response = client.get(f'/api/task-runs/{task_run.id}')
        
        # Assert
        assert response.status_code == 200
        data = response.get_json()
        assert data['code'] == 'OK'
        assert 'dagNodes' in data['data']
        assert 'dagEdges' in data['data']
        assert len(data['data']['dagNodes']) > 0
