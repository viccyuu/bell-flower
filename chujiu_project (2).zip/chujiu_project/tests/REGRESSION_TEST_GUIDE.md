# 鍥炲綊娴嬭瘯鎸囧崡

## 蹇€熷紑濮?
### 杩愯瀹屾暣鍥炲綊娴嬭瘯

```bash
cd chujiu_project
pytest tests/integration/test_regression.py -v
```

### 杩愯鐗瑰畾娴嬭瘯绫?
```bash
# 鍋ュ悍妫€鏌?pytest tests/integration/test_regression.py::TestHealthCheck -v

# API 璺敱娴嬭瘯
pytest tests/integration/test_regression.py::TestApiRoutes -v

# 鏂囦欢涓婁紶娴嬭瘯
pytest tests/integration/test_regression.py::TestFileUpload -v

# 浠诲姟鍒涘缓娴嬭瘯
pytest tests/integration/test_regression.py::TestTaskCreation -v

# 浠诲姟璇︽儏娴嬭瘯
pytest tests/integration/test_regression.py::TestTaskDetail -v

# 鍓嶇椤甸潰娴嬭瘯
pytest tests/integration/test_regression.py::TestFrontendPages -v

# 鍥炲綊娴嬭瘯娓呭崟
pytest tests/integration/test_regression.py::TestRegressionChecklist -v
```

### 杩愯鍗曚釜娴嬭瘯

```bash
# 娴嬭瘯鍋ュ悍妫€鏌ョ鐐?pytest tests/integration/test_regression.py::TestHealthCheck::test_health_endpoint -v

# 娴嬭瘯浠诲姟鍒楄〃绔偣
pytest tests/integration/test_regression.py::TestApiRoutes::test_task_runs_list_endpoint -v

# 娴嬭瘯 DAG 鏁版嵁鍔犺浇
pytest tests/integration/test_regression.py::TestTaskDetail::test_task_detail_includes_dag_nodes -v
```

## 娴嬭瘯瑕嗙洊鐨勫巻鍙查棶棰?
| 闂缂栧彿 | 闂鎻忚堪 | 娴嬭瘯鐢ㄤ緥 |
|---------|---------|---------|
| #1 | API 璺敱缂哄け锛?api/task-runs GET銆?api/artifacts GET锛?| `TestApiRoutes` |
| #2 | 鍏ㄥ眬鍑芥暟鏈毚闇诧紙createTaskRun銆乻tartTask銆乿iewTask锛?| `TestFrontendPages::test_app_js_exports_global_functions` |
| #3 | 鍙橀噺浣滅敤鍩熼敊璇紙dagNodes is not defined锛?| `TestRegressionChecklist::test_variable_scope` |
| #4 | DAG 鏁版嵁鍔犺浇澶辫触锛堝悗绔湭杩斿洖 dagNodes锛?| `TestTaskDetail::test_task_detail_includes_dag_nodes` |
| #5 | 鍓嶇椤甸潰鍔犺浇閿欒锛圲nexpected token '<'锛?| `TestFrontendPages::test_index_page_loads` |

## 鍓嶇疆鏉′欢

1. **鏈嶅姟杩愯涓?*锛氱‘淇?Flask 搴旂敤鍦?`http://127.0.0.1:5001` 杩愯
   ```bash
   cd chujiu_project
   py app.py
   ```

2. **渚濊禆瀹夎**锛?   ```bash
   pip install -r requirements.txt
   pip install pytest requests
   ```

3. **鏁版嵁搴撳垵濮嬪寲**锛氶娆¤繍琛屼細鑷姩鍒涘缓鏁版嵁搴?
## 娴嬭瘯鎶ュ憡

### 鏌ョ湅娴嬭瘯瑕嗙洊鐜?
```bash
pytest tests/integration/test_regression.py --cov=. --cov-report=html --cov-report=term
```

### 鐢熸垚 JUnit 鎶ュ憡

```bash
pytest tests/integration/test_regression.py --junitxml=test-results.xml -v
```

### 澶辫触鏃跺揩閫熻皟璇?
```bash
pytest tests/integration/test_regression.py -v --tb=long -s
```

## 鎸佺画闆嗘垚

### 鍦?CI/CD 涓繍琛?
```yaml
# 绀轰緥锛欸itHub Actions
- name: Run Regression Tests
  run: |
    cd chujiu_project
    pip install -r requirements.txt
    py app.py &
    sleep 3
    pytest tests/integration/test_regression.py -v --junitxml=test-results.xml
```

### 鏈湴寮€鍙戝伐浣滄祦

```bash
# 1. 淇敼浠ｇ爜鍚?# 2. 閲嶅惎鏈嶅姟
# 3. 杩愯鍥炲綊娴嬭瘯
pytest tests/integration/test_regression.py -v

# 4. 楠岃瘉鎵€鏈夋祴璇曢€氳繃
# 鉁?鎵€鏈夋祴璇曢€氳繃 -> 鎻愪氦浠ｇ爜
# 鉂?鏈夋祴璇曞け璐?-> 淇闂
```

## 娴嬭瘯鏁版嵁娓呯悊

娴嬭瘯浼氳嚜鍔ㄥ垱寤烘祴璇曟暟鎹紝娓呯悊鏂规硶锛?
```bash
# 鍒犻櫎娴嬭瘯鏁版嵁搴?rm instance/app.db

# 鍒犻櫎娴嬭瘯鏂囦欢
rm -rf uploads/*
rm -rf artifacts/*
```

## 甯歌闂

### Q: 娴嬭瘯澶辫触 "Connection refused"
**A**: 纭繚 Flask 鏈嶅姟姝ｅ湪杩愯锛?```bash
py app.py
```

### Q: 娴嬭瘯澶辫触 "404 Not Found"
**A**: 妫€鏌?API 璺敱鏄惁姝ｇ‘娉ㄥ唽锛屾煡鐪?`web/` 鐩綍涓嬬殑璺敱鏂囦欢

### Q: 娴嬭瘯澶辫触 "dagNodes is not defined"
**A**: 妫€鏌ュ墠绔?JS 鏂囦欢涓槸鍚︿娇鐢ㄤ簡姝ｇ‘鐨勫彉閲忓悕锛坄dagData.nodes` 鑰岄潪 `dagNodes`锛?
## 娴嬭瘯娓呭崟

姣忔淇敼鍚庤繍琛屼互涓嬫祴璇曪細

- [ ] 鉁?鍋ュ悍妫€鏌ラ€氳繃
- [ ] 鉁?API 璺敱娴嬭瘯閫氳繃
- [ ] 鉁?鏂囦欢涓婁紶娴嬭瘯閫氳繃
- [ ] 鉁?浠诲姟鍒涘缓娴嬭瘯閫氳繃
- [ ] 鉁?浠诲姟璇︽儏娴嬭瘯閫氳繃
- [ ] 鉁?鍓嶇椤甸潰娴嬭瘯閫氳繃
- [ ] 鉁?鍥炲綊娴嬭瘯娓呭崟閫氳繃

---

**鏈€鍚庢洿鏂?*: 2026-03-13  
**缁存姢鑰?*: Chujiu Design Team
