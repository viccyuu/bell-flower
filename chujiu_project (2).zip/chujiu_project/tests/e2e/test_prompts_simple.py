# -*- coding: utf-8 -*-
"""
E2E 娴嬭瘯 - 鎻愮ず璇嶅簱锛堝疄鐢ㄧ増锛?"""
import pytest
from playwright.sync_api import Page, expect


class TestPromptLibrarySimple:
    """鎻愮ず璇嶅簱绠€鍖栨祴璇?""
    
    def test_prompts_page_loads(self, page: Page, base_url: str):
        """E2E-L01: 鎻愮ず璇嶅簱椤甸潰鍔犺浇"""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(3000)
        
        # 楠岃瘉鏈夊崱鐗?        card = page.locator('.card')
        expect(card).to_be_visible()
    
    def test_prompts_has_title(self, page: Page, base_url: str):
        """E2E-L02: 鎻愮ず璇嶅簱椤甸潰鏈夋爣棰?""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(3000)
        
        # 楠岃瘉鏈夋爣棰?        title = page.locator('.card-title, h3, div:has-text("鎻愮ず璇?)')
        expect(title).to_be_visible()
    
    def test_prompts_has_table(self, page: Page, base_url: str):
        """E2E-L03: 鎻愮ず璇嶅簱椤甸潰鏈夎〃鏍?""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(3000)
        
        # 楠岃瘉鏈夎〃鏍兼垨鍒楄〃
        table_or_list = page.locator('table, .data-table, .card')
        expect(table_or_list).to_be_visible()
