# -*- coding: utf-8 -*-
"""
E2E 测试 - 冒烟测试（使用数据属性选择器）

编码：UTF-8 无 BOM
选择器：数据属性优先
等待：智能等待
"""
import pytest
from playwright.sync_api import Page, expect


class TestQuickSmoke:
    """快速冒烟测试"""
    
    def test_app_loads(self, page: Page, base_url: str):
        """E2E-S01: 应用能加载"""
        page.goto(base_url)
        page.wait_for_load_state('load')
        expect(page).to_have_title("Chujiu Design TodoList")
    
    def test_upload_page_loads(self, page: Page, base_url: str):
        """E2E-S02: 上传页面能加载"""
        page.goto(f"{base_url}/#/upload")
        page.wait_for_load_state('load')
        page.wait_for_timeout(3000)
        
        # 使用通用选择器（页面动态生成）
        card = page.locator('.card')
        expect(card).to_be_visible()
    
    def test_tasks_page_loads(self, page: Page, base_url: str):
        """E2E-S03: 任务页面能加载"""
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        
        # 使用通用选择器
        card = page.locator('.card')
        expect(card).to_be_visible()
    
    def test_plugins_page_loads(self, page: Page, base_url: str):
        """E2E-S04: 插件页面能加载"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(3000)
        
        # 使用通用选择器
        card = page.locator('.card')
        expect(card).to_be_visible()
    
    def test_templates_page_loads(self, page: Page, base_url: str):
        """E2E-S05: 提示词库页面能加载"""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(3000)
        
        # 使用通用选择器
        card = page.locator('.card')
        expect(card).to_be_visible()
