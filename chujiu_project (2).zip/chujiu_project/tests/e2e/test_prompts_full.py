# -*- coding: utf-8 -*-
"""
E2E 娴嬭瘯 - 鎻愮ず璇嶅簱鍔熻兘锛堝畬鏁寸増锛?
瑕嗙洊 5 涓祴璇曞眰娆★細
1. 椤甸潰鍔犺浇
2. 鍏冪礌瀛樺湪
3. 鐐瑰嚮浜や簰
4. 娴佺▼楠岃瘉
5. 鏁版嵁楠岃瘉
"""
import pytest
from playwright.sync_api import Page, expect


class TestPromptLibraryPageLoad:
    """鎻愮ず璇嶅簱椤甸潰鍔犺浇娴嬭瘯"""
    
    def test_prompt_library_page_loads_successfully(self, page: Page, base_url: str):
        """E2E-050: 鎻愮ず璇嶅簱椤甸潰鎴愬姛鍔犺浇"""
        page.goto(f"{base_url}/#/templates")
        
        # 楠岃瘉椤甸潰鍔犺浇
        expect(page).to_have_title("Chujiu TodoList")
        
        # 楠岃瘉鎻愮ず璇嶅簱鍖哄煙瀛樺湪
        prompt_area = page.locator('.card:has-text("鎻愮ず璇?)')
        expect(prompt_area).to_be_visible(timeout=5000)
    
    def test_prompt_library_has_categories(self, page: Page, base_url: str):
        """E2E-051: 鎻愮ず璇嶅簱鏄剧ず鍒嗙被"""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(2000)
        
        # 楠岃瘉鑷冲皯鏈変竴涓垎绫?        category = page.locator('h3:has-text("Excel"), h3:has-text("浠ｇ爜"), h3:has-text("缃戦〉")')
        expect(category).to_be_visible()


class TestPromptLibraryElements:
    """鎻愮ず璇嶅簱鍏冪礌瀛樺湪娴嬭瘯"""
    
    def test_add_prompt_button_exists(self, page: Page, base_url: str):
        """E2E-052: 鏂板鎻愮ず璇嶆寜閽瓨鍦?""
        page.goto(f"{base_url}/#/templates")
        
        add_btn = page.locator('button:has-text("鏂板"), button:has-text("鉃?)')
        expect(add_btn).to_be_visible()
    
    def test_prompt_table_exists(self, page: Page, base_url: str):
        """E2E-053: 鎻愮ず璇嶈〃鏍煎瓨鍦?""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(2000)
        
        table = page.locator('table.data-table')
        expect(table).to_be_visible()
    
    def test_prompt_action_buttons_exist(self, page: Page, base_url: str):
        """E2E-054: 鎻愮ず璇嶆搷浣滄寜閽瓨鍦?""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(2000)
        
        # 楠岃瘉鏌ョ湅鎸夐挳瀛樺湪
        view_btn = page.locator('button:has-text("鏌ョ湅")')
        expect(view_btn).to_be_visible()
        
        # 楠岃瘉缂栬緫鎸夐挳瀛樺湪
        edit_btn = page.locator('button:has-text("缂栬緫")')
        expect(edit_btn).to_be_visible()


class TestPromptLibraryInteraction:
    """鎻愮ず璇嶅簱鐐瑰嚮浜や簰娴嬭瘯"""
    
    def test_click_add_prompt_button(self, page: Page, base_url: str):
        """E2E-055: 鐐瑰嚮鏂板鎻愮ず璇嶆寜閽?""
        page.goto(f"{base_url}/#/templates")
        
        add_btn = page.locator('button:has-text("鏂板")')
        add_btn.click()
        
        # 楠岃瘉寮圭獥鏄剧ず
        modal = page.locator('.modal-overlay')
        expect(modal).to_be_visible()
    
    def test_click_edit_prompt_button(self, page: Page, base_url: str):
        """E2E-056: 鐐瑰嚮缂栬緫鎻愮ず璇嶆寜閽?""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(2000)
        
        edit_btn = page.locator('button:has-text("缂栬緫")').first
        edit_btn.click()
        
        # 楠岃瘉缂栬緫寮圭獥鏄剧ず
        modal = page.locator('.modal-overlay')
        expect(modal).to_be_visible()
    
    def test_close_edit_modal(self, page: Page, base_url: str):
        """E2E-057: 鍏抽棴缂栬緫寮圭獥"""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(2000)
        
        # 鎵撳紑缂栬緫
        edit_btn = page.locator('button:has-text("缂栬緫")').first
        edit_btn.click()
        
        # 鍏抽棴寮圭獥
        close_btn = page.locator('.modal-overlay button:has-text("鉁?)')
        close_btn.click()
        
        # 楠岃瘉寮圭獥鍏抽棴
        modal = page.locator('.modal-overlay')
        expect(modal).to_be_hidden()
    
    def test_click_view_prompt_detail(self, page: Page, base_url: str):
        """E2E-058: 鐐瑰嚮鏌ョ湅鎻愮ず璇嶈鎯?""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(2000)
        
        view_btn = page.locator('button:has-text("鏌ョ湅")').first
        view_btn.click()
        
        # 楠岃瘉璇︽儏寮圭獥鏄剧ず
        modal = page.locator('.modal-overlay')
        expect(modal).to_be_visible()


class TestPromptLibraryFlow:
    """鎻愮ず璇嶅簱娴佺▼楠岃瘉娴嬭瘯"""
    
    def test_create_new_prompt_full_flow(self, page: Page, base_url: str):
        """E2E-059: 鍒涘缓鏂版彁绀鸿瘝瀹屾暣娴佺▼"""
        # 1. 鎵撳紑鏂板寮圭獥
        page.goto(f"{base_url}/#/templates")
        add_btn = page.locator('button:has-text("鏂板")')
        add_btn.click()
        
        # 2. 濉啓琛ㄥ崟
        page.fill('#prompt-code', 'test_prompt_e2e')
        page.fill('#prompt-name', 'E2E 娴嬭瘯鎻愮ず璇?)
        page.fill('#prompt-description', '鐢ㄤ簬 E2E 娴嬭瘯鐨勬彁绀鸿瘝')
        page.fill('#prompt-system', '浣犳槸涓€涓祴璇曞姪鎵?)
        page.fill('#prompt-user', '璇峰鐞嗭細{{input}}')
        
        # 3. 閫夋嫨鍒嗙被
        page.select_option('#prompt-category', '1')
        
        # 4. 淇濆瓨
        save_btn = page.locator('button:has-text("淇濆瓨")')
        save_btn.click()
        
        # 5. 楠岃瘉淇濆瓨鎴愬姛
        page.wait_for_timeout(2000)
        success_toast = page.locator('.toast-success, .toast:has-text("鎴愬姛")')
        expect(success_toast).to_be_visible()
    
    def test_edit_prompt_and_verify(self, page: Page, base_url: str):
        """E2E-060: 缂栬緫鎻愮ず璇嶅苟楠岃瘉"""
        # 1. 鎵撳紑缂栬緫
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(2000)
        edit_btn = page.locator('button:has-text("缂栬緫")').first
        edit_btn.click()
        
        # 2. 淇敼鎻忚堪
        page.fill('#prompt-description', '宸蹭慨鏀圭殑鎻忚堪')
        
        # 3. 淇濆瓨
        save_btn = page.locator('button:has-text("淇濆瓨")')
        save_btn.click()
        page.wait_for_timeout(2000)
        
        # 4. 鍐嶆鎵撳紑缂栬緫
        edit_btn.click()
        page.wait_for_timeout(1000)
        
        # 5. 楠岃瘉鎻忚堪宸叉洿鏂?        description = page.input_value('#prompt-description')
        assert '宸蹭慨鏀? in description
    
    def test_prompts_grouped_by_category(self, page: Page, base_url: str):
        """E2E-061: 鎻愮ず璇嶆寜鍒嗙被鍒嗙粍鏄剧ず"""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(2000)
        
        # 楠岃瘉鏈夊垎绫绘爣棰?        excel_category = page.locator('h3:has-text("Excel")')
        expect(excel_category).to_be_visible()
        
        # 楠岃瘉璇ュ垎绫讳笅鏈夋彁绀鸿瘝
        prompts_in_category = page.locator('h3:has-text("Excel") + div table tbody tr')
        expect(prompts_in_category).to_be_visible()
    
    def test_filter_prompts_by_category(self, page: Page, base_url: str):
        """E2E-062: 鎸夊垎绫荤瓫閫夋彁绀鸿瘝"""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(2000)
        
        # 鐐瑰嚮鏌愪釜鍒嗙被
        category_link = page.locator('a:has-text("Excel"), .category:has-text("Excel")').first
        category_link.click()
        page.wait_for_timeout(1000)
        
        # 楠岃瘉鍙樉绀鸿鍒嗙被鐨勬彁绀鸿瘝


class TestPromptLibraryDataValidation:
    """鎻愮ず璇嶅簱鏁版嵁楠岃瘉娴嬭瘯"""
    
    def test_prompt_categories_api(self, page: Page, base_url: str):
        """E2E-063: 鎻愮ず璇嶅垎绫?API"""
        response = page.request.get(f"{base_url}/api/prompt-categories")
        data = response.json()
        
        assert data['code'] == 'OK'
        assert len(data['data']) > 0
        assert 'name' in data['data'][0]
    
    def test_prompts_api_returns_all_fields(self, page: Page, base_url: str):
        """E2E-064: 鎻愮ず璇?API 杩斿洖鎵€鏈夊瓧娈?""
        response = page.request.get(f"{base_url}/api/prompts")
        data = response.json()
        
        assert data['code'] == 'OK'
        assert len(data['data']) > 0
        
        prompt = data['data'][0]
        assert 'id' in prompt
        assert 'code' in prompt
        assert 'name' in prompt
        assert 'category_id' in prompt
        assert 'description' in prompt
        assert 'system_prompt' in prompt
        assert 'user_prompt' in prompt
    
    def test_create_prompt_api(self, page: Page, base_url: str):
        """E2E-065: 鍒涘缓鎻愮ず璇?API"""
        payload = {
            'category_id': 1,
            'code': 'api_test_prompt',
            'name': 'API 娴嬭瘯鎻愮ず璇?,
            'description': '閫氳繃 API 鍒涘缓鐨勬祴璇曟彁绀鸿瘝',
            'system_prompt': '娴嬭瘯绯荤粺鎻愮ず璇?,
            'user_prompt': '娴嬭瘯鐢ㄦ埛鎻愮ず璇嶏細{{input}}',
            'variables': {'input': '娴嬭瘯杈撳叆'}
        }
        
        response = page.request.post(
            f"{base_url}/api/prompts",
            json=payload
        )
        
        data = response.json()
        assert data['code'] == 'OK'
        assert 'id' in data['data']
    
    def test_update_prompt_api(self, page: Page, base_url: str):
        """E2E-066: 鏇存柊鎻愮ず璇?API"""
        # 鍏堣幏鍙栨彁绀鸿瘝鍒楄〃
        list_response = page.request.get(f"{base_url}/api/prompts")
        prompts = list_response.json()['data']
        
        if len(prompts) > 0:
            prompt_code = prompts[0]['code']
            
            # 鏇存柊鎻愮ず璇?            payload = {
                'name': '宸叉洿鏂扮殑鍚嶇О',
                'description': '宸叉洿鏂扮殑鎻忚堪'
            }
            
            response = page.request.put(
                f"{base_url}/api/prompts/code/{prompt_code}",
                json=payload
            )
            
            data = response.json()
            assert data['code'] == 'OK'
            
            # 楠岃瘉鏇存柊鎴愬姛
            detail_response = page.request.get(f"{base_url}/api/prompts/code/{prompt_code}")
            updated_prompt = detail_response.json()['data']
            assert updated_prompt['name'] == '宸叉洿鏂扮殑鍚嶇О'
    
    def test_prompt_category_mapping(self, page: Page, base_url: str):
        """E2E-067: 鎻愮ず璇嶅垎绫绘槧灏勬纭?""
        # 鑾峰彇鍒嗙被鍒楄〃
        cat_response = page.request.get(f"{base_url}/api/prompt-categories")
        categories = {c['id']: c['name'] for c in cat_response.json()['data']}
        
        # 鑾峰彇鎻愮ず璇嶅垪琛?        prompt_response = page.request.get(f"{base_url}/api/prompts")
        prompts = prompt_response.json()['data']
        
        # 楠岃瘉姣忎釜鎻愮ず璇嶇殑 category_id 閮借兘鍦ㄥ垎绫诲垪琛ㄤ腑鎵惧埌
        for prompt in prompts:
            assert prompt['category_id'] in categories
