# -*- coding: utf-8 -*-
"""
E2E 娴嬭瘯 - 浠诲姟绠＄悊鍔熻兘锛堝畬鏁寸増锛?
瑕嗙洊 5 涓祴璇曞眰娆★細
1. 椤甸潰鍔犺浇
2. 鍏冪礌瀛樺湪
3. 鐐瑰嚮浜や簰
4. 娴佺▼楠岃瘉
5. 鏁版嵁楠岃瘉
"""
import pytest
from playwright.sync_api import Page, expect
import time


class TestTaskManagementPageLoad:
    """浠诲姟绠＄悊椤甸潰鍔犺浇娴嬭瘯"""
    
    def test_task_list_page_loads_successfully(self, page: Page, base_url: str):
        """E2E-030: 浠诲姟鍒楄〃椤甸潰鎴愬姛鍔犺浇"""
        page.goto(f"{base_url}/#/tasks")
        
        # 楠岃瘉椤甸潰鍔犺浇
        expect(page).to_have_title("Chujiu TodoList")
        
        # 楠岃瘉浠诲姟鍒楄〃鍖哄煙瀛樺湪
        task_list = page.locator('.task-list, #task-list, table')
        expect(task_list).to_be_visible(timeout=5000)
    
    def test_task_list_page_has_correct_heading(self, page: Page, base_url: str):
        """E2E-030-2: 浠诲姟鍒楄〃椤甸潰鏍囬姝ｇ‘"""
        page.goto(f"{base_url}/#/tasks")
        
        heading = page.locator('h2, .card-title:has-text("浠诲姟")')
        expect(heading).to_be_visible()


class TestTaskManagementElements:
    """浠诲姟绠＄悊鍏冪礌瀛樺湪娴嬭瘯"""
    
    def test_task_table_exists(self, page: Page, base_url: str):
        """E2E-031: 浠诲姟琛ㄦ牸瀛樺湪"""
        page.goto(f"{base_url}/#/tasks")
        
        table = page.locator('table.data-table')
        expect(table).to_be_visible()
    
    def test_task_status_badge_exists(self, page: Page, base_url: str):
        """E2E-032: 浠诲姟鐘舵€佹爣绛惧瓨鍦?""
        page.goto(f"{base_url}/#/tasks")
        
        # 绛夊緟浠诲姟鍔犺浇
        page.wait_for_timeout(2000)
        
        status_badge = page.locator('.status-badge, .task-status')
        expect(status_badge).to_be_visible()
    
    def test_task_action_buttons_exist(self, page: Page, base_url: str):
        """E2E-033: 浠诲姟鎿嶄綔鎸夐挳瀛樺湪"""
        page.goto(f"{base_url}/#/tasks")
        
        # 绛夊緟浠诲姟鍔犺浇
        page.wait_for_timeout(2000)
        
        # 楠岃瘉鍚姩鎸夐挳瀛樺湪
        start_btn = page.locator('button:has-text("鍚姩"), .btn-start')
        expect(start_btn).to_be_visible()
        
        # 楠岃瘉璇︽儏鎸夐挳瀛樺湪
        detail_btn = page.locator('button:has-text("璇︽儏"), .btn-detail')
        expect(detail_btn).to_be_visible()


class TestTaskManagementInteraction:
    """浠诲姟绠＄悊鐐瑰嚮浜や簰娴嬭瘯"""
    
    def test_click_start_task_button(self, page: Page, base_url: str):
        """E2E-034: 鐐瑰嚮鍚姩浠诲姟鎸夐挳"""
        page.goto(f"{base_url}/#/tasks")
        
        # 绛夊緟浠诲姟鍔犺浇
        page.wait_for_timeout(2000)
        
        # 鐐瑰嚮鍚姩鎸夐挳
        start_btn = page.locator('button:has-text("鍚姩")').first
        start_btn.click()
        
        # 楠岃瘉鏈夋彁绀轰俊鎭?        page.wait_for_timeout(1000)
        toast = page.locator('#toast-container .toast')
        expect(toast).to_be_visible()
    
    def test_click_view_task_detail_button(self, page: Page, base_url: str):
        """E2E-035: 鐐瑰嚮鏌ョ湅浠诲姟璇︽儏鎸夐挳"""
        page.goto(f"{base_url}/#/tasks")
        
        # 绛夊緟浠诲姟鍔犺浇
        page.wait_for_timeout(2000)
        
        # 鐐瑰嚮璇︽儏鎸夐挳
        detail_btn = page.locator('button:has-text("璇︽儏")').first
        detail_btn.click()
        
        # 楠岃瘉寮圭獥鏄剧ず
        modal = page.locator('.modal-overlay')
        expect(modal).to_be_visible()
    
    def test_close_task_detail_modal(self, page: Page, base_url: str):
        """E2E-036: 鍏抽棴浠诲姟璇︽儏寮圭獥"""
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(2000)
        
        # 鎵撳紑璇︽儏
        detail_btn = page.locator('button:has-text("璇︽儏")').first
        detail_btn.click()
        
        # 鍏抽棴寮圭獥
        close_btn = page.locator('.modal-overlay button:has-text("鉁?)')
        close_btn.click()
        
        # 楠岃瘉寮圭獥鍏抽棴
        modal = page.locator('.modal-overlay')
        expect(modal).to_be_hidden()
    
    def test_reopen_task_detail_modal(self, page: Page, base_url: str):
        """E2E-037: 閲嶆柊鎵撳紑浠诲姟璇︽儏寮圭獥"""
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(2000)
        
        # 绗竴娆℃墦寮€
        detail_btn = page.locator('button:has-text("璇︽儏")').first
        detail_btn.click()
        
        # 鍏抽棴
        close_btn = page.locator('.modal-overlay button:has-text("鉁?)')
        close_btn.click()
        page.wait_for_timeout(500)
        
        # 绗簩娆℃墦寮€
        detail_btn.click()
        
        # 楠岃瘉鍐嶆鏄剧ず
        modal = page.locator('.modal-overlay')
        expect(modal).to_be_visible()


class TestTaskManagementFlow:
    """浠诲姟绠＄悊娴佺▼楠岃瘉娴嬭瘯"""
    
    def test_create_and_start_task_full_flow(self, page: Page, base_url: str):
        """E2E-038: 鍒涘缓骞跺惎鍔ㄤ换鍔″畬鏁存祦绋?""
        # 1. 涓婁紶鏂囦欢
        page.goto(f"{base_url}/#/upload")
        file_input = page.locator('input[type="file"]')
        file_input.set_input_files(b'PK\x03\x04' + b'\x00' * 100)
        
        # 2. 閫夋嫨鎻掍欢
        plugin_selector = page.locator('select#plugin')
        plugin_selector.select_option('excel_vba_to_wps_js')
        
        # 3. 鍒涘缓浠诲姟
        create_btn = page.locator('button:has-text("鍒涘缓浠诲姟")')
        create_btn.click()
        page.wait_for_timeout(2000)
        
        # 4. 璺宠浆鍒颁换鍔″垪琛?        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(2000)
        
        # 5. 鍚姩浠诲姟
        start_btn = page.locator('button:has-text("鍚姩")').first
        start_btn.click()
        
        # 6. 楠岃瘉鍚姩鎴愬姛
        page.wait_for_timeout(2000)
        success_toast = page.locator('.toast-success, .toast:has-text("鍚姩")')
        expect(success_toast).to_be_visible()
    
    def test_view_task_detail_shows_dag_nodes(self, page: Page, base_url: str):
        """E2E-039: 鏌ョ湅浠诲姟璇︽儏鏄剧ず DAG 鑺傜偣"""
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(2000)
        
        # 鎵撳紑璇︽儏
        detail_btn = page.locator('button:has-text("璇︽儏")').first
        detail_btn.click()
        
        # 楠岃瘉 DAG 鑺傜偣鏄剧ず
        dag_nodes = page.locator('.dag-node, .node')
        expect(dag_nodes).to_be_visible()
    
    def test_task_detail_shows_statistics(self, page: Page, base_url: str):
        """E2E-040: 浠诲姟璇︽儏鏄剧ず缁熻淇℃伅"""
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(2000)
        
        # 鎵撳紑璇︽儏
        detail_btn = page.locator('button:has-text("璇︽儏")').first
        detail_btn.click()
        
        # 楠岃瘉鎬绘楠ゆ樉绀?        total_steps = page.locator('div:has-text("鎬绘楠?)')
        expect(total_steps).to_be_visible()
        
        # 楠岃瘉瀹屾垚鏁版樉绀?        completed = page.locator('div:has-text("瀹屾垚鏁?)')
        expect(completed).to_be_visible()


class TestTaskManagementDataValidation:
    """浠诲姟绠＄悊鏁版嵁楠岃瘉娴嬭瘯"""
    
    def test_task_list_api_returns_tasks(self, page: Page, base_url: str):
        """E2E-041: 浠诲姟鍒楄〃 API 杩斿洖浠诲姟"""
        response = page.request.get(f"{base_url}/api/task-runs")
        data = response.json()
        
        assert data['code'] == 'OK'
        assert isinstance(data['data'], list)
    
    def test_task_detail_api_returns_dag_nodes(self, page: Page, base_url: str):
        """E2E-042: 浠诲姟璇︽儏 API 杩斿洖 DAG 鑺傜偣"""
        # 鍏堣幏鍙栦换鍔″垪琛?        list_response = page.request.get(f"{base_url}/api/task-runs")
        tasks = list_response.json()['data']
        
        if len(tasks) > 0:
            task_id = tasks[0]['id']
            
            # 鑾峰彇浠诲姟璇︽儏
            detail_response = page.request.get(f"{base_url}/api/task-runs/{task_id}")
            data = detail_response.json()
            
            assert data['code'] == 'OK'
            assert 'dagNodes' in data['data'] or 'jobs' in data['data']
    
    def test_start_task_api_changes_status(self, page: Page, base_url: str):
        """E2E-043: 鍚姩浠诲姟 API 鏀瑰彉鐘舵€?""
        # 鑾峰彇浠诲姟鍒楄〃
        list_response = page.request.get(f"{base_url}/api/task-runs")
        tasks = list_response.json()['data']
        
        if len(tasks) > 0:
            task_id = tasks[0]['id']
            
            # 鍚姩浠诲姟
            start_response = page.request.post(f"{base_url}/api/task-runs/{task_id}/start")
            start_data = start_response.json()
            
            assert start_data['code'] == 'OK'
            
            # 楠岃瘉鐘舵€佸彉鍖?            detail_response = page.request.get(f"{base_url}/api/task-runs/{task_id}")
            task_data = detail_response.json()['data']
            assert task_data['status'] in ['READY', 'RUNNING', 'SUCCESS']
    
    def test_task_statistics_calculation(self, page: Page, base_url: str):
        """E2E-044: 浠诲姟缁熻璁＄畻姝ｇ‘"""
        # 鑾峰彇浠诲姟鍒楄〃
        list_response = page.request.get(f"{base_url}/api/task-runs")
        tasks = list_response.json()['data']
        
        if len(tasks) > 0:
            task = tasks[0]
            
            # 楠岃瘉鏈?dagNodes
            if 'dagNodes' in task:
                total = len(task['dagNodes'])
                completed = len([n for n in task['dagNodes'] if n.get('status') == 'SUCCESS'])
                
                # 楠岃瘉缁熻閫昏緫
                assert total >= 0
                assert completed >= 0
                assert completed <= total
