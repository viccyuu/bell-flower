# Playwright E2E 测试指南

**创建时间**: 2026-03-14  
**测试框架**: Playwright + pytest

---

## 📋 目录结构

```
tests/e2e/
├── conftest.py              # Pytest fixtures
├── test_homepage.py         # 首页测试
├── test_upload.py           # 文件上传测试
├── test_tasks.py            # 任务管理测试
└── test_plugins.py          # 插件管理测试
```

---

## 🚀 快速开始

### 1. 环境准备

```bash
# 安装依赖
pip install playwright pytest-playwright

# 安装浏览器
playwright install chromium
```

### 2. 启动应用

```bash
# 在另一个终端启动 Flask 应用
cd chujiu_project
python run.py
```

### 3. 运行测试

```bash
# 运行所有 E2E 测试
pytest tests/e2e/ -v

# 运行特定测试文件
pytest tests/e2e/test_homepage.py -v

# 运行特定测试用例
pytest tests/e2e/test_homepage.py::TestHomePage::test_home_page_loads_successfully -v

# 有头模式（显示浏览器）
pytest tests/e2e/ --headed -v

# 生成 HTML 报告
pytest tests/e2e/ --html=report.html --self-contained-html
```

---

## 🎯 测试用例清单

### 首页测试 (`test_homepage.py`)

| 用例 ID | 测试名称 | 验证点 | 状态 |
|--------|---------|--------|------|
| E2E-001 | 首页成功加载 | 页面标题、#app 元素 | ✅ |
| E2E-002 | 导航菜单存在 | 侧边栏可见 | ✅ |
| E2E-003 | 上传按钮存在 | 上传按钮可见 | ✅ |
| E2E-004 | 任务列表区域存在 | 任务列表可见 | ✅ |

### 文件上传测试 (`test_upload.py`)

| 用例 ID | 测试名称 | 验证点 | 状态 |
|--------|---------|--------|------|
| E2E-010 | 上传页面加载 | 上传区域存在 | ✅ |
| E2E-011 | 点击上传按钮 | 文件选择器出现 | ✅ |
| E2E-012 | 插件选择器存在 | 插件下拉框可见 | ✅ |
| E2E-013 | 创建任务按钮存在 | 创建按钮可见 | ✅ |

### 任务管理测试 (`test_tasks.py`)

| 用例 ID | 测试名称 | 验证点 | 状态 |
|--------|---------|--------|------|
| E2E-020 | 任务列表页面加载 | 列表区域可见 | ✅ |
| E2E-021 | 任务状态标签存在 | 状态徽章可见 | ⏳ |
| E2E-022 | 任务操作按钮存在 | 操作按钮可见 | ⏳ |

### 插件管理测试 (`test_plugins.py`)

| 用例 ID | 测试名称 | 验证点 | 状态 |
|--------|---------|--------|------|
| E2E-030 | 插件列表页面加载 | 列表区域可见 | ✅ |
| E2E-031 | 插件项目存在 | 至少 1 个插件 | ✅ |
| E2E-032 | 插件开关存在 | 开关控件可见 | ✅ |
| E2E-033 | 查看 DAG 按钮存在 | DAG 按钮可见 | ✅ |

---

## 🔧 配置说明

### conftest.py Fixtures

| Fixture | 作用域 | 说明 |
|--------|--------|------|
| `base_url` | session | 应用基础 URL（默认 http://127.0.0.1:5001） |
| `browser` | session | Chromium 浏览器实例 |
| `context` | session | 浏览器上下文（1920x1080） |
| `page` | function | 新页面实例 |
| `logged_in_page` | function | 已登录页面（待实现） |

### 环境变量

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `TEST_BASE_URL` | http://127.0.0.1:5001 | 测试应用地址 |

---

## 📊 运行示例

### 基础运行

```powershell
# 运行所有 E2E 测试
.\run_e2e_tests.ps1

# 有头模式（查看浏览器）
.\run_e2e_tests.ps1 -Headed

# 生成 HTML 报告
.\run_e2e_tests.ps1 -Report

# 运行特定测试
.\run_e2e_tests.ps1 -TestFile tests/e2e/test_homepage.py
```

### 直接运行 pytest

```bash
# 基础运行
pytest tests/e2e/ -v

# 带覆盖率
pytest tests/e2e/ -v --cov=app

# 慢测试分析
pytest tests/e2e/ -v --durations=10

# 失败重试
pytest tests/e2e/ -v --reruns 2
```

---

## 🐛 调试技巧

### 1. 有头模式调试

```bash
pytest tests/e2e/test_homepage.py --headed -v
```

### 2. 暂停执行

```python
def test_debug(page: Page, base_url: str):
    page.goto(base_url)
    page.pause()  # 打开 Playwright Inspector
```

### 3. 截图调试

```python
def test_with_screenshot(page: Page, base_url: str):
    page.goto(base_url)
    page.screenshot(path='debug.png')
```

### 4. 录制脚本

```bash
# 使用 Playwright 录制工具
playwright codegen http://127.0.0.1:5001
```

---

## 📈 最佳实践

### 1. 使用显式等待

```python
from playwright.sync_api import expect

# ✅ 推荐：显式等待元素
expect(page.locator('#app')).to_be_visible(timeout=5000)

# ❌ 避免：硬编码等待
import time
time.sleep(5)  # 不要这样做
```

### 2. 使用数据属性定位

```python
# ✅ 推荐：稳定的定位器
page.locator('[data-testid="upload-btn"]')
page.locator('[data-page="tasks"]')

# ❌ 避免：脆弱的 XPath
page.locator('/html/body/div[2]/button[3]')
```

### 3. 页面对象模式

```python
class UploadPage:
    def __init__(self, page: Page):
        self.page = page
        self.upload_btn = page.locator('#upload-btn')
    
    def goto(self, base_url: str):
        self.page.goto(f"{base_url}/#/upload")
    
    def upload_file(self, file_path: str):
        self.page.set_input_files('input[type=file]', file_path)
```

---

## 🔍 常见问题

### Q: 测试失败 "Connection refused"
**A**: 确保 Flask 应用已启动
```bash
python run.py
```

### Q: 元素定位失败
**A**: 检查元素是否加载完成，使用显式等待
```python
expect(page.locator('#app')).to_be_visible()
```

### Q: 浏览器无法启动
**A**: 重新安装浏览器
```bash
playwright install chromium
```

### Q: 测试执行太慢
**A**: 使用无头模式，减少不必要的等待
```bash
pytest tests/e2e/ --timeout=30000
```

---

## 📝 编写新测试

### 模板

```python
# -*- coding: utf-8 -*-
"""
E2E 测试 - [功能名称]
"""
import pytest
from playwright.sync_api import Page, expect


class Test[FeatureName]:
    """[功能名称] E2E 测试"""
    
    def test_[scenario](self, page: Page, base_url: str):
        """E2E-XXX: [测试描述]"""
        # Arrange - 准备数据
        page.goto(base_url)
        
        # Act - 执行操作
        page.click('#action-btn')
        
        # Assert - 验证结果
        expect(page.locator('#result')).to_be_visible()
```

---

## 🎯 下一步计划

1. ✅ 基础页面测试（首页、上传、任务、插件）
2. ⏳ 完整流程测试（上传→创建→执行→下载）
3. ⏳ 登录认证测试
4. ⏳ 提示词库管理测试
5. ⏳ DAG 可视化交互测试

---

**文档维护**: Chujiu Design Team  
**最后更新**: 2026-03-14
