# -*- coding: utf-8 -*-
"""
E2E Test - Dashboard Page
"""
import pytest
from playwright.sync_api import Page, expect


class TestDashboardPage:
    """Dashboard Page E2E Tests"""
    
    def test_l1_dashboard_page_loads(self, page: Page, base_url: str):
        """E2E-L1-001: Dashboard page loads"""
        page.goto(f"{base_url}/#/dashboard")
        page.wait_for_load_state('load')
        expect(page).to_have_title("Chujiu Design TodoList")
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
    
    def test_l1_dashboard_has_card(self, page: Page, base_url: str):
        """E2E-L1-002: Dashboard has card"""
        page.goto(f"{base_url}/#/dashboard")
        page.wait_for_load_state('load')
        card = page.locator('.card')
        expect(card).to_be_visible()
    
    def test_l2_dashboard_elements_exist(self, page: Page, base_url: str):
        """E2E-L2-001: Dashboard elements exist"""
        page.goto(f"{base_url}/#/dashboard")
        page.wait_for_timeout(3000)
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
    
    def test_l2_dashboard_has_title(self, page: Page, base_url: str):
        """E2E-L2-002: Dashboard has title"""
        page.goto(f"{base_url}/#/dashboard")
        page.wait_for_timeout(3000)
        card_title = page.locator('.card-title')
        expect(card_title).to_be_visible()
    
    def test_l3_dashboard_click_interaction(self, page: Page, base_url: str):
        """E2E-L3-001: Dashboard click interaction"""
        page.goto(f"{base_url}/#/dashboard")
        page.wait_for_timeout(3000)
        task_items = page.locator('.task-item, tbody tr')
        if task_items.count() > 0:
            task_items.first.click()
            page.wait_for_timeout(1000)
    
    def test_l3_dashboard_navigation(self, page: Page, base_url: str):
        """E2E-L3-002: Dashboard navigation"""
        page.goto(f"{base_url}/#/dashboard")
        page.wait_for_timeout(3000)
        nav_items = page.locator('.nav-item')
        if nav_items.count() > 0:
            nav_items.first.click()
            page.wait_for_timeout(2000)
    
    def test_l4_dashboard_load_stats_flow(self, page: Page, base_url: str):
        """E2E-L4-001: Dashboard load stats flow"""
        page.goto(f"{base_url}/#/dashboard")
        page.wait_for_timeout(3000)
        stats_cards = page.locator('.stats-card, .stat-card')
        count = stats_cards.count()
        if count > 0:
            for i in range(count):
                stat_card = stats_cards.nth(i)
                expect(stat_card).to_be_visible()
    
    def test_l4_dashboard_refresh_flow(self, page: Page, base_url: str):
        """E2E-L4-002: Dashboard refresh flow"""
        page.goto(f"{base_url}/#/dashboard")
        page.wait_for_timeout(3000)
        page.reload()
        page.wait_for_timeout(3000)
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
    
    def test_l5_dashboard_api_data_validation(self, page: Page, base_url: str):
        """E2E-L5-001: Dashboard API data validation"""
        import requests
        api_response = requests.get(f'{base_url}/api/task-runs?limit=10')
        assert api_response.status_code == 200
        api_data = api_response.json()
        assert api_data['code'] == 'OK'
        page.goto(f"{base_url}/#/dashboard")
        page.wait_for_timeout(3000)
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
    
    def test_l5_dashboard_data_consistency(self, page: Page, base_url: str):
        """E2E-L5-002: Dashboard data consistency"""
        import requests
        api_response = requests.get(f'{base_url}/api/task-runs?limit=10')
        api_tasks = api_response.json()['data']
        page.goto(f"{base_url}/#/dashboard")
        page.wait_for_timeout(3000)
        task_items = page.locator('.task-item, tbody tr')
        if len(api_tasks) > 0:
            count = task_items.count()
            assert count >= 0
