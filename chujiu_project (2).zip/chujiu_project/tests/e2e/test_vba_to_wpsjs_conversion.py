# -*- coding: utf-8 -*-
"""
E2E 测试 - VBA 到 WPS JS 转换完整流程

测试从文件上传到转换完成的完整流程
"""
import pytest
from playwright.sync_api import Page, expect
import os
import time


class TestVbaToWpsJsConversion:
    """VBA 到 WPS JS 转换 E2E 测试"""
    
    def test_upload_file_and_create_task(self, page: Page, base_url: str):
        """E2E-CONV-001: 上传文件并创建任务
        
        【测试步骤】
        1. 访问上传页面
        2. 上传 Excel 文件
        3. 选择插件
        4. 创建任务
        
        【预期结果】
        - 文件上传成功
        - 任务创建成功
        """
        # Arrange
        page.goto(f"{base_url}/#/upload")
        page.wait_for_timeout(3000)
        
        # Act - 上传文件
        file_input = page.locator('input[type="file"]')
        test_file = os.path.join(
            os.path.dirname(__file__),
            '..', '..', '..', '..',
            'chujiu_design',
            'vba2js3-chujiu.xlsm'
        )
        
        if os.path.exists(test_file):
            file_input.set_input_files(test_file)
            page.wait_for_timeout(2000)
            
            # 选择插件
            plugin_select = page.locator('select#plugin')
            plugin_select.select_option('excel_vba_to_wps_js')
            page.wait_for_timeout(1000)
            
            # 创建任务
            create_btn = page.locator('button:has-text("创建任务")')
            create_btn.click()
            page.wait_for_timeout(2000)
            
            # Assert - 验证创建成功
            success_toast = page.locator('.toast-success, .toast:has-text("成功")')
            expect(success_toast).to_be_visible(timeout=5000)
        else:
            # 使用模拟文件
            pytest.skip(f"Test file not found: {test_file}")
    
    def test_view_task_list(self, page: Page, base_url: str):
        """E2E-CONV-002: 查看任务列表
        
        【测试步骤】
        1. 访问任务列表页面
        2. 验证任务显示
        
        【预期结果】
        - 任务列表显示
        - 任务状态正确
        """
        # Arrange
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        
        # Assert - 验证任务列表显示
        task_list = page.locator('.task-list, table')
        expect(task_list).to_be_visible()
    
    def test_view_task_detail_with_dag(self, page: Page, base_url: str):
        """E2E-CONV-003: 查看任务详情和 DAG
        
        【测试步骤】
        1. 访问任务列表
        2. 点击详情按钮
        3. 验证 DAG 显示
        
        【预期结果】
        - 任务详情显示
        - DAG 节点显示
        - 节点状态正确
        """
        # Arrange
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        
        # Act - 点击详情按钮
        detail_btn = page.locator('button:has-text("详情")').first
        detail_btn.click()
        page.wait_for_timeout(2000)
        
        # Assert - 验证详情弹窗显示
        modal = page.locator('.modal-overlay')
        expect(modal).to_be_visible()
        
        # 验证 DAG 节点显示
        dag_nodes = page.locator('.dag-node, .node')
        expect(dag_nodes).to_be_visible()
    
    def test_start_task_execution(self, page: Page, base_url: str):
        """E2E-CONV-004: 启动任务执行
        
        【测试步骤】
        1. 访问任务列表
        2. 点击启动按钮
        3. 验证状态变化
        
        【预期结果】
        - 任务启动成功
        - 状态变为 RUNNING
        """
        # Arrange
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        
        # Act - 点击启动按钮
        start_btn = page.locator('button:has-text("启动")').first
        start_btn.click()
        page.wait_for_timeout(2000)
        
        # Assert - 验证启动成功
        success_toast = page.locator('.toast-success, .toast:has-text("启动")')
        expect(success_toast).to_be_visible(timeout=5000)
    
    def test_monitor_task_progress(self, page: Page, base_url: str):
        """E2E-CONV-005: 监控任务进度
        
        【测试步骤】
        1. 访问任务列表
        2. 刷新页面
        3. 验证状态更新
        
        【预期结果】
        - 状态实时更新
        - 进度显示正确
        """
        # Arrange
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        
        # Act - 刷新页面
        page.reload()
        page.wait_for_timeout(3000)
        
        # Assert - 验证状态显示
        status_badge = page.locator('.status-badge, .task-status')
        expect(status_badge).to_be_visible()
    
    def test_download_conversion_result(self, page: Page, base_url: str):
        """E2E-CONV-006: 下载转换结果
        
        【测试步骤】
        1. 访问任务列表
        2. 等待任务完成
        3. 下载产物
        
        【预期结果】
        - 任务完成
        - 产物可下载
        """
        # Arrange
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        
        # Act - 等待任务完成（简化测试）
        # 实际应该轮询任务状态
        
        # Assert - 验证产物下载按钮存在
        download_btn = page.locator('button:has-text("下载"), .download-btn')
        expect(download_btn).to_be_visible()
    
    def test_view_plugin_dag(self, page: Page, base_url: str):
        """E2E-CONV-007: 查看插件 DAG
        
        【测试步骤】
        1. 访问插件管理页面
        2. 点击 DAG 按钮
        3. 验证 DAG 显示
        
        【预期结果】
        - DAG 弹窗显示
        - 节点和边显示正确
        """
        # Arrange
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(3000)
        
        # Act - 点击 DAG 按钮
        dag_btn = page.locator('button:has-text("DAG")').first
        dag_btn.click()
        page.wait_for_timeout(2000)
        
        # Assert - 验证 DAG 弹窗显示
        modal = page.locator('.modal-overlay')
        expect(modal).to_be_visible()
        
        # 验证节点显示
        nodes = page.locator('.dag-node, .node')
        expect(nodes).to_be_visible()
    
    def test_view_plugin_learning_rules(self, page: Page, base_url: str):
        """E2E-CONV-008: 查看插件 Learning 规则
        
        【测试步骤】
        1. 访问插件管理页面
        2. 点击 Learning 按钮
        3. 验证规则显示
        
        【预期结果】
        - Learning 弹窗显示
        - 规则内容显示
        """
        # Arrange
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(3000)
        
        # Act - 点击 Learning 按钮
        learning_btn = page.locator('button:has-text("Learning")').first
        learning_btn.click()
        page.wait_for_timeout(2000)
        
        # Assert - 验证 Learning 弹窗显示
        modal = page.locator('.modal-overlay')
        expect(modal).to_be_visible()
    
    def test_full_conversion_workflow(self, page: Page, base_url: str):
        """E2E-CONV-009: 完整转换工作流
        
        【测试步骤】
        1. 上传文件
        2. 创建任务
        3. 启动任务
        4. 监控进度
        5. 下载结果
        
        【预期结果】
        - 完整流程成功
        - 转换结果正确
        """
        # Step 1: 上传文件
        page.goto(f"{base_url}/#/upload")
        page.wait_for_timeout(3000)
        
        file_input = page.locator('input[type="file"]')
        expect(file_input).to_be_visible()
        
        # Step 2: 创建任务（简化）
        # Step 3: 访问任务列表
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        
        # Step 4: 验证任务显示
        task_list = page.locator('.task-list, table')
        expect(task_list).to_be_visible()
        
        # Step 5: 查看任务详情
        detail_btn = page.locator('button:has-text("详情")').first
        detail_btn.click()
        page.wait_for_timeout(2000)
        
        modal = page.locator('.modal-overlay')
        expect(modal).to_be_visible()
        
        # Step 6: 关闭弹窗
        close_btn = page.locator('.modal-overlay button:has-text("✕")')
        close_btn.click()
        page.wait_for_timeout(1000)
        
        # Assert - 验证流程完成
        expect(page).to_have_url(f"{base_url}/#/tasks")
