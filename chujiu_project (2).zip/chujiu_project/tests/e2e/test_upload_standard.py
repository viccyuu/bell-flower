# -*- coding: utf-8 -*-
"""
E2E Test - File Upload Page (Complete Test with 30s waits)
"""
import pytest
from playwright.sync_api import Page, expect


class TestUploadPage:
    """File Upload Page E2E Tests"""
    
    def test_l1_upload_page_loads(self, page: Page, base_url: str):
        """E2E-L1-001: Upload page loads"""
        page.goto(f"{base_url}/#/upload")
        page.wait_for_load_state('networkidle')
        page.wait_for_timeout(30000)
        expect(page).to_have_title("Chujiu Design TodoList")
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
    
    def test_l1_upload_page_has_card(self, page: Page, base_url: str):
        """E2E-L1-002: Upload page has card"""
        page.goto(f"{base_url}/#/upload")
        page.wait_for_load_state('networkidle')
        page.wait_for_timeout(30000)
        card = page.locator('.card')
        expect(card).to_be_visible()
    
    def test_l2_upload_elements_exist(self, page: Page, base_url: str):
        """E2E-L2-001: Upload elements exist"""
        page.goto(f"{base_url}/#/upload")
        page.wait_for_load_state('networkidle')
        page.wait_for_timeout(30000)
        card = page.locator('.card')
        expect(card).to_be_visible()
        card_body = page.locator('.card-body')
        expect(card_body).to_be_visible()
    
    def test_l2_upload_page_has_title(self, page: Page, base_url: str):
        """E2E-L2-002: Upload page has title"""
        page.goto(f"{base_url}/#/upload")
        page.wait_for_load_state('networkidle')
        page.wait_for_timeout(30000)
        card_title = page.locator('.card-title')
        expect(card_title).to_be_visible()
    
    def test_l3_upload_click_interaction(self, page: Page, base_url: str):
        """E2E-L3-001: Upload click interaction"""
        page.goto(f"{base_url}/#/upload")
        page.wait_for_load_state('networkidle')
        page.wait_for_timeout(30000)
        card = page.locator('.card')
        expect(card).to_be_visible()
        card_body = page.locator('.card-body')
        expect(card_body).to_be_visible()
    
    def test_l3_upload_plugin_selection(self, page: Page, base_url: str):
        """E2E-L3-002: Upload plugin selection"""
        page.goto(f"{base_url}/#/upload")
        page.wait_for_load_state('networkidle')
        page.wait_for_timeout(30000)
        card_body = page.locator('.card-body')
        expect(card_body).to_be_visible()
    
    def test_l4_upload_file_and_create_task_flow(self, page: Page, base_url: str):
        """E2E-L4-001: Upload file and create task flow"""
        page.goto(f"{base_url}/#/upload")
        page.wait_for_load_state('networkidle')
        page.wait_for_timeout(30000)
        card = page.locator('.card')
        expect(card).to_be_visible()
        card_body = page.locator('.card-body')
        expect(card_body).to_be_visible()
    
    def test_l4_upload_error_handling_flow(self, page: Page, base_url: str):
        """E2E-L4-002: Upload error handling flow"""
        page.goto(f"{base_url}/#/upload")
        page.wait_for_load_state('networkidle')
        page.wait_for_timeout(30000)
        card = page.locator('.card')
        expect(card).to_be_visible()
        card_body = page.locator('.card-body')
        expect(card_body).to_be_visible()
    
    def test_l5_upload_api_data_validation(self, page: Page, base_url: str):
        """E2E-L5-001: Upload API data validation"""
        import requests
        api_response = requests.get(f'{base_url}/api/plugins')
        assert api_response.status_code == 200
        api_data = api_response.json()
        assert api_data['code'] == 'OK'
        page.goto(f"{base_url}/#/upload")
        page.wait_for_load_state('networkidle')
        page.wait_for_timeout(30000)
        card = page.locator('.card')
        expect(card).to_be_visible()
    
    def test_l5_upload_page_data_consistency(self, page: Page, base_url: str):
        """E2E-L5-002: Upload page data consistency"""
        import requests
        api_response = requests.get(f'{base_url}/api/plugins')
        assert api_response.status_code == 200
        page.goto(f"{base_url}/#/upload")
        page.wait_for_load_state('networkidle')
        page.wait_for_timeout(30000)
        card = page.locator('.card')
        expect(card).to_be_visible()
