# -*- coding: utf-8 -*-
"""
Playwright E2E Test Fixtures

提供：
1. 浏览器配置
2. 页面上下文
3. 测试数据清理
4. 智能等待机制
"""
import pytest
from playwright.sync_api import sync_playwright, Page, Browser, BrowserContext
import os


@pytest.fixture(scope="session")
def base_url():
    """获取应用基础 URL"""
    return os.getenv('TEST_BASE_URL', 'http://127.0.0.1:5001')


@pytest.fixture(scope="session")
def browser():
    """启动浏览器"""
    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=True,  # 无头模式
            args=[
                '--no-sandbox',
                '--disable-dev-shm-usage',
                '--disable-gpu'
            ]
        )
        yield browser
        browser.close()


@pytest.fixture
def context(browser: Browser):
    """创建浏览器上下文"""
    context = browser.new_context(
        viewport={'width': 1920, 'height': 1080},
        ignore_https_errors=True
    )
    yield context
    context.close()


@pytest.fixture
def page(context: BrowserContext) -> Page:
    """创建页面（带智能等待）"""
    page = context.new_page()
    
    # 设置默认超时
    page.set_default_timeout(10000)
    page.set_default_navigation_timeout(10000)
    
    yield page
    page.close()


@pytest.fixture
def logged_in_page(page: Page, base_url: str):
    """已登录的页面（模拟登录）"""
    # TODO: 实现登录逻辑
    # 目前直接访问首页
    page.goto(base_url)
    return page


# 智能等待辅助函数
def wait_for_page_ready(page: Page, timeout: int = 5000):
    """等待页面就绪"""
    page.wait_for_load_state('load', timeout=timeout)
    page.wait_for_load_state('networkidle', timeout=timeout)


def wait_for_element(page: Page, selector: str, timeout: int = 5000):
    """等待元素可见"""
    page.wait_for_selector(selector, state='visible', timeout=timeout)
