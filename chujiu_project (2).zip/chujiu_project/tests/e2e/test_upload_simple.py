# -*- coding: utf-8 -*-
"""
E2E 娴嬭瘯 - 鏂囦欢涓婁紶锛堝疄鐢ㄧ増锛?
绠€鍖栭€夋嫨鍣紝鎻愰珮绋冲畾鎬?"""
import pytest
from playwright.sync_api import Page, expect


class TestFileUploadSimple:
    """鏂囦欢涓婁紶绠€鍖栨祴璇?""
    
    def test_upload_page_loads(self, page: Page, base_url: str):
        """E2E-U01: 涓婁紶椤甸潰鍔犺浇"""
        page.goto(f"{base_url}/#/upload")
        page.wait_for_timeout(3000)
        
        # 楠岃瘉鏈夊崱鐗?        card = page.locator('.card')
        expect(card).to_be_visible()
    
    def test_upload_has_title(self, page: Page, base_url: str):
        """E2E-U02: 涓婁紶椤甸潰鏈夋爣棰?""
        page.goto(f"{base_url}/#/upload")
        page.wait_for_timeout(3000)
        
        # 楠岃瘉鏈夋爣棰樻枃瀛?        title = page.locator('.card-title, h3, div:has-text("涓婁紶")')
        expect(title).to_be_visible()
    
    def test_upload_has_button(self, page: Page, base_url: str):
        """E2E-U03: 涓婁紶椤甸潰鏈夋寜閽?""
        page.goto(f"{base_url}/#/upload")
        page.wait_for_timeout(3000)
        
        # 楠岃瘉鏈夋寜閽?        button = page.locator('button')
        expect(button).to_be_visible()
