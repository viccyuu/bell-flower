# -*- coding: utf-8 -*-
"""
E2E Test - Plugin Management Page
"""
import pytest
from playwright.sync_api import Page, expect


class TestPluginManagementPage:
    """Plugin Management Page E2E Tests"""
    
    def test_l1_plugin_page_loads(self, page: Page, base_url: str):
        """E2E-L1-001: Plugin page loads"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_load_state('load')
        expect(page).to_have_title("Chujiu Design TodoList")
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
    
    def test_l1_plugin_page_has_card(self, page: Page, base_url: str):
        """E2E-L1-002: Plugin page has card"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_load_state('load')
        card = page.locator('.card')
        expect(card).to_be_visible()
    
    def test_l2_plugin_elements_exist(self, page: Page, base_url: str):
        """E2E-L2-001: Plugin elements exist"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(3000)
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
        card_body = page.locator('.card-body')
        expect(card_body).to_be_visible()
    
    def test_l2_plugin_page_has_title(self, page: Page, base_url: str):
        """E2E-L2-002: Plugin page has title"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(3000)
        card_title = page.locator('.card-title')
        expect(card_title).to_be_visible()
    
    def test_l3_plugin_click_interaction(self, page: Page, base_url: str):
        """E2E-L3-001: Plugin click interaction"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(3000)
        dag_buttons = page.locator('button:has-text("DAG")')
        if dag_buttons.count() > 0:
            dag_buttons.first.click()
            page.wait_for_timeout(2000)
            modal = page.locator('.modal-overlay')
            expect(modal).to_be_visible()
            close_btn = modal.locator('button:has-text("✕")')
            close_btn.click()
            page.wait_for_timeout(1000)
            expect(modal).not_to_be_visible()
    
    def test_l3_plugin_dag_view(self, page: Page, base_url: str):
        """E2E-L3-002: Plugin DAG view"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(3000)
        dag_buttons = page.locator('button:has-text("DAG")')
        if dag_buttons.count() > 0:
            dag_buttons.first.click()
            page.wait_for_timeout(2000)
            modal = page.locator('.modal-overlay')
            expect(modal).to_be_visible()
    
    def test_l4_plugin_view_dag_flow(self, page: Page, base_url: str):
        """E2E-L4-001: Plugin view DAG flow"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(3000)
        dag_buttons = page.locator('button:has-text("DAG")')
        if dag_buttons.count() > 0:
            dag_buttons.first.click()
            page.wait_for_timeout(2000)
            modal = page.locator('.modal-overlay')
            expect(modal).to_be_visible()
            close_btn = modal.locator('button:has-text("✕")')
            close_btn.click()
            page.wait_for_timeout(1000)
            expect(modal).not_to_be_visible()
    
    def test_l4_plugin_view_learning_flow(self, page: Page, base_url: str):
        """E2E-L4-002: Plugin view Learning flow"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(3000)
        learning_buttons = page.locator('button:has-text("Learning")')
        if learning_buttons.count() > 0:
            learning_buttons.first.click()
            page.wait_for_timeout(2000)
            modal = page.locator('.modal-overlay')
            expect(modal).to_be_visible()
            close_btn = modal.locator('button:has-text("✕")')
            close_btn.click()
            page.wait_for_timeout(1000)
            expect(modal).not_to_be_visible()
    
    def test_l5_plugin_api_data_validation(self, page: Page, base_url: str):
        """E2E-L5-001: Plugin API data validation"""
        import requests
        api_response = requests.get(f'{base_url}/api/plugins')
        assert api_response.status_code == 200
        api_data = api_response.json()
        assert api_data['code'] == 'OK'
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(3000)
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
    
    def test_l5_plugin_data_consistency(self, page: Page, base_url: str):
        """E2E-L5-002: Plugin data consistency"""
        import requests
        api_response = requests.get(f'{base_url}/api/plugins')
        api_plugins = api_response.json()['data']
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(3000)
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
        if len(api_plugins) > 0:
            card_body = page.locator('.card-body')
            expect(card_body).to_be_visible()
