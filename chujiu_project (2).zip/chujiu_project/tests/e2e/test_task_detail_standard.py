# -*- coding: utf-8 -*-
"""
E2E 测试 - 任务详情模块

严格按照 5 个层次执行：
L1: 页面加载
L2: 元素存在
L3: 点击交互
L4: 流程验证
L5: 数据验证
"""
import pytest
from playwright.sync_api import Page, expect


class TestTaskDetailPage:
    """任务详情页面 E2E 测试"""
    
    # =========================================================================
    # L1: 页面加载测试
    # =========================================================================
    
    def test_l1_task_detail_page_loads(self, page: Page, base_url: str):
        """E2E-L1-001: 任务详情页面加载测试"""
        # Arrange: 先访问任务列表
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        
        # Act: 点击详情按钮
        detail_buttons = page.locator('button:has-text("详情")')
        if detail_buttons.count() > 0:
            detail_buttons.first.click()
            page.wait_for_timeout(2000)
            
            # Assert
            modal = page.locator('.modal-overlay')
            expect(modal).to_be_visible()
    
    def test_l1_task_detail_modal_loads(self, page: Page, base_url: str):
        """E2E-L1-002: 任务详情弹窗加载测试"""
        # Arrange
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        
        # Act
        detail_buttons = page.locator('button:has-text("详情")')
        if detail_buttons.count() > 0:
            detail_buttons.first.click()
            page.wait_for_timeout(2000)
            
            # Assert
            modal = page.locator('.modal-overlay')
            expect(modal).to_be_visible()
            
            modal_content = modal.locator('.modal-content')
            expect(modal_content).to_be_visible()
    
    # =========================================================================
    # L2: 元素存在测试
    # =========================================================================
    
    def test_l2_task_detail_elements_exist(self, page: Page, base_url: str):
        """E2E-L2-001: 任务详情元素存在测试"""
        # Arrange
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        
        # Act
        detail_buttons = page.locator('button:has-text("详情")')
        if detail_buttons.count() > 0:
            detail_buttons.first.click()
            page.wait_for_timeout(2000)
            
            # Assert
            modal = page.locator('.modal-overlay')
            
            # 1. 弹窗标题
            modal_title = modal.locator('h3, .modal-title')
            expect(modal_title).to_be_visible()
            
            # 2. 任务信息区域
            task_info = modal.locator('.task-info, .task-detail')
            expect(task_info).to_be_visible()
            
            # 3. 关闭按钮
            close_btn = modal.locator('button:has-text("✕")')
            expect(close_btn).to_be_visible()
    
    def test_l2_task_detail_dag_exists(self, page: Page, base_url: str):
        """E2E-L2-002: 任务详情 DAG 区域存在测试"""
        # Arrange
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        
        # Act
        detail_buttons = page.locator('button:has-text("详情")')
        if detail_buttons.count() > 0:
            detail_buttons.first.click()
            page.wait_for_timeout(2000)
            
            # Assert
            modal = page.locator('.modal-overlay')
            
            # DAG 区域
            dag_area = modal.locator('#dag-visualization, .dag-container')
            expect(dag_area).to_be_attached()
    
    # =========================================================================
    # L3: 点击交互测试
    # =========================================================================
    
    def test_l3_task_detail_close_modal(self, page: Page, base_url: str):
        """E2E-L3-001: 任务详情关闭弹窗测试"""
        # Arrange
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        
        # Act
        detail_buttons = page.locator('button:has-text("详情")')
        if detail_buttons.count() > 0:
            detail_buttons.first.click()
            page.wait_for_timeout(2000)
            
            # 验证弹窗显示
            modal = page.locator('.modal-overlay')
            expect(modal).to_be_visible()
            
            # 关闭弹窗
            close_btn = modal.locator('button:has-text("✕")')
            close_btn.click()
            page.wait_for_timeout(1000)
            
            # Assert: 验证弹窗关闭
            expect(modal).not_to_be_visible()
    
    def test_l3_task_detail_dag_interaction(self, page: Page, base_url: str):
        """E2E-L3-002: 任务详情 DAG 交互测试"""
        # Arrange
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        
        # Act
        detail_buttons = page.locator('button:has-text("详情")')
        if detail_buttons.count() > 0:
            detail_buttons.first.click()
            page.wait_for_timeout(2000)
            
            # Assert: 验证 DAG 节点存在
            modal = page.locator('.modal-overlay')
            dag_nodes = modal.locator('.dag-node, .node')
            expect(dag_nodes).to_have_count(greater_than_or_equal(1))
    
    # =========================================================================
    # L4: 流程验证测试
    # =========================================================================
    
    def test_l4_task_detail_view_flow(self, page: Page, base_url: str):
        """E2E-L4-001: 任务详情查看流程测试"""
        # Step 1: 访问任务列表
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        
        # Step 2: 点击详情按钮
        detail_buttons = page.locator('button:has-text("详情")')
        if detail_buttons.count() > 0:
            detail_buttons.first.click()
            page.wait_for_timeout(2000)
            
            # Step 3: 验证详情弹窗显示
            modal = page.locator('.modal-overlay')
            expect(modal).to_be_visible()
            
            # Step 4: 验证任务信息显示
            task_info = modal.locator('.task-info')
            expect(task_info).to_be_visible()
            
            # Step 5: 关闭弹窗
            close_btn = modal.locator('button:has-text("✕")')
            close_btn.click()
            page.wait_for_timeout(1000)
            
            # Step 6: 验证弹窗关闭
            expect(modal).not_to_be_visible()
    
    def test_l4_task_detail_multiple_open_close_flow(self, page: Page, base_url: str):
        """E2E-L4-002: 任务详情多次打开关闭流程测试"""
        # Arrange
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        
        detail_buttons = page.locator('button:has-text("详情")')
        if detail_buttons.count() > 0:
            # 第一次打开关闭
            detail_buttons.first.click()
            page.wait_for_timeout(2000)
            modal = page.locator('.modal-overlay')
            expect(modal).to_be_visible()
            
            close_btn = modal.locator('button:has-text("✕")')
            close_btn.click()
            page.wait_for_timeout(1000)
            expect(modal).not_to_be_visible()
            
            # 第二次打开关闭
            detail_buttons.first.click()
            page.wait_for_timeout(2000)
            expect(modal).to_be_visible()
            
            close_btn.click()
            page.wait_for_timeout(1000)
            expect(modal).not_to_be_visible()
    
    # =========================================================================
    # L5: 数据验证测试
    # =========================================================================
    
    def test_l5_task_detail_api_data_validation(self, page: Page, base_url: str):
        """E2E-L5-001: 任务详情 API 数据验证测试"""
        import requests
        
        # Step 1: 获取任务列表
        api_response = requests.get(f'{base_url}/api/task-runs?limit=10')
        assert api_response.status_code == 200
        
        api_tasks = api_response.json()['data']
        
        if len(api_tasks) > 0:
            task_id = api_tasks[0]['id']
            
            # Step 2: 获取任务详情 API
            detail_response = requests.get(f'{base_url}/api/task-runs/{task_id}')
            assert detail_response.status_code == 200
            
            detail_data = detail_response.json()
            assert detail_data['code'] == 'OK'
            assert 'dagNodes' in detail_data['data']
            assert 'dagEdges' in detail_data['data']
    
    def test_l5_task_detail_data_consistency(self, page: Page, base_url: str):
        """E2E-L5-002: 任务详情数据一致性测试"""
        import requests
        
        # Step 1: 获取任务列表
        api_response = requests.get(f'{base_url}/api/task-runs?limit=10')
        api_tasks = api_response.json()['data']
        
        if len(api_tasks) > 0:
            task = api_tasks[0]
            
            # Step 2: 访问页面并打开详情
            page.goto(f"{base_url}/#/tasks")
            page.wait_for_timeout(3000)
            
            detail_buttons = page.locator('button:has-text("详情")')
            if detail_buttons.count() > 0:
                detail_buttons.first.click()
                page.wait_for_timeout(2000)
                
                # Step 3: 验证弹窗显示
                modal = page.locator('.modal-overlay')
                expect(modal).to_be_visible()
                
                # Step 4: 验证任务 ID 显示（简化验证）
                modal_title = modal.locator('h3, .modal-title')
                expect(modal_title).to_be_visible()
