# E2E 测试代码规范

**版本**: 1.0  
**生效日期**: 2026-03-14  
**适用范围**: 所有 E2E 测试代码

---

## 📝 1. 文件头注释规范

### 1.1 标准格式

```python
# -*- coding: utf-8 -*-
"""
E2E 测试 - [模块名称]

【文件信息】
- 创建日期：YYYY-MM-DD
- 创建人：[姓名]
- 最后更新：YYYY-MM-DD
- 测试范围：[简要描述]

【编码规范】
- 文件编码：UTF-8 无 BOM
- Python 版本：3.12+
- 测试框架：pytest + Playwright

【选择器优先级】
1. data-testid 属性（静态 HTML）
2. CSS 类选择器（.card, .button）
3. 标签选择器（button, table）
4. 避免使用文本匹配（has-text）

【等待策略】
1. page.wait_for_load_state('load')
2. page.wait_for_selector(selector, state='visible')
3. page.wait_for_timeout(3000) - 最后选择

【运行命令】
```bash
pytest tests/e2e/test_[module].py -v
```
"""
```

### 1.2 必填字段

| 字段 | 说明 | 示例 |
|------|------|------|
| 模块名称 | 测试的模块 | 文件上传、任务管理 |
| 创建日期 | 文件创建日期 | 2026-03-14 |
| 创建人 | 文件创建者 | 小爪 |
| 最后更新 | 最后修改日期 | 2026-03-14 |
| 测试范围 | 测试覆盖范围 | 文件上传、创建任务流程 |

### 1.3 可选字段

| 字段 | 说明 | 示例 |
|------|------|------|
| 相关文件 | 关联的测试文件 | test_upload.py |
| 依赖模块 | 依赖的其他模块 | 用户登录模块 |
| 特殊说明 | 需要特别说明的事项 | 需要管理员权限 |

---

## 🎯 2. 选择器使用规范

### 2.1 优先级顺序

```
✅ 推荐（按优先级排序）：
1. [data-testid="element-id"]    # 静态 HTML 元素
2. .card, .button, .table        # CSS 类选择器
3. button, table, form           # 标签选择器
4. #upload-btn                   # ID 选择器

❌ 避免：
1. button:has-text("创建任务")   # 中文文本匹配
2. div:has-text("文件上传")      # 中文文本匹配
3. xpath=//div[contains(.,'上传')] # XPath
```

### 2.2 使用示例

#### ✅ 推荐用法

```python
# 1. 数据属性选择器（静态 HTML）
page.locator('[data-testid="upload-btn"]')
page.locator('[data-testid="nav-tasks"]')

# 2. CSS 类选择器（通用元素）
page.locator('.card')
page.locator('.button')
page.locator('.data-table')

# 3. 标签选择器（基础元素）
page.locator('button')
page.locator('table')
page.locator('form')

# 4. 组合选择器（精确匹配）
page.locator('.card [data-testid="upload-btn"]')
page.locator('form#upload-form button[type="submit"]')
```

#### ❌ 避免用法

```python
# 1. 中文文本匹配（不稳定）
page.locator('button:has-text("创建任务")')
page.locator('div:has-text("文件上传")')

# 2. 复杂 XPath（难维护）
page.locator('xpath=//div[@class="card"]//button[contains(.,"创建")]')

# 3. 绝对路径（脆弱）
page.locator('html body div main div button')
```

### 2.3 数据属性添加指南

#### HTML 静态元素

```html
<!-- 导航菜单 -->
<nav data-testid="sidebar-nav">
    <a data-testid="nav-dashboard" data-page="dashboard">概览</a>
    <a data-testid="nav-upload" data-page="upload">文件上传</a>
    <a data-testid="nav-tasks" data-page="tasks">任务列表</a>
</nav>

<!-- 表单元素 -->
<form data-testid="upload-form">
    <input data-testid="file-input" type="file">
    <select data-testid="plugin-select">
    <button data-testid="submit-btn">提交</button>
</form>

<!-- 内容区域 -->
<div data-testid="upload-result">
    <div data-testid="success-message">上传成功</div>
</div>
```

#### JavaScript 动态生成

```javascript
function loadUpload() {
    contentArea.innerHTML = `
        <div class="card" data-testid="upload-card">
            <div class="card-title" data-testid="upload-title">上传文件</div>
            <div class="upload-area" data-testid="upload-area">
                <input data-testid="file-input" type="file">
            </div>
            <select data-testid="plugin-select">
            <button data-testid="create-task-btn">创建任务</button>
        </div>
    `;
}
```

---

## ⏱️ 3. 等待策略规范

### 3.1 等待类型优先级

```
✅ 推荐（按优先级排序）：
1. page.wait_for_load_state('load')           # 页面加载完成
2. page.wait_for_load_state('networkidle')    # 网络空闲
3. page.wait_for_selector(selector)           # 元素出现
4. page.wait_for_selector(selector, 'visible')# 元素可见
5. page.wait_for_timeout(3000)                # 固定等待（最后选择）
```

### 3.2 使用示例

#### ✅ 推荐用法

```python
# 1. 等待页面加载
page.goto(f"{base_url}/#/upload")
page.wait_for_load_state('load')

# 2. 等待网络空闲
page.goto(f"{base_url}/#/tasks")
page.wait_for_load_state('networkidle')

# 3. 等待元素出现
page.wait_for_selector('.card', timeout=5000)

# 4. 等待元素可见
page.wait_for_selector('.card', state='visible', timeout=5000)

# 5. 组合等待（推荐）
page.goto(f"{base_url}/#/upload")
page.wait_for_load_state('load')
page.wait_for_selector('.card', state='visible')
expect(page.locator('.card')).to_be_visible()
```

#### ❌ 避免用法

```python
# 1. 只使用固定等待
page.goto(f"{base_url}/#/upload")
page.wait_for_timeout(5000)  # 不推荐单独使用

# 2. 没有等待直接断言
page.goto(f"{base_url}/#/upload")
expect(page.locator('.card')).to_be_visible()  # 可能失败

# 3. 等待时间过长
page.wait_for_timeout(30000)  # 避免超过 10 秒
```

### 3.3 超时设置

```python
# 全局超时（conftest.py）
@pytest.fixture
def page(context: BrowserContext) -> Page:
    page = context.new_page()
    page.set_default_timeout(10000)  # 10 秒
    page.set_default_navigation_timeout(10000)
    yield page

# 单个操作超时
page.wait_for_selector('.card', timeout=5000)  # 5 秒
page.wait_for_timeout(3000)  # 3 秒固定等待
```

---

## 📋 4. 测试用例编写规范

### 4.1 命名规范

```python
# 测试类：大驼峰命名
class TestFileUpload:
    pass

class TestTaskManagement:
    pass

# 测试方法：test_[功能]_[场景]
def test_upload_page_loads(self):
    pass

def test_upload_file_success(self):
    pass

# 测试 ID: E2E-[模块]-[序号]
"""E2E-UPLOAD-001: 上传页面加载"""
"""E2E-TASK-002: 创建任务成功"""
```

### 4.2 测试结构（AAA 模式）

```python
def test_upload_file_success(self, page: Page, base_url: str):
    """E2E-UPLOAD-001: 上传文件成功
    
    【测试步骤】
    1. 访问上传页面
    2. 选择文件
    3. 点击上传
    4. 验证成功提示
    
    【预期结果】
    - 文件上传成功
    - 显示成功提示
    - 文件出现在列表中
    
    【优先级】P0
    """
    # Arrange - 准备数据
    page.goto(f"{base_url}/#/upload")
    page.wait_for_load_state('load')
    
    # Act - 执行操作
    file_input = page.locator('[data-testid="file-input"]')
    file_input.set_input_files(b'test content')
    
    upload_btn = page.locator('[data-testid="upload-btn"]')
    upload_btn.click()
    
    # Assert - 验证结果
    success_message = page.locator('[data-testid="success-message"]')
    expect(success_message).to_be_visible()
```

### 4.3 断言规范

```python
# 1. 元素可见性
expect(element).to_be_visible()
expect(element).to_be_hidden()

# 2. 元素状态
expect(element).to_be_enabled()
expect(element).to_be_disabled()

# 3. 文本内容
expect(element).to_have_text("成功")
expect(element).to_contain_text("上传")

# 4. 页面属性
expect(page).to_have_title("Chujiu Design TodoList")
expect(page).to_have_url("http://127.0.0.1:5001")

# 5. 元素计数
elements = page.locator('.item')
expect(elements).to_have_count(5)
```

---

## 🧹 5. 数据清理规范

### 5.1 测试数据隔离

```python
# 使用 fixture 自动清理
@pytest.fixture
def test_file(page: Page):
    # 创建测试数据
    file_path = create_test_file()
    yield file_path
    # 清理测试数据
    delete_test_file(file_path)

def test_upload_file(self, page: Page, test_file):
    # 使用测试数据
    page.locator('[data-testid="file-input"]').set_input_files(test_file)
```

### 5.2 测试后清理

```python
def teardown_module(module):
    """测试模块结束后清理"""
    delete_all_test_files()
    reset_database()

def teardown_function(function):
    """每个测试函数结束后清理"""
    logout_user()
    clear_cache()
```

---

## 📊 6. 测试报告规范

### 6.1 HTML 报告生成

```bash
# 生成 HTML 报告
pytest tests/e2e/ --html=tests/e2e/report.html --self-contained-html

# 查看报告
start tests/e2e/report.html
```

### 6.2 报告内容要求

- ✅ 测试用例总数
- ✅ 通过率统计
- ✅ 失败用例详情
- ✅ 执行时间统计
- ✅ 错误堆栈信息

---

## 🔍 7. 代码审查清单

### 7.1 提交前检查

- [ ] 文件编码为 UTF-8 无 BOM
- [ ] 文件头注释完整
- [ ] 使用推荐的选择器
- [ ] 使用智能等待
- [ ] 测试用例命名规范
- [ ] 包含详细的文档字符串
- [ ] 测试数据已清理
- [ ] 本地测试通过

### 7.2 常见问题

| 问题 | 检查项 | 解决方案 |
|------|--------|---------|
| 测试失败 | 选择器是否正确 | 使用 data-testid |
| 测试超时 | 等待时间是否足够 | 增加 timeout |
| 测试不稳定 | 是否使用固定等待 | 改用智能等待 |
| 中文乱码 | 文件编码是否正确 | 转换为 UTF-8 无 BOM |

---

## 📚 8. 参考资源

### 8.1 官方文档
- [Playwright 文档](https://playwright.dev/python/)
- [pytest 文档](https://docs.pytest.org/)
- [Python 编码规范](https://peps.python.org/pep-0008/)

### 8.2 内部文档
- [编码问题复盘报告](../../复盘/测试复盘/2026-03-14_编码问题复盘.md)
- [E2E 测试实施报告](./IMPLEMENTATION_REPORT.md)
- [测试执行总结](../TEST_FINAL_REPORT.md)

---

**文档维护**: Chujiu Design Team  
**最后更新**: 2026-03-14  
**状态**: ✅ 生效中
