# 测试代码模板使用指南

**版本**: 1.0  
**生效日期**: 2026-03-14  
**适用范围**: 所有新创建的 E2E 测试文件

---

## 📁 1. 模板文件位置

```
tests/e2e/templates/
├── test_template.py          # 标准测试模板
├── CODE_STYLE_GUIDE.md       # 代码规范指南
└── TEMPLATE_USAGE.md         # 本文件
```

---

## 🚀 2. 快速开始

### 2.1 创建新测试文件

**步骤 1**: 复制模板
```bash
# 复制标准模板
cp tests/e2e/templates/test_template.py tests/e2e/test_[module].py
```

**步骤 2**: 修改文件头
```python
# 修改前
E2E 测试 - [模块名称]
- 创建日期：YYYY-MM-DD
- 创建人：[姓名]

# 修改后
E2E 测试 - 文件上传模块
- 创建日期：2026-03-14
- 创建人：小爪
```

**步骤 3**: 修改测试类名
```python
# 修改前
class Test[ModuleName]:

# 修改后
class TestFileUpload:
```

**步骤 4**: 添加测试用例
```python
def test_[feature]_[scenario](self, page: Page, base_url: str):
    """E2E-[MODULE]-[ID]: [测试场景描述]"""
    # Arrange
    # Act
    # Assert
```

---

## 📋 3. 文件头注释模板

### 3.1 必填字段

```python
# -*- coding: utf-8 -*-
"""
E2E 测试 - [模块名称]

【文件信息】
- 创建日期：2026-03-14          # 必填：YYYY-MM-DD 格式
- 创建人：[你的姓名]            # 必填
- 最后更新：2026-03-14          # 必填：YYYY-MM-DD 格式
- 测试范围：[简要描述]          # 必填：一句话描述

【编码规范】
- 文件编码：UTF-8 无 BOM        # 固定
- Python 版本：3.12+           # 固定
- 测试框架：pytest + Playwright # 固定

【选择器优先级】               # 固定内容
1. data-testid 属性（静态 HTML）
2. CSS 类选择器（.card, .button）
3. 标签选择器（button, table）
4. 避免使用文本匹配（has-text）

【等待策略】                   # 固定内容
1. page.wait_for_load_state('load')
2. page.wait_for_selector(selector, state='visible')
3. page.wait_for_timeout(3000) - 最后选择

【运行命令】                   # 根据实际修改
```bash
pytest tests/e2e/test_[module].py -v
```
"""
```

### 3.2 示例

```python
# -*- coding: utf-8 -*-
"""
E2E 测试 - 文件上传模块

【文件信息】
- 创建日期：2026-03-14
- 创建人：小爪
- 最后更新：2026-03-14
- 测试范围：文件上传页面加载、元素验证、上传流程

【编码规范】
- 文件编码：UTF-8 无 BOM
- Python 版本：3.12+
- 测试框架：pytest + Playwright

【选择器优先级】
1. data-testid 属性（静态 HTML）
2. CSS 类选择器（.card, .button）
3. 标签选择器（button, table）
4. 避免使用文本匹配（has-text）

【等待策略】
1. page.wait_for_load_state('load')
2. page.wait_for_selector(selector, state='visible')
3. page.wait_for_timeout(3000) - 最后选择

【运行命令】
```bash
pytest tests/e2e/test_upload.py -v
```
"""
```

---

## 🎯 4. 测试用例模板

### 4.1 标准格式

```python
def test_[feature]_[scenario](self, page: Page, base_url: str):
    """E2E-[MODULE]-[ID]: [测试场景描述]
    
    【测试步骤】
    1. [步骤 1]
    2. [步骤 2]
    3. [步骤 3]
    
    【预期结果】
    - [预期 1]
    - [预期 2]
    
    【优先级】P0/P1/P2
    """
    # Arrange - 准备数据
    page.goto(f"{base_url}/#/[page]")
    page.wait_for_load_state('load')
    
    # Act - 执行操作
    page.wait_for_timeout(3000)  # 等待动态加载
    
    # Assert - 验证结果
    element = page.locator('[data-testid="element-id"]')
    expect(element).to_be_visible()
```

### 4.2 完整示例

```python
def test_upload_page_loads(self, page: Page, base_url: str):
    """E2E-UPLOAD-001: 上传页面加载
    
    【测试步骤】
    1. 访问上传页面
    2. 等待页面加载完成
    3. 验证页面标题
    
    【预期结果】
    - 页面成功加载
    - 标题正确
    
    【优先级】P0
    """
    # Arrange
    page.goto(f"{base_url}/#/upload")
    
    # Act
    page.wait_for_load_state('load')
    
    # Assert
    expect(page).to_have_title("Chujiu Design TodoList")
```

---

## 🔧 5. 选择器使用模板

### 5.1 数据属性选择器

```python
# HTML 中添加 data-testid
<div data-testid="upload-card">
    <button data-testid="upload-btn">上传</button>
</div>

# 测试代码中使用
page.locator('[data-testid="upload-card"]')
page.locator('[data-testid="upload-btn"]')
```

### 5.2 CSS 类选择器

```python
# 通用类选择器
page.locator('.card')
page.locator('.button')
page.locator('.table')

# 组合选择器
page.locator('.card .button')
page.locator('form .submit-btn')
```

### 5.3 标签选择器

```python
# 基础标签
page.locator('button')
page.locator('table')
page.locator('input')

# 带属性
page.locator('button[type="submit"]')
page.locator('input[type="file"]')
```

---

## ⏱️ 6. 等待策略模板

### 6.1 标准等待组合

```python
def test_page_loads(self, page: Page, base_url: str):
    # 1. 导航到页面
    page.goto(f"{base_url}/#/upload")
    
    # 2. 等待页面加载完成
    page.wait_for_load_state('load')
    
    # 3. 等待关键元素可见
    page.wait_for_selector('.card', state='visible', timeout=5000)
    
    # 4. 断言
    expect(page.locator('.card')).to_be_visible()
```

### 6.2 动态页面等待

```python
def test_dynamic_content(self, page: Page, base_url: str):
    page.goto(f"{base_url}/#/upload")
    page.wait_for_load_state('load')
    
    # 动态内容需要额外等待
    page.wait_for_timeout(3000)
    
    # 验证
    expect(page.locator('.card')).to_be_visible()
```

---

## 📊 7. 优先级定义

### 7.1 优先级标准

| 优先级 | 说明 | 示例 |
|--------|------|------|
| **P0** | 核心功能，必须测试 | 页面加载、登录 |
| **P1** | 重要功能，应该测试 | 表单提交、数据验证 |
| **P2** | 辅助功能，可以测试 | UI 细节、边缘场景 |

### 7.2 优先级分配示例

```python
# P0 - 核心功能
def test_upload_page_loads(self):
    """E2E-UPLOAD-001: 上传页面加载【P0】"""
    pass

def test_upload_file_success(self):
    """E2E-UPLOAD-002: 上传文件成功【P0】"""
    pass

# P1 - 重要功能
def test_upload_file_input_exists(self):
    """E2E-UPLOAD-003: 文件输入框存在【P1】"""
    pass

# P2 - 辅助功能
def test_upload_result_area_exists(self):
    """E2E-UPLOAD-004: 上传结果区域存在【P2】"""
    pass
```

---

## ✅ 8. 检查清单

### 8.1 提交前检查

- [ ] 文件编码为 UTF-8 无 BOM
- [ ] 文件头注释完整（创建日期、创建人、测试范围）
- [ ] 测试类名符合规范（Test[ModuleName]）
- [ ] 测试方法名符合规范（test_[feature]_[scenario]）
- [ ] 每个测试用例有文档字符串
- [ ] 使用推荐的选择器（data-testid > CSS > 标签）
- [ ] 使用智能等待（避免单独使用 wait_for_timeout）
- [ ] 测试用例有优先级标记（P0/P1/P2）
- [ ] 本地测试通过

### 8.2 代码审查要点

| 检查项 | 标准 | 工具 |
|--------|------|------|
| 文件编码 | UTF-8 无 BOM | file -i |
| 命名规范 | 大驼峰/下划线 | 人工审查 |
| 选择器使用 | 数据属性优先 | 人工审查 |
| 等待策略 | 智能等待 | 人工审查 |
| 文档完整性 | 完整的文档字符串 | 人工审查 |

---

## 📚 9. 参考资源

### 9.1 模板文件
- `test_template.py` - 标准测试模板
- `CODE_STYLE_GUIDE.md` - 代码规范指南

### 9.2 示例文件
- `test_upload_standard.py` - 文件上传标准测试
- `test_tasks_standard.py` - 任务管理标准测试

### 9.3 相关文档
- [编码问题复盘报告](../../复盘/测试复盘/2026-03-14_编码问题复盘.md)
- [E2E 测试实施报告](./IMPLEMENTATION_REPORT.md)

---

## 🎯 10. 常见问题

### Q1: 如何选择合适的选择器？

**A**: 按以下优先级选择：
1. 静态 HTML 使用 `data-testid`
2. 动态内容使用 CSS 类
3. 基础元素使用标签选择器
4. 避免使用文本匹配

### Q2: 等待时间设置多少合适？

**A**: 
- 页面加载：`wait_for_load_state('load')`
- 元素可见：`timeout=5000` (5 秒)
- 动态内容：`wait_for_timeout(3000)` (3 秒)

### Q3: 如何组织多个测试用例？

**A**: 
1. 按功能分组（test_upload_, test_download_）
2. 按优先级排序（P0 → P1 → P2）
3. 保持独立性（测试间不依赖）

---

**文档维护**: Chujiu Design Team  
**最后更新**: 2026-03-14  
**状态**: ✅ 生效中
