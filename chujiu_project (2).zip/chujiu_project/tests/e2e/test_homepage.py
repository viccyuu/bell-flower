# -*- coding: utf-8 -*-
"""
E2E 娴嬭瘯 - 棣栭〉鍔犺浇

楠岃瘉棣栭〉姝ｅ父鍔犺浇鍜屾牳蹇冨厓绱犲瓨鍦ㄣ€?"""
import pytest
from playwright.sync_api import Page, expect


class TestHomePage:
    """棣栭〉 E2E 娴嬭瘯"""
    
    def test_home_page_loads_successfully(self, page: Page, base_url: str):
        """E2E-001: 棣栭〉鎴愬姛鍔犺浇"""
        # 璁块棶棣栭〉
        page.goto(base_url)
        
        # 楠岃瘉椤甸潰鏍囬
        expect(page).to_have_title("Chujiu TodoList")
        
        # 楠岃瘉椤甸潰鍔犺浇鎴愬姛
        assert page.is_visible("#app")
    
    def test_navigation_menu_exists(self, page: Page, base_url: str):
        """E2E-002: 瀵艰埅鑿滃崟瀛樺湪"""
        page.goto(base_url)
        
        # 楠岃瘉宸︿晶瀵艰埅瀛樺湪
        nav = page.locator('.sidebar, .nav, aside')
        expect(nav).to_be_visible()
    
    def test_upload_button_exists(self, page: Page, base_url: str):
        """E2E-003: 涓婁紶鎸夐挳瀛樺湪"""
        page.goto(base_url)
        
        # 楠岃瘉涓婁紶鎸夐挳瀛樺湪
        upload_btn = page.locator('#upload-btn, button:has-text("涓婁紶"), [data-page="upload"]')
        expect(upload_btn).to_be_visible()
    
    def test_task_list_section_exists(self, page: Page, base_url: str):
        """E2E-004: 浠诲姟鍒楄〃鍖哄煙瀛樺湪"""
        page.goto(base_url)
        
        # 楠岃瘉浠诲姟鍒楄〃鍖哄煙瀛樺湪
        task_section = page.locator('#tasks, .task-list, [data-page="tasks"]')
        expect(task_section).to_be_visible()
