# -*- coding: utf-8 -*-
"""
E2E 测试 - Heartbeat & Cron 服务

测试 Heartbeat 和 Cron 服务的端到端功能
"""
import pytest
from pathlib import Path
import tempfile
import os


class TestHeartbeatE2E:
    """Heartbeat E2E 测试"""
    
    def test_heartbeat_service_start_stop(self, app_context):
        """测试 Heartbeat 服务启动停止"""
        from app.heartbeat.service import HeartbeatService
        
        # 创建临时工作目录
        with tempfile.TemporaryDirectory() as tmpdir:
            workspace = Path(tmpdir)
            
            # 创建 Heartbeat 服务
            service = HeartbeatService(
                workspace=workspace,
                provider=None,
                model='test-model',
                interval_s=60,
            )
            
            # 启动服务
            service.start()
            assert service._running == True
            
            # 停止服务
            service.stop()
            assert service._running == False


class TestCronE2E:
    """Cron E2E 测试"""
    
    def test_cron_service_lifecycle(self, app_context):
        """测试 Cron 服务生命周期"""
        from app.cron.service import CronService
        from app.cron.types import CronSchedule
        
        # 创建临时存储文件
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            store_path = Path(f.name)
        
        try:
            # 创建 Cron 服务
            service = CronService(store_path=store_path)
            
            # 启动服务
            service.start()
            assert service._running == True
            
            # 添加任务
            job = service.add_job(
                name='test_job',
                schedule=CronSchedule(kind='every', every_ms=60000),
                message='test'
            )
            assert job is not None
            
            # 列出任务
            jobs = service.list_jobs()
            assert len(jobs) >= 1
            
            # 停止服务
            service.stop()
            assert service._running == False
            
        finally:
            # 清理临时文件
            if store_path.exists():
                os.unlink(store_path)
    
    def test_cron_job_execution(self, app_context):
        """测试 Cron 任务执行"""
        from app.cron.service import CronService
        from app.cron.types import CronSchedule
        import asyncio
        
        # 创建临时存储文件
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            store_path = Path(f.name)
        
        try:
            executed = []
            
            async def on_job(job):
                executed.append(job.id)
                return 'executed'
            
            # 创建 Cron 服务
            service = CronService(store_path=store_path, on_job=on_job)
            
            # 添加立即执行的任务
            job = service.add_job(
                name='immediate_job',
                schedule=CronSchedule(kind='at', at_ms=0),
                message='test'
            )
            
            # 启动服务
            service.start()
            
            # 等待执行
            import time
            time.sleep(0.1)
            
            # 验证执行
            jobs = service.list_jobs()
            assert len(jobs) >= 1
            
            # 停止服务
            service.stop()
            
        finally:
            # 清理临时文件
            if store_path.exists():
                os.unlink(store_path)


class TestErrorRecoveryE2E:
    """错误恢复 E2E 测试"""
    
    def test_retry_scheduling(self, app_context):
        """测试重试调度"""
        from app.todolist.error_recovery import ErrorRecoveryManager
        from app.cron.service import CronService
        from pathlib import Path
        import tempfile
        import os
        
        # 创建临时存储文件
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            store_path = Path(f.name)
        
        try:
            # 创建 Cron 服务
            cron_service = CronService(store_path=store_path)
            
            # 创建错误恢复管理器
            recovery = ErrorRecoveryManager(cron_service=cron_service, max_retries=3)
            
            # 调度重试
            recovery.schedule_retry(
                task_run_id=1,
                node_code='test_node',
                delay_seconds=60
            )
            
            # 验证重试任务已调度
            jobs = cron_service.list_jobs()
            assert len(jobs) >= 1
            assert any('retry' in j.name for j in jobs)
            
        finally:
            # 清理临时文件
            if store_path.exists():
                os.unlink(store_path)
