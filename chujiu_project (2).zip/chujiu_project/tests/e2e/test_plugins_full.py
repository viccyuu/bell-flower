# -*- coding: utf-8 -*-
"""
E2E 娴嬭瘯 - 鎻掍欢绠＄悊鍔熻兘锛堝畬鏁寸増锛?
瑕嗙洊 5 涓祴璇曞眰娆★細
1. 椤甸潰鍔犺浇
2. 鍏冪礌瀛樺湪
3. 鐐瑰嚮浜や簰
4. 娴佺▼楠岃瘉
5. 鏁版嵁楠岃瘉
"""
import pytest
from playwright.sync_api import Page, expect


class TestPluginManagementPageLoad:
    """鎻掍欢绠＄悊椤甸潰鍔犺浇娴嬭瘯"""
    
    def test_plugin_list_page_loads_successfully(self, page: Page, base_url: str):
        """E2E-070: 鎻掍欢鍒楄〃椤甸潰鎴愬姛鍔犺浇"""
        page.goto(f"{base_url}/#/plugins")
        
        # 楠岃瘉椤甸潰鍔犺浇
        expect(page).to_have_title("Chujiu TodoList")
        
        # 楠岃瘉鎻掍欢鍒楄〃鍖哄煙瀛樺湪
        plugin_area = page.locator('.plugin-list, .card:has-text("鎻掍欢")')
        expect(plugin_area).to_be_visible(timeout=5000)
    
    def test_plugin_list_has_plugins(self, page: Page, base_url: str):
        """E2E-071: 鎻掍欢鍒楄〃鏄剧ず鎻掍欢"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(2000)
        
        # 楠岃瘉鑷冲皯鏈変竴涓彃浠?        plugin_item = page.locator('.plugin-item, .card:has-text("Excel")')
        expect(plugin_item).to_be_visible()


class TestPluginManagementElements:
    """鎻掍欢绠＄悊鍏冪礌瀛樺湪娴嬭瘯"""
    
    def test_plugin_items_exist(self, page: Page, base_url: str):
        """E2E-072: 鎻掍欢椤圭洰瀛樺湪"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(2000)
        
        plugin_items = page.locator('.plugin-item')
        expect(plugin_items).to_be_visible()
    
    def test_plugin_toggle_switch_exists(self, page: Page, base_url: str):
        """E2E-073: 鎻掍欢寮€鍏冲瓨鍦?""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(2000)
        
        toggle_switch = page.locator('input[type="checkbox"].plugin-toggle, .toggle-switch')
        expect(toggle_switch).to_be_visible()
    
    def test_plugin_dag_button_exists(self, page: Page, base_url: str):
        """E2E-074: 鏌ョ湅 DAG 鎸夐挳瀛樺湪"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(2000)
        
        dag_btn = page.locator('button:has-text("DAG"), .dag-btn')
        expect(dag_btn).to_be_visible()
    
    def test_plugin_learning_button_exists(self, page: Page, base_url: str):
        """E2E-075: 鏌ョ湅 Learning 鎸夐挳瀛樺湪"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(2000)
        
        learning_btn = page.locator('button:has-text("Learning"), .learning-btn')
        expect(learning_btn).to_be_visible()


class TestPluginManagementInteraction:
    """鎻掍欢绠＄悊鐐瑰嚮浜や簰娴嬭瘯"""
    
    def test_toggle_plugin_switch(self, page: Page, base_url: str):
        """E2E-076: 鍒囨崲鎻掍欢寮€鍏?""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(2000)
        
        # 鑾峰彇褰撳墠鐘舵€?        toggle = page.locator('input[type="checkbox"].plugin-toggle').first
        initial_state = toggle.is_checked()
        
        # 鍒囨崲鐘舵€?        toggle.click()
        page.wait_for_timeout(1000)
        
        # 楠岃瘉鐘舵€佹敼鍙?        new_state = toggle.is_checked()
        assert initial_state != new_state
    
    def test_click_view_dag_button(self, page: Page, base_url: str):
        """E2E-077: 鐐瑰嚮鏌ョ湅 DAG 鎸夐挳"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(2000)
        
        dag_btn = page.locator('button:has-text("DAG")').first
        dag_btn.click()
        
        # 楠岃瘉 DAG 寮圭獥鏄剧ず
        modal = page.locator('.modal-overlay')
        expect(modal).to_be_visible()
    
    def test_click_view_learning_button(self, page: Page, base_url: str):
        """E2E-078: 鐐瑰嚮鏌ョ湅 Learning 鎸夐挳"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(2000)
        
        learning_btn = page.locator('button:has-text("Learning")').first
        learning_btn.click()
        
        # 楠岃瘉 Learning 寮圭獥鏄剧ず
        modal = page.locator('.modal-overlay')
        expect(modal).to_be_visible()
    
    def test_close_dag_modal(self, page: Page, base_url: str):
        """E2E-079: 鍏抽棴 DAG 寮圭獥"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(2000)
        
        # 鎵撳紑 DAG
        dag_btn = page.locator('button:has-text("DAG")').first
        dag_btn.click()
        
        # 鍏抽棴寮圭獥
        close_btn = page.locator('.modal-overlay button:has-text("鉁?)')
        close_btn.click()
        
        # 楠岃瘉寮圭獥鍏抽棴
        modal = page.locator('.modal-overlay')
        expect(modal).to_be_hidden()


class TestPluginManagementFlow:
    """鎻掍欢绠＄悊娴佺▼楠岃瘉娴嬭瘯"""
    
    def test_view_plugin_dag_shows_nodes(self, page: Page, base_url: str):
        """E2E-080: 鏌ョ湅鎻掍欢 DAG 鏄剧ず鑺傜偣"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(2000)
        
        # 鎵撳紑 DAG
        dag_btn = page.locator('button:has-text("DAG")').first
        dag_btn.click()
        
        # 楠岃瘉鑺傜偣鏄剧ず
        dag_nodes = page.locator('.dag-node, .node')
        expect(dag_nodes).to_be_visible()
    
    def test_view_plugin_learning_shows_rules(self, page: Page, base_url: str):
        """E2E-081: 鏌ョ湅鎻掍欢 Learning 鏄剧ず瑙勫垯"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(2000)
        
        # 鎵撳紑 Learning
        learning_btn = page.locator('button:has-text("Learning")').first
        learning_btn.click()
        
        # 楠岃瘉瑙勫垯鏄剧ず
        learning_rules = page.locator('.learning-rule, .rule-item')
        expect(learning_rules).to_be_visible()
    
    def test_plugin_list_shows_three_plugins(self, page: Page, base_url: str):
        """E2E-082: 鎻掍欢鍒楄〃鏄剧ず 3 涓彃浠?""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(2000)
        
        # 楠岃瘉鏈?3 涓彃浠?        plugin_items = page.locator('.plugin-item')
        count = plugin_items.count()
        assert count >= 3  # excel_vba_to_wps_js, wps_js_to_excel_vba, web_briefing


class TestPluginManagementDataValidation:
    """鎻掍欢绠＄悊鏁版嵁楠岃瘉娴嬭瘯"""
    
    def test_plugins_api_returns_all_plugins(self, page: Page, base_url: str):
        """E2E-083: 鎻掍欢 API 杩斿洖鎵€鏈夋彃浠?""
        response = page.request.get(f"{base_url}/api/plugins")
        data = response.json()
        
        assert data['code'] == 'OK'
        assert len(data['data']) >= 3
    
    def test_plugin_dag_api_returns_structure(self, page: Page, base_url: str):
        """E2E-084: 鎻掍欢 DAG API 杩斿洖缁撴瀯"""
        response = page.request.get(f"{base_url}/api/plugins/excel_vba_to_wps_js/dag")
        data = response.json()
        
        assert data['code'] == 'OK'
        assert 'nodes' in data['data']
        assert 'edges' in data['data']
    
    def test_plugin_learning_api_returns_rules(self, page: Page, base_url: str):
        """E2E-085: 鎻掍欢 Learning API 杩斿洖瑙勫垯"""
        response = page.request.get(f"{base_url}/api/plugins/excel_vba_to_wps_js/learning")
        data = response.json()
        
        assert data['code'] == 'OK'
        assert isinstance(data['data'], list)
    
    def test_plugin_has_required_fields(self, page: Page, base_url: str):
        """E2E-086: 鎻掍欢鏈夊繀闇€瀛楁"""
        response = page.request.get(f"{base_url}/api/plugins")
        plugins = response.json()['data']
        
        for plugin in plugins:
            assert 'code' in plugin
            assert 'name' in plugin
            assert 'description' in plugin
            assert 'status' in plugin or 'enabled' in plugin
    
    def test_plugin_dag_nodes_have_required_fields(self, page: Page, base_url: str):
        """E2E-087: DAG 鑺傜偣鏈夊繀闇€瀛楁"""
        response = page.request.get(f"{base_url}/api/plugins/excel_vba_to_wps_js/dag")
        dag = response.json()['data']
        
        for node in dag['nodes']:
            assert 'id' in node
            assert 'code' in node
            assert 'type' in node or 'nodeType' in node
