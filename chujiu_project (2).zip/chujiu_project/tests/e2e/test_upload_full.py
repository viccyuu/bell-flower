# -*- coding: utf-8 -*-
"""
E2E 娴嬭瘯 - 鏂囦欢涓婁紶鍔熻兘锛堝畬鏁寸増锛?
瑕嗙洊 5 涓祴璇曞眰娆★細
1. 椤甸潰鍔犺浇
2. 鍏冪礌瀛樺湪
3. 鐐瑰嚮浜や簰
4. 娴佺▼楠岃瘉
5. 鏁版嵁楠岃瘉
"""
import pytest
from playwright.sync_api import Page, expect
import os
import time


class TestFileUploadPageLoad:
    """鏂囦欢涓婁紶椤甸潰鍔犺浇娴嬭瘯"""
    
    def test_upload_page_loads_successfully(self, page: Page, base_url: str):
        """E2E-010: 涓婁紶椤甸潰鎴愬姛鍔犺浇"""
        page.goto(f"{base_url}/#/upload")
        
        # 楠岃瘉椤甸潰鏍囬
        expect(page).to_have_title("Chujiu Design TodoList")
        
        # 楠岃瘉涓婁紶鍖哄煙瀛樺湪锛堢瓑寰呴〉闈㈠姞杞斤級
        page.wait_for_selector('.upload-area', timeout=5000)
        upload_area = page.locator('.upload-area')
        expect(upload_area).to_be_visible()
    
    def test_upload_page_has_correct_heading(self, page: Page, base_url: str):
        """E2E-010-2: 涓婁紶椤甸潰鏍囬姝ｇ‘"""
        page.goto(f"{base_url}/#/upload")
        
        # 楠岃瘉鍗＄墖鏍囬
        heading = page.locator('.card-title')
        expect(heading).to_be_visible()


class TestFileUploadElements:
    """鏂囦欢涓婁紶鍏冪礌瀛樺湪娴嬭瘯"""
    
    def test_upload_button_exists(self, page: Page, base_url: str):
        """E2E-011: 涓婁紶鎸夐挳瀛樺湪"""
        page.goto(f"{base_url}/#/upload")
        page.wait_for_selector('.upload-area', timeout=5000)
        
        upload_area = page.locator('.upload-area')
        expect(upload_area).to_be_visible()
    
    def test_plugin_selector_exists(self, page: Page, base_url: str):
        """E2E-012: 鎻掍欢閫夋嫨鍣ㄥ瓨鍦?""
        page.goto(f"{base_url}/#/upload")
        page.wait_for_selector('.upload-area', timeout=5000)
        
        plugin_selector = page.locator('select#plugin')
        expect(plugin_selector).to_be_visible()
    
    def test_create_task_button_exists(self, page: Page, base_url: str):
        """E2E-013: 鍒涘缓浠诲姟鎸夐挳瀛樺湪"""
        page.goto(f"{base_url}/#/upload")
        page.wait_for_selector('.upload-area', timeout=5000)
        
        create_btn = page.locator('button:has-text("鍒涘缓浠诲姟")')
        expect(create_btn).to_be_visible()
    
    def test_upload_result_area_exists(self, page: Page, base_url: str):
        """E2E-013-2: 涓婁紶缁撴灉鍖哄煙瀛樺湪"""
        page.goto(f"{base_url}/#/upload")
        
        result_area = page.locator('#upload-result, .upload-result')
        expect(result_area).to_be_visible()


class TestFileUploadInteraction:
    """鏂囦欢涓婁紶鐐瑰嚮浜や簰娴嬭瘯"""
    
    def test_click_upload_button_opens_file_picker(self, page: Page, base_url: str):
        """E2E-014: 鐐瑰嚮涓婁紶鎸夐挳鎵撳紑鏂囦欢閫夋嫨鍣?""
        page.goto(f"{base_url}/#/upload")
        
        # 鐐瑰嚮涓婁紶鍖哄煙
        upload_area = page.locator('.upload-area')
        upload_area.click()
        
        # 楠岃瘉鏂囦欢杈撳叆琚縺娲?        file_input = page.locator('input[type="file"]')
        expect(file_input).to_be_attached()
    
    def test_select_plugin_from_dropdown(self, page: Page, base_url: str):
        """E2E-015: 浠庝笅鎷夎彍鍗曢€夋嫨鎻掍欢"""
        page.goto(f"{base_url}/#/upload")
        
        # 閫夋嫨鎻掍欢
        plugin_selector = page.locator('select#plugin')
        plugin_selector.select_option('excel_vba_to_wps_js')
        
        # 楠岃瘉閫夋嫨鎴愬姛
        selected = plugin_selector.input_value()
        assert selected == 'excel_vba_to_wps_js'
    
    def test_click_create_task_button(self, page: Page, base_url: str):
        """E2E-016: 鐐瑰嚮鍒涘缓浠诲姟鎸夐挳"""
        page.goto(f"{base_url}/#/upload")
        
        # 鐐瑰嚮鍒涘缓浠诲姟鎸夐挳锛堝簲璇ユ彁绀哄厛涓婁紶鏂囦欢锛?        create_btn = page.locator('button:has-text("鍒涘缓浠诲姟")')
        create_btn.click()
        
        # 楠岃瘉鏈夋彁绀轰俊鎭?        page.wait_for_timeout(1000)
        toast = page.locator('#toast-container .toast')
        expect(toast).to_be_visible()


class TestFileUploadFlow:
    """鏂囦欢涓婁紶娴佺▼楠岃瘉娴嬭瘯"""
    
    def test_upload_file_and_create_task_full_flow(self, page: Page, base_url: str):
        """E2E-017: 涓婁紶鏂囦欢骞跺垱寤轰换鍔″畬鏁存祦绋?""
        # 1. 璁块棶涓婁紶椤甸潰
        page.goto(f"{base_url}/#/upload")
        
        # 2. 鍑嗗娴嬭瘯鏂囦欢锛堝垱寤轰复鏃舵枃浠讹級
        test_content = b'PK\x03\x04' + b'\x00' * 100  # 妯℃嫙 Excel 鏂囦欢
        test_file = 'test_upload.xlsm'
        
        # 3. 涓婁紶鏂囦欢
        file_input = page.locator('input[type="file"]')
        file_input.set_input_files(test_content)
        
        # 4. 閫夋嫨鎻掍欢
        plugin_selector = page.locator('select#plugin')
        plugin_selector.select_option('excel_vba_to_wps_js')
        
        # 5. 鐐瑰嚮鍒涘缓浠诲姟
        create_btn = page.locator('button:has-text("鍒涘缓浠诲姟")')
        create_btn.click()
        
        # 6. 楠岃瘉鍒涘缓鎴愬姛
        page.wait_for_timeout(2000)
        success_message = page.locator('.toast-success, .toast:has-text("鎴愬姛")')
        expect(success_message).to_be_visible(timeout=5000)
    
    def test_upload_empty_file_should_fail(self, page: Page, base_url: str):
        """E2E-018: 涓婁紶绌烘枃浠跺簲璇ュけ璐?""
        page.goto(f"{base_url}/#/upload")
        
        # 涓婁紶绌烘枃浠?        file_input = page.locator('input[type="file"]')
        file_input.set_input_files(b'')
        
        # 楠岃瘉閿欒鎻愮ず
        page.wait_for_timeout(2000)
        error_message = page.locator('.toast-error, .toast:has-text("澶辫触")')
        expect(error_message).to_be_visible()
    
    def test_upload_without_selecting_plugin_should_fail(self, page: Page, base_url: str):
        """E2E-019: 鏈€夋嫨鎻掍欢涓婁紶搴旇澶辫触"""
        page.goto(f"{base_url}/#/upload")
        
        # 涓婁紶鏂囦欢浣嗕笉閫夋嫨鎻掍欢
        file_input = page.locator('input[type="file"]')
        file_input.set_input_files(b'PK\x03\x04' + b'\x00' * 100)
        
        # 楠岃瘉閿欒鎻愮ず
        page.wait_for_timeout(2000)


class TestFileUploadDataValidation:
    """鏂囦欢涓婁紶鏁版嵁楠岃瘉娴嬭瘯"""
    
    def test_upload_response_contains_upload_id(self, page: Page, base_url: str):
        """E2E-020: 涓婁紶鍝嶅簲鍖呭惈 uploadId"""
        # 閫氳繃 API 鐩存帴娴嬭瘯
        response = page.request.post(
            f"{base_url}/api/uploads",
            multipart={
                'file': {
                    'name': 'test.xlsm',
                    'mimeType': 'application/vnd.ms-excel.sheet.macroEnabled.12',
                    'buffer': b'PK\x03\x04' + b'\x00' * 100
                },
                'pluginCode': 'excel_vba_to_wps_js'
            }
        )
        
        data = response.json()
        assert data['code'] == 'OK'
        assert 'uploadId' in data['data']
    
    def test_upload_response_contains_file_name(self, page: Page, base_url: str):
        """E2E-021: 涓婁紶鍝嶅簲鍖呭惈鏂囦欢鍚?""
        response = page.request.post(
            f"{base_url}/api/uploads",
            multipart={
                'file': {
                    'name': 'test.xlsm',
                    'mimeType': 'application/vnd.ms-excel.sheet.macroEnabled.12',
                    'buffer': b'PK\x03\x04' + b'\x00' * 100
                },
                'pluginCode': 'excel_vba_to_wps_js'
            }
        )
        
        data = response.json()
        assert 'fileName' in data['data']
        assert data['data']['fileName'] == 'test.xlsm'
    
    def test_upload_response_status_is_uploaded(self, page: Page, base_url: str):
        """E2E-022: 涓婁紶鍝嶅簲鐘舵€佷负 UPLOADED"""
        response = page.request.post(
            f"{base_url}/api/uploads",
            multipart={
                'file': {
                    'name': 'test.xlsm',
                    'mimeType': 'application/vnd.ms-excel.sheet.macroEnabled.12',
                    'buffer': b'PK\x03\x04' + b'\x00' * 100
                },
                'pluginCode': 'excel_vba_to_wps_js'
            }
        )
        
        data = response.json()
        assert data['data']['status'] == 'UPLOADED'
    
    def test_uploaded_file_appears_in_list(self, page: Page, base_url: str):
        """E2E-023: 涓婁紶鐨勬枃浠跺嚭鐜板湪鍒楄〃涓?""
        # 1. 涓婁紶鏂囦欢
        response = page.request.post(
            f"{base_url}/api/uploads",
            multipart={
                'file': {
                    'name': 'test_list.xlsm',
                    'mimeType': 'application/vnd.ms-excel.sheet.macroEnabled.12',
                    'buffer': b'PK\x03\x04' + b'\x00' * 100
                },
                'pluginCode': 'excel_vba_to_wps_js'
            }
        )
        
        # 2. 鑾峰彇涓婁紶鍒楄〃
        list_response = page.request.get(f"{base_url}/api/uploads")
        uploads = list_response.json()['data']
        
        # 3. 楠岃瘉鏂囦欢鍦ㄥ垪琛ㄤ腑
        assert len(uploads) > 0
        assert any(u['original_name'] == 'test_list.xlsm' for u in uploads)
