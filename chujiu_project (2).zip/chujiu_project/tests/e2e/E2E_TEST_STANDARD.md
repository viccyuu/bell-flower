# E2E 测试执行标准

**版本**: v2.0  
**生效日期**: 2026-03-14  
**适用范围**: 所有 E2E 测试用例

---

## 📋 测试层次定义

### L1: 页面加载测试 ✅

**目标**: 验证页面能正常加载

**测试要点**:
- ✅ 页面 HTTP 200 响应
- ✅ 页面标题正确
- ✅ 核心容器可见
- ✅ 无 JS 错误

**示例**:
```python
def test_page_loads(self, page: Page, base_url: str):
    """E2E-L1-001: 页面加载测试"""
    # Act
    page.goto(f"{base_url}/#/upload")
    page.wait_for_load_state('load')
    
    # Assert
    expect(page).to_have_title("Chujiu Design TodoList")
    
    content_area = page.locator('#content-area')
    expect(content_area).to_be_visible()
    
    # 验证无 JS 错误
    page.on('console', lambda msg: print(f"Console: {msg.type} {msg.text}"))
    page.on('pageerror', lambda err: pytest.fail(f"JS Error: {err}"))
```

**通过标准**:
- 页面加载时间 < 3 秒
- 无 404/500 错误
- 无 JS 语法错误
- 核心容器可见

---

### L2: 元素存在测试 ✅

**目标**: 验证页面元素存在且可见

**测试要点**:
- ✅ 关键按钮存在
- ✅ 表单字段存在
- ✅ 表格/列表容器存在
- ✅ 图标/图片存在

**示例**:
```python
def test_elements_exist(self, page: Page, base_url: str):
    """E2E-L2-001: 元素存在测试"""
    # Arrange
    page.goto(f"{base_url}/#/upload")
    page.wait_for_timeout(3000)
    
    # Assert - 验证关键元素存在
    # 1. 上传区域
    upload_area = page.locator('.upload-area, #upload-area')
    expect(upload_area).to_be_visible()
    
    # 2. 文件输入框
    file_input = page.locator('input[type="file"]')
    expect(file_input).to_be_attached()
    
    # 3. 插件选择器
    plugin_select = page.locator('select#plugin')
    expect(plugin_select).to_be_visible()
    
    # 4. 创建任务按钮
    create_btn = page.locator('button:has-text("创建任务")')
    expect(create_btn).to_be_visible()
    
    # 5. 结果区域
    result_area = page.locator('#upload-result')
    expect(result_area).to_be_attached()
```

**通过标准**:
- 所有关键元素可见
- 元素属性正确
- 元素文本正确
- 元素样式正确

---

### L3: 点击交互测试 ✅

**目标**: 验证用户交互正常工作

**测试要点**:
- ✅ 按钮点击响应
- ✅ 表单提交响应
- ✅ 下拉选择响应
- ✅ 弹窗显示/关闭

**示例**:
```python
def test_click_interaction(self, page: Page, base_url: str):
    """E2E-L3-001: 点击交互测试"""
    # Arrange
    page.goto(f"{base_url}/#/upload")
    page.wait_for_timeout(3000)
    
    # Act & Assert - 验证交互
    
    # 1. 点击上传区域
    upload_area = page.locator('.upload-area')
    upload_area.click()
    page.wait_for_timeout(1000)
    
    # 验证文件选择器激活
    file_input = page.locator('input[type="file"]')
    expect(file_input).to_be_focused()
    
    # 2. 选择插件
    plugin_select = page.locator('select#plugin')
    plugin_select.select_option('excel_vba_to_wps_js')
    page.wait_for_timeout(500)
    
    # 验证选择成功
    selected_value = plugin_select.input_value()
    assert selected_value == 'excel_vba_to_wps_js'
    
    # 3. 点击创建任务按钮
    create_btn = page.locator('button:has-text("创建任务")')
    create_btn.click()
    page.wait_for_timeout(2000)
    
    # 验证有提示信息
    toast = page.locator('.toast, .toast-message')
    expect(toast).to_be_visible()
```

**通过标准**:
- 点击事件触发
- 状态变化正确
- 反馈信息正确
- 无错误提示

---

### L4: 流程验证测试 ✅

**目标**: 验证完整业务流程正常

**测试要点**:
- ✅ 多步骤流程完整
- ✅ 步骤间状态传递
- ✅ 流程结果正确
- ✅ 异常流程处理

**示例**:
```python
def test_upload_and_create_task_flow(self, page: Page, base_url: str):
    """E2E-L4-001: 上传并创建任务流程"""
    # Step 1: 访问上传页面
    page.goto(f"{base_url}/#/upload")
    page.wait_for_load_state('load')
    page.wait_for_timeout(3000)
    
    # Step 2: 上传文件
    file_input = page.locator('input[type="file"]')
    test_content = b'PK\x03\x04' + b'\x00' * 100
    file_input.set_input_files({
        'name': 'test.xlsm',
        'mimeType': 'application/vnd.ms-excel.sheet.macroEnabled.12',
        'buffer': test_content
    })
    page.wait_for_timeout(2000)
    
    # 验证上传成功提示
    upload_success = page.locator('.toast-success, .toast:has-text("成功")')
    expect(upload_success).to_be_visible(timeout=5000)
    
    # Step 3: 选择插件
    plugin_select = page.locator('select#plugin')
    plugin_select.select_option('excel_vba_to_wps_js')
    page.wait_for_timeout(1000)
    
    # Step 4: 创建任务
    create_btn = page.locator('button:has-text("创建任务")')
    create_btn.click()
    page.wait_for_timeout(3000)
    
    # 验证任务创建成功
    create_success = page.locator('.toast-success, .toast:has-text("成功")')
    expect(create_success).to_be_visible(timeout=5000)
    
    # Step 5: 验证跳转到任务列表
    page.wait_for_url(f"{base_url}/#/tasks", timeout=5000)
    task_list = page.locator('.task-list, table')
    expect(task_list).to_be_visible()
```

**通过标准**:
- 所有步骤执行成功
- 步骤间状态正确传递
- 最终结果符合预期
- 流程时间合理

---

### L5: 数据验证测试 ✅

**目标**: 验证数据正确性和一致性

**测试要点**:
- ✅ API 返回数据正确
- ✅ 页面显示数据正确
- ✅ 数据存储正确
- ✅ 数据一致性验证

**示例**:
```python
def test_data_validation(self, page: Page, base_url: str):
    """E2E-L5-001: 数据验证测试"""
    import requests
    
    # Step 1: 验证 API 数据
    # 获取插件列表
    api_response = requests.get(f'{base_url}/api/plugins')
    assert api_response.status_code == 200
    
    api_data = api_response.json()
    assert api_data['code'] == 'OK'
    assert len(api_data['data']) >= 3
    
    # 验证 excel_vba_to_wps_js 插件存在
    plugin = next(
        (p for p in api_data['data'] if p['code'] == 'excel_vba_to_wps_js'),
        None
    )
    assert plugin is not None
    assert 'dag' in plugin
    assert len(plugin['dag']['nodes']) >= 3
    
    # Step 2: 验证页面显示数据
    page.goto(f"{base_url}/#/plugins")
    page.wait_for_timeout(3000)
    
    # 验证插件列表显示
    plugin_items = page.locator('.plugin-item')
    expect(plugin_items).to_have_count(greater_than_or_equal(3))
    
    # 验证插件名称显示
    first_plugin_name = page.locator('.plugin-item:first-child .plugin-name')
    expect(first_plugin_name).to_be_visible()
    
    # Step 3: 验证数据一致性
    # 页面显示的插件数应该与 API 返回的一致
    plugin_count_api = len(api_data['data'])
    plugin_count_page = plugin_items.count()
    assert plugin_count_page >= plugin_count_api
```

**通过标准**:
- API 数据格式正确
- 页面显示与 API 一致
- 数据存储可验证
- 数据一致性通过

---

## 📊 测试覆盖要求

### 覆盖率矩阵

| 页面/功能 | L1 加载 | L2 元素 | L3 交互 | L4 流程 | L5 数据 | 总计 |
|---------|--------|--------|--------|--------|--------|------|
| 概览/仪表盘 | ✅ | ✅ | ✅ | ✅ | ✅ | 5 |
| 文件上传 | ✅ | ✅ | ✅ | ✅ | ✅ | 5 |
| 任务列表 | ✅ | ✅ | ✅ | ✅ | ✅ | 5 |
| 任务详情 | ✅ | ✅ | ✅ | ✅ | ✅ | 5 |
| 提示词库 | ✅ | ✅ | ✅ | ✅ | ✅ | 5 |
| 插件管理 | ✅ | ✅ | ✅ | ✅ | ✅ | 5 |
| 产物下载 | ✅ | ✅ | ✅ | ✅ | ✅ | 5 |
| **总计** | **7** | **7** | **7** | **7** | **7** | **35** |

### 最低覆盖要求

| 测试层次 | 最低用例数 | 优先级 |
|---------|-----------|--------|
| L1: 页面加载 | 7 (100% 页面) | P0 |
| L2: 元素存在 | 7 (100% 页面) | P0 |
| L3: 点击交互 | 5 (核心功能) | P1 |
| L4: 流程验证 | 3 (核心流程) | P1 |
| L5: 数据验证 | 3 (核心数据) | P2 |

---

## 📝 测试编写规范

### 命名规范

```python
# 格式：test_[层次]_[页面]_[测试点]
def test_l1_upload_page_loads(self):
    """L1: 上传页面加载测试"""
    pass

def test_l2_upload_elements_exist(self):
    """L2: 上传页面元素存在测试"""
    pass

def test_l3_upload_click_interaction(self):
    """L3: 上传页面点击交互测试"""
    pass

def test_l4_upload_create_task_flow(self):
    """L4: 上传创建任务流程测试"""
    pass

def test_l5_upload_data_validation(self):
    """L5: 上传数据验证测试"""
    pass
```

### 断言规范

```python
# ✅ 推荐：具体明确的断言
expect(element).to_be_visible()
expect(element).to_have_text("预期文本")
expect(element).to_have_count(5)
assert response.status_code == 200
assert data['code'] == 'OK'

# ❌ 避免：模糊的断言
assert element
assert response
assert data
```

### 等待规范

```python
# ✅ 推荐：智能等待
page.wait_for_load_state('load')
page.wait_for_selector('.element', state='visible', timeout=5000)
expect(element).to_be_visible(timeout=5000)

# ⚠️ 谨慎使用：固定等待
page.wait_for_timeout(3000)  # 仅在必要时使用

# ❌ 避免：无等待
page.goto(url)
element.click()  # 可能元素还未加载
```

---

## 🔧 测试执行

### 运行命令

```bash
# 运行所有 E2E 测试
pytest tests/e2e/ -v

# 运行特定层次测试
pytest tests/e2e/ -k "l1" -v  # L1 测试
pytest tests/e2e/ -k "l2" -v  # L2 测试
pytest tests/e2e/ -k "l3" -v  # L3 测试
pytest tests/e2e/ -k "l4" -v  # L4 测试
pytest tests/e2e/ -k "l5" -v  # L5 测试

# 运行特定页面测试
pytest tests/e2e/test_upload.py -v
pytest tests/e2e/test_tasks.py -v
pytest tests/e2e/test_plugins.py -v
```

### 报告生成

```bash
# HTML 报告
pytest tests/e2e/ --html=tests/e2e/report.html --self-contained-html

# XML 报告 (CI/CD)
pytest tests/e2e/ --junitxml=tests/e2e/report.xml

# 覆盖率报告
pytest tests/e2e/ --cov=app --cov-report=html
```

---

## ✅ 验收标准

### L1: 页面加载

- [ ] 所有页面 HTTP 200 响应
- [ ] 页面标题正确
- [ ] 核心容器可见
- [ ] 无 JS 错误
- [ ] 加载时间 < 3 秒

### L2: 元素存在

- [ ] 所有关键按钮可见
- [ ] 所有表单字段可见
- [ ] 所有表格/列表可见
- [ ] 元素属性正确
- [ ] 元素文本正确

### L3: 点击交互

- [ ] 所有按钮可点击
- [ ] 所有表单可提交
- [ ] 所有下拉可选择
- [ ] 弹窗显示/关闭正常
- [ ] 反馈信息正确

### L4: 流程验证

- [ ] 核心流程完整
- [ ] 步骤间状态传递正确
- [ ] 流程结果符合预期
- [ ] 异常流程有处理
- [ ] 流程时间合理

### L5: 数据验证

- [ ] API 返回数据正确
- [ ] 页面显示数据正确
- [ ] 数据存储可验证
- [ ] 数据一致性通过
- [ ] 数据格式正确

---

**文档生成时间**: 2026-03-14 12:06  
**版本**: v2.0  
**状态**: ✅ **生效中**
