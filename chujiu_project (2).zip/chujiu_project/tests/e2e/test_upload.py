# -*- coding: utf-8 -*-
"""
E2E 娴嬭瘯 - 鏂囦欢涓婁紶鍔熻兘

楠岃瘉鏂囦欢涓婁紶娴佺▼銆?"""
import pytest
from playwright.sync_api import Page, expect
import os


class TestFileUpload:
    """鏂囦欢涓婁紶 E2E 娴嬭瘯"""
    
    def test_upload_page_loads(self, page: Page, base_url: str):
        """E2E-010: 涓婁紶椤甸潰鍔犺浇"""
        page.goto(f"{base_url}/#/upload")
        
        # 楠岃瘉涓婁紶鍖哄煙瀛樺湪
        upload_area = page.locator('.upload-area, input[type="file"]')
        expect(upload_area).to_be_visible()
    
    def test_upload_button_click(self, page: Page, base_url: str):
        """E2E-011: 鐐瑰嚮涓婁紶鎸夐挳"""
        page.goto(base_url)
        
        # 鐐瑰嚮涓婁紶鎸夐挳
        upload_btn = page.locator('#upload-btn, button:has-text("涓婁紶")')
        upload_btn.click()
        
        # 楠岃瘉鏂囦欢閫夋嫨鍣ㄥ嚭鐜?        file_input = page.locator('input[type="file"]')
        expect(file_input).to_be_visible()
    
    def test_plugin_selector_exists(self, page: Page, base_url: str):
        """E2E-012: 鎻掍欢閫夋嫨鍣ㄥ瓨鍦?""
        page.goto(f"{base_url}/#/upload")
        
        # 楠岃瘉鎻掍欢閫夋嫨鍣ㄥ瓨鍦?        plugin_selector = page.locator('select#plugin, .plugin-selector')
        expect(plugin_selector).to_be_visible()
    
    def test_create_task_button_exists(self, page: Page, base_url: str):
        """E2E-013: 鍒涘缓浠诲姟鎸夐挳瀛樺湪"""
        page.goto(f"{base_url}/#/upload")
        
        # 楠岃瘉鍒涘缓浠诲姟鎸夐挳瀛樺湪
        create_btn = page.locator('#create-task-btn, button:has-text("鍒涘缓浠诲姟")')
        expect(create_btn).to_be_visible()
