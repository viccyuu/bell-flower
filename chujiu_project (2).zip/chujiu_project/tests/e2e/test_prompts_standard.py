# -*- coding: utf-8 -*-
"""
E2E Test - Prompt Library Page
"""
import pytest
from playwright.sync_api import Page, expect


class TestPromptLibraryPage:
    """Prompt Library Page E2E Tests"""
    
    def test_l1_prompts_page_loads(self, page: Page, base_url: str):
        """E2E-L1-001: Prompt library page loads"""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_load_state('load')
        expect(page).to_have_title("Chujiu Design TodoList")
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
    
    def test_l1_prompts_has_card(self, page: Page, base_url: str):
        """E2E-L1-002: Prompt library has card"""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_load_state('load')
        card = page.locator('.card')
        expect(card).to_be_visible()
    
    def test_l2_prompts_elements_exist(self, page: Page, base_url: str):
        """E2E-L2-001: Prompt library elements exist"""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(3000)
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
    
    def test_l2_prompts_has_title(self, page: Page, base_url: str):
        """E2E-L2-002: Prompt library has title"""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(3000)
        card_title = page.locator('.card-title')
        expect(card_title).to_be_visible()
    
    def test_l3_prompts_click_interaction(self, page: Page, base_url: str):
        """E2E-L3-001: Prompt library click interaction"""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(3000)
        categories = page.locator('.category-item, .category-tab')
        if categories.count() > 0:
            categories.first.click()
            page.wait_for_timeout(1000)
    
    def test_l3_prompts_add_button(self, page: Page, base_url: str):
        """E2E-L3-002: Prompt library add button"""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(3000)
        add_btn = page.locator('button:has-text("新增"), button:has-text("添加")')
        if add_btn.count() > 0:
            expect(add_btn.first).to_be_enabled()
    
    def test_l4_prompts_view_flow(self, page: Page, base_url: str):
        """E2E-L4-001: Prompt library view flow"""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(3000)
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
        card_body = page.locator('.card-body')
        expect(card_body).to_be_visible()
    
    def test_l4_prompts_refresh_flow(self, page: Page, base_url: str):
        """E2E-L4-002: Prompt library refresh flow"""
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(3000)
        page.reload()
        page.wait_for_timeout(3000)
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
    
    def test_l5_prompts_api_data_validation(self, page: Page, base_url: str):
        """E2E-L5-001: Prompt library API data validation"""
        import requests
        categories_response = requests.get(f'{base_url}/api/prompt-categories')
        assert categories_response.status_code == 200
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(3000)
        categories = page.locator('.category-item, .category-tab')
        count = categories.count()
        if count > 0:
            assert count >= 1
    
    def test_l5_prompts_data_consistency(self, page: Page, base_url: str):
        """E2E-L5-002: Prompt library data consistency"""
        import requests
        prompts_response = requests.get(f'{base_url}/api/prompts')
        api_prompts = prompts_response.json()['data']
        page.goto(f"{base_url}/#/templates")
        page.wait_for_timeout(3000)
        prompt_rows = page.locator('tbody tr, .prompt-item')
        if len(api_prompts) > 0:
            count = prompt_rows.count()
            assert count >= 0
