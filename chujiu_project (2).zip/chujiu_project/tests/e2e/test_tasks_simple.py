# -*- coding: utf-8 -*-
"""
E2E 娴嬭瘯 - 浠诲姟绠＄悊锛堝疄鐢ㄧ増锛?"""
import pytest
from playwright.sync_api import Page, expect


class TestTaskManagementSimple:
    """浠诲姟绠＄悊绠€鍖栨祴璇?""
    
    def test_tasks_page_loads(self, page: Page, base_url: str):
        """E2E-T01: 浠诲姟椤甸潰鍔犺浇"""
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        
        # 楠岃瘉鏈夊崱鐗?        card = page.locator('.card')
        expect(card).to_be_visible()
    
    def test_tasks_has_title(self, page: Page, base_url: str):
        """E2E-T02: 浠诲姟椤甸潰鏈夋爣棰?""
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        
        # 楠岃瘉鏈夋爣棰?        title = page.locator('.card-title, h3, div:has-text("浠诲姟")')
        expect(title).to_be_visible()
    
    def test_tasks_has_table(self, page: Page, base_url: str):
        """E2E-T03: 浠诲姟椤甸潰鏈夎〃鏍?""
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        
        # 楠岃瘉鏈夎〃鏍兼垨鍒楄〃
        table_or_list = page.locator('table, .data-table, .card')
        expect(table_or_list).to_be_visible()
