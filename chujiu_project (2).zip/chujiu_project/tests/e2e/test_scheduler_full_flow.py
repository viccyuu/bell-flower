# -*- coding: utf-8 -*-
"""
Scheduler Full Flow E2E 测试 ⭐

测试完整的调度流程。
"""
import pytest
from app.scheduler import (
    DagScheduler,
    ExecutorRegistry,
    PythonExecutor,
    InputResolver,
    OutputValidator
)


class TestSchedulerFullFlow:
    """Scheduler 完整流程 E2E 测试"""
    
    @pytest.fixture
    def registry(self):
        """创建执行器注册表"""
        ExecutorRegistry._instance = None
        ExecutorRegistry._executors = {}
        return ExecutorRegistry()
    
    @pytest.fixture
    def scheduler(self, registry):
        """创建调度器"""
        registry.register('python_executor', PythonExecutor())
        return DagScheduler(executor_registry=registry)
    
    def test_full_vba_to_js_flow(self, scheduler):
        """测试完整的 VBA 转 JS 流程"""
        dag = {
            'job': {
                'code': 'vba_to_js',
                'name': 'VBA to JS',
                'version': 1
            },
            'defaults': {
                'timeout_seconds': 180
            },
            'nodes': [
                {
                    'code': 'extract',
                    'name': 'Extract VBA',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {
                        'callable': 'tests.e2e.test_scheduler_full_flow.mock_extract'
                    },
                    'input_mapping': {
                        'file_path': '{{ task.vars.file_path }}'
                    }
                },
                {
                    'code': 'convert',
                    'name': 'Convert to JS',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {
                        'callable': 'tests.e2e.test_scheduler_full_flow.mock_convert'
                    },
                    'input_mapping': {
                        'vba_code': '{{ node.extract.output.vba_code }}'
                    }
                },
                {
                    'code': 'save',
                    'name': 'Save JS',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {
                        'callable': 'tests.e2e.test_scheduler_full_flow.mock_save'
                    },
                    'input_mapping': {
                        'js_code': '{{ node.convert.output.js_code }}'
                    }
                }
            ],
            'edges': [
                {'from': 'extract', 'to': 'convert'},
                {'from': 'convert', 'to': 'save'}
            ]
        }
        
        runtime_context = {
            'task': {
                'id': 1001,
                'vars': {
                    'file_path': '/path/to/file.xlsm'
                }
            },
            'job': {
                'id': 2001,
                'vars': {}
            },
            'node': {}
        }
        
        result = scheduler.run(dag, runtime_context)
        
        # 验证结果
        assert result['state']['job_status'] == 'SUCCESS'
        assert result['state']['nodes']['extract']['status'] == 'SUCCESS'
        assert result['state']['nodes']['convert']['status'] == 'SUCCESS'
        assert result['state']['nodes']['save']['status'] == 'SUCCESS'
        
        # 验证输出
        assert 'vba_code' in result['context']['node']['extract']['output']
        assert 'js_code' in result['context']['node']['convert']['output']
    
    def test_full_recovery_flow(self, scheduler):
        """测试完整的恢复流程"""
        dag = {
            'job': {
                'code': 'recovery_test',
                'name': 'Recovery Test',
                'version': 1
            },
            'nodes': [
                {
                    'code': 'step1',
                    'name': 'Step 1',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {
                        'callable': 'tests.e2e.test_scheduler_full_flow.mock_success'
                    }
                },
                {
                    'code': 'step2',
                    'name': 'Step 2',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {
                        'callable': 'tests.e2e.test_scheduler_full_flow.mock_success'
                    }
                }
            ],
            'edges': [
                {'from': 'step1', 'to': 'step2'}
            ]
        }
        
        runtime_context = {
            'task': {'id': 1001, 'vars': {}},
            'job': {'id': 2001, 'vars': {}},
            'node': {
                'step1': {'status': 'SUCCESS', 'output': {'result': 'success'}},
                'step2': {'status': 'RUNNING', 'output': None}
            }
        }
        
        # 恢复执行
        result = scheduler.run(dag, runtime_context, resume=True)
        
        # 验证结果
        assert result['state']['job_status'] == 'SUCCESS'
        assert result['state']['nodes']['step1']['status'] == 'SUCCESS'
        assert result['state']['nodes']['step2']['status'] == 'SUCCESS'


# Mock 函数

def mock_extract(file_path):
    """模拟提取函数"""
    return {'vba_code': 'Sub Test()\nEnd Sub'}


def mock_convert(vba_code):
    """模拟转换函数"""
    return {'js_code': 'function test() {}'}


def mock_save(js_code):
    """模拟保存函数"""
    return {'file_path': '/path/to/file.js'}


def mock_success(**kwargs):
    """模拟成功函数"""
    return {'result': 'success'}
