# -*- coding: utf-8 -*-
"""
E2E 娴嬭瘯 - 鎻掍欢绠＄悊锛堝疄鐢ㄧ増锛?"""
import pytest
from playwright.sync_api import Page, expect


class TestPluginManagementSimple:
    """鎻掍欢绠＄悊绠€鍖栨祴璇?""
    
    def test_plugins_page_loads(self, page: Page, base_url: str):
        """E2E-P01: 鎻掍欢椤甸潰鍔犺浇"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(3000)
        
        # 楠岃瘉鏈夊崱鐗?        card = page.locator('.card')
        expect(card).to_be_visible()
    
    def test_plugins_has_items(self, page: Page, base_url: str):
        """E2E-P02: 鎻掍欢椤甸潰鏈夋彃浠堕」"""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(3000)
        
        # 楠岃瘉鏈夋彃浠剁浉鍏冲厓绱?        plugin_item = page.locator('.card:has-text("Excel"), .card:has-text("鎻掍欢")')
        expect(plugin_item).to_be_visible()
    
    def test_plugins_has_buttons(self, page: Page, base_url: str):
        """E2E-P03: 鎻掍欢椤甸潰鏈夋寜閽?""
        page.goto(f"{base_url}/#/plugins")
        page.wait_for_timeout(3000)
        
        # 楠岃瘉鏈夋寜閽?        button = page.locator('button')
        expect(button).to_be_visible()
