# -*- coding: utf-8 -*-
"""
E2E Test - Artifacts Page
"""
import pytest
from playwright.sync_api import Page, expect


class TestArtifactsPage:
    """Artifacts Page E2E Tests"""
    
    def test_l1_artifacts_page_loads(self, page: Page, base_url: str):
        """E2E-L1-001: Artifacts page loads"""
        page.goto(f"{base_url}/#/artifacts")
        page.wait_for_load_state('load')
        expect(page).to_have_title("Chujiu Design TodoList")
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
    
    def test_l1_artifacts_has_card(self, page: Page, base_url: str):
        """E2E-L1-002: Artifacts has card"""
        page.goto(f"{base_url}/#/artifacts")
        page.wait_for_load_state('load')
        card = page.locator('.card')
        expect(card).to_be_visible()
    
    def test_l2_artifacts_elements_exist(self, page: Page, base_url: str):
        """E2E-L2-001: Artifacts elements exist"""
        page.goto(f"{base_url}/#/artifacts")
        page.wait_for_timeout(3000)
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
        card_body = page.locator('.card-body')
        expect(card_body).to_be_visible()
    
    def test_l2_artifacts_has_title(self, page: Page, base_url: str):
        """E2E-L2-002: Artifacts has title"""
        page.goto(f"{base_url}/#/artifacts")
        page.wait_for_timeout(3000)
        card_title = page.locator('.card-title')
        expect(card_title).to_be_visible()
    
    def test_l3_artifacts_click_interaction(self, page: Page, base_url: str):
        """E2E-L3-001: Artifacts click interaction"""
        page.goto(f"{base_url}/#/artifacts")
        page.wait_for_timeout(3000)
        download_btns = page.locator('button:has-text("下载")')
        if download_btns.count() > 0:
            expect(download_btns.first).to_be_enabled()
    
    def test_l3_artifacts_download_button(self, page: Page, base_url: str):
        """E2E-L3-002: Artifacts download button"""
        page.goto(f"{base_url}/#/artifacts")
        page.wait_for_timeout(3000)
        download_btns = page.locator('button:has-text("下载")')
        if download_btns.count() > 0:
            expect(download_btns.first).to_be_visible()
            expect(download_btns.first).to_be_enabled()
    
    def test_l4_artifacts_view_flow(self, page: Page, base_url: str):
        """E2E-L4-001: Artifacts view flow"""
        page.goto(f"{base_url}/#/artifacts")
        page.wait_for_timeout(3000)
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
        card_body = page.locator('.card-body')
        expect(card_body).to_be_visible()
    
    def test_l4_artifacts_refresh_flow(self, page: Page, base_url: str):
        """E2E-L4-002: Artifacts refresh flow"""
        page.goto(f"{base_url}/#/artifacts")
        page.wait_for_timeout(3000)
        page.reload()
        page.wait_for_timeout(3000)
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
    
    def test_l5_artifacts_api_data_validation(self, page: Page, base_url: str):
        """E2E-L5-001: Artifacts API data validation"""
        import requests
        api_response = requests.get(f'{base_url}/api/artifacts')
        assert api_response.status_code == 200
        page.goto(f"{base_url}/#/artifacts")
        page.wait_for_timeout(3000)
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
    
    def test_l5_artifacts_data_consistency(self, page: Page, base_url: str):
        """E2E-L5-002: Artifacts data consistency"""
        import requests
        api_response = requests.get(f'{base_url}/api/artifacts')
        api_artifacts = api_response.json()['data']
        page.goto(f"{base_url}/#/artifacts")
        page.wait_for_timeout(3000)
        artifact_items = page.locator('.artifact-item')
        if len(api_artifacts) > 0:
            count = artifact_items.count()
            assert count >= 0
