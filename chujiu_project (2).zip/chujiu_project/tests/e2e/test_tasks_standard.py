# -*- coding: utf-8 -*-
"""
E2E Test - Task List Page
"""
import pytest
from playwright.sync_api import Page, expect


class TestTaskListPage:
    """Task List Page E2E Tests"""
    
    def test_l1_task_list_page_loads(self, page: Page, base_url: str):
        """E2E-L1-001: Task list page loads"""
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_load_state('load')
        expect(page).to_have_title("Chujiu Design TodoList")
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
    
    def test_l1_task_list_has_card(self, page: Page, base_url: str):
        """E2E-L1-002: Task list has card"""
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_load_state('load')
        card = page.locator('.card')
        expect(card).to_be_visible()
    
    def test_l2_task_list_elements_exist(self, page: Page, base_url: str):
        """E2E-L2-001: Task list elements exist"""
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
        card_body = page.locator('.card-body')
        expect(card_body).to_be_visible()
    
    def test_l2_task_list_has_title(self, page: Page, base_url: str):
        """E2E-L2-002: Task list has title"""
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        card_title = page.locator('.card-title')
        expect(card_title).to_be_visible()
    
    def test_l3_task_list_click_interaction(self, page: Page, base_url: str):
        """E2E-L3-001: Task list click interaction"""
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        detail_buttons = page.locator('button:has-text("详情")')
        if detail_buttons.count() > 0:
            detail_buttons.first.click()
            page.wait_for_timeout(2000)
            modal = page.locator('.modal-overlay')
            expect(modal).to_be_visible()
            close_btn = modal.locator('button:has-text("✕")')
            close_btn.click()
            page.wait_for_timeout(1000)
            expect(modal).not_to_be_visible()
    
    def test_l3_task_list_start_button(self, page: Page, base_url: str):
        """E2E-L3-002: Task list start button"""
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        start_buttons = page.locator('button:has-text("启动")')
        if start_buttons.count() > 0:
            expect(start_buttons.first).to_be_enabled()
    
    def test_l4_task_list_view_detail_flow(self, page: Page, base_url: str):
        """E2E-L4-001: Task list view detail flow"""
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        detail_buttons = page.locator('button:has-text("详情")')
        if detail_buttons.count() > 0:
            detail_buttons.first.click()
            page.wait_for_timeout(2000)
            modal = page.locator('.modal-overlay')
            expect(modal).to_be_visible()
            close_btn = modal.locator('button:has-text("✕")')
            close_btn.click()
            page.wait_for_timeout(1000)
            expect(modal).not_to_be_visible()
    
    def test_l4_task_list_refresh_flow(self, page: Page, base_url: str):
        """E2E-L4-002: Task list refresh flow"""
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        page.reload()
        page.wait_for_timeout(3000)
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
    
    def test_l5_task_list_api_data_validation(self, page: Page, base_url: str):
        """E2E-L5-001: Task list API data validation"""
        import requests
        api_response = requests.get(f'{base_url}/api/task-runs?limit=10')
        assert api_response.status_code == 200
        api_data = api_response.json()
        assert api_data['code'] == 'OK'
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        content_area = page.locator('#content-area')
        expect(content_area).to_be_visible()
    
    def test_l5_task_list_data_consistency(self, page: Page, base_url: str):
        """E2E-L5-002: Task list data consistency"""
        import requests
        api_response = requests.get(f'{base_url}/api/task-runs?limit=10')
        api_tasks = api_response.json()['data']
        page.goto(f"{base_url}/#/tasks")
        page.wait_for_timeout(3000)
        task_items = page.locator('tbody tr, .task-item')
        if len(api_tasks) > 0:
            count = task_items.count()
            assert count >= 0
