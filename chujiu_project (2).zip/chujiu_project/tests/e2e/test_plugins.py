# -*- coding: utf-8 -*-
"""
E2E 娴嬭瘯 - 鎻掍欢绠＄悊鍔熻兘

楠岃瘉鎻掍欢鍒楄〃鍜岄厤缃姛鑳姐€?"""
import pytest
from playwright.sync_api import Page, expect


class TestPluginManagement:
    """鎻掍欢绠＄悊 E2E 娴嬭瘯"""
    
    def test_plugin_list_page_loads(self, page: Page, base_url: str):
        """E2E-030: 鎻掍欢鍒楄〃椤甸潰鍔犺浇"""
        page.goto(f"{base_url}/#/plugins")
        
        # 楠岃瘉鎻掍欢鍒楄〃瀛樺湪
        plugin_list = page.locator('.plugin-list, #plugin-list')
        expect(plugin_list).to_be_visible()
    
    def test_plugin_items_exist(self, page: Page, base_url: str):
        """E2E-031: 鎻掍欢椤圭洰瀛樺湪"""
        page.goto(f"{base_url}/#/plugins")
        
        # 楠岃瘉鑷冲皯鏈変竴涓彃浠?        plugin_items = page.locator('.plugin-item')
        # 棰勬湡鑷冲皯鏈?3 涓彃浠讹紙excel_vba_to_wps_js, web_briefing, wps_js_to_excel_vba锛?        assert plugin_items.count() >= 1
    
    def test_plugin_toggle_switch_exists(self, page: Page, base_url: str):
        """E2E-032: 鎻掍欢寮€鍏冲瓨鍦?""
        page.goto(f"{base_url}/#/plugins")
        
        # 楠岃瘉鎻掍欢寮€鍏冲瓨鍦?        toggle_switch = page.locator('.toggle-switch, input[type="checkbox"].plugin-toggle')
        # 鍙兘鏈夊涓紑鍏?        assert toggle_switch.count() >= 1
    
    def test_plugin_dag_button_exists(self, page: Page, base_url: str):
        """E2E-033: 鏌ョ湅 DAG 鎸夐挳瀛樺湪"""
        page.goto(f"{base_url}/#/plugins")
        
        # 楠岃瘉 DAG 鎸夐挳瀛樺湪
        dag_btn = page.locator('button:has-text("DAG"), .dag-btn')
        # 鍙兘鏈夊涓寜閽?        assert dag_btn.count() >= 1
