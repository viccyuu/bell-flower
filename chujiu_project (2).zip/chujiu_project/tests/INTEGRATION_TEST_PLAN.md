# Chujiu Project Integration Test Plan

**Version**: 1.0  
**Date**: 2026-03-13  
**Status**: Ready for Execution

---

## 1. Overview

### 1.1 Purpose
This document defines the integration test strategy for Chujiu TodoList Platform, ensuring all modules work together correctly.

### 1.2 Scope
- API endpoint integration tests
- Plugin-Engine integration tests
- DAG scheduler integration tests
- End-to-end workflow tests
- Database integration tests

### 1.3 Test Environment
- **Base URL**: http://127.0.0.1:5001
- **Database**: SQLite (instance/app.db)
- **Test Framework**: pytest
- **Coverage Target**: ≥80% for core modules

---

## 2. Test Categories

### 2.1 API Integration Tests
**File**: `tests/integration/test_api_integration.py`

| Test ID | Endpoint | Method | Description | Priority |
|---------|----------|--------|-------------|----------|
| API-001 | `/health` | GET | Health check endpoint | P0 |
| API-002 | `/api/task-templates` | GET | List task templates | P0 |
| API-003 | `/api/uploads` | POST | File upload | P0 |
| API-004 | `/api/task-runs` | POST | Create task run | P0 |
| API-005 | `/api/task-runs/{id}/start` | POST | Start task | P0 |
| API-006 | `/api/task-runs/{id}` | GET | Get task details | P0 |
| API-007 | `/api/prompts` | GET | List prompts | P1 |
| API-008 | `/api/plugins` | GET | List plugins | P1 |

### 2.2 Plugin-Engine Integration Tests
**File**: `tests/integration/test_plugin_engine_integration.py`

| Test ID | Description | Priority |
|---------|-------------|----------|
| PE-001 | Plugin DAG registration | P0 |
| PE-002 | Node handler registration | P0 |
| PE-003 | Learning rule injection | P1 |
| PE-004 | SubJob management | P1 |

### 2.3 DAG Scheduler Tests
**File**: `tests/integration/test_dag_scheduler.py`

| Test ID | Description | Priority |
|---------|-------------|----------|
| DAG-001 | Topological sort | P0 |
| DAG-002 | Cycle detection | P0 |
| DAG-003 | Node scheduling order | P0 |
| DAG-004 | Ready node finding | P1 |

### 2.4 SubJob Recovery Tests
**File**: `tests/integration/test_subjob_recovery.py`

| Test ID | Description | Priority |
|---------|-------------|----------|
| SJ-001 | WAITING_SUBJOB state recovery | P0 |
| SJ-002 | SubJob status check | P1 |
| SJ-003 | Recovery point selection | P1 |

### 2.5 End-to-End Tests
**File**: `tests/integration/test_e2e_workflows.py`

| Test ID | Workflow | Priority |
|---------|----------|----------|
| E2E-001 | VBA to WPS JS conversion | P0 |
| E2E-002 | WPS JS to VBA conversion | P0 |
| E2E-003 | Web briefing generation | P1 |

---

## 3. Test Data

### 3.1 Test Files
- `test_vba.xlsm` - Excel file with VBA macros
- `test_wps.xlsm` - Excel file with WPS JS macros
- `test_urls.txt` - List of URLs for web briefing

### 3.2 Test Templates
- `excel_vba_to_wps_js` - Built-in template
- `wps_js_to_excel_vba` - Built-in template
- `web_briefing` - Built-in template

---

## 4. Test Execution

### 4.1 Prerequisites
1. Flask app running on http://127.0.0.1:5001
2. Database initialized
3. Test data prepared

### 4.2 Run All Tests
```bash
cd chujiu_project
pytest tests/integration/ -v
```

### 4.3 Run Specific Category
```bash
# API tests
pytest tests/integration/test_api_integration.py -v

# Plugin-Engine tests
pytest tests/integration/test_plugin_engine_integration.py -v

# DAG tests
pytest tests/integration/test_dag_scheduler.py -v
```

### 4.4 Generate Coverage Report
```bash
pytest tests/integration/ --cov=app --cov-report=html --cov-report=term
```

---

## 5. Pass/Fail Criteria

### 5.1 Pass Criteria
- All P0 tests must pass (100%)
- P1 tests ≥90% pass rate
- No critical defects
- API response time < 500ms (p95)

### 5.2 Fail Criteria
- Any P0 test fails
- P1 pass rate < 90%
- Critical defect found
- API response time > 1000ms (p95)

---

## 6. Defect Management

### 6.1 Severity Levels
- **Critical**: Application crash, data loss
- **Major**: Feature not working, workaround exists
- **Minor**: UI issue, cosmetic problem

### 6.2 Reporting
- Log defects in test report
- Include steps to reproduce
- Attach logs and screenshots

---

## 7. Test Report

### 7.1 Format
```markdown
# Integration Test Report

**Date**: YYYY-MM-DD
**Executor**: [Name]
**Environment**: [Environment details]

## Summary
- Total Tests: X
- Passed: Y
- Failed: Z
- Skipped: W

## Results by Category
| Category | Total | Passed | Failed | Pass Rate |
|----------|-------|--------|--------|-----------|
| API | ... | ... | ... | ...% |
| Plugin-Engine | ... | ... | ... | ...% |
| DAG | ... | ... | ... | ...% |
| SubJob | ... | ... | ... | ...% |
| E2E | ... | ... | ... | ...% |

## Critical Issues
1. [Issue description]
2. [Issue description]

## Recommendations
1. [Recommendation]
2. [Recommendation]
```

---

## 8. Maintenance

### 8.1 Update Frequency
- Test plan: Quarterly review
- Test cases: Update with each feature release

### 8.2 Ownership
- **Test Plan**: QA Lead
- **Test Cases**: Development Team
- **Execution**: QA Team

---

**Document History**:
- v1.0 (2026-03-13): Initial version
