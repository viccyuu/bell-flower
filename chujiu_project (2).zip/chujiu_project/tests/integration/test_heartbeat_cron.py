# -*- coding: utf-8 -*-
"""
集成测试 - Heartbeat & Cron（异步版本）⭐

测试 Heartbeat 和 Cron 服务的集成
支持异步数据库操作
"""
import pytest
import asyncio
from pathlib import Path
from app.heartbeat.task_query import task_query
from app.models import TaskRun, JobRun, NodeRun


class TestHeartbeatCronIntegration:
    """Heartbeat & Cron 集成测试"""
    
    @pytest.mark.asyncio
    async def test_heartbeat_query_and_execute(self, db_session):
        """测试 Heartbeat 查询并执行任务（异步）⭐"""
        # 创建测试任务（异步）
        task = TaskRun(
            task_template_id=1,
            status='RUNNING'
        )
        db_session.add(task)
        await db_session.commit()
        await db_session.refresh(task)
        
        # Heartbeat 查询
        pending_tasks = task_query.get_pending_tasks(cutoff_minutes=5)
        assert len(pending_tasks) >= 1
        
        # Cron 执行（如果是异步函数则 await）
        from app.cron.task_execution import task_execution
        result = task_execution.execute_task_run(task.id)
        assert result['success'] == True
    
    @pytest.mark.asyncio
    async def test_cron_schedule_and_execute(self, db_session):
        """测试 Cron 调度并执行（异步）⭐"""
        from app.cron.service import CronService
        from app.cron.types import CronSchedule
        import tempfile
        import os
        
        # 创建临时存储文件
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            store_path = Path(f.name)
        
        try:
            # 创建 Cron 服务
            cron_service = CronService(store_path=store_path)
            
            # 添加任务
            job = cron_service.add_job(
                name='test_job',
                schedule=CronSchedule(kind='every', every_ms=60000),
                message='test message'
            )
            
            # 验证任务已添加
            jobs = cron_service.list_jobs()
            assert len(jobs) >= 1
            assert job.id in [j.id for j in jobs]
            
        finally:
            # 清理临时文件
            if store_path.exists():
                os.unlink(store_path)


class TestErrorRecoveryIntegration:
    """错误恢复集成测试"""
    
    @pytest.mark.asyncio
    async def test_schedule_retry_with_cron(self, db_session):
        """测试使用 Cron 调度重试（异步）⭐"""
        from app.todolist.error_recovery import ErrorRecoveryManager
        from app.cron.service import CronService
        import tempfile
        import os
        from pathlib import Path
        
        # 创建临时存储文件
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            store_path = Path(f.name)
        
        try:
            # 创建错误恢复管理器
            recovery_manager = ErrorRecoveryManager()
            
            # 创建 Cron 服务
            cron_service = CronService(store_path=store_path)
            
            # 验证组件可用
            assert recovery_manager is not None
            assert cron_service is not None
            
        finally:
            # 清理临时文件
            if store_path.exists():
                os.unlink(store_path)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
