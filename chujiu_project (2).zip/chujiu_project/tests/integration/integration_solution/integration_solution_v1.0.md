# Chujiu Project 集成测试方案

**版本号**: v1.0  
**创建日期**: 2026-03-14  
**最后更新**: 2026-03-14

---

## 1. 项目背景

### 1.1 技术栈
- **后端**:
  - Python 3.12+
  - Flask 2.3+
  - Flask-SQLAlchemy
  - SQLite (开发环境) / MySQL 8.0 (生产环境)
  
- **前端**:
  - HTML5/CSS3/JavaScript (ES6+)
  - Jinja2 模板渲染
  - 原生 JavaScript (无框架依赖)

### 1.2 核心功能模块
1. **文件上传模块** - 支持拖拽上传、文件验证
2. **任务管理模块** - 任务创建、启动、状态查询
3. **提示词库模块** - 提示词分类、新增、编辑、查看
4. **插件管理模块** - 插件启用/禁用、DAG 查看、Learning 规则
5. **产物下载模块** - 产物列表、文件下载
6. **DAG 可视化模块** - DAG 图渲染、节点交互、缩放控制

### 1.3 关键页面 URL
| 页面 | URL | 说明 |
|------|-----|------|
| 首页/概览 | `/#dashboard` | 系统概览、统计信息 |
| 文件上传 | `/#upload` | 文件上传、任务创建 |
| 任务列表 | `/#tasks` | 任务列表、状态查看 |
| 提示词库 | `/#templates` | 提示词分类管理 |
| 插件管理 | `/#plugins` | 插件配置管理 |
| 产物下载 | `/#artifacts` | 产物列表下载 |
| 健康检查 | `/#health` | 系统健康状态 |

### 1.4 项目部署环境
- **开发环境**: http://127.0.0.1:5001
- **测试环境**: Docker 容器 (待配置)
- **生产环境**: 待定

---

## 2. 测试范围

### 2.1 后端接口测试范围
| 模块 | 接口 | 测试类型 |
|------|------|----------|
| 健康检查 | `GET /health` | 正常流程 |
| 文件上传 | `POST /api/uploads` | 正常/异常/边界 |
| 任务管理 | `GET/POST /api/task-runs` | 正常/异常 |
| 任务启动 | `POST /api/task-runs/<id>/start` | 正常/异常 |
| 提示词 | `GET/POST/PUT /api/prompts` | 正常/异常 |
| 提示词分类 | `GET /api/prompt-categories` | 正常流程 |
| 插件列表 | `GET /api/plugins` | 正常流程 |
| 插件 DAG | `GET /api/plugins/<code>/dag` | 正常流程 |
| 插件 Learning | `GET/POST /api/plugins/<code>/learning` | 正常/异常 |
| SubJob 管理 | `GET/POST /api/task-runs/<id>/subjobs` | 正常/异常 |
| Learning 生成 | `POST /api/task-runs/<id>/generate-learning` | 正常流程 |

### 2.2 前端页面测试范围
| 页面 | 测试元素 | 测试交互 |
|------|---------|---------|
| 文件上传页 | 上传区域、文件选择器、插件选择器 | 拖拽上传、点击上传、创建任务 |
| 任务列表页 | 任务表格、状态标签、操作按钮 | 启动任务、查看详情 |
| 提示词库页 | 分类展示、提示词列表、新增/编辑按钮 | 新增提示词、编辑提示词、查看详情 |
| 插件管理页 | 插件列表、启用开关、操作按钮 | 启用/禁用、查看 DAG、查看 Learning |
| 任务详情页 | DAG 可视化、节点信息、Job 列表 | 节点点击、缩放控制 |

### 2.3 数据流程测试
1. **文件上传 → 任务创建 → 任务执行** 完整链路
2. **提示词新增 → 提示词编辑 → 提示词删除** 完整链路
3. **插件启用 → DAG 查看 → Learning 规则生成** 完整链路

---

## 3. 测试环境

### 3.1 环境搭建步骤

#### 3.1.1 依赖安装
```bash
# 进入项目目录
cd chujiu_project

# 安装后端依赖
pip install -r requirements.txt

# 安装测试依赖
pip install pytest pytest-cov pytest-html requests
pip install playwright
playwright install chromium
```

#### 3.1.2 数据库初始化
```bash
# 运行数据库初始化脚本
python init_database.py
```

#### 3.1.3 Flask 应用启动
```bash
# 开发模式启动
python run.py

# 或使用 pytest 的测试客户端（推荐）
```

### 3.2 测试环境配置
- **操作系统**: Windows 10/11 或 Linux
- **Python 版本**: 3.12+
- **浏览器**: Chromium (Playwright 自动管理)
- **数据库**: SQLite (测试隔离)

---

## 4. 测试工具

### 4.1 后端测试工具
| 工具 | 用途 | 版本 |
|------|------|------|
| pytest | 测试框架 | 7.0+ |
| pytest-cov | 覆盖率报告 | 4.0+ |
| pytest-html | HTML 报告 | 3.2+ |
| requests | API 测试 | 2.28+ |
| Flask-Testing | Flask 测试客户端 | 0.8+ |

### 4.2 前端测试工具
| 工具 | 用途 | 版本 |
|------|------|------|
| Playwright | 浏览器自动化 | 1.30+ |
| pytest-playwright | Playwright pytest 集成 | 0.4+ |

### 4.3 核心依赖包
```txt
# requirements-test.txt
pytest>=7.0.0
pytest-cov>=4.0.0
pytest-html>=3.2.0
requests>=2.28.0
playwright>=1.30.0
pytest-playwright>=0.4.0
```

---

## 5. 测试策略

### 5.1 正常流程测试
- 验证功能按预期工作
- 验证正确的响应状态码
- 验证数据库数据一致性
- 验证页面元素正确渲染

### 5.2 异常流程测试
- 验证无效输入的错误处理
- 验证资源不存在的 404 响应
- 验证权限不足的 403 响应
- 验证服务器错误的 500 响应

### 5.3 边界条件测试
- 验证空数据列表的处理
- 验证大数据量的性能
- 验证文件上传大小限制
- 验证并发请求的处理

---

## 6. 测试数据

### 6.1 数据准备方式
1. **pytest fixture** - 每个测试用例独立的测试数据
2. **数据工厂** - 使用工厂模式生成测试数据
3. **测试数据库** - 使用独立的 SQLite 测试库

### 6.2 测试数据隔离
```python
@pytest.fixture
def test_client():
    """创建测试客户端"""
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            # 初始化测试数据
            init_test_data()
            yield client
            # 清理测试数据
            db.drop_all()
```

### 6.3 前端测试数据
```python
@pytest.fixture
def page_context(browser):
    """创建浏览器上下文"""
    context = browser.new_context(
        viewport={'width': 1920, 'height': 1080}
    )
    yield context
    context.close()
```

---

## 7. 前端自动化测试

### 7.1 测试范围
1. **页面加载验证** - 检查页面标题、核心元素是否存在
2. **内容完整性验证** - 检查关键文本是否正确渲染
3. **功能可用性验证** - 模拟用户操作，验证交互逻辑
4. **异常场景验证** - 验证错误输入的页面反馈

### 7.2 环境搭建步骤
```bash
# 安装 Playwright
pip install playwright
playwright install chromium

# 安装 pytest-playwright
pip install pytest-playwright

# 验证安装
playwright show-install
```

### 7.3 自动化执行策略
```bash
# 运行单模块测试
pytest tests/integration/test_pages.py -v

# 运行全量测试
pytest tests/integration/ -v

# 生成 HTML 报告
pytest tests/integration/ --html=report.html --self-contained-html

# 无头模式运行
pytest tests/integration/ --headed False
```

### 7.4 数据隔离
- 每个测试用例使用独立的浏览器上下文
- 测试后自动清理浏览器状态
- 使用测试数据库，不污染生产数据

---

## 8. 执行与报告

### 8.1 测试执行命令
```bash
# 运行所有集成测试
pytest tests/integration/ -v

# 运行并生成覆盖率报告
pytest tests/integration/ --cov=app --cov-report=html --cov-report=term

# 运行并生成 HTML 报告
pytest tests/integration/ --html=report.html --self-contained-html

# 运行特定模块
pytest tests/integration/test_api.py -v
pytest tests/integration/test_pages.py -v
```

### 8.2 测试覆盖率要求
- **核心模块**: ≥80% (routes, models, repository)
- **非核心模块**: ≥60% (utils, helpers)
- **总体覆盖率**: ≥70%

### 8.3 报告生成方式
```bash
# HTML 报告
pytest tests/integration/ --html=report.html --self-contained-html

# 覆盖率报告
pytest tests/integration/ --cov=app --cov-report=html
# 查看：打开 htmlcov/index.html

# JUnit XML 报告 (用于 CI/CD)
pytest tests/integration/ --junitxml=test-results.xml
```

---

## 9. 测试用例清单

### 9.1 后端接口测试用例
| 用例 ID | 用例名称 | 接口 | 测试类型 | 优先级 |
|--------|---------|------|---------|--------|
| API-001 | 健康检查 | GET /health | 正常流程 | P0 |
| API-002 | 文件上传成功 | POST /api/uploads | 正常流程 | P0 |
| API-003 | 文件上传幂等性 | POST /api/uploads | 正常流程 | P0 |
| API-004 | 创建任务成功 | POST /api/task-runs | 正常流程 | P0 |
| API-005 | 启动任务成功 | POST /api/task-runs/<id>/start | 正常流程 | P0 |
| API-006 | 获取任务详情 | GET /api/task-runs/<id> | 正常流程 | P0 |
| API-007 | 获取提示词列表 | GET /api/prompts | 正常流程 | P1 |
| API-008 | 创建提示词成功 | POST /api/prompts | 正常流程 | P1 |
| API-009 | 更新提示词成功 | PUT /api/prompts/code/<code> | 正常流程 | P1 |
| API-010 | 获取插件列表 | GET /api/plugins | 正常流程 | P1 |
| API-011 | 获取插件 DAG | GET /api/plugins/<code>/dag | 正常流程 | P1 |
| API-012 | 获取 Learning 规则 | GET /api/plugins/<code>/learning | 正常流程 | P1 |
| API-013 | 保存 Learning 规则 | POST /api/plugins/<code>/learning | 正常流程 | P1 |
| API-014 | 获取 SubJob 列表 | GET /api/task-runs/<id>/subjobs | 正常流程 | P2 |
| API-015 | 生成 Learning 规则 | POST /api/task-runs/<id>/generate-learning | 正常流程 | P2 |

### 9.2 前端页面测试用例
| 用例 ID | 用例名称 | 页面 | 测试类型 | 优先级 |
|--------|---------|------|---------|--------|
| PAGE-001 | 首页加载验证 | /#dashboard | 正常流程 | P0 |
| PAGE-002 | 文件上传页加载 | /#upload | 正常流程 | P0 |
| PAGE-003 | 文件上传功能 | /#upload | 功能测试 | P0 |
| PAGE-004 | 任务列表页加载 | /#tasks | 正常流程 | P0 |
| PAGE-005 | 任务详情查看 | /#tasks | 功能测试 | P0 |
| PAGE-006 | 提示词库页加载 | /#templates | 正常流程 | P0 |
| PAGE-007 | 新增提示词功能 | /#templates | 功能测试 | P1 |
| PAGE-008 | 编辑提示词功能 | /#templates | 功能测试 | P1 |
| PAGE-009 | 插件管理页加载 | /#plugins | 正常流程 | P0 |
| PAGE-010 | 插件启用/禁用 | /#plugins | 功能测试 | P1 |
| PAGE-011 | 查看插件 DAG | /#plugins | 功能测试 | P1 |
| PAGE-012 | DAG 可视化加载 | 任务详情页 | 功能测试 | P1 |
| PAGE-013 | DAG 节点交互 | 任务详情页 | 功能测试 | P2 |
| PAGE-014 | DAG 缩放控制 | 任务详情页 | 功能测试 | P2 |

---

## 10. 常见问题排查

### 10.1 测试环境问题
**问题**: 测试无法连接数据库  
**解决**: 检查 `TESTING` 配置，确保使用 `sqlite:///:memory:`

**问题**: Playwright 浏览器无法启动  
**解决**: 运行 `playwright install chromium` 重新安装

### 10.2 测试失败问题
**问题**: 元素定位失败  
**解决**: 检查元素 ID/Name，使用显式等待 `page.wait_for_selector()`

**问题**: API 返回 500 错误  
**解决**: 检查应用日志，验证请求参数格式

### 10.3 覆盖率问题
**问题**: 覆盖率不达标  
**解决**: 增加边界条件和异常流程测试用例

---

## 11. 版本管理

### 11.1 版本记录
| 版本 | 日期 | 修改内容 | 修改人 |
|------|------|---------|--------|
| v1.0 | 2026-03-14 | 初始版本 | AI Assistant |

### 11.2 备份策略
- 修改前的方案备份到 `tests/integration/integration_solution/bak/`
- 备份文件名格式：`{原文件名}_{timestamp}.{扩展名}`
- 保留最近 5 个版本的备份

---

**文档结束**
