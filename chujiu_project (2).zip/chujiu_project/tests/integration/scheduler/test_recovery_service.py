# -*- coding: utf-8 -*-
"""
RecoveryService 集成测试 ⭐

测试 RecoveryService 的各种场景。
"""
import pytest
from app.scheduler import (
    DagScheduler,
    RecoveryService,
    ExecutorRegistry,
    PythonExecutor,
    InputResolver,
    OutputValidator
)


class TestRecoveryService:
    """RecoveryService 测试类"""
    
    @pytest.fixture
    def scheduler(self):
        """创建 DagScheduler 实例"""
        ExecutorRegistry._instance = None
        ExecutorRegistry._executors = {}
        
        registry = ExecutorRegistry()
        registry.register('python_executor', PythonExecutor(
            input_resolver=InputResolver(),
            output_validator=OutputValidator()
        ))
        
        return DagScheduler(executor_registry=registry)
    
    @pytest.fixture
    def recovery_service(self, scheduler):
        """创建 RecoveryService 实例"""
        return RecoveryService(
            scheduler=scheduler,
            dag_registry={
                'test_job': {
                    'job': {'code': 'test_job', 'name': 'Test Job', 'version': 1},
                    'nodes': [
                        {
                            'code': 'step1',
                            'action_type': 'PYTHON',
                            'executor': 'python_executor',
                            'config': {'callable': 'tests.integration.scheduler.test_recovery_service.mock_success'}
                        },
                        {
                            'code': 'step2',
                            'action_type': 'PYTHON',
                            'executor': 'python_executor',
                            'config': {'callable': 'tests.integration.scheduler.test_recovery_service.mock_success'}
                        }
                    ],
                    'edges': [{'from': 'step1', 'to': 'step2'}]
                }
            }
        )
    
    def test_recovery_service_initialization(self, recovery_service):
        """测试 RecoveryService 初始化"""
        assert recovery_service.scheduler is not None
        assert recovery_service.dag_registry is not None
        assert 'test_job' in recovery_service.dag_registry
    
    def test_recover_all_empty(self, recovery_service):
        """测试恢复空任务列表"""
        # 没有可恢复任务时返回空列表
        result = recovery_service.recover_all()
        assert isinstance(result, list)
    
    def test_recovery_with_valid_context(self, scheduler):
        """测试有效上下文的恢复"""
        dag = {
            'job': {'code': 'recovery_test', 'name': 'Recovery Test', 'version': 1},
            'defaults': {'timeout_seconds': 60},
            'nodes': [
                {
                    'code': 'step1',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {'callable': 'tests.integration.scheduler.test_recovery_service.mock_success'},
                    'input_mapping': {'value': '{{ task.vars.value }}'}
                },
                {
                    'code': 'step2',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {'callable': 'tests.integration.scheduler.test_recovery_service.mock_success'},
                    'input_mapping': {'value': '{{ task.vars.value }}'}
                }
            ],
            'edges': [{'from': 'step1', 'to': 'step2'}]
        }
        
        # 创建 RecoveryService
        recovery = RecoveryService(
            scheduler=scheduler,
            dag_registry={'recovery_test': dag}
        )
        
        # 模拟运行时上下文
        runtime_context = {
            'task': {'id': 1001, 'vars': {'value': 42}},
            'job': {'id': 2001, 'vars': {}},
            'node': {
                'step1': {'status': 'SUCCESS', 'output': {'result': 84}},
                'step2': {'status': 'RUNNING', 'output': None}  # 模拟中断
            }
        }
        
        # 执行恢复
        result = scheduler.run(dag, runtime_context, resume=True)
        
        # 验证恢复成功
        assert result['state']['job_status'] == 'SUCCESS'
        assert result['state']['nodes']['step1']['status'] == 'SUCCESS'
        assert result['state']['nodes']['step2']['status'] == 'SUCCESS'
    
    def test_recovery_preserves_successful_nodes(self, scheduler):
        """测试恢复时保留成功节点"""
        dag = {
            'job': {'code': 'preserve_test', 'name': 'Preserve Test', 'version': 1},
            'defaults': {'timeout_seconds': 60},
            'nodes': [
                {
                    'code': 'step1',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {'callable': 'tests.integration.scheduler.test_recovery_service.mock_success'},
                    'input_mapping': {'value': '{{ task.vars.value }}'}
                },
                {
                    'code': 'step2',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {'callable': 'tests.integration.scheduler.test_recovery_service.mock_success'},
                    'input_mapping': {'value': '{{ task.vars.value }}'}
                },
                {
                    'code': 'step3',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {'callable': 'tests.integration.scheduler.test_recovery_service.mock_success'},
                    'input_mapping': {'value': '{{ task.vars.value }}'}
                }
            ],
            'edges': [
                {'from': 'step1', 'to': 'step2'},
                {'from': 'step2', 'to': 'step3'}
            ]
        }
        
        runtime_context = {
            'task': {'id': 1001, 'vars': {'value': 42}},
            'job': {'id': 2001, 'vars': {}},
            'node': {
                'step1': {'status': 'SUCCESS', 'output': {'result': 84}},
                'step2': {'status': 'SUCCESS', 'output': {'result': 168}},
                'step3': {'status': 'RUNNING', 'output': None}  # 模拟中断
            }
        }
        
        # 执行恢复
        result = scheduler.run(dag, runtime_context, resume=True)
        
        # 验证所有节点成功
        assert result['state']['job_status'] == 'SUCCESS'
        assert result['state']['nodes']['step1']['status'] == 'SUCCESS'
        assert result['state']['nodes']['step2']['status'] == 'SUCCESS'
        assert result['state']['nodes']['step3']['status'] == 'SUCCESS'
        
        # 验证成功节点的数据保留
        assert result['context']['node']['step1']['output']['result'] == 84
        assert result['context']['node']['step2']['output']['result'] == 168
    
    def test_recovery_with_dag_not_found(self, scheduler):
        """测试 DAG 未找到的恢复"""
        runtime_context = {
            'task': {'id': 1001, 'vars': {}},
            'job': {'id': 2001, 'vars': {}},
            'node': {}
        }
        
        recovery = RecoveryService(
            scheduler=scheduler,
            dag_registry={}  # 空注册表
        )
        
        # 恢复应该返回空列表（DAG 未找到）
        result = recovery.recover_all()
        assert isinstance(result, list)
    
    def test_recovery_logging(self, scheduler, caplog):
        """测试恢复日志记录"""
        import logging
        
        dag = {
            'job': {'code': 'log_test', 'name': 'Log Test', 'version': 1},
            'defaults': {'timeout_seconds': 60},
            'nodes': [
                {
                    'code': 'step1',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {'callable': 'tests.integration.scheduler.test_recovery_service.mock_success'}
                }
            ],
            'edges': []
        }
        
        runtime_context = {
            'task': {'id': 1001, 'vars': {}},
            'job': {'id': 2001, 'vars': {}},
            'node': {}
        }
        
        with caplog.at_level(logging.INFO):
            result = scheduler.run(dag, runtime_context, resume=True)
        
        # 验证日志记录
        assert any('JOB_STARTED' in record.message or 'JOB_RESUMED' in record.message for record in caplog.records)
        assert any('JOB_FINISHED' in record.message for record in caplog.records)


# Mock 函数

def mock_success(**kwargs):
    """模拟成功函数"""
    value = kwargs.get('value', 0)
    return {'result': value * 2}
