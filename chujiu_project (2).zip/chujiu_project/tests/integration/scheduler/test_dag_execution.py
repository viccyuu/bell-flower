# -*- coding: utf-8 -*-
"""
DAG Execution 集成测试 ⭐

测试完整的 DAG 执行流程。
"""
import pytest
from app.scheduler import (
    DagScheduler,
    ExecutorRegistry,
    PythonExecutor,
    InputResolver,
    OutputValidator
)


class TestDagExecution:
    """DAG 执行集成测试类"""
    
    @pytest.fixture
    def scheduler(self):
        """创建 DagScheduler 实例"""
        # 清除单例
        ExecutorRegistry._instance = None
        ExecutorRegistry._executors = {}
        
        registry = ExecutorRegistry()
        registry.register('python_executor', PythonExecutor())
        
        return DagScheduler(executor_registry=registry)
    
    @pytest.fixture
    def simple_dag(self):
        """简单 DAG 定义"""
        return {
            'job': {
                'code': 'simple_job',
                'name': 'Simple Job',
                'version': 1
            },
            'defaults': {
                'timeout_seconds': 60
            },
            'nodes': [
                {
                    'code': 'step1',
                    'name': 'Step 1',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {
                        'callable': 'tests.integration.scheduler.test_dag_execution.mock_function'
                    },
                    'input_mapping': {
                        'value': '{{ task.vars.input_value }}'
                    }
                }
            ],
            'edges': []
        }
    
    @pytest.fixture
    def runtime_context(self):
        """运行时上下文"""
        return {
            'task': {
                'id': 1001,
                'vars': {
                    'input_value': 42
                }
            },
            'job': {
                'id': 2001,
                'vars': {}
            },
            'node': {}
        }
    
    def test_simple_dag_execution(self, scheduler, simple_dag, runtime_context):
        """测试简单 DAG 执行"""
        result = scheduler.run(simple_dag, runtime_context)
        
        # 验证 Job 状态
        assert result['state']['job_status'] == 'SUCCESS'
        
        # 验证节点状态
        assert result['state']['nodes']['step1']['status'] == 'SUCCESS'
        
        # 验证 runtime_context
        assert 'step1' in result['context']['node']
        assert result['context']['node']['step1']['status'] == 'SUCCESS'
    
    def test_dag_with_multiple_nodes(self, scheduler, runtime_context):
        """测试多节点 DAG 执行"""
        dag = {
            'job': {
                'code': 'multi_node_job',
                'name': 'Multi Node Job',
                'version': 1
            },
            'defaults': {
                'timeout_seconds': 60
            },
            'nodes': [
                {
                    'code': 'step1',
                    'name': 'Step 1',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {
                        'callable': 'tests.integration.scheduler.test_dag_execution.mock_function'
                    },
                    'input_mapping': {
                        'value': '{{ task.vars.input_value }}'
                    }
                },
                {
                    'code': 'step2',
                    'name': 'Step 2',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {
                        'callable': 'tests.integration.scheduler.test_dag_execution.mock_function'
                    },
                    'input_mapping': {
                        'value': '{{ node.step1.output.result }}'
                    }
                }
            ],
            'edges': [
                {'from': 'step1', 'to': 'step2'}
            ]
        }
        
        result = scheduler.run(dag, runtime_context)
        
        # 验证 Job 状态
        assert result['state']['job_status'] == 'SUCCESS'
        
        # 验证节点状态
        assert result['state']['nodes']['step1']['status'] == 'SUCCESS'
        assert result['state']['nodes']['step2']['status'] == 'SUCCESS'
    
    def test_dag_with_condition_edge_skip(self, scheduler, runtime_context):
        """测试带条件边的 DAG 执行（跳过场景）"""
        # 清除单例
        ExecutorRegistry._instance = None
        ExecutorRegistry._executors = {}
        
        registry = ExecutorRegistry()
        registry.register('python_executor', PythonExecutor())
        
        scheduler = DagScheduler(executor_registry=registry)
        
        dag = {
            'job': {
                'code': 'conditional_job',
                'name': 'Conditional Job',
                'version': 1
            },
            'defaults': {
                'timeout_seconds': 60
            },
            'nodes': [
                {
                    'code': 'step1',
                    'name': 'Step 1',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {
                        'callable': 'tests.integration.scheduler.test_dag_execution.mock_function'
                    },
                    'input_mapping': {'value': '{{ task.vars.value }}'}
                },
                {
                    'code': 'step2',
                    'name': 'Step 2',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {
                        'callable': 'tests.integration.scheduler.test_dag_execution.mock_function'
                    },
                    'input_mapping': {'value': '{{ task.vars.value }}'}
                }
            ],
            'edges': [
                {'from': 'step1', 'to': 'step2', 'condition_expr': '{{ task.vars.enabled == false }}'}
            ]
        }
        
        # enabled == true，但条件要求 false，step2 应该跳过
        runtime_context['task']['vars']['enabled'] = True
        runtime_context['task']['vars']['value'] = 42
        
        result = scheduler.run(dag, runtime_context)
        
        assert result['state']['nodes']['step1']['status'] == 'SUCCESS'
        assert result['state']['nodes']['step2']['status'] == 'SKIPPED'
    
    def test_dag_with_retry(self, scheduler, runtime_context):
        """测试带重试的 DAG 执行"""
        # 清除单例
        ExecutorRegistry._instance = None
        ExecutorRegistry._executors = {}
        
        registry = ExecutorRegistry()
        registry.register('python_executor', PythonExecutor())
        
        scheduler = DagScheduler(executor_registry=registry)
        
        dag = {
            'job': {
                'code': 'retry_job',
                'name': 'Retry Job',
                'version': 1
            },
            'defaults': {
                'timeout_seconds': 60,
                'retry_policy': {
                    'max_retries': 2,
                    'backoff_seconds': 0,
                    'retry_on': ['TEMPORARY_ERROR']
                }
            },
            'nodes': [
                {
                    'code': 'step1',
                    'name': 'Step 1',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {
                        'callable': 'tests.integration.scheduler.test_dag_execution.mock_function_with_retry'
                    },
                    'input_mapping': {
                        'value': '{{ task.vars.value }}'
                    }
                }
            ],
            'edges': []
        }
        
        runtime_context['task']['vars']['value'] = 42
        
        result = scheduler.run(dag, runtime_context)
        
        # 验证节点最终成功
        assert result['state']['nodes']['step1']['status'] == 'SUCCESS'
        # 验证重试历史
        assert len(result['state']['nodes']['step1']['retry_history']) >= 1


# Mock 函数

def mock_function(**kwargs):
    """模拟函数"""
    value = kwargs.get('value', 0)
    return {'result': value * 2}


def mock_function_with_retry(**kwargs):
    """模拟带重试的函数"""
    from app.scheduler.exceptions import TemporaryError
    
    # 第一次调用失败，第二次成功
    if not hasattr(mock_function_with_retry, 'called'):
        mock_function_with_retry.called = True
        raise TemporaryError('Temporary error')
    
    value = kwargs.get('value', 0)
    return {'result': value}
