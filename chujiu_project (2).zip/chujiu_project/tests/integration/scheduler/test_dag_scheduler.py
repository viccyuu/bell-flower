# -*- coding: utf-8 -*-
"""
DagScheduler 集成测试 ⭐

测试 DagScheduler 的各种场景。
"""
import pytest
from app.scheduler import (
    DagScheduler,
    ExecutorRegistry,
    PythonExecutor,
    InputResolver,
    OutputValidator,
    DAGValidationError
)


class TestDagScheduler:
    """DagScheduler 测试类"""
    
    @pytest.fixture
    def scheduler(self):
        """创建 DagScheduler 实例"""
        ExecutorRegistry._instance = None
        ExecutorRegistry._executors = {}
        
        registry = ExecutorRegistry()
        registry.register('python_executor', PythonExecutor(
            input_resolver=InputResolver(),
            output_validator=OutputValidator()
        ))
        
        return DagScheduler(executor_registry=registry)
    
    @pytest.fixture
    def runtime_context(self):
        """创建运行时上下文"""
        return {
            'task': {'id': 1001, 'vars': {}},
            'job': {'id': 2001, 'vars': {}},
            'node': {}
        }
    
    def test_dag_validation_cycle(self, scheduler, runtime_context):
        """测试 DAG 环检测"""
        dag = {
            'job': {'code': 'cycle_job', 'name': 'Cycle Job', 'version': 1},
            'nodes': [
                {'code': 'a', 'action_type': 'PYTHON', 'executor': 'python_executor'},
                {'code': 'b', 'action_type': 'PYTHON', 'executor': 'python_executor'}
            ],
            'edges': [
                {'from': 'a', 'to': 'b'},
                {'from': 'b', 'to': 'a'}  # 形成环
            ]
        }
        
        with pytest.raises(DAGValidationError) as exc_info:
            scheduler.run(dag, runtime_context)
        
        assert 'cycle' in str(exc_info.value).lower()
    
    def test_dag_validation_unknown_node(self, scheduler, runtime_context):
        """测试 DAG 未知节点检测"""
        dag = {
            'job': {'code': 'unknown_job', 'name': 'Unknown Job', 'version': 1},
            'nodes': [
                {'code': 'a', 'action_type': 'PYTHON', 'executor': 'python_executor'}
            ],
            'edges': [
                {'from': 'a', 'to': 'unknown'}  # 未知节点
            ]
        }
        
        with pytest.raises(DAGValidationError) as exc_info:
            scheduler.run(dag, runtime_context)
        
        assert 'unknown' in str(exc_info.value).lower()
    
    def test_dag_with_defaults(self, scheduler, runtime_context):
        """测试 DAG 默认值应用"""
        dag = {
            'job': {'code': 'default_job', 'name': 'Default Job', 'version': 1},
            'defaults': {
                'timeout_seconds': 120,
                'continue_on_error': True,
                'retry_policy': {
                    'max_retries': 3,
                    'backoff_seconds': 5,
                    'retry_on': ['TIMEOUT']
                }
            },
            'nodes': [
                {
                    'code': 'step1',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {'callable': 'tests.integration.scheduler.test_dag_scheduler.mock_success'}
                }
            ],
            'edges': []
        }
        
        runtime_context['task']['vars']['value'] = 42
        result = scheduler.run(dag, runtime_context)
        
        assert result['state']['job_status'] == 'SUCCESS'
        assert result['state']['nodes']['step1']['status'] == 'SUCCESS'
    
    def test_dag_parallel_nodes(self, scheduler, runtime_context):
        """测试并行节点执行"""
        dag = {
            'job': {'code': 'parallel_job', 'name': 'Parallel Job', 'version': 1},
            'defaults': {'timeout_seconds': 60},
            'nodes': [
                {
                    'code': 'step1',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {'callable': 'tests.integration.scheduler.test_dag_scheduler.mock_success'},
                    'input_mapping': {'value': '{{ task.vars.value }}'}
                },
                {
                    'code': 'step2',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {'callable': 'tests.integration.scheduler.test_dag_scheduler.mock_success'},
                    'input_mapping': {'value': '{{ task.vars.value }}'}
                },
                {
                    'code': 'step3',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {'callable': 'tests.integration.scheduler.test_dag_scheduler.mock_success'},
                    'input_mapping': {'value': '{{ task.vars.value }}'}
                }
            ],
            'edges': []  # 无边，所有节点并行
        }
        
        runtime_context['task']['vars']['value'] = 42
        result = scheduler.run(dag, runtime_context)
        
        # 所有节点都应该成功
        assert result['state']['job_status'] == 'SUCCESS'
        assert result['state']['nodes']['step1']['status'] == 'SUCCESS'
        assert result['state']['nodes']['step2']['status'] == 'SUCCESS'
        assert result['state']['nodes']['step3']['status'] == 'SUCCESS'
    
    def test_dag_complex_workflow(self, scheduler, runtime_context):
        """测试复杂工作流"""
        dag = {
            'job': {'code': 'complex_job', 'name': 'Complex Job', 'version': 1},
            'defaults': {'timeout_seconds': 60},
            'nodes': [
                {
                    'code': 'extract',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {'callable': 'tests.integration.scheduler.test_dag_scheduler.mock_extract'},
                    'input_mapping': {'source': '{{ task.vars.source }}'}
                },
                {
                    'code': 'transform',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {'callable': 'tests.integration.scheduler.test_dag_scheduler.mock_transform'},
                    'input_mapping': {'data': '{{ node.extract.output.data }}'}
                },
                {
                    'code': 'load',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {'callable': 'tests.integration.scheduler.test_dag_scheduler.mock_load'},
                    'input_mapping': {'data': '{{ node.transform.output.data }}'}
                }
            ],
            'edges': [
                {'from': 'extract', 'to': 'transform'},
                {'from': 'transform', 'to': 'load'}
            ]
        }
        
        runtime_context['task']['vars']['source'] = 'test_source'
        result = scheduler.run(dag, runtime_context)
        
        assert result['state']['job_status'] == 'SUCCESS'
        assert result['state']['nodes']['extract']['status'] == 'SUCCESS'
        assert result['state']['nodes']['transform']['status'] == 'SUCCESS'
        assert result['state']['nodes']['load']['status'] == 'SUCCESS'
        
        # 验证数据传递
        assert result['context']['node']['extract']['output']['data'] == 'test_source_processed'
        assert result['context']['node']['transform']['output']['data'] == 'test_source_processed_transformed'
        assert result['context']['node']['load']['output']['success'] is True
    
    def test_dag_resume_from_failure(self, scheduler, runtime_context):
        """测试从失败恢复"""
        dag = {
            'job': {'code': 'resume_job', 'name': 'Resume Job', 'version': 1},
            'defaults': {'timeout_seconds': 60},
            'nodes': [
                {
                    'code': 'step1',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {'callable': 'tests.integration.scheduler.test_dag_scheduler.mock_success'},
                    'input_mapping': {'value': '{{ task.vars.value }}'}
                },
                {
                    'code': 'step2',
                    'action_type': 'PYTHON',
                    'executor': 'python_executor',
                    'config': {'callable': 'tests.integration.scheduler.test_dag_scheduler.mock_success'},
                    'input_mapping': {'value': '{{ task.vars.value }}'}
                }
            ],
            'edges': [{'from': 'step1', 'to': 'step2'}]
        }
        
        # 第一次执行，step1 成功
        runtime_context['task']['vars']['value'] = 42
        result = scheduler.run(dag, runtime_context, resume=False)
        
        assert result['state']['nodes']['step1']['status'] == 'SUCCESS'
        assert result['state']['nodes']['step2']['status'] == 'SUCCESS'


# Mock 函数

def mock_success(**kwargs):
    """模拟成功函数"""
    value = kwargs.get('value', 0)
    return {'result': value * 2}


def mock_extract(**kwargs):
    """模拟提取函数"""
    source = kwargs.get('source', '')
    return {'data': f'{source}_processed'}


def mock_transform(**kwargs):
    """模拟转换函数"""
    data = kwargs.get('data', '')
    return {'data': f'{data}_transformed'}


def mock_load(**kwargs):
    """模拟加载函数"""
    data = kwargs.get('data', '')
    return {'success': True, 'loaded_data': data}
