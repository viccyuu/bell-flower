# -*- coding: utf-8 -*-
"""
Pytest Fixtures for Chujiu Project Integration Tests

Provides:
1. Flask test client
2. Database isolation
3. Test data fixtures
4. Browser fixtures for Playwright
"""
import pytest
import os
import sys

# Add app to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from app import create_app
from app.app_config import Settings


@pytest.fixture(scope='session')
def app():
    """Create Flask application for testing"""
    app = create_app(Settings)
    app.config.update({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': 'sqlite+aiosqlite:///:memory:',
        'SQLALCHEMY_TRACK_MODIFICATIONS': False,
        'WTF_CSRF_ENABLED': False
    })
    
    with app.app_context():
        yield app


@pytest.fixture
def client(app):
    """Create test client"""
    return app.test_client()


@pytest.fixture
def runner(app):
    """Create CLI runner"""
    return app.test_cli_runner()


@pytest.fixture
def scheduler():
    """Create DagScheduler for integration tests"""
    from app.scheduler import (
        DagScheduler,
        ExecutorRegistry,
        PythonExecutor,
        InputResolver,
        OutputValidator
    )
    
    # 清除单例
    ExecutorRegistry._instance = None
    ExecutorRegistry._executors = {}
    
    registry = ExecutorRegistry()
    registry.register('python_executor', PythonExecutor(
        input_resolver=InputResolver(),
        output_validator=OutputValidator()
    ))
    
    return DagScheduler(executor_registry=registry)


@pytest.fixture
def runtime_context():
    """Create standard runtime context"""
    return {
        'task': {
            'id': 1001,
            'vars': {}
        },
        'job': {
            'id': 2001,
            'vars': {}
        },
        'node': {}
    }


def init_test_data():
    """Initialize test data"""
    # 简化实现：不初始化数据
    pass
