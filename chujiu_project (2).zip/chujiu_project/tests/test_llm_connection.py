# -*- coding: utf-8 -*-
"""
LLM 连接测试脚本

测试 LLM Executor 是否可以正常连接并返回消息。
加载.chujiu/config.json 配置，使用自定义提示词测试。
"""
import asyncio
import json
from pathlib import Path
import sys

# 添加项目路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from app.todolist.llm_executor import LLMExecutor
from app.config.loader import load_config


async def test_llm_connection():
    """测试 LLM 连接"""
    print("=" * 60)
    print("LLM 连接测试")
    print("=" * 60)
    
    # 1. 加载配置
    config_path = Path(".chujiu/config.json")
    print(f"\n[1] 加载配置文件：{config_path.absolute()}")
    
    if not config_path.exists():
        print(f"[ERROR] 配置文件不存在：{config_path}")
        return False
    
    config = load_config(config_path)
    print(f"[OK] 配置加载成功")
    
    # 显示配置信息
    try:
        api_key = config.providers.dashscope.api_key
        if api_key:
            print(f"[OK] API Key: {api_key[:10]}...{api_key[-5:]}")
        else:
            print(f"[ERROR] API Key 未配置")
            return False
        
        default_model = config.agents.defaults.model
        print(f"[OK] 默认模型：{default_model}")
    except Exception as e:
        print(f"[ERROR] 读取配置失败：{e}")
        return False
    
    # 2. 创建 LLM Executor
    print(f"\n[2] 创建 LLM Executor")
    executor = LLMExecutor(
        config_path=config_path,
        workspace=project_root,
        model=default_model,
        max_iterations=40,
        temperature=0.1,
        max_tokens=8192,
        context_window_tokens=65536,
    )
    print(f"[OK] LLM Executor 创建成功")
    
    # 3. 测试提示词
    test_prompts = [
        {
            'name': '简单问候',
            'system': '你是一个友好的助手。',
            'user': '你好，请介绍一下自己。',
        },
        {
            'name': 'VBA 转 AST 测试',
            'system': '你是 VBA 语法分析专家。请将输入 VBA 源码转换为结构化 AST。必须严格输出 JSON。',
            'user': '''请将以下 VBA 代码转换为结构化 AST：

```vba
Sub TestMacro()
    MsgBox "Hello World"
End Sub
```

输出 JSON AST：''',
        },
        {
            'name': '代码审查测试',
            'system': '你是代码审查专家。请检查代码的语法正确性。',
            'user': '''请审查以下 JavaScript 代码：

```javascript
function test() {
    console.log("Hello");
    return undefined_variable;
}
```

输出审查结果（JSON 格式）：
{
  "passed": true/false,
  "issues": ["问题 1", "问题 2"]
}''',
        },
    ]
    
    # 4. 执行测试
    print(f"\n[3] 执行 LLM 测试")
    print("-" * 60)
    
    results = []
    for i, test in enumerate(test_prompts, 1):
        print(f"\n测试 {i}/{len(test_prompts)}: {test['name']}")
        print(f"  System: {test['system'][:50]}...")
        print(f"  User: {test['user'][:50]}...")
        
        try:
            result = await executor.execute(
                task_id=f"test_{i}",
                system_prompt=test['system'],
                user_prompt=test['user'],
            )
            
            if result.success:
                print(f"  [OK] 成功")
                response = result.data.get('response', '')
                if response:
                    print(f"  响应：{response[:200]}...")
                results.append(True)
            else:
                print(f"  [ERROR] 失败：{result.message}")
                results.append(False)
                
        except Exception as e:
            print(f"  [ERROR] 异常：{str(e)}")
            results.append(False)
        
        print("-" * 60)
    
    # 5. 关闭连接
    print(f"\n[4] 关闭连接")
    await executor.close()
    print(f"[OK] 连接已关闭")
    
    # 6. 总结
    print(f"\n" + "=" * 60)
    print(f"测试总结")
    print(f"=" * 60)
    print(f"总测试数：{len(test_prompts)}")
    print(f"成功：{sum(results)}")
    print(f"失败：{len(results) - sum(results)}")
    print(f"成功率：{sum(results) / len(results) * 100:.1f}%")
    
    if all(results):
        print(f"\n[OK] 所有测试通过！LLM 连接正常。")
        return True
    else:
        print(f"\n[ERROR] 部分测试失败。请检查配置和网络连接。")
        return False


async def test_vba_to_ast():
    """测试 VBA 转 AST 功能"""
    print("\n" + "=" * 60)
    print("VBA 转 AST 专项测试")
    print("=" * 60)
    
    config_path = Path(".chujiu/config.json")
    executor = LLMExecutor(config_path=config_path)
    
    vba_code = '''
Sub CalculateSum()
    Dim sum As Integer
    sum = 0
    For i = 1 To 10
        sum = sum + i
    Next i
    MsgBox "Sum: " & sum
End Sub
'''
    
    print(f"\n输入 VBA 代码:\n{vba_code}")
    
    result = await executor.convert_vba_to_ast(
        task_id="vba_test_1",
        vba_code=vba_code,
    )
    
    if result.success:
        print(f"\n[OK] 转换成功")
        ast = result.data.get('ast', {})
        print(f"AST: {json.dumps(ast, indent=2, ensure_ascii=False)[:500]}...")
    else:
        print(f"\n[ERROR] 转换失败：{result.message}")
    
    await executor.close()
    return result.success


async def main():
    """主函数"""
    print("\n" + "=" * 60)
    print("LLM 连接测试套件")
    print("=" * 60)
    
    # 测试 1: 基础连接
    connection_ok = await test_llm_connection()
    
    # 测试 2: VBA 转 AST
    if connection_ok:
        vba_ok = await test_vba_to_ast()
    else:
        print("\n[SKIP] 跳过 VBA 转 AST 测试（连接失败）")
        vba_ok = False
    
    # 总结
    print("\n" + "=" * 60)
    print("最终总结")
    print("=" * 60)
    
    if connection_ok and vba_ok:
        print("[OK] 所有测试通过！LLM 功能正常。")
        return True
    elif connection_ok:
        print("[WARN] 基础连接正常，但 VBA 转 AST 失败。")
        return False
    else:
        print("[ERROR] LLM 连接失败。请检查配置和网络。")
        return False


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)
