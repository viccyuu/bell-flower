# -*- coding: utf-8 -*-
"""
Pytest Fixtures for Chujiu Project Tests

提供：
1. Flask/FastAPI app context（支持异步）
2. 数据库 session 管理（异步 AsyncSession）
3. 测试数据清理
4. HTTP 测试客户端（httpx AsyncClient）
"""
import pytest
import asyncio
from typing import AsyncGenerator, Generator
from httpx import AsyncClient, ASGITransport

from app import create_app
from app.app_config import Settings


# ============================================================================
# Application Fixtures
# ============================================================================

@pytest.fixture(scope='session')
def app() -> Generator:
    """
    创建 Flask/FastAPI application for testing
    
    Yields:
        Application instance
    """
    app = create_app(Settings)
    app.config.update({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': 'sqlite+aiosqlite:///:memory:',
        'SQLALCHEMY_TRACK_MODIFICATIONS': False,
        'WTF_CSRF_ENABLED': False
    })
    
    with app.app_context():
        yield app


@pytest.fixture
async def client(app) -> AsyncGenerator[AsyncClient, None]:
    """
    创建异步测试客户端（FastAPI 兼容）⭐
    
    Args:
        app: Application instance
    
    Yields:
        AsyncClient: HTTP test client
    """
    async with AsyncClient(
        base_url="http://test",
        timeout=30.0
    ) as ac:
        yield ac


@pytest.fixture
def sync_client(app):
    """
    创建同步测试客户端（Flask 兼容）
    
    Args:
        app: Application instance
    
    Yields:
        FlaskClient: Test client
    """
    return app.test_client()


# ============================================================================
# Scheduler Fixtures
# ============================================================================

@pytest.fixture
def scheduler_registry():
    """
    创建 ExecutorRegistry for scheduler tests
    
    Yields:
        ExecutorRegistry instance
    """
    from app.scheduler import ExecutorRegistry
    # 清除单例
    ExecutorRegistry._instance = None
    ExecutorRegistry._executors = {}
    return ExecutorRegistry()


@pytest.fixture
def scheduler(scheduler_registry):
    """
    创建 DagScheduler for tests
    
    Args:
        scheduler_registry: ExecutorRegistry fixture
    
    Yields:
        DagScheduler instance
    """
    from app.scheduler import DagScheduler, PythonExecutor
    scheduler_registry.register('python_executor', PythonExecutor())
    return DagScheduler(executor_registry=scheduler_registry)


@pytest.fixture
def runtime_context():
    """
    创建标准运行时上下文
    
    Yields:
        dict: runtime context
    """
    return {
        'task': {
            'id': 1001,
            'vars': {}
        },
        'job': {
            'id': 2001,
            'vars': {}
        },
        'node': {}
    }


# ============================================================================
# Resolver Fixtures
# ============================================================================

@pytest.fixture
def input_resolver():
    """
    创建 InputResolver for tests
    
    Yields:
        InputResolver instance
    """
    from app.scheduler.resolver import InputResolver
    return InputResolver()


@pytest.fixture
def output_validator():
    """
    创建 OutputValidator for tests
    
    Yields:
        OutputValidator instance
    """
    from app.scheduler.resolver import OutputValidator
    return OutputValidator()


@pytest.fixture
def test_context():
    """
    创建测试上下文
    
    Yields:
        dict: test context
    """
    return {
        'task': {
            'id': 1001,
            'vars': {
                'value': 42,
                'name': 'test',
                'enabled': True
            }
        },
        'job': {
            'id': 2001,
            'vars': {
                'config': {'key': 'value'}
            }
        },
        'node': {
            'step1': {
                'status': 'SUCCESS',
                'output': {
                    'result': 'success',
                    'data': {'key': 'value'}
                },
                'error': None
            },
            'step2': {
                'status': 'FAILED',
                'output': None,
                'error': {
                    'code': 'ERROR',
                    'message': 'Test error'
                }
            }
        }
    }


# ============================================================================
# Executor Fixtures
# ============================================================================

@pytest.fixture
def mock_executor():
    """
    创建 MockExecutor for tests
    
    Yields:
        MockExecutor instance
    """
    from app.scheduler.executors.base_executor import BaseExecutor, NodeExecutionRequest, NodeExecutionResult
    
    class MockExecutor(BaseExecutor):
        def execute(self, request: NodeExecutionRequest) -> NodeExecutionResult:
            return NodeExecutionResult.success_result({'mock': 'result'})
    
    return MockExecutor()


# ============================================================================
# Retry Utils Fixtures
# ============================================================================

@pytest.fixture
def success_result():
    """
    创建成功结果
    
    Yields:
        NodeExecutionResult
    """
    from app.scheduler.models import NodeExecutionResult
    return NodeExecutionResult.success_result({'data': 'value'})


@pytest.fixture
def error_result():
    """
    创建错误结果
    
    Yields:
        NodeExecutionResult
    """
    from app.scheduler.models import NodeExecutionResult
    return NodeExecutionResult.error_result(
        error_code='TIMEOUT',
        error_message='Timeout error'
    )


# ============================================================================
# Helper Functions
# ============================================================================

def pytest_configure(config):
    """Pytest 配置"""
    config.addinivalue_line(
        "markers", "unit: mark test as unit test"
    )
    config.addinivalue_line(
        "markers", "integration: mark test as integration test"
    )
    config.addinivalue_line(
        "markers", "e2e: mark test as e2e test"
    )
