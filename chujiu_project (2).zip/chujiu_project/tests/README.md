# 测试目录结构说明

**更新日期**: 2026-03-14  
**参考标准**: Python 标准测试目录结构

---

## 📁 目录结构

```
tests/
├── conftest.py              # Pytest 全局 fixtures
├── unit/                    # 单元测试
│   ├── service/             # 服务层单元测试
│   └── api/                 # API 层单元测试
├── integration/             # 集成测试
├── bdd/                     # BDD 验收测试
│   ├── environment.py       # BDD 全局配置
│   ├── features/            # Gherkin 功能描述
│   └── steps/               # 步骤实现
└── e2e/                     # 端到端测试
```

---

## 📋 各目录职责

### 1. `unit/` - 单元测试

**目的**: 测试最小可测试单元（函数、类、方法）

| 子目录 | 测试对象 | 示例 |
|--------|---------|------|
| `service/` | 业务逻辑服务 | `test_task_service.py` |
| `api/` | API 路由和控制器 | `test_routes.py` |

**特点**:
- 快速执行（<100ms/用例）
- 隔离外部依赖（使用 mock）
- 高覆盖率要求（≥80%）

**示例**:
```python
# tests/unit/service/test_task_service.py
def test_create_task_with_valid_template():
    """用例：使用有效模板创建任务"""
    service = TaskService()
    result = service.create_task(template_id=1, upload_id=2)
    assert result.status == 'READY'
```

---

### 2. `integration/` - 集成测试

**目的**: 测试模块间交互和 API 端点

| 文件 | 测试内容 |
|------|---------|
| `test_api.py` | API 端点测试 |
| `conftest.py` | 测试 fixtures |

**特点**:
- 测试真实交互（数据库、文件系统）
- 中等执行速度（<1s/用例）
- 使用测试数据库（内存 SQLite）

**示例**:
```python
# tests/integration/test_api.py
def test_create_task_run(client, uploaded_file):
    """API-004: 测试创建任务运行"""
    response = client.post('/api/task-runs', json={
        'taskTemplateCode': 'excel_vba_to_wps_js',
        'uploadId': uploaded_file.id
    })
    assert response.status_code == 201
```

---

### 3. `bdd/` - BDD 验收测试

**目的**: 从用户角度验证功能是否符合需求

| 子目录 | 内容 |
|--------|------|
| `features/` | Gherkin 语法的功能描述 (.feature) |
| `steps/` | 步骤定义的 Python 实现 |
| `environment.py` | BDD 全局配置 |

**特点**:
- 使用 Gherkin 语法（Given/When/Then）
- 非技术人员可读
- 验证用户故事

**示例**:
```gherkin
# tests/bdd/features/task_creation.feature
Feature: 任务创建
  Scenario: 成功创建任务
    Given 用户已登录系统
    When 用户上传一个有效的 Excel 文件
    And 选择 "VBA 转 WPS JS" 模板
    Then 任务应该创建成功
```

```python
# tests/bdd/steps/task_creation_steps.py
@given('用户已登录系统')
def step_impl(context):
    context.user_logged_in = True

@when('用户上传一个有效的 Excel 文件')
def step_impl(context):
    context.file_uploaded = True
```

---

### 4. `e2e/` - 端到端测试

**目的**: 模拟真实用户操作，验证完整流程

**特点**:
- 使用真实浏览器（Playwright/Selenium）
- 测试完整用户流程
- 执行速度较慢（>5s/用例）

**示例**:
```python
# tests/e2e/test_task_flow.py
def test_complete_task_flow(page):
    """E2E-001: 完整任务流程"""
    page.goto('http://127.0.0.1:5001')
    page.click('#upload-btn')
    page.set_input_files('input[type=file]', 'test.xlsm')
    page.click('#create-task-btn')
    assert page.is_visible('.task-success')
```

---

## 🎯 测试金字塔

```
        /\
       /  \
      / BDD \      验收测试（少量）
     /--------\
    /Integration\   集成测试（适中）
   /--------------\
  /     Unit       \ 单元测试（大量）
 /------------------\
```

**推荐比例**:
- Unit: 70%
- Integration: 20%
- BDD/E2E: 10%

---

## 🚀 执行命令

```bash
# 运行所有测试
pytest tests/ -v

# 运行单元测试
pytest tests/unit/ -v

# 运行集成测试
pytest tests/integration/ -v

# 运行 BDD 测试
behave tests/bdd/

# 运行特定测试
pytest tests/integration/test_api.py::TestHealthAPI -v

# 生成覆盖率报告
pytest tests/ --cov=app --cov-report=html

# 生成 HTML 报告
pytest tests/ --html=report.html --self-contained-html
```

---

## 📝 命名规范

| 类型 | 命名模式 | 示例 |
|------|---------|------|
| 测试文件 | `test_*.py` | `test_task_service.py` |
| 测试类 | `Test*` | `TestTaskCreationService` |
| 测试函数 | `test_*` | `test_create_task_with_valid_template` |
| Feature 文件 | `*.feature` | `task_creation.feature` |
| Steps 文件 | `*_steps.py` | `task_creation_steps.py` |

---

## 📊 测试覆盖率要求

| 模块类型 | 覆盖率要求 |
|---------|-----------|
| 核心业务逻辑 | ≥80% |
| API 路由 | ≥70% |
| 工具函数 | ≥60% |
| 总体覆盖率 | ≥70% |

---

## 🔧 配置说明

### pytest.ini
```ini
[pytest]
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
```

### behave 配置
- 自动读取 `tests/bdd/environment.py`
- Feature 文件位于 `tests/bdd/features/`
- Steps 文件位于 `tests/bdd/steps/`

---

**文档维护**: Chujiu Design Team  
**最后更新**: 2026-03-14
