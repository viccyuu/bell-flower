# E2E Integration Test Guide

**Version**: 1.0  
**Date**: 2026-03-13  
**Status**: Ready for Execution

---

## 1. Overview

This directory contains end-to-end (E2E) integration tests for the Chujiu TodoList application.

### Test Types

| File | Type | Description |
|------|------|-------------|
| `conftest_e2e.py` | Fixtures | Selenium and Flask fixtures |
| `test_e2e_home_navigation.py` | E2E | Home page and navigation tests |
| `test_e2e_task_management.py` | E2E | Task management page tests |
| `test_e2e_upload_task.py` | E2E | File upload and task creation tests |
| `test_api_with_requests.py` | API | API endpoint tests with requests |
| `test_api_integration.py` | API | API integration tests |
| `test_dag_scheduler.py` | Unit | DAG scheduler tests |
| `test_plugin_engine_integration.py` | Integration | Plugin-engine integration tests |

---

## 2. Prerequisites

### 2.1 Install Dependencies

```bash
cd chujiu_project
pip install pytest requests selenium webdriver-manager
```

### 2.2 Start Flask Application

```bash
# Terminal 1: Start Flask app
py run.py
```

The app should be running on `http://127.0.0.1:5001`

---

## 3. Running Tests

### 3.1 Run All E2E Tests

```bash
# Run all E2E tests
pytest tests/integration/test_e2e_*.py -v
```

### 3.2 Run API Tests

```bash
# Run API tests with requests
pytest tests/integration/test_api_with_requests.py -v

# Run all API tests
pytest tests/integration/test_api_*.py -v
```

### 3.3 Run Specific Test

```bash
# Run specific test class
pytest tests/integration/test_e2e_home_navigation.py::TestHomePage -v

# Run specific test function
pytest tests/integration/test_e2e_home_navigation.py::TestHomePage::test_index_page_loads -v
```

### 3.4 Run with Coverage

```bash
# Generate coverage report
pytest tests/integration/ --cov=app --cov-report=html --cov-report=term
```

---

## 4. Test Structure

### 4.1 Fixtures (conftest_e2e.py)

```python
@pytest.fixture(scope="module")
def start_flask():
    """Start Flask app in background"""
    ...

@pytest.fixture(scope="module")
def browser():
    """Start Chrome browser with Selenium"""
    ...

@pytest.fixture
def base_url():
    """Return base URL"""
    return "http://127.0.0.1:5001"
```

### 4.2 Test Classes

```python
class TestHomePage:
    """Home page tests"""
    
    def test_index_page_loads(self, start_flask, browser, base_url):
        """Test index page loads"""
        browser.get(base_url)
        assert "Chujiu" in browser.title

class TestNavigation:
    """Navigation tests"""
    
    def test_navigation_click(self, start_flask, browser, base_url, page_name, page_id):
        """Test clicking navigation items"""
        ...
```

---

## 5. Test Categories

### 5.1 E2E Tests (Selenium)

| Test | Description | Status |
|------|-------------|--------|
| `test_index_page_loads` | Index page loads | ✅ |
| `test_health_status_displayed` | Health status shown | ✅ |
| `test_navigation_menu_exists` | Navigation menu exists | ✅ |
| `test_navigation_click` | Navigation click works | ✅ |
| `test_url_hash_changes` | URL hash updates | ✅ |
| `test_dashboard_loads` | Dashboard loads | ✅ |
| `test_health_page_loads` | Health page loads | ✅ |
| `test_upload_page_loads` | Upload page loads | ✅ |
| `test_upload_area_exists` | Upload area exists | ✅ |
| `test_create_task_from_upload` | Create task from upload | ✅ |
| `test_task_list_loads` | Task list page loads | ✅ |
| `test_task_list_shows_tasks` | Task list shows tasks | ✅ |
| `test_start_task_button` | Start task button exists | ✅ |

### 5.2 API Tests (Requests)

| Test | Description | Status |
|------|-------------|--------|
| `test_health_endpoint` | Health API | ✅ |
| `test_list_templates` | List templates | ✅ |
| `test_list_plugins` | List plugins | ✅ |
| `test_get_plugin_dag` | Get plugin DAG | ✅ |
| `test_list_prompts` | List prompts | ✅ |
| `test_create_task_run` | Create task | ✅ |
| `test_upload_file` | Upload file | ✅ |

---

## 6. Debugging Tests

### 6.1 Run with Verbose Output

```bash
pytest tests/integration/ -v -s
```

### 6.2 Run with Logging

```bash
pytest tests/integration/ --log-cli-level=INFO
```

### 6.3 Stop on First Failure

```bash
pytest tests/integration/ -x
```

### 6.4 Run Failed Tests Only

```bash
pytest tests/integration/ --lf
```

---

## 7. Common Issues

### 7.1 Chrome Driver Issues

**Error**: `Message: session not created`

**Solution**:
```bash
pip install --upgrade webdriver-manager
pip install --upgrade selenium
```

### 7.2 Flask Not Starting

**Error**: `Connection refused`

**Solution**:
```bash
# Check if port 5001 is in use
netstat -ano | findstr :5001

# Kill process if needed
taskkill /PID <PID> /F

# Restart Flask
py run.py
```

### 7.3 Test Timeout

**Error**: `TimeoutException`

**Solution**:
- Increase implicit wait time in `conftest_e2e.py`
- Check if Flask app is running
- Check if page elements exist

---

## 8. Adding New Tests

### 8.1 E2E Test Template

```python
def test_new_feature(self, start_flask, browser, base_url):
    """Test new feature"""
    browser.get(f"{base_url}/#feature")
    
    # Wait for element
    WebDriverWait(browser, 10).until(
        EC.presence_of_element_located((By.ID, "element-id"))
    )
    
    # Assert
    element = browser.find_element(By.ID, "element-id")
    assert element is not None
```

### 8.2 API Test Template

```python
def test_new_api(self):
    """Test new API endpoint"""
    response = requests.get(f'{API_BASE}/new-endpoint')
    assert response.status_code == 200
    data = response.json()
    assert data['code'] == 'OK'
```

---

## 9. Test Report

### 9.1 Generate HTML Report

```bash
pytest tests/integration/ --html=report.html --self-contained-html
```

### 9.2 Generate XML Report (for CI/CD)

```bash
pytest tests/integration/ --junitxml=test-results.xml
```

---

## 10. CI/CD Integration

### 10.1 GitHub Actions Example

```yaml
name: E2E Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.12'
      
      - name: Install dependencies
        run: |
          pip install -r requirements.txt
          pip install pytest selenium webdriver-manager
      
      - name: Start Flask
        run: |
          py run.py &
          sleep 5
      
      - name: Run E2E tests
        run: |
          pytest tests/integration/test_e2e_*.py -v --junitxml=test-results.xml
      
      - name: Upload test results
        uses: actions/upload-artifact@v3
        with:
          name: test-results
          path: test-results.xml
```

---

## 11. Best Practices

1. **Use fixtures** for common setup (browser, Flask app)
2. **Use WebDriverWait** instead of time.sleep()
3. **Use page objects** for complex pages
4. **Keep tests independent** - no test should depend on another
5. **Use descriptive test names** - `test_feature_does_something`
6. **Assert early and often** - catch failures quickly
7. **Clean up after tests** - close browser, delete test data

---

**Document History**:
- v1.0 (2026-03-13): Initial version
