# Playwright E2E 测试运行脚本

param (
    [switch]$Headed,          # 有头模式（显示浏览器）
    [switch]$Debug,           # 调试模式
    [string]$TestFile,        # 指定测试文件
    [switch]$Report           # 生成 HTML 报告
)

$projectRoot = $PSScriptRoot
$testArgs = @()

# 基础参数
$testArgs += "--maxfail=5"
$testArgs += "--tb=short"

# 有头模式
if ($Headed) {
    $testArgs += "--headed"
    Write-Host "🎭 运行模式：有头模式（显示浏览器）" -ForegroundColor Cyan
} else {
    Write-Host "🎭 运行模式：无头模式（后台运行）" -ForegroundColor Cyan
}

# 调试模式
if ($Debug) {
    $testArgs += "-s"
    $testArgs += "--timeout=0"
    Write-Host "🐛 调试模式：已启用" -ForegroundColor Yellow
}

# 指定测试文件
if ($TestFile) {
    $testArgs += $TestFile
    Write-Host "📄 测试文件：$TestFile" -ForegroundColor Cyan
} else {
    $testArgs += "tests/e2e/"
    Write-Host "📁 测试目录：tests/e2e/" -ForegroundColor Cyan
}

# HTML 报告
if ($Report) {
    $testArgs += "--html=tests/e2e/report.html"
    $testArgs += "--self-contained-html"
    Write-Host "📊 HTML 报告：tests/e2e/report.html" -ForegroundColor Cyan
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  开始运行 Playwright E2E 测试" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""

# 运行测试
Set-Location $projectRoot
py -m pytest $testArgs

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  测试执行完成" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
