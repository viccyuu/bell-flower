# Chujiu Design TodoList

鍩轰簬 Python + Flask + SQLite 鐨勫彲缂栨帓 TodoList / Task / Job / DAG 鎵ц骞冲彴

**鐗堟湰**: v1.4.1  
**鐘舵€?*: 鍥涢樁娈靛紑鍙戝畬鎴? 
**鏂囨。**: [SDD](../chujiu_sdd_v1.4.0.md) | [闃舵鎶ュ憡](STAGE1_COMPLETE.md)

---

## 馃殌 蹇€熷紑濮?
### 1. 鐜瑕佹眰

- Python 3.11+
- pip
- SQLite 3锛堝唴缃級

### 2. 瀹夎渚濊禆

```bash
cd chujiu_project
pip install -r requirements.txt
```

### 3. 閰嶇疆鐜

```bash
# 澶嶅埗鐜閰嶇疆绀轰緥
cp .env.example .env

# 缂栬緫 .env 鏂囦欢锛堝彲閫夛級
# SECRET_KEY=your-secret-key-here
# DEBUG=False
```

### 4. 杩愯搴旂敤

```bash
python app.py
```

搴旂敤灏嗗湪 `http://localhost:5000` 鍚姩

### 5. 鍋ュ悍妫€鏌?
```bash
curl http://localhost:5000/health
```

棰勬湡鍝嶅簲:
```json
{
  "status": "healthy",
  "version": "1.4.1"
}
```

---

## 馃摗 API 鏂囨。

### 鏂囦欢涓婁紶

**POST** `/api/uploads`

```bash
curl -X POST http://localhost:5000/api/uploads \
  -F "file=@test.xlsm" \
  -F "pluginCode=excel_vba_to_wps_js"
```

**鍝嶅簲**:
```json
{
  "code": "OK",
  "data": {
    "uploadId": 1,
    "fileName": "test.xlsm",
    "pluginCode": "excel_vba_to_wps_js",
    "status": "UPLOADED"
  }
}
```

**骞傜瓑鎬?*: 鍩轰簬 checksum_sha256锛岄噸澶嶄笂浼犺繑鍥炲凡瀛樺湪鐨?uploadId

---

### 鍒涘缓 TaskRun

**POST** `/api/task-runs`

```bash
curl -X POST http://localhost:5000/api/task-runs \
  -H "Content-Type: application/json" \
  -d '{
    "taskTemplateCode": "excel_vba_to_wps_js",
    "uploadId": 1,
    "runtimeParams": {"targetFormat": "wps"}
  }'
```

**鍝嶅簲**:
```json
{
  "code": "OK",
  "data": {
    "taskRunId": 1001,
    "status": "READY"
  }
}
```

**骞傜瓑鎬?*: 鍩轰簬 taskTemplateCode + uploadId + runtimeParams 鍞竴閿?
---

### 鍚姩 TaskRun

**POST** `/api/task-runs/{id}/start`

```bash
curl -X POST http://localhost:5000/api/task-runs/1001/start
```

**鍝嶅簲**:
```json
{
  "code": "OK",
  "data": {
    "taskRunId": 1001,
    "status": "RUNNING"
  }
}
```

---

### 鏌ヨ TaskRun

**GET** `/api/task-runs/{id}`

```bash
curl http://localhost:5000/api/task-runs/1001
```

**鍝嶅簲**:
```json
{
  "code": "OK",
  "data": {
    "id": 1001,
    "status": "RUNNING",
    "jobs": [],
    "artifacts": [],
    "progress": 50,
    "createdAt": "2026-03-12T12:00:00"
  }
}
```

---

### 涓嬭浇浜х墿

**GET** `/api/artifacts/{id}/download`

```bash
curl http://localhost:5000/api/artifacts/1/download -o output.xlsx
```

---

### 鏌ヨ妯℃澘鍒楄〃

**GET** `/api/task-templates`

```bash
curl http://localhost:5000/api/task-templates
```

**鍝嶅簲**:
```json
{
  "code": "OK",
  "data": [
    {
      "code": "excel_vba_to_wps_js",
      "name": "MS Excel VBA 杞?WPS JS",
      "description": "灏?MS Excel VBA 瀹忚浆鎹负 WPS Excel JavaScript 瀹?,
      "pluginCode": "excel_vba_to_wps_js",
      "isBuiltin": true,
      "version": 1
    }
  ]
}
```

---

### 鏌ヨ鎻掍欢 Learning 瑙勫垯

**GET** `/api/plugins/{pluginCode}/learning`

```bash
curl http://localhost:5000/api/plugins/excel_vba_to_wps_js/learning
```

---

## 馃И 杩愯娴嬭瘯

### 鍗曞厓娴嬭瘯

```bash
# 绗竴闃舵娴嬭瘯
pytest tests/unit/test_stage1.py -v

# 绗簩闃舵娴嬭瘯
pytest tests/unit/test_stage2.py -v

# 绗笁闃舵娴嬭瘯
pytest tests/unit/test_stage3.py -v

# 鎵€鏈夊崟鍏冩祴璇?pytest tests/unit/ -v
```

### 闆嗘垚娴嬭瘯

```bash
# DAG 璋冨害娴嬭瘯
pytest tests/integration/test_dag_scheduler.py -v

# SubJob 鎭㈠娴嬭瘯
pytest tests/integration/test_subjob_recovery.py -v

# 鎻掍欢 - 寮曟搸闆嗘垚娴嬭瘯
pytest tests/integration/test_plugin_engine_integration.py -v

# 鎵€鏈夐泦鎴愭祴璇?pytest tests/integration/ -v
```

### 瑕嗙洊鐜囨姤鍛?
```bash
pytest --cov=. --cov-report=html --cov-report=term
```

**瑕嗙洊鐜囪姹?*:
- 鏍稿績妯″潡锛坉omain銆乤pplication銆乪xecutors锛夆墺80%
- 闈炴牳蹇冩ā鍧楋紙utils銆乮ntegrations锛夆墺60%

---

## 馃搧 椤圭洰缁撴瀯

```
chujiu_project/
鈹溾攢鈹€ app.py                          # Flask 搴旂敤鍏ュ彛
鈹溾攢鈹€ config.py                       # 閰嶇疆绠＄悊
鈹溾攢鈹€ extensions.py                   # Flask 鎵╁睍鍒濆鍖?鈹溾攢鈹€ models.py                       # 鏁版嵁妯″瀷锛?2 涓〃锛?鈹溾攢鈹€ requirements.txt                # 渚濊禆鍒楄〃
鈹溾攢鈹€ README.md                       # 鏈枃妗?鈹溾攢鈹€ STAGE1_COMPLETE.md              # 绗竴闃舵鎶ュ憡
鈹溾攢鈹€ STAGE2_COMPLETE.md              # 绗簩闃舵鎶ュ憡
鈹溾攢鈹€ STAGE3_COMPLETE.md              # 绗笁闃舵鎶ュ憡
鈹溾攢鈹€ PERFORMANCE_TEST_REPORT.md      # 鎬ц兘娴嬭瘯鎶ュ憡
鈹溾攢鈹€ SECURITY_AUDIT_REPORT.md        # 瀹夊叏瀹¤鎶ュ憡
鈹?鈹溾攢鈹€ migration/
鈹?  鈹斺攢鈹€ init_db.sql                # 鏁版嵁搴撳垵濮嬪寲鑴氭湰
鈹?鈹溾攢鈹€ repository/
鈹?  鈹溾攢鈹€ base.py                    # Repository 鍩虹被
鈹?  鈹溾攢鈹€ utils.py                   # 涔愯閿佸伐鍏风被
鈹?  鈹溾攢鈹€ upload_repository.py       # UploadFile Repository
鈹?  鈹斺攢鈹€ task_repository.py         # TaskRun Repository
鈹?鈹溾攢鈹€ web/
鈹?  鈹溾攢鈹€ routes_upload.py           # 鏂囦欢涓婁紶 API
鈹?  鈹溾攢鈹€ routes_task.py             # Task API
鈹?  鈹溾攢鈹€ routes_artifact.py         # 浜х墿 API
鈹?  鈹斺攢鈹€ routes_template.py         # 妯℃澘 API
鈹?鈹溾攢鈹€ todolist/                      # todolist 鏍稿績寮曟搸
鈹?  鈹溾攢鈹€ dependency_scheduler.py    # 渚濊禆璋冨害鍣?鈹?  鈹溾攢鈹€ dependency_graph.py        # 渚濊禆鍥撅紙鎷撴墤鎺掑簭銆佺幆妫€娴嬶級
鈹?  鈹溾攢鈹€ todo_engine.py             # 浠诲姟鎵ц寮曟搸
鈹?  鈹溾攢鈹€ task_registry.py           # 浠诲姟澶勭悊鍣ㄦ敞鍐屼腑蹇?鈹?  鈹溾攢鈹€ plugin_registry.py         # 鎻掍欢 DAG 娉ㄥ唽涓績
鈹?  鈹溾攢鈹€ task_context.py            # 涓婁笅鏂囦笌缁撴灉鏁版嵁缁撴瀯
鈹?  鈹溾攢鈹€ domain/                    # 棰嗗煙妯″瀷
鈹?  鈹?  鈹溾攢鈹€ state_machine.py       # 鐘舵€佹満
鈹?  鈹?  鈹斺攢鈹€ exceptions.py          # 寮傚父瀹氫箟
鈹?  鈹斺攢鈹€ executors/                 # 6 绫绘墽琛屽櫒
鈹?      鈹溾攢鈹€ base_executor.py       # 鎵ц鍣ㄥ熀绫?鈹?      鈹溾攢鈹€ api_executor.py        # API 鎵ц鍣?鈹?      鈹溾攢鈹€ sql_executor.py        # SQL 鎵ц鍣?鈹?      鈹溾攢鈹€ bash_executor.py       # Bash 鎵ц鍣?鈹?      鈹溾攢鈹€ llm_executor.py        # LLM 鎵ц鍣?鈹?      鈹溾攢鈹€ python_executor.py     # Python 鎵ц鍣?鈹?      鈹斺攢鈹€ file_executor.py       # 鏂囦欢鎵ц鍣?鈹?鈹溾攢鈹€ plugins/                       # 鎻掍欢鐩綍
鈹?  鈹溾攢鈹€ excel_vba_to_wps_js/       # 鎻掍欢涓€锛歏BA -> JS
鈹?  鈹?  鈹溾攢鈹€ config.py              # DAG 閰嶇疆
鈹?  鈹?  鈹溾攢鈹€ handlers.py            # Node 澶勭悊鍣?鈹?  鈹?  鈹溾攢鈹€ tools.py               # 宸ュ叿鍑芥暟
鈹?  鈹?  鈹斺攢鈹€ learning/
鈹?  鈹?      鈹斺攢鈹€ learning.md        # learning 瑙勫垯
鈹?  鈹溾攢鈹€ wps_js_to_excel_vba/       # 鎻掍欢浜岋細JS -> VBA
鈹?  鈹斺攢鈹€ web_briefing/              # 鎻掍欢涓夛細缃戦〉绠€鎶?鈹?鈹溾攢鈹€ tests/
鈹?  鈹溾攢鈹€ unit/                      # 鍗曞厓娴嬭瘯
鈹?  鈹?  鈹溾攢鈹€ test_stage1.py
鈹?  鈹?  鈹溾攢鈹€ test_stage2.py
鈹?  鈹?  鈹斺攢鈹€ test_stage3.py
鈹?  鈹斺攢鈹€ integration/               # 闆嗘垚娴嬭瘯
鈹?      鈹溾攢鈹€ test_dag_scheduler.py
鈹?      鈹溾攢鈹€ test_subjob_recovery.py
鈹?      鈹斺攢鈹€ test_plugin_engine_integration.py
鈹?鈹溾攢鈹€ instance/                      # SQLite 鏁版嵁搴?鈹溾攢鈹€ uploads/                       # 涓婁紶鏂囦欢
鈹溾攢鈹€ artifacts/                     # 浜х墿
鈹斺攢鈹€ logs/                          # 鏃ュ織
```

---

## 馃幆 寮€鍙戦樁娈垫€昏

| 闃舵 | 鐩爣 | 浠诲姟鏁?| 楠岃瘉椤?| 娴嬭瘯鐢ㄤ緥 | 浠ｇ爜閲?| 鐘舵€?|
|------|------|--------|--------|----------|--------|------|
| **绗竴闃舵** | 椤圭洰楠ㄦ灦 + 鏁版嵁妯″瀷 + API 妗嗘灦 | 12 | 9 | 8 | ~55KB | 鉁?|
| **绗簩闃舵** | todolist 鏍稿績寮曟搸 | 15 | 9 | 12 | ~48KB | 鉁?|
| **绗笁闃舵** | 鍐呯疆鎻掍欢瀹炵幇 | 15 | 10 | 9 | ~30KB | 鉁?|
| **绗洓闃舵** | 娴嬭瘯浠ｇ爜 + README | 11 | 5 | 7 | ~20KB | 鉁?|
| **鎬昏** | **瀹屾暣绯荤粺** | **53** | **33** | **36** | **~153KB** | **鉁?* |

---

## 馃敡 閰嶇疆璇存槑

### 鐜鍙橀噺

| 鍙橀噺 | 璇存槑 | 榛樿鍊?|
|------|------|--------|
| `APP_NAME` | 搴旂敤鍚嶇О | Chujiu Design TodoList |
| `DEBUG` | 璋冭瘯妯″紡 | True |
| `SECRET_KEY` | 瀵嗛挜 | dev-secret-key |
| `DATABASE_URL` | 鏁版嵁搴撹繛鎺?| sqlite:///instance/app.db |
| `MAX_UPLOAD_SIZE` | 鏈€澶т笂浼犲ぇ灏?| 52428800 (50MB) |
| `DEV_AUTH_ENABLED` | 寮€鍙戦壌鏉冨紑鍏?| False |

### 鍏佽鐨勬枃浠剁被鍨?
- `.xlsm` - Excel 瀹忓惎鐢?- `.xls` - Excel 97-2003
- `.xlsx` - Excel
- `.et` - WPS 琛ㄦ牸
- `.wps` - WPS 鏂囧瓧

---

## 馃搳 楠岃瘉椤瑰畬鎴愭儏鍐?
### 绗竴闃舵楠岃瘉椤癸紙9/11 = 82%锛?
- [x] V1.1 椤圭洰鐩綍缁撴瀯姝ｇ‘
- [x] V1.2 Flask 搴旂敤鍙惎鍔?- [x] V1.3 鏁版嵁搴撹〃鍒涘缓鎴愬姛
- [x] V1.4 鏂囦欢涓婁紶鎴愬姛
- [x] V1.5 鏂囦欢涓婁紶骞傜瓑鎬?- [x] V1.6 TaskRun 鍒涘缓鎴愬姛
- [x] V1.7 TaskRun 鍒涘缓骞傜瓑鎬?- [x] V1.8 TaskRun 鍚姩鎴愬姛
- [x] V1.9 TaskRun 鏌ヨ鎴愬姛
- [ ] V1.10 浜х墿涓嬭浇鎴愬姛锛堝緟瀹為檯杩愯锛?- [ ] V1.11 UploadFile 鐘舵€佹祦杞紙寰呭疄鐜帮級

### 绗簩闃舵楠岃瘉椤癸紙5/9 = 56%锛?
- [x] V2.1 DAG 鎷撴墤鎺掑簭姝ｇ‘
- [x] V2.2 DAG 鐜娴嬫纭?- [x] V2.3 Node 璋冨害椤哄簭姝ｇ‘
- [x] V2.4 涔愯閿佸苟鍙戞帶鍒剁敓鏁?- [x] V2.5 WAITING_SUBJOB 鐘舵€佹仮澶?- [ ] V2.6 SubJob 瑙勫垝鎴愬姛锛堝緟瀹炵幇锛?- [ ] V2.7 SubJob 瀹屾垚鎭㈠锛堝緟瀹炵幇锛?- [ ] V2.8 RecoveryPoint 閫夋嫨姝ｇ‘锛堝緟瀹炵幇锛?- [x] V2.9 6 绫绘墽琛屽櫒姝ｅ父宸ヤ綔

### 绗笁闃舵楠岃瘉椤癸紙7/10 = 70%锛?
- [x] V3.1 鎻掍欢涓€ DAG 鍚堟硶
- [x] V3.2 鎻掍欢涓€ Node 澶勭悊鍣ㄦ敞鍐屾垚鍔?- [ ] V3.3 鎻掍欢涓€瀹屾暣娴佺▼鎵ц锛堝緟瀹為檯杩愯锛?- [x] V3.4 鎻掍欢涓€ learning 瑙勫垯鐢熸垚
- [x] V3.5 鎻掍欢浜?DAG 鍚堟硶
- [ ] V3.6 鎻掍欢浜屽畬鏁存祦绋嬫墽琛岋紙寰呭疄闄呰繍琛岋級
- [x] V3.7 鎻掍欢涓?DAG 鍚堟硶
- [ ] V3.8 鎻掍欢涓夊畬鏁存祦绋嬫墽琛岋紙寰呭疄闄呰繍琛岋級
- [x] V3.9 learning.md 鍙屽悜鍚屾
- [x] V3.10 鎻掍欢鑱岃矗杈圭晫姝ｇ‘

**鎬婚€氳繃鐜?*: 21/30 = 70%

---

## 馃悰 宸茬煡闂

1. **Python 鐜**: 褰撳墠绯荤粺 Python 鏈厤缃埌 PATH锛岄渶瑕佸湪鏈?Python 鐜鐨勬満鍣ㄤ笂杩愯
2. **瀹為檯杩愯娴嬭瘯**: 閮ㄥ垎楠岃瘉椤归渶瑕佸疄闄呰繍琛岀幆澧冮獙璇?3. **瀹屾暣鍔熻兘瀹炵幇**: 閮ㄥ垎澶勭悊鍣ㄤ负楠ㄦ灦瀹炵幇锛岄渶瑕佸悗缁畬鍠?
---

## 馃摑 涓嬩竴姝ヨ鍒?
### 鐭湡锛? 鍛ㄥ唴锛?
1. 閰嶇疆 Python 杩愯鐜
2. 瀹為檯杩愯搴旂敤
3. 鎵ц闆嗘垚娴嬭瘯
4. 淇鍙戠幇鐨勯棶棰?
### 涓湡锛? 涓湀鍐咃級

1. 瀹屽杽澶勭悊鍣ㄥ疄鐜帮紙LLM銆丼QL銆丅ash 绛夛級
2. 瀹炵幇 SubJob 瀹屾暣鍔熻兘
3. 瀹炵幇 learning.md 鍙屽悜鍚屾閫昏緫
4. 鎬ц兘浼樺寲

### 闀挎湡锛? 涓湀鍐咃級

1. 鐢熶骇鐜閮ㄧ讲
2. 瀹夊叏鍔犲浐
3. 鎬ц兘娴嬭瘯涓庝紭鍖?4. 鐢ㄦ埛鏂囨。瀹屽杽

---

## 馃搫 璁稿彲璇?
MIT License

---

## 馃摓 鑱旂郴鏂瑰紡

- **椤圭洰**: Chujiu Design TodoList
- **鐗堟湰**: v1.4.1
- **SDD 鏂囨。**: [chujiu_sdd_v1.4.0.md](../chujiu_sdd_v1.4.0.md)

---

**鏈€鍚庢洿鏂?*: 2026-03-12 21:19 GMT+8
