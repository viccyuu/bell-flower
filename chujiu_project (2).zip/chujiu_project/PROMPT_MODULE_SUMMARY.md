# 鎻愮ず璇嶇鐞嗘ā鍧?- 瀹炴柦鎬荤粨

## 鉁?宸插畬鎴?
### 1. 鏁版嵁妯″瀷璁捐
**鏂囦欢**: `app/models/prompts.py`

- **PromptCategory** (鎻愮ず璇嶅垎绫昏〃)
  - 鏀寔澶氱骇鍒嗙被锛坧arent_id锛?  - 瀛楁锛歝ode, name, description, sort_order
  
- **PromptTemplate** (鎻愮ず璇嶆ā鏉胯〃)
  - 鏀寔鐗堟湰绠＄悊
  - 鏀寔 Jinja2 妯℃澘鍙橀噺
  - 瀛楁锛歝ode, name, content, variables, version, enabled, is_system

### 2. API 璺敱
**鏂囦欢**: `app/routes/routes_prompts.py`

| 绔偣 | 鏂规硶 | 璇存槑 |
|------|------|------|
| `/api/prompt-categories` | GET | 鑾峰彇鍒嗙被鍒楄〃 |
| `/api/prompt-categories` | POST | 鍒涘缓鍒嗙被 |
| `/api/prompts` | GET | 鑾峰彇鎻愮ず璇嶅垪琛?|
| `/api/prompts/{id}` | GET | 鑾峰彇鎻愮ず璇嶈鎯?|
| `/api/prompts/code/{code}` | GET | 鏍规嵁浠ｇ爜鑾峰彇 |
| `/api/prompts` | POST | 鍒涘缓鎻愮ず璇?|
| `/api/prompts/{id}` | PUT | 鏇存柊鎻愮ず璇?|
| `/api/prompts/{id}` | DELETE | 鍒犻櫎鎻愮ず璇?|
| `/api/prompts/{id}/render` | POST | 娓叉煋鎻愮ず璇嶏紙鍙橀噺鏇挎崲锛?|

### 3. 棰勫畾涔夊垎绫?1. **excel_convert** - Excel 杞崲锛圴BA鈫擶PS JS锛?2. **code_review** - 浠ｇ爜瀹¤锛圓ST 瀹℃煡銆佹簮鐮佸鏌ワ級
3. **web_browse** - 缃戦〉娴忚锛堝唴瀹规彁鍙栥€佺畝鎶ョ敓鎴愶級
4. **general** - 閫氱敤

### 4. 棰勫畾涔夋彁绀鸿瘝
- `vba_to_ast` - VBA 杞?AST
- `ast_to_wps_js` - AST 杞?WPS JS
- `review_ast` - AST 瀹℃煡
- `review_source` - 婧愮爜瀹℃煡
- `extract_content` - 缃戦〉鍐呭鎻愬彇
- `summarize_briefing` - 绠€鎶ョ敓鎴?
## 馃摑 浣跨敤鏂规硶

### 鍦ㄦ彃浠朵腑璋冪敤鎻愮ず璇?
```python
import requests

# 鑾峰彇鎻愮ず璇?response = requests.get('http://127.0.0.1:5001/api/prompts/code/vba_to_ast')
prompt = response.json()['data']

# 娓叉煋鎻愮ず璇嶏紙鍙橀噺鏇挎崲锛?render_response = requests.post(
    f'http://127.0.0.1:5001/api/prompts/{prompt["id"]}/render',
    json={
        'variables': {
            'schema': '...',
            'code': 'VBA 婧愪唬鐮?
        }
    }
)

rendered_content = render_response.json()['data']['rendered_content']

# 璋冪敤 LLM
# llm_response = llm.generate(rendered_content)
```

## 鈿狅笍 寰呰В鍐抽棶棰?
鐢变簬 models 妯″潡瀵煎叆璺緞澶嶆潅锛岄渶瑕佺粺涓€澶勭悊锛?
1. `app/models.py` - 涓绘ā鍨嬫枃浠讹紙鍖呭惈 TaskRun, LearningRule 绛夛級
2. `app/models/prompts.py` - 鎻愮ず璇嶆ā鍨?3. `app/models/__init__.py` - 鍖呭垵濮嬪寲

**寤鸿鏂规**锛?- 灏嗘墍鏈夋ā鍨嬭縼绉诲埌 `app/models/` 鐩綍涓?- 鎴栬€呭皢 prompts 妯″瀷娣诲姞鍒?`app/models.py` 涓绘枃浠朵腑

## 馃И 娴嬭瘯鐢ㄤ緥

娴嬭瘯鐢ㄤ緥宸茶璁★紝寰呭鍏ラ棶棰樿В鍐冲悗娣诲姞鍒?`tests/integration/test_regression.py`

## 馃搳 鏁版嵁搴撹〃缁撴瀯

### prompt_category
```sql
CREATE TABLE prompt_category (
    id INTEGER PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    parent_id INTEGER REFERENCES prompt_category(id),
    sort_order INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### prompt_template
```sql
CREATE TABLE prompt_template (
    id INTEGER PRIMARY KEY,
    category_id INTEGER NOT NULL REFERENCES prompt_category(id),
    code VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    content TEXT NOT NULL,
    variables TEXT,  -- JSON
    version INTEGER DEFAULT 1,
    enabled BOOLEAN DEFAULT 1,
    is_system BOOLEAN DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

---

**鍒涘缓鏃堕棿**: 2026-03-13  
**鐘舵€?*: 璁捐瀹屾垚锛屽緟瀵煎叆闂淇鍚庡惎鐢?