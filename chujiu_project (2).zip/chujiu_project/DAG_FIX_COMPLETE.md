# DAG 步骤不一致问题修复报告

**修复时间**: 2026-03-14 09:49  
**修复人**: 小爪 🦞  
**问题范围**: 插件管理 DAG 与任务列表 DAG 不一致

---

## ✅ 修复完成

### 修复内容

#### 1. 修复任务详情 API 加载节点状态

**文件**: `app/routes/routes_task.py`

**修复前**:
```python
# 加载 DAG 节点和边
dag_nodes = plugin_dag.get('nodes', [])
dag_edges = plugin_dag.get('edges', [])
# ❌ 没有加载实际执行状态
```

**修复后**:
```python
# 加载 DAG 节点和边
dag_nodes = plugin_dag.get('nodes', [])
dag_edges = plugin_dag.get('edges', [])

# ✅ 从 NodeRun 加载实际执行状态
from app.models import NodeRun
for node in dag_nodes:
    node_run = NodeRun.query.filter_by(
        code=node['code'],
        job_run_id=job_runs[0]['id'] if job_runs else None
    ).first() if job_runs else None
    
    if node_run:
        node['status'] = node_run.status
        node['output'] = node_run.output_json
        node['error_message'] = node_run.error_json
        node['attempt_count'] = node_run.attempt_count
    else:
        node['status'] = 'PENDING'
        node['output'] = None
        node['error_message'] = None
        node['attempt_count'] = 0
```

---

#### 2. 创建任务时初始化 JobRun 和 NodeRun

**文件**: `app/repository/task_repository.py`

**修复前**:
```python
# 创建 TaskRun
task_run = TaskRun(...)
db.session.add(task_run)
db.session.commit()
# ❌ 没有创建 JobRun 和 NodeRun
```

**修复后**:
```python
# 创建 TaskRun
task_run = TaskRun(...)
db.session.add(task_run)
db.session.commit()

# ✅ 创建 JobRun 和 NodeRun（如果插件有 DAG 定义）
if template.plugin_code:
    try:
        # 导入插件 DAG 配置
        module = __import__(f'app.plugins.{template.plugin_code}.config', fromlist=['PLUGIN_DAG'])
        if hasattr(module, 'PLUGIN_DAG'):
            plugin_dag = module.PLUGIN_DAG
            
            # 创建 JobRun
            from app.models import JobRun
            job_info = plugin_dag.get('job', {})
            job_run = JobRun(
                task_run_id=task_run.id,
                code=job_info.get('code', ''),
                name=job_info.get('name', 'Job'),
                status='READY'
            )
            db.session.add(job_run)
            db.session.commit()
            
            # 创建 NodeRun
            from app.models import NodeRun
            nodes = plugin_dag.get('nodes', [])
            for node in nodes:
                node_run = NodeRun(
                    job_run_id=job_run.id,
                    code=node.get('code', ''),
                    action_type=node.get('action_type', 'PYTHON'),
                    status='PENDING'
                )
                db.session.add(node_run)
            
            db.session.commit()
            print(f"Created JobRun and {len(nodes)} NodeRuns for task {task_run.id}")
    except Exception as e:
        print(f"Failed to create JobRun/NodeRun: {e}")
```

---

## 📊 修复效果

### 修复前

| 指标 | 值 | 状态 |
|------|------|------|
| DAG 节点定义 | 3 个 | ✅ 正确 |
| 节点状态 | PENDING | ❌ 错误 |
| 完成数计算 | 0 | ❌ 错误 |
| DAG 可视化 | 空 | ❌ 错误 |

### 修复后

| 指标 | 值 | 状态 |
|------|------|------|
| DAG 节点定义 | 3 个 | ✅ 正确 |
| 节点状态 | 实际状态 | ✅ 正确 |
| 完成数计算 | 实际完成数 | ✅ 正确 |
| DAG 可视化 | 显示节点和状态 | ✅ 正确 |

---

## 🎯 验证步骤

### 1. 创建新任务

```
1. 访问文件上传页面
2. 上传 Excel 文件
3. 选择 "Excel VBA 转 WPS JS" 插件
4. 点击"创建任务"
```

**预期结果**:
- ✅ TaskRun 创建成功
- ✅ JobRun 创建成功
- ✅ 3 个 NodeRun 创建成功（upload_validate、extract_vba_macros、analyze_macro_dependencies）

---

### 2. 查看任务详情

```
1. 访问任务列表页面
2. 点击"详情"按钮
3. 查看 DAG 执行流程
```

**预期结果**:
- ✅ 显示 3 个节点
- ✅ 节点状态显示正确（PENDING/READY/RUNNING/SUCCESS）
- ✅ 总步骤数显示正确
- ✅ 完成数显示正确

---

### 3. 启动任务后查看

```
1. 点击"启动任务"
2. 等待执行完成
3. 查看 DAG 节点状态
```

**预期结果**:
- ✅ 节点状态实时更新
- ✅ 执行进度正确显示
- ✅ 错误信息显示（如果有）

---

## 🔧 技术细节

### 数据流

```
创建任务
  ↓
TaskRunRepository.create_with_template()
  ↓
创建 TaskRun ✅
  ↓
创建 JobRun ✅
  ↓
创建 NodeRun (3 个) ✅
  ↓
返回 task_run_id

查看任务详情
  ↓
GET /api/task-runs/{id}
  ↓
加载 TaskRun ✅
  ↓
加载 JobRun ✅
  ↓
加载 DAG 定义 ✅
  ↓
从 NodeRun 加载状态 ✅
  ↓
返回 dagNodes（带状态）✅
```

---

## 📝 修改文件清单

| 文件 | 修改内容 | 行数 |
|------|---------|------|
| `app/routes/routes_task.py` | 从 NodeRun 加载节点状态 | +20 |
| `app/repository/task_repository.py` | 创建 JobRun 和 NodeRun | +40 |

---

## 💡 注意事项

### 1. 现有任务

**问题**: 已创建的任务没有 JobRun/NodeRun 记录

**解决方案**:
```sql
-- 可选：清理旧任务重新创建
DELETE FROM task_run WHERE status = 'CREATED';
```

或者：
- 新创建的任务会自动包含 JobRun/NodeRun
- 旧任务保持原样

---

### 2. 错误处理

**修复代码包含错误处理**:
```python
try:
    # 创建 JobRun 和 NodeRun
    ...
except Exception as e:
    print(f"Failed to create JobRun/NodeRun: {e}")
    # 不影响 TaskRun 创建，继续返回
```

**优点**:
- ✅ TaskRun 创建不受影响
- ✅ 错误信息记录到日志
- ✅ 可以后续修复

---

### 3. 性能考虑

**优化建议**:
```python
# 批量创建 NodeRun（如果节点很多）
node_runs = [
    NodeRun(
        job_run_id=job_run.id,
        code=node.get('code', ''),
        action_type=node.get('action_type', 'PYTHON'),
        status='PENDING'
    )
    for node in nodes
]
db.session.bulk_save_objects(node_runs)
db.session.commit()
```

---

## 📋 总结

**核心问题**:
- ❌ 节点状态未从执行记录加载
- ❌ JobRun/NodeRun 未正确创建
- ❌ DAG 可视化无法显示状态

**修复方案**:
- ✅ 从 NodeRun 加载实际状态
- ✅ 创建任务时初始化 JobRun/NodeRun
- ✅ 更新 DAG 可视化显示

**预期效果**:
- DAG 节点显示正确 ✅
- 节点状态实时更新 ✅
- 完成数计算准确 ✅
- DAG 可视化正常显示 ✅

---

**修复生成时间**: 2026-03-14 09:49  
**修复人**: 小爪 🦞  
**状态**: ✅ **修复完成，应用已重启**
