# 测试覆盖率检查脚本
# 用法：.\run_coverage.ps1

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Chujiu TodoList 测试覆盖率检查" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 检查依赖
Write-Host "[1/2] 检查测试依赖..." -ForegroundColor Yellow
try {
    $null = Get-Command pytest -ErrorAction Stop
    $null = Get-Command coverage -ErrorAction Stop
    Write-Host "✅ pytest 和 coverage 已安装" -ForegroundColor Green
} catch {
    Write-Host "❌ 缺少依赖！安装命令：" -ForegroundColor Red
    Write-Host "   pip install pytest pytest-cov coverage" -ForegroundColor Gray
    exit 1
}

Write-Host ""

# 运行测试并生成覆盖率报告
Write-Host "[2/2] 运行测试并生成覆盖率报告..." -ForegroundColor Yellow
Write-Host ""

Set-Location $ProjectRoot

# 定义核心模块和非核心模块
$CoreModules = @(
    "repository",
    "todolist/domain",
    "todolist/application"
)

$NonCoreModules = @(
    "web",
    "plugins",
    "utils"
)

# 运行测试并生成覆盖率
try {
    # 生成 HTML 报告
    & coverage run -m pytest tests/ -v --tb=short
    & coverage html -d coverage_html
    & coverage report --fail-under=60
    
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  ✅ 覆盖率报告已生成！" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "查看报告：" -ForegroundColor Yellow
    Write-Host "   打开 coverage_html/index.html" -ForegroundColor Gray
    Write-Host ""
    
    exit 0
} catch {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Red
    Write-Host "  ❌ 测试失败或覆盖率不达标" -ForegroundColor Red
    Write-Host "========================================" -ForegroundColor Red
    Write-Host ""
    
    exit 1
}
