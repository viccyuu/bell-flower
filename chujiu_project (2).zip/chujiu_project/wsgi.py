﻿# -*- coding: utf-8 -*-

from app import create_app
from app.config import Settings

app = create_app(Settings)

if __name__ == "__main__":
    app.run()
