/**
 * WPS JavaScript 宏示例
 * 包含 Main 函数和常用 WPS API 操作
 */

// 主入口函数
function Main() {
    try {
        var workbook = Application.ActiveWorkbook;
        if (!workbook) {
            Console.log("错误：没有打开的工作簿");
            return;
        }
        
        Console.log("当前工作簿名称: " + workbook.Name);
        
        // 获取活动工作表
        var sheet = workbook.ActiveSheet;
        Console.log("当前工作表名称: " + sheet.Name);
        
        // 示例：写入数据到单元格
        WriteDataToSheet(sheet);
        
        // 示例：读取单元格数据
        ReadDataFromSheet(sheet);
        
        // 示例：格式化单元格
        FormatCells(sheet);
        
        Console.log("宏执行完成！");
        
    } catch (e) {
        Console.log("执行出错: " + e.message);
    }
}

// 写入数据到工作表
function WriteDataToSheet(sheet) {
    Console.log("开始写入数据...");
    
    // 设置表头
    sheet.Range("A1").Value = "序号";
    sheet.Range("B1").Value = "名称";
    sheet.Range("C1").Value = "数量";
    sheet.Range("D1").Value = "金额";
    
    // 写入数据行
    var data = [
        [1, "苹果", 10, 50.5],
        [2, "香蕉", 20, 30.0],
        [3, "橙子", 15, 45.0],
        [4, "葡萄", 8, 80.0],
        [5, "西瓜", 5, 100.0]
    ];
    
    for (var i = 0; i < data.length; i++) {
        var row = i + 2;
        sheet.Range("A" + row).Value = data[i][0];
        sheet.Range("B" + row).Value = data[i][1];
        sheet.Range("C" + row).Value = data[i][2];
        sheet.Range("D" + row).Value = data[i][3];
    }
    
    Console.log("数据写入完成，共 " + data.length + " 行");
}

// 从工作表读取数据
function ReadDataFromSheet(sheet) {
    Console.log("开始读取数据...");
    
    var lastRow = sheet.UsedRange.Rows.Count;
    var lastCol = sheet.UsedRange.Columns.Count;
    
    Console.log("数据范围: " + lastRow + " 行, " + lastCol + " 列");
    
    // 读取并显示数据
    for (var row = 1; row <= Math.min(lastRow, 6); row++) {
        var rowData = [];
        for (var col = 1; col <= lastCol; col++) {
            var cell = sheet.Cells(row, col);
            rowData.push(cell.Value || "");
        }
        Console.log("第 " + row + " 行: " + rowData.join(" | "));
    }
}

// 格式化单元格
function FormatCells(sheet) {
    Console.log("开始格式化单元格...");
    
    // 设置表头样式
    var headerRange = sheet.Range("A1:D1");
    headerRange.Font.Bold = true;
    headerRange.Font.Size = 12;
    headerRange.Interior.ColorIndex = 15; // 灰色背景
    
    // 设置列宽
    sheet.Columns("A").ColumnWidth = 8;
    sheet.Columns("B").ColumnWidth = 15;
    sheet.Columns("C").ColumnWidth = 10;
    sheet.Columns("D").ColumnWidth = 12;
    
    // 设置数字格式
    sheet.Range("D2:D6").NumberFormat = "#,##0.00";
    
    // 添加边框
    var dataRange = sheet.Range("A1:D6");
    dataRange.Borders.LineStyle = 1; // xlContinuous
    
    Console.log("格式化完成");
}

// 创建新工作表
function CreateNewSheet(workbook, sheetName) {
    try {
        var newSheet = workbook.Worksheets.Add();
        newSheet.Name = sheetName;
        Console.log("创建新工作表: " + sheetName);
        return newSheet;
    } catch (e) {
        Console.log("创建工作表失败: " + e.message);
        return null;
    }
}

// 保存工作簿
function SaveWorkbook(workbook, filePath) {
    try {
        if (filePath) {
            workbook.SaveAs(filePath);
            Console.log("工作簿已保存到: " + filePath);
        } else {
            workbook.Save();
            Console.log("工作簿已保存");
        }
    } catch (e) {
        Console.log("保存失败: " + e.message);
    }
}

// 获取当前时间字符串
function GetCurrentTime() {
    var now = new Date();
    return now.getFullYear() + "-" + 
           (now.getMonth() + 1).toString().padStart(2, '0') + "-" + 
           now.getDate().toString().padStart(2, '0') + " " +
           now.getHours().toString().padStart(2, '0') + ":" +
           now.getMinutes().toString().padStart(2, '0') + ":" +
           now.getSeconds().toString().padStart(2, '0');
}

// 打印工作簿信息
function PrintWorkbookInfo(workbook) {
    Console.log("=== 工作簿信息 ===");
    Console.log("名称: " + workbook.Name);
    Console.log("路径: " + workbook.Path);
    Console.log("工作表数量: " + workbook.Worksheets.Count);
    
    Console.log("工作表列表:");
    for (var i = 1; i <= workbook.Worksheets.Count; i++) {
        Console.log("  " + i + ". " + workbook.Worksheets(i).Name);
    }
}