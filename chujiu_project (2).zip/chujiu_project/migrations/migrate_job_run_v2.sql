-- 数据库迁移脚本
-- 版本：v2.0
-- 日期：2026-03-14
-- 说明：添加 JobRun 新字段支持双来源主 Job 和 SubJob

-- 添加 job_source 字段
ALTER TABLE job_run ADD COLUMN job_source VARCHAR(20) NOT NULL DEFAULT 'PLUGIN';

-- 添加 is_sub_job 字段
ALTER TABLE job_run ADD COLUMN is_sub_job BOOLEAN NOT NULL DEFAULT FALSE;

-- 添加 failed_node_code 字段
ALTER TABLE job_run ADD COLUMN failed_node_code VARCHAR(100);

-- 添加 error_context_json 字段
ALTER TABLE job_run ADD COLUMN error_context_json TEXT;

-- 添加 dag_json 字段
ALTER TABLE job_run ADD COLUMN dag_json TEXT;

-- 验证迁移
SELECT 
    COUNT(*) as total_jobs,
    SUM(CASE WHEN job_source = 'PLUGIN' THEN 1 ELSE 0 END) as plugin_jobs,
    SUM(CASE WHEN job_source = 'LLM' THEN 1 ELSE 0 END) as llm_jobs,
    SUM(CASE WHEN is_sub_job = TRUE THEN 1 ELSE 0 END) as subjobs
FROM job_run;
