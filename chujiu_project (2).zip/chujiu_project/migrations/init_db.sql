-- Chujiu Design TodoList 数据库初始化脚本
-- 版本：v1.4.1

-- 启用外键约束
PRAGMA foreign_keys = ON;

-- 用户表
CREATE TABLE IF NOT EXISTS user (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(80) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'user',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 上传文件表
CREATE TABLE IF NOT EXISTS upload_file (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    original_name VARCHAR(255) NOT NULL,
    stored_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    mime_type VARCHAR(100),
    size_bytes INTEGER NOT NULL,
    checksum_sha256 VARCHAR(64) NOT NULL,
    plugin_code VARCHAR(100) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'UPLOADED',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES user(id),
    INDEX idx_checksum (checksum_sha256)
);

-- 任务模板表
CREATE TABLE IF NOT EXISTS task_template (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    plugin_code VARCHAR(100),
    params_schema_json TEXT,
    is_builtin INTEGER NOT NULL DEFAULT 0,
    version INTEGER NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 任务运行实例表
CREATE TABLE IF NOT EXISTS task_run (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_template_id INTEGER NOT NULL,
    user_id INTEGER,
    upload_file_id INTEGER,
    status VARCHAR(20) NOT NULL DEFAULT 'CREATED',
    runtime_params_json TEXT,
    context_json TEXT,
    started_at DATETIME,
    finished_at DATETIME,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_template_id) REFERENCES task_template(id),
    FOREIGN KEY (user_id) REFERENCES user(id),
    FOREIGN KEY (upload_file_id) REFERENCES upload_file(id)
);

-- Job 模板表
CREATE TABLE IF NOT EXISTS job_template (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_template_id INTEGER NOT NULL,
    parent_job_template_id INTEGER,
    code VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    is_sub_job INTEGER NOT NULL DEFAULT 0,
    dag_json TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_template_id) REFERENCES task_template(id),
    FOREIGN KEY (parent_job_template_id) REFERENCES job_template(id),
    UNIQUE (task_template_id, code)
);

-- Job 运行实例表
CREATE TABLE IF NOT EXISTS job_run (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_run_id INTEGER NOT NULL,
    job_template_id INTEGER,
    parent_job_run_id INTEGER,
    code VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    source VARCHAR(20) NOT NULL DEFAULT 'TEMPLATE',
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    context_json TEXT,
    recovery_node_code VARCHAR(100),
    started_at DATETIME,
    finished_at DATETIME,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_run_id) REFERENCES task_run(id),
    FOREIGN KEY (job_template_id) REFERENCES job_template(id),
    FOREIGN KEY (parent_job_run_id) REFERENCES job_run(id)
);

-- Node 模板表
CREATE TABLE IF NOT EXISTS node_template (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_template_id INTEGER NOT NULL,
    code VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    action_type VARCHAR(20) NOT NULL,
    config_json TEXT NOT NULL,
    input_mapping_json TEXT,
    output_schema_json TEXT,
    retry_policy_json TEXT,
    continue_on_error INTEGER NOT NULL DEFAULT 0,
    timeout_seconds INTEGER,
    order_hint INTEGER,
    FOREIGN KEY (job_template_id) REFERENCES job_template(id),
    UNIQUE (job_template_id, code)
);

-- Edge 模板表（DAG 边）
CREATE TABLE IF NOT EXISTS edge_template (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_template_id INTEGER NOT NULL,
    from_node_code VARCHAR(100) NOT NULL,
    to_node_code VARCHAR(100) NOT NULL,
    condition_expr TEXT,
    FOREIGN KEY (job_template_id) REFERENCES job_template(id)
);

-- Node 运行实例表
CREATE TABLE IF NOT EXISTS node_run (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_run_id INTEGER NOT NULL,
    node_template_id INTEGER,
    code VARCHAR(100) NOT NULL,
    action_type VARCHAR(20) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    input_json TEXT,
    output_json TEXT,
    error_json TEXT,
    attempt_count INTEGER NOT NULL DEFAULT 0,
    version INTEGER NOT NULL DEFAULT 0,
    started_at DATETIME,
    finished_at DATETIME,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (job_run_id) REFERENCES job_run(id),
    FOREIGN KEY (node_template_id) REFERENCES node_template(id)
);

-- 产物表
CREATE TABLE IF NOT EXISTS artifact (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_run_id INTEGER NOT NULL,
    job_run_id INTEGER,
    node_run_id INTEGER,
    artifact_type VARCHAR(20) NOT NULL,
    name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500),
    content_text TEXT,
    content_json TEXT,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_run_id) REFERENCES task_run(id),
    FOREIGN KEY (job_run_id) REFERENCES job_run(id),
    FOREIGN KEY (node_run_id) REFERENCES node_run(id)
);

-- 执行日志表
CREATE TABLE IF NOT EXISTS execution_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_run_id INTEGER NOT NULL,
    job_run_id INTEGER,
    node_run_id INTEGER,
    level VARCHAR(10) NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    message TEXT NOT NULL,
    detail_json TEXT,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_run_id) REFERENCES task_run(id),
    FOREIGN KEY (job_run_id) REFERENCES job_run(id),
    FOREIGN KEY (node_run_id) REFERENCES node_run(id)
);

-- 学习规则表
CREATE TABLE IF NOT EXISTS learning_rule (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_run_id INTEGER NOT NULL,
    plugin_code VARCHAR(100) NOT NULL,
    error_id VARCHAR(50) NOT NULL,
    scenario TEXT NOT NULL,
    root_cause TEXT NOT NULL,
    forbidden_patterns TEXT NOT NULL,
    correct_patterns TEXT NOT NULL,
    markdown_content TEXT NOT NULL,
    file_path VARCHAR(500),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_run_id) REFERENCES task_run(id)
);

-- 插件 DAG 注册表
CREATE TABLE IF NOT EXISTS plugin_dag_registry (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    plugin_code VARCHAR(100) UNIQUE NOT NULL,
    dag_json TEXT NOT NULL,
    version INTEGER NOT NULL DEFAULT 1,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    registered_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_upload_file_checksum ON upload_file(checksum_sha256);
CREATE INDEX IF NOT EXISTS idx_task_template_code ON task_template(code);
CREATE INDEX IF NOT EXISTS idx_task_run_status ON task_run(status);
CREATE INDEX IF NOT EXISTS idx_job_run_status ON job_run(status);
CREATE INDEX IF NOT EXISTS idx_node_run_status ON node_run(status);
CREATE INDEX IF NOT EXISTS idx_execution_log_task_run ON execution_log(task_run_id);

-- 插入默认用户（匿名用户）
INSERT OR IGNORE INTO user (id, username, password_hash, role) VALUES (1, 'anonymous', 'anonymous', 'user');
