# 重试管理功能实施文档 ⭐

**实施日期**: 2026-03-16  
**版本**: 1.0.0  
**状态**: ✅ 完成

---

## 📋 实施概述

本次实施为 Chujiu Project 的 DAG 展示模块添加了完整的失败重试管理功能，包括：

- 单个节点重试
- 批量重试
- 重试历史查询
- 重试策略配置
- 可视化重试界面

---

## 📁 新增文件清单

### 后端文件

| 文件路径 | 类型 | 说明 | 行数 |
|---------|------|------|------|
| `app/schemas/retry.py` | Schema | 重试请求/响应模型 | 72 |
| `app/repository/retry_repository.py` | Repository | 重试数据访问层 | 172 |
| `app/routes/routes_retry.py` | Routes | 重试 API 路由 | 295 |

### 前端文件

| 文件路径 | 类型 | 说明 | 行数 |
|---------|------|------|------|
| `app/static/css/retry-manager.css` | CSS | 重试管理样式 | 373 |
| `app/static/js/retry-manager.js` | JavaScript | 重试管理模块 | 436 |
| `app/templates/modals/retry-modal.html` | HTML | 重试对话框模板 | 233 |

### 测试文件

| 文件路径 | 类型 | 说明 |
|---------|------|------|
| `tests/unit/retry/test_retry_manager.py` | 单元测试 | 重试功能测试用例 |

---

## 🔧 修改文件清单

| 文件路径 | 修改内容 |
|---------|---------|
| `app/templates/index.html` | 引入 retry-manager.css 和 retry-manager.js |
| `app/static/js/dag-viewer.js` | 集成重试按钮和回调函数 |
| `app/__init__.py` | 注册 retry_router |

---

## 🎯 功能特性

### 1. 单个节点重试

**API**: `POST /api/retry/nodes`

**请求**:
```json
{
  "task_run_id": 1,
  "node_code": "vba_to_ast",
  "retry_reason": "临时错误，请求重试"
}
```

**响应**:
```json
{
  "code": 200,
  "data": {
    "success": true,
    "message": "Node vba_to_ast has been queued for retry",
    "node_code": "vba_to_ast",
    "new_status": "RETRYING",
    "attempt_count": 2
  }
}
```

### 2. 批量重试

**API**: `POST /api/retry/nodes/batch`

**请求**:
```json
{
  "task_run_id": 1,
  "node_codes": ["node1", "node2", "node3"],
  "retry_reason": "批量重试失败节点"
}
```

**响应**:
```json
{
  "code": 200,
  "data": {
    "success_count": 3,
    "failed_count": 0,
    "results": [...]
  }
}
```

### 3. 重试历史查询

**API**: `GET /api/retry/history`

**参数**:
- `task_run_id`: 任务 ID（可选）
- `node_code`: 节点代码（可选）
- `limit`: 返回数量限制（默认 50）

**响应**:
```json
{
  "code": 200,
  "data": {
    "history": [
      {
        "id": 1,
        "task_run_id": 1,
        "node_code": "vba_to_ast",
        "node_name": "VBA to AST",
        "attempt_number": 2,
        "previous_status": "FAILED",
        "new_status": "RETRYING",
        "error_message": "Connection timeout",
        "retry_reason": "临时错误",
        "retried_at": "2026-03-16T06:30:00Z",
        "result_status": "SUCCESS"
      }
    ],
    "statistics": {
      "total_retries": 5,
      "successful_retries": 4,
      "failed_retries": 1,
      "success_rate": 0.8
    }
  }
}
```

### 4. 重试状态查询

**API**: `GET /api/retry/status/{task_run_id}/{node_code}`

**响应**:
```json
{
  "code": 200,
  "data": {
    "node_code": "vba_to_ast",
    "node_name": "VBA to AST",
    "current_status": "FAILED",
    "attempt_count": 1,
    "max_retries": 3,
    "can_retry": true,
    "last_error": "Connection timeout",
    "retry_policy": {
      "max_retries": 3,
      "backoff_seconds": 5,
      "retry_on": ["TIMEOUT", "LLM_TRANSIENT_ERROR"]
    }
  }
}
```

---

## 🎨 前端界面

### 重试对话框

包含以下模块：

1. **节点信息卡片**
   - 节点代码
   - 节点名称
   - 当前状态
   - 尝试次数

2. **错误信息显示**
   - 最后一次错误详情
   - 错误类型标识

3. **重试策略配置**
   - 最大重试次数
   - 重试间隔
   - 触发条件

4. **重试历史记录**
   - 历史重试列表
   - 状态变更追踪
   - 结果统计

### 视觉设计

- **状态颜色**:
  - 🟢 SUCCESS: `#10b981`
  - 🔴 FAILED: `#ef4444`
  - 🟡 RETRYING: `#f59e0b`
  - ⚪ PENDING: `#9ca3af`

- **动画效果**:
  - 重试按钮旋转动画
  - 对话框淡入淡出
  - Toast 提示自动消失

---

## 🧪 测试用例

### 单元测试覆盖

```
tests/unit/retry/test_retry_manager.py
├── TestRetryNode
│   ├── test_retry_node_success
│   ├── test_retry_node_not_found
│   └── test_retry_node_invalid_status
├── TestBatchRetry
│   └── test_batch_retry_success
├── TestRetryHistory
│   └── test_get_retry_history
└── TestRetryStatus
    └── test_get_retry_status
```

### 运行测试

```bash
cd C:\Users\yoyo\.openclaw\workspace\chujiu_design\chujiu_project
pytest tests/unit/retry/test_retry_manager.py -v
```

---

## 📊 集成流程

### 1. DAG 视图集成

```javascript
// 在 dag-viewer.js 中
function showNodeDetail(node) {
    if (node.status === 'FAILED' && window.retryManager) {
        window.retryManager.openRetryModal(taskRunId, node.code);
    }
}
```

### 2. 重试回调

```javascript
// 重试完成后自动刷新 DAG 视图
window.onNodeRetry = function(taskRunId) {
    setTimeout(() => {
        refreshDagView(taskRunId);
    }, 2000);
};
```

---

## ⚙️ 配置说明

### 重试策略配置

在节点定义中添加 `retry_policy_json`:

```json
{
  "code": "vba_to_ast",
  "action_type": "LLM",
  "retry_policy_json": {
    "max_retries": 3,
    "backoff_seconds": 5,
    "retry_on": ["TIMEOUT", "LLM_TRANSIENT_ERROR", "LLM_RESPONSE_INVALID"]
  }
}
```

### 环境变量（可选）

```bash
# 最大重试次数限制
RETRY_MAX_ATTEMPTS=10

# 重试间隔（秒）
RETRY_BACKOFF_SECONDS=5
```

---

## 🐛 已知问题

| 问题 | 影响 | 解决方案 | 状态 |
|------|------|---------|------|
| 重试历史使用内存存储 | 重启后丢失 | 后续迁移到数据库 | 待优化 |
| 批量重试缺少进度显示 | 用户体验 | 添加进度条 | 待增强 |
| 缺少重试通知 | 用户感知弱 | 添加 WebSocket 推送 | 待规划 |

---

## 📈 后续优化

### 短期（1 周）

- [ ] 将重试历史迁移到数据库存储
- [ ] 添加重试进度实时显示
- [ ] 优化移动端响应式布局

### 中期（1 月）

- [ ] 添加 WebSocket 实时通知
- [ ] 支持自动重试配置
- [ ] 重试统计报表

### 长期（3 月）

- [ ] 智能重试策略（基于错误类型）
- [ ] 重试成本分析
- [ ] 重试预测模型

---

## 📚 相关文档

- [DAG 调度 SDD](../SDD/dag_schedule/schedule_dag_sdd.md)
- [重试策略设计](../SDD/retry/retry_strategy_sdd.md) (待创建)
- [API 文档](../docs/api/retry_api.md) (待创建)

---

**实施人**: 小爪 🦞  
**审核人**: 待审核  
**批准日期**: 待批准
