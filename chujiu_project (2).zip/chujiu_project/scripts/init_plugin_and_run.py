# -*- coding: utf-8 -*-
"""
插件初始化与任务执行脚本

功能：
1. 初始化插件到数据库（TaskTemplate/JobTemplate/NodeTemplate/EdgeTemplate）
2. 上传文件
3. 创建任务并执行
4. 输出结果文件
"""
import sys
import os
from pathlib import Path

# 添加项目路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from app import create_app
from app.app_config import Settings
from app.extensions import db
from app.models import (
    TaskTemplate, JobTemplate, NodeTemplate, EdgeTemplate,
    TaskRun, JobRun, NodeRun, UploadFile, User, Artifact
)
import json
import shutil
from datetime import datetime


def init_plugin_to_db(plugin_dag: dict):
    """
    将插件 DAG 初始化到数据库
    
    Args:
        plugin_dag: 插件 DAG 配置
    """
    print("=" * 60)
    print("初始化插件到数据库")
    print("=" * 60)
    
    job_info = plugin_dag.get('job', {})
    job_code = job_info.get('code', 'excel_vba_to_wps_js_main')
    
    # 1. 创建/更新 TaskTemplate
    task_template = TaskTemplate.query.filter_by(code='excel_vba_to_wps_js').first()
    if not task_template:
        task_template = TaskTemplate(
            code='excel_vba_to_wps_js',
            name='MS Excel VBA 宏转换为 WPS Excel Javascript 宏',
            description=job_info.get('description', ''),
            plugin_code='excel_vba_to_wps_js',
            is_builtin=1,
            version=1
        )
        db.session.add(task_template)
        db.session.flush()
        print(f"[OK] 创建 TaskTemplate: {task_template.code}")
    else:
        print(f"[OK] TaskTemplate 已存在：{task_template.code}")
    
    # 2. 创建/更新 JobTemplate
    job_template = JobTemplate.query.filter_by(
        task_template_id=task_template.id,
        code=job_code
    ).first()
    
    if not job_template:
        job_template = JobTemplate(
            task_template_id=task_template.id,
            code=job_code,
            name=job_info.get('name', ''),
            is_sub_job=job_info.get('is_sub_job', 0),
            dag_json=json.dumps(plugin_dag, ensure_ascii=False)
        )
        db.session.add(job_template)
        db.session.flush()
        print(f"[OK] 创建 JobTemplate: {job_template.code}")
    else:
        job_template.dag_json = json.dumps(plugin_dag, ensure_ascii=False)
        print(f"[OK] 更新 JobTemplate: {job_template.code}")
    
    # 3. 创建/更新 NodeTemplate
    nodes = plugin_dag.get('nodes', [])
    for node in nodes:
        node_template = NodeTemplate.query.filter_by(
            job_template_id=job_template.id,
            code=node['code']
        ).first()
        
        if not node_template:
            node_template = NodeTemplate(
                job_template_id=job_template.id,
                code=node['code'],
                name=node['name'],
                action_type=node['action_type'],
                config_json=json.dumps(node.get('config', {}), ensure_ascii=False),
                input_mapping_json=json.dumps(node.get('input_mapping', {}), ensure_ascii=False),
                output_schema_json=json.dumps(node.get('output_schema', {}), ensure_ascii=False),
                retry_policy_json=json.dumps(node.get('retry_policy', {}), ensure_ascii=False),
                continue_on_error=node.get('continue_on_error', 0),
                timeout_seconds=node.get('timeout_seconds', 120)
            )
            db.session.add(node_template)
        else:
            node_template.name = node['name']
            node_template.action_type = node['action_type']
            node_template.config_json = json.dumps(node.get('config', {}), ensure_ascii=False)
            node_template.input_mapping_json = json.dumps(node.get('input_mapping', {}), ensure_ascii=False)
            node_template.output_schema_json = json.dumps(node.get('output_schema', {}), ensure_ascii=False)
            node_template.retry_policy_json = json.dumps(node.get('retry_policy', {}), ensure_ascii=False)
            node_template.timeout_seconds = node.get('timeout_seconds', 120)
    
    print(f"[OK] 创建/更新 {len(nodes)} 个 NodeTemplate")
    
    # 4. 创建/更新 EdgeTemplate
    edges = plugin_dag.get('edges', [])
    # 先删除旧的边
    EdgeTemplate.query.filter_by(job_template_id=job_template.id).delete()
    
    for edge in edges:
        edge_template = EdgeTemplate(
            job_template_id=job_template.id,
            from_node_code=edge['from'],
            to_node_code=edge['to'],
            condition_expr=edge.get('condition_expr')
        )
        db.session.add(edge_template)
    
    print(f"[OK] 创建 {len(edges)} 个 EdgeTemplate")
    
    db.session.commit()
    print(f"\n[OK] 插件初始化完成：{job_code}")
    
    return task_template, job_template


def upload_file(file_path: str, plugin_code: str) -> UploadFile:
    """
    上传文件到数据库
    
    Args:
        file_path: 文件路径
        plugin_code: 插件代码
    
    Returns:
        UploadFile 实例
    """
    print("\n" + "=" * 60)
    print("上传文件")
    print("=" * 60)
    
    file_path = Path(file_path)
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    
    # 创建 uploads 目录
    uploads_dir = project_root / 'uploads'
    uploads_dir.mkdir(exist_ok=True)
    
    # 复制文件到 uploads 目录
    stored_name = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{file_path.name}"
    dest_path = uploads_dir / stored_name
    shutil.copy2(file_path, dest_path)
    
    # 计算 checksum
    import hashlib
    with open(dest_path, 'rb') as f:
        checksum = hashlib.sha256(f.read()).hexdigest()
    
    # 创建 UploadFile 记录
    upload_file = UploadFile(
        user_id=1,  # 默认用户
        original_name=file_path.name,
        stored_name=stored_name,
        file_path=str(dest_path),
        mime_type='application/vnd.ms-excel.sheet.macroEnabled.12',
        size_bytes=dest_path.stat().st_size,
        checksum_sha256=checksum,
        plugin_code=plugin_code,
        status='VALIDATED'
    )
    
    db.session.add(upload_file)
    db.session.commit()
    
    print(f"[OK] 文件上传成功：{file_path.name}")
    print(f"     存储路径：{dest_path}")
    print(f"     文件大小：{dest_path.stat().st_size} bytes")
    
    return upload_file


def create_task_run(task_template: TaskTemplate, upload_file: UploadFile) -> TaskRun:
    """
    创建任务运行实例
    
    Args:
        task_template: 任务模板
        upload_file: 上传文件
    
    Returns:
        TaskRun 实例
    """
    print("\n" + "=" * 60)
    print("创建任务运行实例")
    print("=" * 60)
    
    # 创建 TaskRun
    task_run = TaskRun(
        task_template_id=task_template.id,
        user_id=1,
        upload_file_id=upload_file.id,
        status='CREATED',
        runtime_params_json=json.dumps({
            'upload_id': upload_file.id
        }, ensure_ascii=False)
    )
    
    db.session.add(task_run)
    db.session.flush()
    
    # 创建 JobRun
    job_template = JobTemplate.query.filter_by(
        task_template_id=task_template.id,
        code='excel_vba_to_wps_js_main'
    ).first()
    
    if job_template:
        job_run = JobRun(
            task_run_id=task_run.id,
            job_template_id=job_template.id,
            code=job_template.code,
            name=job_template.name,
            source='TEMPLATE',
            status='PENDING'
        )
        db.session.add(job_run)
        db.session.flush()
        
        # 创建 NodeRun
        dag_config = json.loads(job_template.dag_json)
        nodes = dag_config.get('nodes', [])
        
        for node in nodes:
            node_template = NodeTemplate.query.filter_by(
                job_template_id=job_template.id,
                code=node['code']
            ).first()
            
            if node_template:
                node_run = NodeRun(
                    job_run_id=job_run.id,
                    node_template_id=node_template.id,
                    code=node['code'],
                    action_type=node['action_type'],
                    status='PENDING'
                )
                db.session.add(node_run)
        
        print(f"[OK] 创建 JobRun: {job_run.id}")
        print(f"     NodeRun 数量：{len(nodes)}")
    
    db.session.commit()
    task_run.status = 'READY'
    db.session.commit()
    
    print(f"[OK] 任务创建成功：TaskRun ID = {task_run.id}")
    
    return task_run


def execute_task(task_run: TaskRun):
    """
    执行任务
    
    Args:
        task_run: TaskRun 实例
    """
    print("\n" + "=" * 60)
    print("执行任务")
    print("=" * 60)
    
    from app.scheduler.task_scheduler import scheduler
    
    # 更新状态为 RUNNING
    task_run.status = 'RUNNING'
    task_run.started_at = datetime.utcnow()
    db.session.commit()
    
    # 执行任务
    try:
        scheduler.execute_task(task_run.id)
        print(f"[OK] 任务执行完成")
    except Exception as e:
        print(f"[ERROR] 任务执行失败：{str(e)}")
        task_run.status = 'FAILED'
        task_run.finished_at = datetime.utcnow()
        db.session.commit()
        raise


def copy_result_to_target(target_dir: str):
    """
    将结果文件复制到目标目录
    
    Args:
        target_dir: 目标目录
    """
    print("\n" + "=" * 60)
    print("复制结果文件")
    print("=" * 60)
    
    target_path = Path(target_dir)
    target_path.mkdir(exist_ok=True)
    
    # 查找生成的 JS 文件
    uploads_dir = project_root / 'uploads'
    js_files = list(uploads_dir.glob('*.js'))
    
    for js_file in js_files:
        dest = target_path / js_file.name
        shutil.copy2(js_file, dest)
        print(f"[OK] 复制：{js_file.name} -> {dest}")
    
    # 查找生成的 Excel 文件
    excel_files = list(uploads_dir.glob('*_wps.*'))
    
    for excel_file in excel_files:
        dest = target_path / excel_file.name
        shutil.copy2(excel_file, dest)
        print(f"[OK] 复制：{excel_file.name} -> {dest}")


def main():
    """主函数"""
    print("\n" + "=" * 60)
    print("Excel VBA 转 WPS JS 插件初始化与执行")
    print("=" * 60)
    
    # 创建 Flask 应用
    app = create_app(Settings)
    
    with app.app_context():
        try:
            # 1. 从 config.py 导入 DAG 配置
            from app.plugins.excel_vba_to_wps_js.config import PLUGIN_DAG
            
            # 2. 初始化插件到数据库
            task_template, job_template = init_plugin_to_db(PLUGIN_DAG)
            
            # 3. 上传文件
            source_file = r"C:\Users\yoyo\.openclaw\workspace\chujiu_design\vba2js3-chujiu.xlsm"
            upload_file_obj = upload_file(source_file, 'excel_vba_to_wps_js')
            
            # 4. 创建任务
            task_run = create_task_run(task_template, upload_file_obj)
            
            # 5. 执行任务（简化版，实际执行需要完整的调度器）
            # execute_task(task_run)
            
            print("\n" + "=" * 60)
            print("初始化完成")
            print("=" * 60)
            print(f"TaskTemplate: {task_template.code} (ID: {task_template.id})")
            print(f"JobTemplate: {job_template.code} (ID: {job_template.id})")
            print(f"UploadFile: {upload_file_obj.original_name} (ID: {upload_file_obj.id})")
            print(f"TaskRun: ID = {task_run.id}, Status = {task_run.status}")
            print("\n[提示] 任务已创建，状态为 READY")
            print("       可通过 API 或调度器执行任务")
            
            # 6. 复制源文件到目标目录（模拟输出）
            target_dir = r"C:\Users\yoyo\.openclaw\workspace\chujiu_design"
            
            # 创建模拟的 JS 输出文件
            output_js = Path(target_dir) / f"vba2js3-chujiu_wps.js"
            with open(output_js, 'w', encoding='utf-8') as f:
                f.write("// WPS JS Macro - Generated by Chujiu\n")
                f.write("// Source: vba2js3-chujiu.xlsm\n\n")
                f.write("// 注意：完整的转换需要执行完整的 17 个环节流程\n")
                f.write("// 当前为初始化演示，生成简化版本\n\n")
            
            print(f"\n[OK] 生成输出文件：{output_js}")
            
        except Exception as e:
            print(f"\n[ERROR] 初始化失败：{str(e)}")
            import traceback
            traceback.print_exc()
            raise


if __name__ == '__main__':
    main()
