# -*- coding: utf-8 -*-
"""
执行已创建的任务
"""
import sys
from pathlib import Path

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from app import create_app
from app.app_config import Settings
from app.extensions import db
from app.models import TaskRun, JobRun, NodeRun
from app.scheduler.task_scheduler import scheduler
import shutil
from datetime import datetime


def main():
    """主函数"""
    print("\n" + "=" * 60)
    print("执行 VBA 转 JS 任务")
    print("=" * 60)
    
    app = create_app(Settings)
    
    with app.app_context():
        # 获取最新的 TaskRun
        task_run = TaskRun.query.filter_by(status='READY').order_by(TaskRun.id.desc()).first()
        
        if not task_run:
            print("[ERROR] 未找到 READY 状态的任务")
            return
        
        print(f"\n[OK] 找到任务：TaskRun ID = {task_run.id}")
        
        # 执行任务
        print("\n开始执行任务...")
        try:
            scheduler.execute_task(task_run.id)
            print(f"[OK] 任务执行完成")
        except Exception as e:
            print(f"[ERROR] 任务执行失败：{str(e)}")
            import traceback
            traceback.print_exc()
        
        # 刷新任务状态
        db.session.refresh(task_run)
        print(f"\n任务状态：{task_run.status}")
        
        # 查找生成的文件并复制到目标目录
        target_dir = Path(r"C:\Users\yoyo\.openclaw\workspace\chujiu_design")
        uploads_dir = project_root / 'uploads'
        
        print("\n" + "=" * 60)
        print("复制结果文件")
        print("=" * 60)
        
        # 复制 JS 文件
        js_files = list(uploads_dir.glob('*_wps.js'))
        for js_file in js_files:
            dest = target_dir / js_file.name
            shutil.copy2(js_file, dest)
            print(f"[OK] 复制：{js_file.name} -> {dest}")
        
        # 复制 Excel 文件
        excel_files = list(uploads_dir.glob('*_wps.*'))
        for excel_file in excel_files:
            dest = target_dir / excel_file.name
            shutil.copy2(excel_file, dest)
            print(f"[OK] 复制：{excel_file.name} -> {dest}")
        
        print("\n[OK] 所有操作完成")


if __name__ == '__main__':
    main()
