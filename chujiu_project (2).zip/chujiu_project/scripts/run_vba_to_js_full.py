# -*- coding: utf-8 -*-
"""
VBA 转 JS 完整执行脚本 - 使用新 Scheduler 模块 ⭐

要求：
1. 按照插件 excel_vba_to_wps_js 的 DAG 定义执行
2. 全部真实调用，不模拟（尤其是 LLM）
3. 使用 scheduler/executors/llm_executor.py
4. 使用 .chujiu/config.json 配置
"""
import sys
import json
import os
import asyncio
from pathlib import Path
from datetime import datetime, timezone

# 添加项目路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

# 设置环境变量
os.environ['PYTHONIOENCODING'] = 'utf-8'

from app.scheduler import (
    DagScheduler,
    ExecutorRegistry,
    PythonExecutor,
    LLMExecutor,
    FileExecutor,
    TodolistExecutor,
    InputResolver,
    OutputValidator
)
from app.plugins.excel_vba_to_wps_js.config import PLUGIN_DAG


class VbaToJsConverter:
    """VBA 转 JS 转换器 - 完整流程"""
    
    def __init__(self, source_file: str, target_dir: str):
        self.source_file = Path(source_file)
        self.target_dir = Path(target_dir)
        self.config_path = project_root / '.chujiu' / 'config.json'
        
        if not self.source_file.exists():
            raise FileNotFoundError(f"源文件不存在：{source_file}")
        
        self.target_dir.mkdir(parents=True, exist_ok=True)
        
        # 初始化组件
        self.input_resolver = InputResolver()
        self.output_validator = OutputValidator()
        self.executor_registry = self._create_executor_registry()
        self.scheduler = DagScheduler(executor_registry=self.executor_registry)
    
    def _create_executor_registry(self):
        """创建执行器注册表"""
        # 清除单例
        ExecutorRegistry._instance = None
        ExecutorRegistry._executors = {}
        
        registry = ExecutorRegistry()
        
        # 注册执行器
        registry.register('python_executor', PythonExecutor(
            input_resolver=self.input_resolver,
            output_validator=self.output_validator
        ))
        
        registry.register('llm_executor', LLMExecutor(
            input_resolver=self.input_resolver,
            output_validator=self.output_validator,
            config_path=self.config_path
        ))
        
        registry.register('file_executor', FileExecutor(
            input_resolver=self.input_resolver,
            output_validator=self.output_validator,
            base_dir=str(self.target_dir)
        ))
        
        registry.register('todolist_executor', TodolistExecutor(
            input_resolver=self.input_resolver,
            output_validator=self.output_validator,
            config_path=self.config_path
        ))
        
        print(f"[OK] 执行器注册表初始化完成")
        print(f"     已注册执行器：{registry.list_executors()}")
        
        return registry
    
    async def execute(self):
        """执行完整转换流程"""
        print("\n" + "=" * 60)
        print("VBA 转 JS - 完整流程执行")
        print("=" * 60)
        print(f"源文件：{self.source_file}")
        print(f"目标目录：{self.target_dir}")
        print(f"配置文件：{self.config_path}")
        
        # 1. 准备运行时上下文
        runtime_context = {
            'task': {
                'id': 1001,
                'vars': {
                    'file_path': str(self.source_file),
                    'output_name': self.source_file.stem,
                    'upload_id': 1
                }
            },
            'job': {
                'id': 2001,
                'vars': {}
            },
            'node': {}
        }
        
        # 2. 执行 DAG
        print("\n[开始执行 DAG]")
        result = self.scheduler.run(
            dag_def=PLUGIN_DAG,
            runtime_context=runtime_context,
            resume=False
        )
        
        # 3. 检查结果
        print("\n" + "=" * 60)
        print("执行结果")
        print("=" * 60)
        
        job_status = result['state']['job_status']
        print(f"Job 状态：{job_status}")
        
        # 打印节点状态
        print("\n节点状态:")
        for node_code, node_state in result['state']['nodes'].items():
            status = node_state['status']
            if status == 'SUCCESS':
                symbol = '[OK]'
            elif status == 'SKIPPED':
                symbol = '[SKIP]'
            else:
                symbol = '[FAIL]'
            print(f"  {symbol} {node_code}: {status}")
        
        # 4. 复制输出文件到目标目录
        if job_status == 'SUCCESS':
            js_source = None
            
            # 从 context 中获取 JS 源码
            if 'wps_js_ast_to_source' in result['context']['node']:
                js_source = result['context']['node']['wps_js_ast_to_source'].get('output', {}).get('wps_js_source')
            
            if js_source:
                # 写入文件
                output_file = self.target_dir / f"{self.source_file.stem}_wps.js"
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(js_source)
                
                print(f"\n[OK] JS 文件已生成：{output_file}")
                
                # 复制 Excel 文件
                import shutil
                excel_output = self.target_dir / f"{self.source_file.stem}_converted.xlsm"
                shutil.copy2(self.source_file, excel_output)
                print(f"[OK] Excel 文件已复制：{excel_output}")
            else:
                print("\n[WARN] 未找到 JS 源码")
        else:
            print(f"\n[ERROR] Job 执行失败：{job_status}")
        
        return result


async def main():
    """主函数"""
    source_file = r"C:\Users\yoyo\.openclaw\workspace\chujiu_design\vba2js3-chujiu.xlsm"
    target_dir = r"C:\Users\yoyo\.openclaw\workspace\chujiu_design"
    
    try:
        converter = VbaToJsConverter(source_file, target_dir)
        result = await converter.execute()
        
        return result['state']['job_status'] == 'SUCCESS'
    
    except Exception as e:
        print(f"\n[ERROR] 执行失败：{str(e)}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == '__main__':
    success = asyncio.run(main())
    
    print("\n" + "=" * 60)
    if success:
        print("[OK] VBA 转 JS 转换成功完成！")
    else:
        print("[ERROR] VBA 转 JS 转换失败！")
    print("=" * 60)
    
    sys.exit(0 if success else 1)
