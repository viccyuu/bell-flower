# 插件 DAG 配置修复报告

**修复时间**: 2026-03-14 09:52  
**修复人**: 小爪 🦞  
**设计依据**: three-plugins-dag-json-define.MD

---

## ✅ 已完成修复

### 1. excel_vba_to_wps_js 插件 ✅

**文件**: `app/plugins/excel_vba_to_wps_js/config.py`

**修复内容**:
- ✅ 更新为完整 17 节点 DAG 定义
- ✅ 添加 input_mapping 配置
- ✅ 添加 output_schema 配置
- ✅ 添加 retry_policy 配置
- ✅ 添加 condition_expr 条件边
- ✅ 启用 planning_enabled 用于 LLM 自主规划

**节点列表** (17 个):
1. upload_validate - 校验上传文件
2. extract_vba_macros - 提取 VBA 宏
3. analyze_macro_dependencies - 分析宏依赖
4. load_learning_rules - 加载学习规则
5. vba_to_vba_ast - VBA 转 AST (LLM, planning_enabled=True)
6. review_vba_ast - 审查 VBA AST (LLM)
7. vba_ast_to_canonical_ast - VBA AST 转 Canonical AST (LLM, planning_enabled=True)
8. review_canonical_ast - 审查 Canonical AST (LLM)
9. canonical_ast_to_wps_js_ast - Canonical AST 转 WPS JS AST (LLM, planning_enabled=True)
10. review_wps_js_ast - 审查 WPS JS AST (LLM)
11. wps_js_ast_to_source - WPS JS AST 转源码 (LLM, planning_enabled=True)
12. review_wps_js_source - 审查 WPS JS 源码 (LLM)
13. write_js_to_wps_file - 写入 WPS 文件 (PYTHON)
14. compare_results - 比对结果 (PYTHON)
15. generate_learning_rule_if_needed - 生成学习规则 (LLM, planning_enabled=True)
16. persist_learning_rule - 保存学习规则 (FILE)
17. publish_download_artifact - 发布产物 (FILE)

**边定义** (16 条):
- 包含条件边（condition_expr）
- 支持失败后生成 learning rule
- 支持重试机制

---

### 2. wps_js_to_excel_vba 插件 ⏳

**文件**: `app/plugins/wps_js_to_excel_vba/config.py`

**待修复**:
- ⏳ 更新为完整 17 节点 DAG 定义
- ⏳ 添加 input_mapping/output_schema
- ⏳ 添加 retry_policy
- ⏳ 添加 condition_expr

**计划节点** (17 个):
1. upload_validate
2. extract_js_macros
3. analyze_macro_dependencies
4. load_learning_rules
5. js_to_js_ast (LLM, planning_enabled=True)
6. review_js_ast (LLM)
7. js_ast_to_canonical_ast (LLM, planning_enabled=True)
8. review_canonical_ast (LLM)
9. canonical_ast_to_vba_ast (LLM, planning_enabled=True)
10. review_vba_ast (LLM)
11. vba_ast_to_source (LLM, planning_enabled=True)
12. review_vba_source (LLM)
13. write_vba_to_excel_file (PYTHON)
14. compare_results (PYTHON)
15. generate_learning_rule_if_needed (LLM, planning_enabled=True)
16. persist_learning_rule (FILE)
17. publish_download_artifact (FILE)

---

### 3. web_briefing 插件 ⏳

**文件**: `app/plugins/web_briefing/config.py`

**待修复**:
- ⏳ 更新为完整 6 节点 DAG 定义
- ⏳ 添加 input_mapping/output_schema
- ⏳ 添加 retry_policy

**计划节点** (6 个):
1. validate_input (PYTHON)
2. fetch_web_pages (PYTHON)
3. extract_clean_content (PYTHON)
4. summarize_with_llm (LLM)
5. save_report_file (FILE)
6. push_to_git_optional (PYTHON)

---

## 📊 DAG 结构对比

| 插件 | 设计节点数 | 当前节点数 | 状态 |
|------|-----------|-----------|------|
| excel_vba_to_wps_js | 17 | 17 | ✅ 完成 |
| wps_js_to_excel_vba | 17 | 3 | ⏳ 待更新 |
| web_briefing | 6 | 3 | ⏳ 待更新 |

---

## 🔧 任务运行模块修复

### routes_task.py ✅

**已修复**:
- ✅ 从 NodeRun 加载实际状态
- ✅ 返回 dagNodes 带 status 字段
- ✅ 返回 dagEdges

**代码**:
```python
# 从 NodeRun 加载实际状态
from app.models import NodeRun
for node in dag_nodes:
    node_run = NodeRun.query.filter_by(
        code=node['code'],
        job_run_id=job_runs[0]['id'] if job_runs else None
    ).first()
    
    if node_run:
        node['status'] = node_run.status
        node['output'] = node_run.output_json
        node['error_message'] = node_run.error_json
    else:
        node['status'] = 'PENDING'
```

---

### task_repository.py ✅

**已修复**:
- ✅ 创建 TaskRun 时自动创建 JobRun
- ✅ 根据 PLUGIN_DAG 创建 NodeRun
- ✅ 节点状态初始化为 PENDING

**代码**:
```python
# 创建 JobRun 和 NodeRun
if template.plugin_code:
    plugin_dag = module.PLUGIN_DAG
    
    # 创建 JobRun
    job_run = JobRun(task_run_id=task_run.id, ...)
    
    # 创建 NodeRun
    for node in plugin_dag['nodes']:
        node_run = NodeRun(
            job_run_id=job_run.id,
            code=node['code'],
            action_type=node['action_type'],
            status='PENDING'
        )
```

---

## 📝 后续工作

### 高优先级
1. ⏳ 更新 wps_js_to_excel_vba 插件配置
2. ⏳ 更新 web_briefing 插件配置
3. ⏳ 实现 handlers.py 中的处理函数
4. ⏳ 实现 LLM executor 支持 planning_enabled

### 中优先级
5. ⏳ 实现 condition_expr 条件边解析
6. ⏳ 实现 input_mapping 输入映射
7. ⏳ 实现 output_schema 验证
8. ⏳ 实现 retry_policy 重试机制

### 低优先级
9. ⏳ 实现 learning rule 自动生成
10. ⏳ 实现测试用例生成和执行
11. ⏳ 实现结果比对功能

---

## 🎯 验证步骤

### 1. 创建新任务
```
1. 访问文件上传页面
2. 上传 Excel 文件
3. 选择 "Excel VBA 转 WPS JS" 插件
4. 点击"创建任务"
```

**预期**:
- ✅ TaskRun 创建成功
- ✅ JobRun 创建成功
- ✅ 17 个 NodeRun 创建成功

### 2. 查看任务详情
```
1. 访问任务列表
2. 点击"详情"
3. 查看 DAG 执行流程
```

**预期**:
- ✅ 显示 17 个节点
- ✅ 节点状态正确显示
- ✅ 边显示正确（包括条件边）

### 3. 启动任务
```
1. 点击"启动任务"
2. 查看节点执行
3. 查看状态更新
```

**预期**:
- ✅ 节点按 DAG 顺序执行
- ✅ 状态实时更新
- ✅ 条件边正确判断

---

## 📋 总结

**已完成**:
- ✅ excel_vba_to_wps_js 插件 DAG 配置（17 节点）
- ✅ routes_task.py 从 NodeRun 加载状态
- ✅ task_repository.py 创建 JobRun/NodeRun

**待完成**:
- ⏳ wps_js_to_excel_vba 插件 DAG 配置
- ⏳ web_briefing 插件 DAG 配置
- ⏳ handlers.py 实现
- ⏳ executor 支持

**预期效果**:
- DAG 节点显示正确 ✅
- 节点状态实时更新 ✅
- 条件边正确执行 ⏳
- learning rule 自动生成 ⏳

---

**报告生成时间**: 2026-03-14 09:52  
**修复人**: 小爪 🦞  
**状态**: ⏳ **部分完成，继续修复中**
