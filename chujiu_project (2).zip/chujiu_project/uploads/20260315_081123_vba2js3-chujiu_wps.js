// -*- coding: utf-8 -*-
/**
 * WPS Excel JavaScript Macro
 * 源文件：vba2js3-chujiu.xlsm
 * 生成时间：2026-03-15 09:08:58
 * 转换工具：Chujiu VBA to WPS JS Converter
 * AST 类型：Program
 */

function Main() {
    var workbook = Application.ActiveWorkbook;
    if (!workbook) {
        console.log("未找到活动工作簿");
        return;
    }
    
    console.log("工作簿：" + workbook.Name);
    
    var worksheet = Application.ActiveSheet;
    if (worksheet) {
        console.log("工作表：" + worksheet.Name);
        worksheet.Range("A1").Value2 = "Hello from WPS JS!";
    }
}

function IterateWorksheets() {
    var workbook = Application.ActiveWorkbook;
    if (!workbook) return;
    
    for (var i = 0; i < workbook.Worksheets.Count; i++) {
        var ws = workbook.Worksheets.Item(i + 1);
        console.log("工作表 " + (i + 1) + ": " + ws.Name);
    }
}

function FormatRange(rangeAddr) {
    var ws = Application.ActiveSheet;
    if (!ws) return;
    
    var r = ws.Range(rangeAddr);
    r.Font.Bold = true;
    r.Font.Color = 0xFF0000;
    r.Interior.Color = 0xFFFF00;
}
