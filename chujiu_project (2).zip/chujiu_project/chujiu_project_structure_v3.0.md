# Chujiu Project - 项目目录结构 v3.0

**版本**: v3.0  
**更新日期**: 2026-03-15  
**状态**: ✅ FastAPI 迁移中  
**总文件数**: 185 个 Python 文件

---

## 📁 项目目录结构

```
chujiu_project/
│
├── 📄 run.py                              # 🚀 应用启动入口 (FastAPI + uvicorn)
├── 📄 requirements.txt                    # 📦 Python 依赖清单
├── 📄 pytest.ini                          # 🧪 Pytest 测试配置
├── 📄 pyproject.toml                      # 📋 项目配置
│
├── 📂 .chujiu/                            # ⚙️ 应用配置目录
│   ├── config.json                        # ✅ 核心配置 (LLM/API/数据库)
│   ├── cron/                              # ⏰ Cron 任务配置
│   ├── history/                           # 📜 执行历史
│   └── workspace/                         # 💼 工作空间
│       ├── memory/                        # 🧠 记忆存储
│       └── sessions/                      # 💬 会话存储
│
├── 📂 app/                                # 🎯 核心应用包
│   │
│   ├── 📄 __init__.py                     # ✅ FastAPI 应用工厂 (create_app)
│   ├── 📄 database.py                     # ✅ 异步数据库配置 (SQLAlchemy)
│   ├── 📄 models.py                       # ✅ 数据库模型定义
│   ├── 📄 extensions.py                   # ⚠️ Flask-SQLAlchemy 扩展 (待迁移)
│   │
│   ├── 📂 agent/                          # 🤖 LLM Agent 模块
│   │   ├── 📄 __init__.py                 # 模块初始化
│   │   ├── 📄 loop.py                     # ✅ Agent 循环 (LLM 调用核心)
│   │   ├── 📄 context.py                  # ✅ 上下文管理
│   │   ├── 📄 memory.py                   # ✅ 会话记忆管理
│   │   └── 📂 tools/                      # 🔧 Agent 工具
│   │       ├── 📄 __init__.py
│   │       ├── 📄 base.py                 # ✅ 工具基类
│   │       ├── 📄 filesystem.py           # ✅ 文件系统工具
│   │       ├── 📄 shell.py                # ✅ Shell 执行工具
│   │       ├── 📄 web.py                  # ✅ Web 搜索工具
│   │       ├── 📄 message.py              # ✅ 消息工具
│   │       ├── 📄 mcp.py                  # ⚠️ MCP 工具 (未使用)
│   │       ├── 📄 spawn.py                # ⚠️ 子进程工具 (未使用)
│   │       ├── 📄 cron.py                 # ⚠️ Cron 工具 (未使用)
│   │       └── 📄 registry.py             # ✅ 工具注册表
│   │
│   ├── 📂 config/                         # ⚙️ 配置模块
│   │   ├── 📄 __init__.py
│   │   ├── 📄 loader.py                   # ✅ 配置加载器
│   │   └── 📄 schema.py                   # ✅ Pydantic 配置模型
│   │
│   ├── 📂 cron/                           # ⏰ 定时任务模块
│   │   ├── 📄 __init__.py
│   │   ├── 📄 service.py                  # ✅ Cron 服务
│   │   ├── 📄 task_execution.py           # ✅ 任务执行
│   │   └── 📄 types.py                    # ✅ 类型定义
│   │
│   ├── 📂 heartbeat/                      # 💓 心跳服务模块
│   │   ├── 📄 __init__.py
│   │   ├── 📄 service.py                  # ✅ 心跳服务 (异步)
│   │   ├── 📄 task_query.py               # ✅ 任务查询
│   │   └── 📄 types.py                    # ✅ 类型定义
│   │
│   ├── 📂 plugins/                        # 🔌 插件系统
│   │   ├── 📄 __init__.py
│   │   ├── 📄 plugin_registry.py          # ✅ 插件注册表
│   │   │
│   │   ├── 📂 excel_vba_to_wps_js/        # ✅ VBA 转 JS 插件
│   │   │   ├── 📄 __init__.py
│   │   │   ├── 📄 config.py               # ✅ 插件配置 (DAG JSON)
│   │   │   ├── 📄 handler.py              # ✅ 处理函数实现
│   │   │   └── 📂 learning/               # 📚 学习规则
│   │   │       └── 📄 learning.md         # ✅ 学习规则文件
│   │   │
│   │   ├── 📂 wps_js_to_excel_vba/        # ✅ JS 转 VBA 插件
│   │   │   ├── 📄 __init__.py
│   │   │   ├── 📄 config.py               # ✅ 插件配置 (DAG JSON)
│   │   │   └── 📂 learning/
│   │   │       └── 📄 learning.md         # ✅ 学习规则文件
│   │   │
│   │   └── 📂 web_briefing/               # ✅ 网页简报插件
│   │       ├── 📄 __init__.py
│   │       ├── 📄 config.py               # ✅ 插件配置 (DAG JSON)
│   │       └── 📂 learning/
│   │           └── 📄 learning.md         # ✅ 学习规则文件
│   │
│   ├── 📂 providers/                      # 🌐 LLM Provider 模块
│   │   ├── 📄 __init__.py
│   │   ├── 📄 base.py                     # ✅ Provider 基类
│   │   ├── 📄 litellm_provider.py         # ✅ LiteLLM Provider
│   │   └── 📄 registry.py                 # ✅ Provider 注册表
│   │
│   ├── 📂 repository/                     # 💾 数据访问层
│   │   ├── 📄 __init__.py
│   │   ├── 📄 base.py                     # ✅ 仓库基类
│   │   ├── 📄 utils.py                    # ✅ 工具函数 (乐观锁)
│   │   ├── 📄 upload_repository.py        # ✅ 上传文件仓库
│   │   ├── 📄 task_repository.py          # ✅ 任务仓库
│   │   ├── 📄 node_repository.py          # ⚠️ 节点仓库 (未使用)
│   │   └── 📄 learning_repository.py      # ✅ 学习规则仓库
│   │
│   ├── 📂 routes/                         # 🛣️ API 路由
│   │   ├── 📄 __init__.py
│   │   ├── 📄 routes_task.py              # ✅ 任务 API (FastAPI 已迁移)
│   │   ├── 📄 routes_upload.py            # ✅ 上传 API (FastAPI 已迁移)
│   │   ├── 📄 routes_artifact.py          # ⚠️ 产物 API (Flask 待迁移)
│   │   ├── 📄 routes_template.py          # ⚠️ 模板 API (Flask 待迁移)
│   │   ├── 📄 routes_plugins.py           # ⚠️ 插件 API (Flask 待迁移)
│   │   ├── 📄 routes_prompts.py           # ⚠️ Prompt API (Flask 待迁移)
│   │   └── 📄 routes_subjob.py            # ⚠️ SubJob API (Flask 待迁移)
│   │
│   ├── 📂 scheduler/                      # 📅 任务调度器
│   │   ├── 📄 __init__.py
│   │   ├── 📄 task_scheduler.py           # ✅ 任务调度器 (核心)
│   │   └── 📄 error_recovery.py           # ⚠️ 错误恢复 (未使用)
│   │
│   ├── 📂 schemas/                        # 📋 Pydantic 模型 (FastAPI)
│   │   ├── 📄 __init__.py
│   │   ├── 📄 task.py                     # ✅ Task 模型
│   │   └── 📄 upload.py                   # ✅ Upload 模型
│   │
│   ├── 📂 todolist/                       # ⭐ 核心引擎 (17 环节)
│   │   ├── 📄 __init__.py
│   │   ├── 📄 llm_executor.py             # ✅ LLM 执行器 (核心)
│   │   ├── 📄 task_context.py             # ✅ 任务上下文
│   │   ├── 📄 input_mapping_resolver.py   # ✅ 输入映射解析器
│   │   │
│   │   ├── 📂 domain/                     # 领域层
│   │   │   ├── 📄 __init__.py
│   │   │   ├── 📄 dag.py                  # ✅ DAG 校验与拓扑排序
│   │   │   ├── 📄 state_machine.py        # ✅ 状态机定义
│   │   │   ├── 📄 enums.py                # ✅ 枚举定义
│   │   │   └── 📄 exceptions.py           # ✅ 异常定义
│   │   │
│   │   ├── 📂 executors/                  # 执行器层
│   │   │   ├── 📄 __init__.py
│   │   │   ├── 📄 base_executor.py        # ✅ 执行器基类
│   │   │   ├── 📄 python_executor.py      # ✅ Python 执行器
│   │   │   ├── 📄 llm_executor.py         # ✅ LLM 执行器
│   │   │   ├── 📄 file_executor.py        # ✅ 文件执行器
│   │   │   ├── 📄 api_executor.py         # ⚠️ API 执行器 (未使用)
│   │   │   ├── 📄 sql_executor.py         # ⚠️ SQL 执行器 (未使用)
│   │   │   └── 📄 bash_executor.py        # ⚠️ Bash 执行器 (未使用)
│   │   │
│   │   ├── 📂 utils/                      # 工具层
│   │   │   ├── 📄 __init__.py
│   │   │   └── 📄 helpers.py              # ✅ 辅助函数
│   │   │
│   │   └── 📂 integrations/               # 集成层
│   │       └── (空目录)                   # ⚠️ 未使用，可删除
│   │
│   ├── 📂 services/                       # 🔧 服务层
│   │   ├── 📄 __init__.py
│   │   └── 📄 task_execution.py           # ⚠️ 任务执行服务 (未使用)
│   │
│   ├── 📂 static/                         # 🎨 静态文件
│   │   ├── 📂 css/
│   │   │   └── 📄 style.css               # ⚠️ 样式文件 (未使用)
│   │   └── 📂 js/
│   │       ├── 📄 app.js                  # ⚠️ 前端应用 (未使用)
│   │       └── 📄 dag-viewer.js           # ⚠️ DAG 查看器 (未使用)
│   │
│   ├── 📂 templates/                      # 📄 HTML 模板
│   │   └── 📄 index.html                  # ⚠️ 首页模板 (未使用)
│   │
│   ├── 📂 artifacts/                      # 📦 产物存储
│   │   └── (自动创建)                     # ✅ 运行时创建
│   │
│   ├── 📂 uploads/                        # 📤 上传文件存储
│   │   └── (自动创建)                     # ✅ 运行时创建
│   │
│   ├── 📂 logs/                           # 📝 日志文件
│   │   └── (自动创建)                     # ✅ 运行时创建
│   │
│   ├── 📂 instance/                       # 🏛️ Flask 实例目录
│   │   └── (空目录)                       # ⚠️ Flask 遗留，可删除
│   │
│   └── 📂 utils/                          # 🔧 通用工具
│       └── (空目录)                       # ⚠️ 未使用，可删除
│
├── 📂 scripts/                            # 🛠️ 脚本工具
│   ├── 📄 run_17_nodes_fixed.py           # ✅ 17 环节执行脚本 (模拟)
│   ├── 📄 run_17_nodes_real_llm.py        # ✅ 17 环节执行脚本 (真实 LLM)
│   ├── 📄 run_17_nodes_real_sync.py       # ✅ 17 环节执行脚本 (同步)
│   ├── 📄 vba2js_17_steps_simple.py       # ✅ VBA 转 JS 简化版
│   ├── 📄 vba2js_17_steps_standalone.py   # ✅ VBA 转 JS 独立版
│   ├── 📄 vba2js_17_steps_final.py        # ✅ VBA 转 JS 最终版
│   ├── 📄 init_plugin_and_run.py          # ✅ 插件初始化脚本
│   ├── 📄 execute_task.py                 # ✅ 任务执行脚本
│   └── 📄 demo_convert.py                 # ✅ 演示转换脚本
│
├── 📂 tests/                              # 🧪 测试目录
│   ├── 📄 conftest.py                     # ✅ Pytest 配置 (异步 fixtures)
│   ├── 📄 test_async_config.py            # ✅ 异步配置测试
│   ├── 📄 test_llm_connection.py          # ✅ LLM 连接测试
│   │
│   ├── 📂 unit/                           # 单元测试
│   │   ├── 📄 test_stage1.py              # ✅ 项目骨架测试
│   │   ├── 📄 test_stage2.py              # ✅ 核心引擎测试
│   │   ├── 📄 test_stage3.py              # ✅ 插件实现测试
│   │   ├── 📂 api/                        # ⚠️ API 测试 (空目录)
│   │   ├── 📂 cron/                       # ⚠️ Cron 测试 (空目录)
│   │   ├── 📂 heartbeat/                  # ⚠️ Heartbeat 测试 (空目录)
│   │   ├── 📂 service/                    # ⚠️ 服务测试 (空目录)
│   │   └── 📂 todolist/                   # ⚠️ Todolist 测试 (空目录)
│   │
│   ├── 📂 integration/                    # 集成测试
│   │   ├── 📄 test_api.py                 # ⚠️ API 集成测试 (未使用)
│   │   ├── 📄 test_heartbeat_cron.py      # ✅ Heartbeat & Cron 测试
│   │   ├── 📂 bak/                        # ⚠️ 备份目录 (可删除)
│   │   └── 📂 integration_solution/       # ⚠️ 集成方案 (可删除)
│   │
│   ├── 📂 e2e/                            # E2E 测试
│   │   ├── 📄 conftest.py                 # ✅ E2E 测试配置
│   │   ├── 📄 test_tasks.py               # ⚠️ 任务测试 (未使用)
│   │   ├── 📄 test_plugins.py             # ⚠️ 插件测试 (未使用)
│   │   ├── 📄 test_prompts.py             # ⚠️ Prompt 测试 (未使用)
│   │   ├── 📄 test_upload.py              # ⚠️ 上传测试 (未使用)
│   │   ├── 📄 test_homepage.py            # ⚠️ 首页测试 (未使用)
│   │   ├── 📄 test_smoke.py               # ⚠️ 冒烟测试 (未使用)
│   │   ├── 📄 test_artifacts_standard.py  # ⚠️ 产物测试 (未使用)
│   │   ├── 📄 test_dashboard_standard.py  # ⚠️ 仪表板测试 (未使用)
│   │   ├── 📄 test_heartbeat_cron_e2e.py  # ⚠️ Heartbeat E2E (未使用)
│   │   ├── 📄 test_plugins_standard.py    # ⚠️ 插件标准测试 (未使用)
│   │   ├── 📄 test_prompts_standard.py    # ⚠️ Prompt 标准测试 (未使用)
│   │   ├── 📄 test_tasks_standard.py      # ⚠️ 任务标准测试 (未使用)
│   │   ├── 📄 test_tasks_full.py          # ⚠️ 任务完整测试 (未使用)
│   │   ├── 📄 test_tasks_simple.py        # ⚠️ 任务简单测试 (未使用)
│   │   ├── 📄 test_plugins_simple.py      # ⚠️ 插件简单测试 (未使用)
│   │   ├── 📄 test_plugins_full.py        # ⚠️ 插件完整测试 (未使用)
│   │   ├── 📄 test_prompts_simple.py      # ⚠️ Prompt 简单测试 (未使用)
│   │   ├── 📄 test_prompts_full.py        # ⚠️ Prompt 完整测试 (未使用)
│   │   ├── 📄 test_task_detail_standard.py# ⚠️ 任务详情测试 (未使用)
│   │   └── 📂 templates/                  # ⚠️ 测试模板 (可删除)
│   │
│   └── 📂 bdd/                            # BDD 测试
│       ├── 📄 environment.py              # ✅ BDD 环境配置
│       ├── 📄 __init__.py
│       ├── 📂 features/                   # Gherkin 特性文件
│       │   └── (空目录)                   # ⚠️ 未使用
│       └── 📂 steps/                      # 步骤定义
│           ├── 📄 __init__.py
│           ├── 📄 task_execution_steps.py # ✅ 任务执行步骤 (异步已改造)
│           ├── 📄 vba_to_wpsjs_conversion_steps.py  # ✅ VBA 转 JS 步骤 (异步已改造)
│           ├── 📄 file_upload_steps.py    # ✅ 文件上传步骤 (异步已改造)
│           ├── 📄 job_source_llm_steps.py # ✅ LLM Job 步骤 (异步已改造)
│           ├── 📄 job_source_plugin_steps.py# ✅ 插件 Job 步骤 (异步已改造)
│           ├── 📄 plugin_management_steps.py# ✅ 插件管理步骤 (异步已改造)
│           ├── 📄 subjob_planning_steps.py# ✅ SubJob 规划步骤 (异步已改造)
│           └── 📄 __init__.py
│
├── 📂 artifacts/                          # 📦 产物输出 (根目录)
│   └── (自动创建)                         # ✅ 运行时创建
│
├── 📂 learning/                           # 📚 学习规则 (根目录)
│   └── (空目录)                           # ⚠️ 未使用，可删除
│
├── 📂 logs/                               # 📝 日志文件 (根目录)
│   └── (自动创建)                         # ✅ 运行时创建
│
├── 📂 migrations/                         # 🔀 数据库迁移
│   └── (空目录)                           # ⚠️ Flask-Migrate 遗留，可删除
│
├── 📂 sessions/                           # 💬 会话存储 (根目录)
│   └── (空目录)                           # ⚠️ 未使用，可删除
│
├── 📂 uploads/                            # 📤 上传文件 (根目录)
│   └── (自动创建)                         # ✅ 运行时创建
│
├── 📂 .pytest_cache/                      # 🧪 Pytest 缓存
│   └── (自动创建)                         # ⚠️ 测试缓存，可忽略
│
├── 📂 htmlcov/                            # 📊 测试覆盖率报告
│   └── (自动创建)                         # ⚠️ 测试生成，可忽略
│
└── 📂 .idea/                              # 💡 PyCharm 配置
    └── (IDE 配置)                         # ⚠️ IDE 配置，可忽略
```

---

## 📊 文件统计

### 按类型统计

| 类型 | 数量 | 说明 |
|------|------|------|
| **Python 文件** | 185 | 总文件数 |
| **核心业务文件** | ~50 | 实际使用的业务代码 |
| **测试文件** | ~40 | 测试相关 |
| **脚本文件** | ~10 | 工具和脚本 |
| **未使用文件** | ~85 | 可清理或待迁移 |

### 按状态统计

| 状态 | 数量 | 百分比 |
|------|------|--------|
| ✅ **已使用/已迁移** | ~60 | 32% |
| ⚠️ **未使用/待迁移** | ~85 | 46% |
| 🗑️ **可删除** | ~40 | 22% |

---

## 🔑 核心文件说明

### 应用启动

| 文件 | 用途 | 状态 |
|------|------|------|
| `run.py` | 应用启动入口 (uvicorn) | ✅ FastAPI |
| `app/__init__.py` | FastAPI 应用工厂 | ✅ FastAPI |
| `app/database.py` | 异步数据库配置 | ✅ FastAPI |

### 核心业务

| 文件 | 用途 | 状态 |
|------|------|------|
| `app/todolist/llm_executor.py` | LLM 执行器 (17 环节核心) | ✅ 使用中 |
| `app/todolist/input_mapping_resolver.py` | 输入映射解析器 | ✅ 使用中 |
| `app/scheduler/task_scheduler.py` | 任务调度器 | ✅ 使用中 |
| `app/agent/loop.py` | Agent 循环 (LLM 调用) | ✅ 使用中 |

### 插件系统

| 文件/目录 | 用途 | 状态 |
|----------|------|------|
| `app/plugins/excel_vba_to_wps_js/` | VBA 转 JS 插件 | ✅ 使用中 |
| `app/plugins/wps_js_to_excel_vba/` | JS 转 VBA 插件 | ✅ 使用中 |
| `app/plugins/web_briefing/` | 网页简报插件 | ✅ 使用中 |
| `app/plugins/plugin_registry.py` | 插件注册表 | ✅ 使用中 |

### 测试相关

| 文件/目录 | 用途 | 状态 |
|----------|------|------|
| `tests/conftest.py` | Pytest 配置 (异步 fixtures) | ✅ 已改造 |
| `tests/bdd/steps/*.py` | BDD 步骤定义 (8 个文件) | ✅ 已改造 |
| `tests/unit/test_stage*.py` | 单元测试 | ✅ 已改造 |
| `tests/e2e/*.py` | E2E 测试 (15 个文件) | ⚠️ 未使用 |

---

## ⚠️ 未使用/待清理文件

### 可删除的文件和目录

| 文件/目录 | 原因 | 建议 |
|----------|------|------|
| `app/instance/` | Flask 遗留目录 | 🗑️ 删除 |
| `app/utils/` | 空目录 | 🗑️ 删除 |
| `app/todolist/integrations/` | 空目录 | 🗑️ 删除 |
| `learning/` | 根目录学习规则 (已移到 plugins) | 🗑️ 删除 |
| `migrations/` | Flask-Migrate 遗留 | 🗑️ 删除 |
| `sessions/` | 未使用 | 🗑️ 删除 |
| `tests/unit/api/` | 空目录 | 🗑️ 删除 |
| `tests/unit/cron/` | 空目录 | 🗑️ 删除 |
| `tests/unit/heartbeat/` | 空目录 | 🗑️ 删除 |
| `tests/unit/service/` | 空目录 | 🗑️ 删除 |
| `tests/unit/todolist/` | 空目录 | 🗑️ 删除 |
| `tests/integration/bak/` | 备份目录 | 🗑️ 删除 |
| `tests/integration/integration_solution/` | 旧方案 | 🗑️ 删除 |
| `tests/e2e/templates/` | 测试模板 | 🗑️ 删除 |
| `tests/e2e/test_*.py` (15 个) | E2E 测试 (未使用) | ⚠️ 保留或归档 |
| `app/static/*` | 前端文件 (未使用) | ⚠️ 保留或归档 |
| `app/templates/*` | HTML 模板 (未使用) | ⚠️ 保留或归档 |

### 待迁移到 FastAPI 的文件

| 文件 | 当前框架 | 迁移优先级 |
|------|---------|-----------|
| `app/extensions.py` | Flask-SQLAlchemy | 🔴 P0 |
| `app/routes/routes_artifact.py` | Flask | 🔴 P1 |
| `app/routes/routes_template.py` | Flask | 🔴 P1 |
| `app/routes/routes_plugins.py` | Flask | 🔴 P1 |
| `app/routes/routes_prompts.py` | Flask | 🔴 P1 |
| `app/routes/routes_subjob.py` | Flask | 🔴 P1 |

### 未使用的执行器

| 文件 | 用途 | 状态 |
|------|------|------|
| `app/todolist/executors/api_executor.py` | API 执行器 | ⚠️ 未使用 |
| `app/todolist/executors/sql_executor.py` | SQL 执行器 | ⚠️ 未使用 |
| `app/todolist/executors/bash_executor.py` | Bash 执行器 | ⚠️ 未使用 |

### 未使用的 Agent 工具

| 文件 | 用途 | 状态 |
|------|------|------|
| `app/agent/tools/mcp.py` | MCP 工具 | ⚠️ 未使用 |
| `app/agent/tools/spawn.py` | 子进程工具 | ⚠️ 未使用 |
| `app/agent/tools/cron.py` | Cron 工具 | ⚠️ 未使用 |

---

## 📈 迁移进度

### FastAPI 迁移

| 模块 | 总数 | 已迁移 | 未迁移 | 进度 |
|------|------|--------|--------|------|
| **应用工厂** | 1 | 1 | 0 | 100% ✅ |
| **数据库配置** | 1 | 1 | 0 | 100% ✅ |
| **核心路由** | 2 | 2 | 0 | 100% ✅ |
| **其他路由** | 5 | 0 | 5 | 0% ⏳ |
| **扩展配置** | 1 | 0 | 1 | 0% ⏳ |
| **总计** | 10 | 4 | 6 | 40% 🔄 |

### 测试异步化

| 测试类型 | 总数 | 已改造 | 未改造 | 进度 |
|---------|------|--------|--------|------|
| **单元测试** | 3 | 3 | 0 | 100% ✅ |
| **BDD 步骤** | 8 | 8 | 0 | 100% ✅ |
| **E2E 测试** | 15 | 0 | 15 | 0% ⏳ |
| **集成测试** | 2 | 1 | 1 | 50% 🔄 |
| **总计** | 28 | 12 | 16 | 43% 🔄 |

---

## 🎯 下一步行动

### 短期（1 周）

1. **完成 FastAPI 路由迁移**
   - [ ] `app/routes/routes_artifact.py`
   - [ ] `app/routes/routes_template.py`
   - [ ] `app/routes/routes_plugins.py`
   - [ ] `app/routes/routes_prompts.py`
   - [ ] `app/routes/routes_subjob.py`

2. **迁移 app/extensions.py**
   - [ ] 移除 Flask-SQLAlchemy
   - [ ] 使用 SQLAlchemy 异步 ORM

3. **清理可删除文件**
   - [ ] 删除空目录
   - [ ] 删除 Flask 遗留文件

### 中期（2 周）

1. **E2E 测试改造**
   - [ ] 异步化 E2E 测试
   - [ ] 或删除未使用的 E2E 测试

2. **性能优化**
   - [ ] 优化 LLM 调用
   - [ ] 数据库连接池优化

### 长期（1 月）

1. **代码重构**
   - [ ] 移除未使用的执行器
   - [ ] 移除未使用的 Agent 工具
   - [ ] 简化目录结构

---

## 📝 版本历史

| 版本 | 日期 | 变更说明 |
|------|------|---------|
| v1.0 | 2026-03-13 | 初始目录结构 |
| v2.0 | 2026-03-14 | 插件系统重构 |
| v3.0 | 2026-03-15 | FastAPI 迁移 + 用途标注 |

---

**文档维护人**: 小爪 🦞  
**最后更新**: 2026-03-15  
**项目状态**: 🔄 FastAPI 迁移中 (40%)
