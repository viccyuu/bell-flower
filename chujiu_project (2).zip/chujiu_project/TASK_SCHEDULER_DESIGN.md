# 任务运行模块增强设计

**设计时间**: 2026-03-14 09:54  
**设计人**: 小爪 🦞  
**设计目标**: 支持插件引入任务和 LLM 自主规划任务调度

---

## 📋 需求分析

### 1. 任务来源

#### 来源 1: 插件管理引入的任务
```
用户操作：
1. 上传文件
2. 选择插件（excel_vba_to_wps_js）
3. 点击"创建任务"

系统处理：
1. 从插件配置加载 PLUGIN_DAG
2. 创建 TaskRun
3. 根据 DAG 创建 JobRun
4. 根据 DAG nodes 创建 NodeRun（17 个）
5. 初始化节点状态为 PENDING
```

**特点**:
- ✅ DAG 结构固定（来自插件配置）
- ✅ 节点数量已知
- ✅ 输入输出 schema 已定义
- ✅ 支持条件边和重试策略

---

#### 来源 2: LLM 自主规划生成的任务（SubJob）
```
触发场景：
1. 节点执行失败
2. LLM 分析失败原因
3. LLM 生成恢复方案（SubJob DAG）
4. 创建 SubJob 执行
5. SubJob 完成后恢复主 Job

系统处理：
1. 接收 LLM 生成的 SubJob DAG
2. 动态创建 JobRun（is_sub_job=True）
3. 根据 SubJob DAG 创建 NodeRun
4. 执行 SubJob
5. 更新主 Job 状态
```

**特点**:
- ⏳ DAG 结构动态生成
- ⏳ 节点数量不固定
- ⏳ 需要 LLM executor 支持 planning_enabled
- ⏳ 需要 SubJob 调度机制

---

## 🔧 设计方案

### 方案 1: 完善插件引入任务处理

**修改文件**: `app/repository/task_repository.py`

**当前实现**:
```python
def create_with_template(self, template_code, upload_id, runtime_params):
    # 创建 TaskRun
    task_run = TaskRun(...)
    
    # 创建 JobRun 和 NodeRun
    if template.plugin_code:
        plugin_dag = module.PLUGIN_DAG
        # 创建 JobRun
        # 创建 NodeRun
```

**增强实现**:
```python
def create_with_template(self, template_code, upload_id, runtime_params):
    """
    根据模板创建 TaskRun（支持插件 DAG）
    
    Args:
        template_code: 模板代码
        upload_id: 上传文件 ID
        runtime_params: 运行时参数
    
    Returns:
        TaskRun 实例
    """
    # 1. 获取模板
    template = TaskTemplate.query.filter_by(code=template_code).first()
    
    # 2. 创建 TaskRun
    task_run = TaskRun(
        task_template_id=template.id,
        upload_file_id=upload_id,
        status='READY',
        runtime_params_json=json.dumps(runtime_params or {})
    )
    db.session.add(task_run)
    db.session.commit()
    
    # 3. 如果模板有关联插件，从插件加载 DAG
    if template.plugin_code:
        self._create_job_from_plugin_dag(task_run, template.plugin_code)
    
    return task_run


def _create_job_from_plugin_dag(self, task_run, plugin_code):
    """
    从插件 DAG 创建 JobRun 和 NodeRun
    
    Args:
        task_run: TaskRun 实例
        plugin_code: 插件编码
    """
    from app.models import JobRun, NodeRun
    
    # 1. 加载插件 DAG
    try:
        module = __import__(f'app.plugins.{plugin_code}.config', 
                          fromlist=['PLUGIN_DAG'])
        if not hasattr(module, 'PLUGIN_DAG'):
            return
        
        plugin_dag = module.PLUGIN_DAG
    except Exception as e:
        current_app.logger.warning(f'Failed to load plugin DAG: {e}')
        return
    
    # 2. 创建 JobRun
    job_info = plugin_dag.get('job', {})
    job_run = JobRun(
        task_run_id=task_run.id,
        code=job_info.get('code', f'{plugin_code}_job'),
        name=job_info.get('name', 'Job'),
        status='READY',
        is_sub_job=False
    )
    db.session.add(job_run)
    db.session.commit()
    
    # 3. 创建 NodeRun（根据 DAG nodes）
    nodes = plugin_dag.get('nodes', [])
    for node in nodes:
        node_run = NodeRun(
            job_run_id=job_run.id,
            code=node.get('code', ''),
            node_name=node.get('name', ''),
            node_type=node.get('action_type', 'PYTHON'),
            status='PENDING',
            input_mapping_json=json.dumps(node.get('input_mapping', {})),
            output_schema_json=json.dumps(node.get('output_schema', {})),
            config_json=json.dumps(node.get('config', {})),
            retry_policy_json=json.dumps(node.get('retry_policy', {})),
            timeout_seconds=node.get('timeout_seconds', 120)
        )
        db.session.add(node_run)
    
    db.session.commit()
    print(f"Created JobRun and {len(nodes)} NodeRuns for task {task_run.id}")
```

---

### 方案 2: 支持 LLM 自主规划生成 SubJob

**修改文件**: `app/routes/routes_subjob.py`

**新增 API**:
```python
@subjob_bp.route('/task-runs/<int:task_run_id>/subjobs', methods=['POST'])
def create_subjob(task_run_id):
    """
    创建 SubJob（LLM 自主规划）
    
    Request:
    {
        "parent_job_id": 1,
        "failed_node_code": "vba_to_vba_ast",
        "error_message": "LLM response invalid",
        "error_context": {
            "scenario": "VBA AST conversion failed",
            "node_output": {...}
        },
        "subjob_dag": {
            "job": {...},
            "nodes": [...],
            "edges": [...]
        }
    }
    
    Returns:
    {
        "code": "OK",
        "data": {
            "subjob_id": 2,
            "status": "CREATED"
        }
    }
    """
    data = request.get_json()
    
    # 1. 验证主任务存在
    task_run = task_run_repository.get(task_run_id)
    if not task_run:
        return jsonify({
            'code': 'TASK_RUN_NOT_FOUND',
            'message': f'TaskRun {task_run_id} not found'
        }), 404
    
    # 2. 验证父 Job 存在
    parent_job_id = data.get('parent_job_id')
    parent_job = JobRun.query.get(parent_job_id)
    if not parent_job:
        return jsonify({
            'code': 'JOB_RUN_NOT_FOUND',
            'message': f'JobRun {parent_job_id} not found'
        }), 404
    
    # 3. 获取 SubJob DAG（来自 LLM 规划）
    subjob_dag = data.get('subjob_dag')
    if not subjob_dag:
        return jsonify({
            'code': 'PARAMS_INVALID',
            'message': 'subjob_dag is required'
        }), 400
    
    # 4. 创建 SubJob
    from app.models import JobRun, NodeRun
    
    job_info = subjob_dag.get('job', {})
    subjob = JobRun(
        task_run_id=task_run.id,
        code=job_info.get('code', 'subjob'),
        name=job_info.get('name', 'SubJob'),
        status='CREATED',
        is_sub_job=True,
        parent_job_id=parent_job.id,
        failed_node_code=data.get('failed_node_code'),
        error_context_json=json.dumps(data.get('error_context', {}))
    )
    db.session.add(subjob)
    db.session.commit()
    
    # 5. 创建 SubJob 的 NodeRun
    nodes = subjob_dag.get('nodes', [])
    for node in nodes:
        node_run = NodeRun(
            job_run_id=subjob.id,
            code=node.get('code', ''),
            node_name=node.get('name', ''),
            node_type=node.get('action_type', 'PYTHON'),
            status='PENDING',
            input_mapping_json=json.dumps(node.get('input_mapping', {})),
            output_schema_json=json.dumps(node.get('output_schema', {})),
            config_json=json.dumps(node.get('config', {})),
            timeout_seconds=node.get('timeout_seconds', 120)
        )
        db.session.add(node_run)
    
    db.session.commit()
    
    return jsonify({
        'code': 'OK',
        'data': {
            'subjob_id': subjob.id,
            'status': subjob.status
        }
    }), 201


@subjob_bp.route('/subjobs/<int:subjob_id>/start', methods=['POST'])
def start_subjob(subjob_id):
    """
    启动 SubJob 执行
    
    Returns:
        JSON response
    """
    subjob = JobRun.query.get(subjob_id)
    if not subjob:
        return jsonify({
            'code': 'JOB_RUN_NOT_FOUND',
            'message': f'SubJob {subjob_id} not found'
        }), 404
    
    # 验证是 SubJob
    if not subjob.is_sub_job:
        return jsonify({
            'code': 'NOT_SUBJOB',
            'message': f'JobRun {subjob_id} is not a SubJob'
        }), 400
    
    # 更新状态为 RUNNING
    subjob.status = 'RUNNING'
    db.session.commit()
    
    # TODO: 触发调度器执行 SubJob
    # scheduler.execute_job(subjob)
    
    return jsonify({
        'code': 'OK',
        'data': {
            'subjob_id': subjob.id,
            'status': subjob.status
        }
    }), 200


@subjob_bp.route('/subjobs/<int:subjob_id>/complete', methods=['POST'])
def complete_subjob(subjob_id):
    """
    SubJob 完成回调
    
    Request:
    {
        "status": "SUCCESS" | "FAILED",
        "output": {...},
        "recovery_node_code": "vba_to_vba_ast"  # 恢复点
    }
    
    Returns:
        JSON response
    """
    data = request.get_json()
    
    subjob = JobRun.query.get(subjob_id)
    if not subjob:
        return jsonify({
            'code': 'JOB_RUN_NOT_FOUND',
            'message': f'SubJob {subjob_id} not found'
        }), 404
    
    # 更新 SubJob 状态
    subjob.status = data.get('status', 'SUCCESS')
    subjob.output_json = json.dumps(data.get('output', {}))
    db.session.commit()
    
    # 如果 SubJob 成功，恢复主 Job
    if data.get('status') == 'SUCCESS':
        recovery_node_code = data.get('recovery_node_code')
        
        # 更新主 Job 的失败节点状态
        if subjob.failed_node_code:
            failed_node = NodeRun.query.filter_by(
                job_run_id=subjob.parent_job_id,
                code=subjob.failed_node_code
            ).first()
            
            if failed_node:
                failed_node.status = 'READY'  # 重置为就绪状态
                db.session.commit()
        
        # 通知调度器继续执行主 Job
        # scheduler.resume_job(subjob.parent_job_id, recovery_node_code)
    
    return jsonify({
        'code': 'OK',
        'data': {
            'subjob_id': subjob.id,
            'status': subjob.status
        }
    }), 200
```

---

### 方案 3: 任务调度器增强

**新建文件**: `app/scheduler/task_scheduler.py`

```python
# -*- coding: utf-8 -*-
"""
Task Scheduler - 任务调度器

支持：
1. 插件引入任务调度
2. LLM 自主规划 SubJob 调度
3. 条件边判断
4. 重试策略
"""
from app.models import TaskRun, JobRun, NodeRun
from app.extensions import db
import json


class TaskScheduler:
    """任务调度器"""
    
    def __init__(self):
        pass
    
    def execute_task(self, task_run_id):
        """
        执行任务
        
        Args:
            task_run_id: TaskRun ID
        """
        task_run = TaskRun.query.get(task_run_id)
        if not task_run:
            return
        
        # 更新任务状态为 RUNNING
        task_run.status = 'RUNNING'
        db.session.commit()
        
        # 获取所有 JobRuns
        job_runs = JobRun.query.filter_by(task_run_id=task_run.id).all()
        
        for job_run in job_runs:
            if not job_run.is_sub_job:
                # 执行主 Job
                self.execute_job(job_run)
    
    def execute_job(self, job_run):
        """
        执行 Job
        
        Args:
            job_run: JobRun 实例
        """
        # 更新 Job 状态为 RUNNING
        job_run.status = 'RUNNING'
        db.session.commit()
        
        # 获取所有 NodeRuns
        node_runs = NodeRun.query.filter_by(job_run_id=job_run.id).all()
        
        # 构建 DAG
        dag_nodes = [node.code for node in node_runs]
        
        # 拓扑排序，获取执行顺序
        sorted_nodes = self._topological_sort(node_runs)
        
        # 按顺序执行节点
        for node_run in sorted_nodes:
            # 检查前置条件（条件边）
            if not self._check_conditions(node_run):
                node_run.status = 'SKIPPED'
                db.session.commit()
                continue
            
            # 执行节点
            self.execute_node(node_run)
            
            # 检查节点执行结果
            if node_run.status == 'FAILED':
                # 检查重试策略
                if self._should_retry(node_run):
                    self.retry_node(node_run)
                else:
                    # 触发 LLM 自主规划
                    if self._should_trigger_llm_planning(node_run):
                        self.trigger_llm_planning(job_run, node_run)
                    else:
                        # Job 失败
                        job_run.status = 'FAILED'
                        db.session.commit()
                        return
            
            # 检查 Job 是否完成
            if self._is_job_complete(job_run):
                job_run.status = 'SUCCESS'
                db.session.commit()
                break
    
    def execute_node(self, node_run):
        """
        执行节点
        
        Args:
            node_run: NodeRun 实例
        """
        # 更新状态为 RUNNING
        node_run.status = 'RUNNING'
        node_run.started_at = db.func.now()
        db.session.commit()
        
        # 根据节点类型选择执行器
        action_type = node_run.node_type
        
        if action_type == 'PYTHON':
            result = self._execute_python_node(node_run)
        elif action_type == 'LLM':
            result = self._execute_llm_node(node_run)
        elif action_type == 'FILE':
            result = self._execute_file_node(node_run)
        elif action_type == 'API':
            result = self._execute_api_node(node_run)
        else:
            result = {'status': 'FAILED', 'error': f'Unknown action type: {action_type}'}
        
        # 更新节点状态
        if result.get('status') == 'SUCCESS':
            node_run.status = 'SUCCESS'
            node_run.output_json = json.dumps(result.get('output', {}))
        else:
            node_run.status = 'FAILED'
            node_run.error_json = json.dumps(result.get('error', {}))
        
        node_run.finished_at = db.func.now()
        node_run.attempt_count += 1
        db.session.commit()
    
    def _execute_llm_node(self, node_run):
        """
        执行 LLM 节点（支持 planning_enabled）
        
        Args:
            node_run: NodeRun 实例
        
        Returns:
            dict: {status: 'SUCCESS' | 'FAILED', output: {...}, error: str}
        """
        # 解析配置
        config = json.loads(node_run.config_json or '{}')
        
        # 检查是否启用自主规划
        planning_enabled = config.get('planning_enabled', False)
        
        if planning_enabled:
            # LLM 可以生成 SubJob
            # 调用 llm_executor，传入 planning_enabled=True
            # 如果 LLM 返回需要 SubJob，创建 SubJob 并等待完成
            pass
        
        # TODO: 调用 llm_executor
        return {'status': 'SUCCESS', 'output': {}}
    
    def trigger_llm_planning(self, job_run, failed_node):
        """
        触发 LLM 自主规划（生成 SubJob）
        
        Args:
            job_run: JobRun 实例
            failed_node: 失败的 NodeRun 实例
        """
        # 1. 准备错误上下文
        error_context = {
            'node_code': failed_node.code,
            'node_name': failed_node.node_name,
            'error': json.loads(failed_node.error_json or '{}'),
            'input': json.loads(failed_node.input_mapping_json or '{}'),
            'task_run_id': job_run.task_run_id
        }
        
        # 2. 调用 LLM 生成恢复方案
        # TODO: 调用 llm_executor 生成 SubJob DAG
        
        # 3. LLM 返回 SubJob DAG
        # subjob_dag = llm_response.get('subjob_dag')
        
        # 4. 创建 SubJob
        # create_subjob(job_run, failed_node, error_context, subjob_dag)
        pass
    
    def _topological_sort(self, node_runs):
        """拓扑排序，返回执行顺序"""
        # TODO: 实现 DAG 拓扑排序
        return node_runs
    
    def _check_conditions(self, node_run):
        """检查条件边"""
        # TODO: 解析 condition_expr 并判断
        return True
    
    def _should_retry(self, node_run):
        """检查是否应该重试"""
        retry_policy = json.loads(node_run.retry_policy_json or '{}')
        max_retries = retry_policy.get('max_retries', 0)
        return node_run.attempt_count < max_retries
    
    def _should_trigger_llm_planning(self, node_run):
        """检查是否应该触发 LLM 自主规划"""
        # TODO: 根据节点配置和错误类型判断
        config = json.loads(node_run.config_json or '{}')
        return config.get('planning_enabled', False)
    
    def _is_job_complete(self, job_run):
        """检查 Job 是否完成"""
        # TODO: 检查所有节点是否执行完成
        return True


# 全局调度器实例
scheduler = TaskScheduler()
```

---

## 📊 数据流

### 插件引入任务
```
创建任务 API
  ↓
task_repository.create_with_template()
  ↓
_create_job_from_plugin_dag()
  ↓
加载 PLUGIN_DAG
  ↓
创建 JobRun + NodeRun（17 个）
  ↓
scheduler.execute_task()
  ↓
按 DAG 顺序执行节点
```

### LLM 自主规划任务
```
节点执行失败
  ↓
trigger_llm_planning()
  ↓
调用 LLM 生成 SubJob DAG
  ↓
create_subjob API
  ↓
创建 SubJob (is_sub_job=True)
  ↓
scheduler.execute_job(subjob)
  ↓
SubJob 完成
  ↓
complete_subjob API
  ↓
恢复主 Job 执行
```

---

## 📝 总结

**已完成**:
- ✅ 插件引入任务处理设计
- ✅ LLM 自主规划 SubJob 设计
- ✅ 任务调度器设计

**待实施**:
- ⏳ 实现 task_repository._create_job_from_plugin_dag
- ⏳ 实现 routes_subjob.create_subjob
- ⏳ 实现 scheduler.TaskScheduler
- ⏳ 实现 LLM executor 支持 planning_enabled

---

**设计生成时间**: 2026-03-14 09:54  
**设计人**: 小爪 🦞  
**状态**: ⏳ **设计完成，待实施**
