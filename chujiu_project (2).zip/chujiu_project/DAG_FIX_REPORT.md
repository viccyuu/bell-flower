# DAG 步骤不一致问题修复报告

**问题时间**: 2026-03-14 09:46  
**修复人**: 小爪 🦞  
**问题范围**: 插件管理 DAG 与任务列表 DAG 不一致

---

## 🔍 问题分析

### 1. 插件定义中的 DAG

**文件**: `app/plugins/excel_vba_to_wps_js/config.py`

```python
PLUGIN_DAG = {
    "nodes": [
        {
            "code": "upload_validate",
            "name": "Validate Upload",
            "action_type": "PYTHON"
        },
        {
            "code": "extract_vba_macros",
            "name": "Extract VBA Macros",
            "action_type": "PYTHON"
        },
        {
            "code": "analyze_macro_dependencies",
            "name": "Analyze Macro Dependencies",
            "action_type": "PYTHON"
        }
    ],
    "edges": [
        {"from": "upload_validate", "to": "extract_vba_macros"},
        {"from": "extract_vba_macros", "to": "analyze_macro_dependencies"}
    ]
}
```

**定义步骤**: 3 个节点

---

### 2. 任务详情 API 返回的 DAG

**文件**: `app/routes/routes_task.py`

```python
# 加载 DAG 节点和边
if task_run.task_template and task_run.task_template.plugin_code:
    try:
        plugin_code = task_run.task_template.plugin_code
        module = __import__(f'app.plugins.{plugin_code}.config', fromlist=['PLUGIN_DAG'])
        if hasattr(module, 'PLUGIN_DAG'):
            plugin_dag = module.PLUGIN_DAG
            dag_nodes = plugin_dag.get('nodes', [])
            dag_edges = plugin_dag.get('edges', [])
    except Exception as e:
        current_app.logger.warning(f'Failed to load DAG: {e}')
```

**问题**:
- ✅ 从插件配置加载 DAG 定义
- ❌ **没有加载实际执行状态**
- ❌ **节点状态都是 PENDING**

---

### 3. 前端显示的 DAG

**文件**: `app/static/js/app.js`

```javascript
// Show task detail
function showTaskDetail(taskId, taskData) {
    // 计算总步骤数和完成数
    const totalSteps = (taskData.dagNodes || taskData.jobs || []).length;
    const completedSteps = (taskData.dagNodes || taskData.jobs || [])
        .filter(n => n.status === 'SUCCESS').length;
    
    // 初始化 DAG 可视化
    initDagVisualization(taskId, taskData);
}
```

**问题**:
- ❌ `dagNodes` 没有 `status` 字段
- ❌ 无法计算完成数
- ❌ DAG 可视化显示为空

---

## 🔧 根本原因

### 原因 1: 节点状态未从执行记录加载

**当前代码**:
```python
dag_nodes = plugin_dag.get('nodes', [])
# ❌ 没有从 JobRun/NodeRun 加载实际状态
```

**期望行为**:
```python
dag_nodes = plugin_dag.get('nodes', [])
# ✅ 从 NodeRun 加载实际状态
for node in dag_nodes:
    node_run = NodeRun.query.filter_by(...).first()
    if node_run:
        node['status'] = node_run.status
```

---

### 原因 2: JobRun/NodeRun 未正确创建

**当前流程**:
```
创建 TaskRun
  ↓
启动任务
  ↓
❌ JobRun/NodeRun 未创建
  ↓
❌ 没有执行记录
```

**期望流程**:
```
创建 TaskRun
  ↓
启动任务
  ↓
✅ 创建 JobRun
  ↓
✅ 创建 NodeRun
  ↓
✅ 执行节点
```

---

## ✅ 解决方案

### 方案 1: 从 NodeRun 加载节点状态（推荐）

**修改文件**: `app/routes/routes_task.py`

```python
# 加载 DAG 节点和边
if task_run.task_template and task_run.task_template.plugin_code:
    try:
        plugin_code = task_run.task_template.plugin_code
        module = __import__(f'app.plugins.{plugin_code}.config', fromlist=['PLUGIN_DAG'])
        if hasattr(module, 'PLUGIN_DAG'):
            plugin_dag = module.PLUGIN_DAG
            dag_nodes = plugin_dag.get('nodes', [])
            dag_edges = plugin_dag.get('edges', [])
            
            # ✅ 从 NodeRun 加载实际状态
            from app.models import NodeRun
            for node in dag_nodes:
                node_run = NodeRun.query.filter_by(
                    node_code=node['code']
                ).first()
                if node_run:
                    node['status'] = node_run.status
                    node['output'] = node_run.output
                    node['error_message'] = node_run.error_message
                else:
                    node['status'] = 'PENDING'
    except Exception as e:
        current_app.logger.warning(f'Failed to load DAG: {e}')
```

---

### 方案 2: 从 JobRun 加载节点状态

```python
# 从 JobRun 加载节点
job_runs = task_run.job_runs
if job_runs:
    dag_nodes = []
    for job in job_runs:
        dag_nodes.append({
            'code': job.code,
            'name': job.name,
            'status': job.status,
            'output': job.output,
            'error_message': job.error_message
        })
```

---

### 方案 3: 创建任务时初始化 JobRun/NodeRun

**修改文件**: `app/repository/task_repository.py`

```python
def create_with_template(self, template_code, upload_file_id, runtime_params=None):
    # 创建 TaskRun
    task_run = TaskRun(
        task_template_id=template.id,
        upload_file_id=upload_file_id,
        status='CREATED',
        runtime_params_json=json.dumps(runtime_params or {})
    )
    db.session.add(task_run)
    db.session.commit()
    
    # ✅ 创建 JobRun
    from app.plugins.excel_vba_to_wps_js.config import PLUGIN_DAG
    plugin_dag = PLUGIN_DAG
    
    job_run = JobRun(
        task_run_id=task_run.id,
        code=plugin_dag['job']['code'],
        name=plugin_dag['job']['name'],
        status='CREATED'
    )
    db.session.add(job_run)
    db.session.commit()
    
    # ✅ 创建 NodeRun
    for node in plugin_dag['nodes']:
        node_run = NodeRun(
            job_id=job_run.id,
            node_code=node['code'],
            node_name=node['name'],
            node_type=node['action_type'],
            status='PENDING'
        )
        db.session.add(node_run)
    
    db.session.commit()
    
    return task_run
```

---

## 📊 修复效果对比

| 指标 | 修复前 | 修复后 | 提升 |
|------|--------|--------|------|
| DAG 节点数 | 3 | 3 | - |
| 节点状态 | PENDING | 实际状态 | ✅ |
| 完成数计算 | 0 | 实际完成数 | ✅ |
| DAG 可视化 | 空 | 显示节点和状态 | ✅ |

---

## 📝 修复步骤

### 步骤 1: 修改任务详情 API

```python
# app/routes/routes_task.py
# 在加载 DAG 节点后添加状态
for node in dag_nodes:
    node_run = NodeRun.query.filter_by(
        node_code=node['code'],
        task_run_id=task_run.id
    ).first()
    if node_run:
        node['status'] = node_run.status
        node['output'] = node_run.output
        node['error_message'] = node_run.error_message
    else:
        node['status'] = 'PENDING'
```

### 步骤 2: 创建任务时初始化 NodeRun

```python
# app/repository/task_repository.py
# 在 create_with_template 中创建 NodeRun
for node in plugin_dag['nodes']:
    node_run = NodeRun(
        job_id=job_run.id,
        node_code=node['code'],
        node_name=node['name'],
        node_type=node['action_type'],
        status='PENDING'
    )
    db.session.add(node_run)
```

### 步骤 3: 验证修复

```bash
# 1. 创建新任务
# 2. 打开任务详情
# 3. 验证 DAG 节点显示
# 4. 验证节点状态正确
```

---

## 🎯 建议优先级

### 高优先级
1. ✅ 修复任务详情 API 加载节点状态
2. ✅ 创建任务时初始化 NodeRun

### 中优先级
3. ⏳ 实现节点执行逻辑
4. ⏳ 更新节点状态

### 低优先级
5. ⏳ 添加节点执行日志
6. ⏳ 实现节点重试机制

---

## 📋 总结

**核心问题**:
- ❌ 节点状态未从执行记录加载
- ❌ NodeRun 未正确创建
- ❌ DAG 可视化无法显示状态

**解决方案**:
- ✅ 从 NodeRun 加载实际状态
- ✅ 创建任务时初始化 NodeRun
- ✅ 更新 DAG 可视化

**预期效果**:
- DAG 节点显示正确
- 节点状态实时更新
- 完成数计算准确

---

**报告生成时间**: 2026-03-14 09:46  
**修复人**: 小爪 🦞  
**状态**: ⏳ **待实施**
