﻿# -*- coding: utf-8 -*-

"""
Development Server Entry Point
"""
from app import create_app
from app.app_config import Settings

app = create_app(Settings)

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5001, debug=False)
